#!/usr/bin/env bash
set -euo pipefail

WORKSPACE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
OFFICE_CLI="$WORKSPACE/scripts/office.mjs"

if [[ "$#" -ne 0 ]]; then
  printf '%s\n' 'Usage: bash restart-office.sh' >&2
  exit 2
fi

node --input-type=module - "$WORKSPACE" <<'NODE'
import { readFile, realpath } from "node:fs/promises";
const root = await realpath(process.argv[2]);
const config = JSON.parse(await readFile(`${root}/workspace.json`, "utf8"));
if (config.workspaceRoot !== root || config.installed !== true) {
  process.stderr.write("workspace_root_mismatch\n");
  process.exit(1);
}
NODE

WAS_RUNNING=0
if node "$OFFICE_CLI" status --root "$WORKSPACE" >/dev/null 2>&1; then
  WAS_RUNNING=1
fi

START_RESULT="$(node "$OFFICE_CLI" start --root "$WORKSPACE")"
export OFFICE_RESTART_ROOT="$WORKSPACE"
export OFFICE_RESTART_WAS_RUNNING="$WAS_RUNNING"
export OFFICE_RESTART_RESULT="$START_RESULT"

node --input-type=module <<'NODE'
const root = process.env.OFFICE_RESTART_ROOT;
const runtime = JSON.parse(process.env.OFFICE_RESTART_RESULT ?? "{}");
if (runtime.workspaceRoot !== root || !runtime.pid || !runtime.bootId) {
  process.stderr.write("office_runtime_identity_mismatch\n");
  process.exit(1);
}
const origin = new URL(runtime.origin);
if (origin.protocol !== "http:" || origin.hostname !== "127.0.0.1") {
  process.stderr.write("office_origin_not_loopback\n");
  process.exit(1);
}
const pages = {};
for (const route of ["/healthz", "/chat.html", "/office.html"]) {
  const response = await fetch(new URL(route, origin), {
    redirect: "error",
    signal: AbortSignal.timeout(10000),
  });
  await response.body?.cancel();
  if (!response.ok) {
    process.stderr.write("office_http_verification_failed\n");
    process.exit(1);
  }
  pages[route] = response.status;
}
const startedAfterStop = process.env.OFFICE_RESTART_WAS_RUNNING !== "1";
process.stdout.write(JSON.stringify({
  ok: true,
  workspaceRoot: root,
  origin: origin.origin,
  pid: runtime.pid,
  bootId: runtime.bootId,
  activeRuns: runtime.activeRuns.length,
  pages,
  startedAfterStop,
  credentialsReminder: startedAfterStop
    ? "After a server/runtime restart, enter the API Key or complete account authorization in the browser."
    : null,
}, null, 2) + "\n");
NODE
