# 项目目录规范

适用于所有 Agent。公司记忆注入的精简版见 [公司规章](../company/rules.md#8-项目目录规范)。

## 目录结构

```
work/<两位编号>-<项目名>/                 # 编号在同一父目录内独立；中文可，禁空格与"/"，名称<15字
  README.md                              # 结构 + 内容 + 当前状态
  code/                                  # 代码；本项目唯一 git 仓库
    README.md  docs/                     # docs 放拼接后的《特性文档.md》
  test/                                  # 实验中间产物，不进 git
    README.md
    <两位编号>-<主特性>/README.md、实验进展.md
      <两位编号>-<实验名>/README.md        # 本次实验全部输出只放这里
  feature/
    README.md                            # 主特性清单；主特性完成后更新
    <两位编号>-<主特性>/README.md、设计文档.md、实现文档.md、测试文档.md、开发进展.md
      <两位编号>-<子特性>/README.md、设计文档.md、实现文档.md、测试文档.md
```

## 硬规则

- 特性最多两级：主特性 + 子特性；子特性是叶子，不再下分；**每一级目录都要有 README.md**。
- 子特性 README：①≤200 字简介 ②特性开关 ③文件汇总表（序号 | 文件名 | 功能介绍）。
- 主特性 README：①≤500 字简介 ②特性开关 ③各子特性简介（直接复制子特性的 200 字）。
- 主特性有子特性时，其三份文档只写整体方案、实现机制、各子特性最新测试结果，并链接到子特性文档。
- `开发进展.md`：总表 `序号|特性名称|简要描述|收益|状态`，状态只能是待开发/待验证/已采纳/已否决；每完成一个子特性更新一次，主特性完成后更新 `feature/README.md`。
- `test/` 只放实验中间产物；交付物（PPT/HTML/图片/报告）放对应特性目录；每个特性、每次实验都要有记录，禁止散落。

## 开关与提交

- 特性开关按需设置，提交前与用户确认。`README.md` 标注默认开启、默认关闭或无开关；设开关时使用环境变量（如 `OFFICE_FEATURE_<主特性>_<子特性>`），写明变量名和生效方式。
- Git 提交以一级（主）特性为最小单位。提交包含该特性及其二级特性的定稿代码和一份合并后的《特性文档》。提交前更新状态、执行结构检查。
- 用 `finalize-feature` 生成《特性文档》，分为「设计文档」「实现文档」「测试文档」三章。每章按二级特性编号分节，只收录各二级特性对应类型的文档；没有二级特性时，直接使用一级特性的对应文档。
- 定稿文件保留在一级特性目录，提交用副本为 `code/docs/<一级特性编号-名称>-特性文档.md`。
- commit message：`feat(<项目编号-项目名>): <主特性编号-名称>`。

## 阶段产出（skill 包）

Web Office 的应用和随附技能在源码仓库开发、验证和提交。验收只把已核验的提交同步到运行目录，不覆盖运行数据；如需重启，单独确认。

发布前对源码项目运行 `check --project <项目名>`；按已确认的源码提交更新独立的技能发布仓库，记录来源提交。打包发布仓库前也运行严格检查；未提交改动不能直接作为发布输入。生成并验证 ZIP 的操作见技能的 `references/workflows.md`。

## 自检与定稿

- 日常聊天结束运行 `check --development`：未提交或未跟踪的改动显示为「待提交」，不算自检失败；目录、必需文档或 Git 冲突等错误仍报错。
- 手动 `check` 默认严格。定稿后和发布前用 `check --project <项目名>` 验证，未提交或未跟踪的文件仍使检查失败。
- 定稿前确认特性开关及提交范围，仅暂存当前一级特性的文件。带 `--toggle-reviewed` 定稿时，未暂存或未跟踪的其他文件会阻止提交；脚本只额外暂存本特性的合并文档，不自动暂存整个仓库。

## 工具

```bash
node app/scripts/work-layout.mjs new-project --name "01-项目名"
node app/scripts/work-layout.mjs new-feature --project 01-项目名 --name "01-主特性"
node app/scripts/work-layout.mjs new-subfeature --project 01-项目名 --feature 01-主特性 --name "01-子特性"
node app/scripts/work-layout.mjs new-experiment --project 01-项目名 --feature 01-主特性 --name "01-实验"
node app/scripts/work-layout.mjs finalize-feature --project 01-项目名 --feature 01-主特性
node app/scripts/work-layout.mjs check --development
node app/scripts/work-layout.mjs check --project 01-项目名
```
