/**
 * Context-window accounting for automatic compaction.
 *
 * Both executors compact on their own once the conversation approaches the model's
 * context window; the office only has to tell them where "90% of the window" is.
 * The usage numbers they report are folded back into the conversation record so the
 * UI can show how full the window currently is.
 */

export const AUTOCOMPACT_PERCENT = 90;
export const DEFAULT_CONTEXT_WINDOW = 200_000;

/** Explicit, per-model context windows. Longest match wins; unknown models fall back to the default. */
const CONTEXT_WINDOWS: Array<[RegExp, number]> = [
  // Relay models carry the long-context marker in their own name (e.g. `deepseek-flash[1m]`).
  [/\[1m\]/i, 1_000_000],
  // Codex catalog: gpt-6.x defaults to 272000 with 872000 available as the maximum tier.
  [/^gpt-6(\.\d+)?(-|$)/i, 272_000],
  [/^gpt-5(\.\d+)?-codex-max/i, 1_000_000],
  [/^(gpt-5|codex)/i, 400_000],
  [/claude/i, 200_000],
  [/^o[134]/i, 200_000],
];

export interface AutoCompactSettings {
  enabled: boolean;
  /** Percentage of the context window at which compaction is triggered. */
  percent: number;
}

/** `OFFICE_FEATURE_CONTEXT_AUTOCOMPACT` (default on) and `..._PCT` (default 90, clamped to 50–99). */
export function autoCompactSettings(env: NodeJS.ProcessEnv = process.env): AutoCompactSettings {
  const enabled = !["0", "false", "off", "no"].includes(
    String(env.OFFICE_FEATURE_CONTEXT_AUTOCOMPACT ?? "1").toLowerCase(),
  );
  const raw = Number(env.OFFICE_FEATURE_CONTEXT_AUTOCOMPACT_PCT ?? AUTOCOMPACT_PERCENT);
  const percent = Number.isFinite(raw) ? Math.min(99, Math.max(50, Math.round(raw))) : AUTOCOMPACT_PERCENT;
  return { enabled, percent };
}

/** Context window for a model, in tokens. An explicit per-agent override wins over everything. */
export function contextWindowFor(
  model: string | null | undefined,
  reported?: number | null,
  override?: number | null,
): number {
  if (typeof override === "number" && Number.isFinite(override) && override > 0) return Math.round(override);
  if (typeof reported === "number" && Number.isFinite(reported) && reported > 0) return Math.round(reported);
  const fromEnv = Number(process.env.OFFICE_CONTEXT_WINDOW ?? 0);
  if (Number.isFinite(fromEnv) && fromEnv > 0) return Math.round(fromEnv);
  const name = model ?? "";
  for (const [pattern, tokens] of CONTEXT_WINDOWS) if (pattern.test(name)) return tokens;
  return DEFAULT_CONTEXT_WINDOW;
}

export interface ContextUsage {
  /** Tokens currently occupied by the conversation (prompt side of the last request). */
  used: number;
  /** Context window of the selected model. */
  window: number;
  /** Whole percent of the window that is in use. */
  percent: number;
  /** Compaction threshold percentage that applies to this conversation. */
  threshold: number;
}

/** Build a usage record, or null when the executor reported nothing usable. */
export function contextUsage(used: number, window: number, threshold = AUTOCOMPACT_PERCENT): ContextUsage | null {
  if (!Number.isFinite(used) || used <= 0) return null;
  const safeWindow = Number.isFinite(window) && window > 0 ? Math.round(window) : DEFAULT_CONTEXT_WINDOW;
  return {
    used: Math.round(used),
    window: safeWindow,
    percent: Math.min(100, Math.round((used / safeWindow) * 100)),
    threshold,
  };
}

/** Compact token counts for messages: 1_234 → "1.2k", 200_000 → "200k". */
export function formatTokens(tokens: number): string {
  if (tokens >= 1_000_000) return (tokens / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (tokens >= 10_000) return Math.round(tokens / 1000) + "k";
  if (tokens >= 1000) return (tokens / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return String(Math.max(0, Math.round(tokens)));
}

/** True once the window is full enough for the executor to compact. */
export function shouldCompact(usage: ContextUsage | null | undefined): boolean {
  return Boolean(usage && usage.used >= (usage.window * usage.threshold) / 100);
}

/**
 * Whether the next run must start on a fresh native thread. Executors that ignore the
 * threshold (codex exec compacts only near 95–97%) would otherwise keep growing the thread.
 */
export function needsRollover(
  usage: { used: number; window: number; threshold: number } | null | undefined,
  settings: AutoCompactSettings = autoCompactSettings(),
): boolean {
  if (!settings.enabled || !usage) return false;
  if (!Number.isFinite(usage.used) || usage.used <= 0) return false;
  const window = Number.isFinite(usage.window) && usage.window > 0 ? usage.window : DEFAULT_CONTEXT_WINDOW;
  // A request cannot be larger than the window; such a record predates the fixed accounting
  // (thread-cumulative totals). Ignore it and let the next run record a real measurement.
  if (usage.used > window * 2) return false;
  return usage.used >= (window * settings.percent) / 100;
}

/**
 * Codex config overrides. Older codex builds ignore unknown keys, so this is safe to send
 * unconditionally; new builds validate the percentage and compact after the turn that
 * crosses it.
 */
export function codexAutoCompactConfig(settings: AutoCompactSettings = autoCompactSettings()): Record<string, number> {
  return settings.enabled ? { model_post_turn_compact_threshold_percent: settings.percent } : {};
}

/** Claude Code lowers its own compaction threshold to this percentage of the window. */
export function claudeAutoCompactEnv(settings: AutoCompactSettings = autoCompactSettings()): Record<string, string> {
  return settings.enabled ? { CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: String(settings.percent) } : {};
}

type Json = Record<string, unknown>;
const record = (value: unknown): Json =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as Json) : {};
const count = (value: unknown): number => (typeof value === "number" && Number.isFinite(value) ? value : 0);

/** Prompt-side token count of the last request: fresh input + cache reads + cache writes. */
export function claudeUsageTokens(usage: unknown): number {
  const value = record(usage);
  return count(value.input_tokens) + count(value.cache_read_input_tokens) + count(value.cache_creation_input_tokens);
}

/**
 * Codex follows OpenAI counter semantics: `input_tokens` already includes the cached prefix,
 * so cached tokens must not be added again. This value is only meaningful for a single turn;
 * `turn.completed` in `codex exec` reports the whole thread, which is why the rollout is used.
 */
export function codexUsageTokens(usage: unknown): number {
  const value = record(usage);
  return count(value.input_tokens);
}

export interface ExecutorContextReport {
  /** Prompt-side tokens of the most recent request. */
  used: number;
  /** Context window reported by the executor, when it knows it. */
  window: number | null;
}

/**
 * Codex records a `token_count` event per request in its thread rollout. The last one is the
 * only trustworthy occupancy number: `turn.completed` on the JSON stream carries thread totals.
 */
export function parseCodexRolloutTail(text: string): ExecutorContextReport | null {
  let report: ExecutorContextReport | null = null;
  for (const line of text.split("\n")) {
    if (!line.includes('"token_count"')) continue;
    let event: unknown;
    try {
      event = JSON.parse(line);
    } catch {
      continue;
    }
    const info = record(record(event).payload).info ?? record(event).info;
    const value = record(info);
    const used = codexUsageTokens(value.last_token_usage);
    if (used <= 0) continue;
    const window = count(value.model_context_window);
    report = { used, window: window > 0 ? window : null };
  }
  return report;
}

/** Read the tail of the newest codex rollout and report the last request's context size. */
export async function readCodexRolloutUsage(
  codexHome: string,
  options: { maxBytes?: number; since?: number } = {},
): Promise<ExecutorContextReport | null> {
  const { open, readdir, stat } = await import("node:fs/promises");
  const path = await import("node:path");
  const root = path.join(codexHome, "sessions");
  const newest = async (dir: string, depth: number): Promise<string | null> => {
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return null;
    }
    let best: { file: string; mtime: number } | null = null;
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (depth <= 0) continue;
        const nested = await newest(full, depth - 1);
        if (nested) {
          const info = await stat(nested).catch(() => null);
          if (info && (!best || info.mtimeMs > best.mtime)) best = { file: nested, mtime: info.mtimeMs };
        }
        continue;
      }
      if (!entry.isFile() || !entry.name.endsWith(".jsonl")) continue;
      const info = await stat(full).catch(() => null);
      if (!info) continue;
      if (best && info.mtimeMs <= best.mtime) continue;
      best = { file: full, mtime: info.mtimeMs };
    }
    return best?.file ?? null;
  };
  const file = await newest(root, 3);
  if (!file) return null;
  const info = await stat(file).catch(() => null);
  if (!info) return null;
  // A rollout that predates this run cannot describe the context this run is using.
  if (options.since && info.mtimeMs < options.since - 1000) return null;
  const maxBytes = Math.max(64 * 1024, Math.min(options.maxBytes ?? 512 * 1024, 8 * 1024 * 1024));
  const length = Math.min(info.size, maxBytes);
  const handle = await open(file, "r");
  try {
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, Math.max(0, info.size - length));
    const text = buffer.toString("utf8");
    // The first line may be cut in half; it is skipped harmlessly by the JSON guard.
    return parseCodexRolloutTail(info.size > length ? text.slice(text.indexOf("\n") + 1) : text);
  } finally {
    await handle.close();
  }
}

/** A `token_count` event (when the executor emits one) carries the authoritative window size. */

export function codexReportedWindow(event: unknown): number | null {
  const info = record(record(event).info);
  const direct = count(info.model_context_window);
  if (direct > 0) return direct;
  const lastUsage = record(info.last_token_usage);
  const totalUsage = record(info.total_token_usage);
  const window = count(record(lastUsage).model_context_window) || count(record(totalUsage).model_context_window);
  return window > 0 ? window : null;
}

/**
 * Parse the last per-request usage out of a Claude Code session transcript.
 *
 * Each recorded assistant message carries the usage of the request that produced it, so the
 * last one is the occupancy of this thread. `result.usage` on the stream is a whole-invocation
 * aggregate and must never be used for this.
 */
export function parseClaudeTranscriptTail(text: string): ExecutorContextReport | null {
  let report: ExecutorContextReport | null = null;
  for (const line of text.split("\n")) {
    if (!line.includes('"usage"')) continue;
    let entry: unknown;
    try {
      entry = JSON.parse(line);
    } catch {
      continue;
    }
    const message = record(record(entry).message);
    const used = claudeUsageTokens(message.usage);
    if (used <= 0) continue;
    report = { used, window: null };
  }
  return report;
}

/**
 * Read the newest usage of one Claude Code session file. `sessionId` is the native thread id;
 * the transcript lives at `<claudeHome>/projects/<slug>/<sessionId>.jsonl`.
 */
export async function readClaudeSessionUsage(
  claudeHome: string,
  sessionId: string,
  options: { maxBytes?: number } = {},
): Promise<ExecutorContextReport | null> {
  if (!/^[A-Za-z0-9._-]{8,128}$/.test(sessionId)) return null;
  const { open, readdir, stat } = await import("node:fs/promises");
  const path = await import("node:path");
  const projects = path.join(claudeHome, "projects");
  const find = async (dir: string, depth: number): Promise<string | null> => {
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return null;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory() && depth > 0) {
        const nested = await find(full, depth - 1);
        if (nested) return nested;
      } else if (entry.isFile() && entry.name === `${sessionId}.jsonl`) return full;
    }
    return null;
  };
  const file = await find(projects, 2);
  if (!file) return null;
  const info = await stat(file).catch(() => null);
  if (!info) return null;
  const maxBytes = Math.max(64 * 1024, Math.min(options.maxBytes ?? 512 * 1024, 8 * 1024 * 1024));
  const length = Math.min(info.size, maxBytes);
  const handle = await open(file, "r");
  try {
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, Math.max(0, info.size - length));
    const text = buffer.toString("utf8");
    return parseClaudeTranscriptTail(info.size > length ? text.slice(text.indexOf("\n") + 1) : text);
  } finally {
    await handle.close();
  }
}

/**
 * A measured occupancy larger than the estimated window means the estimate is too small (relay
 * models such as `deepseek-flash` run a 1M window while the name table says 200k). The request
 * itself proves the window is at least this big, so widen it instead of discarding the number —
 * discarding is what previously hid a full window and let a session overflow.
 */
export function reconcileWindow(used: number, window: number): number {
  if (!Number.isFinite(used) || used <= 0) return window;
  if (!Number.isFinite(window) || window <= 0) return Math.round(used);
  return used > window ? Math.round(used) : Math.round(window);
}

/**
 * Occupancy used for the rollover decision. The recorded value wins; when a conversation has
 * never recorded one (its runs failed before reporting, or predate the accounting) the executor's
 * own transcript is measured instead — otherwise a thread that is already over the window can
 * never reach the threshold and every later request keeps failing.
 */
export function contextForRollover(
  stored: ContextUsage | null,
  measured: ExecutorContextReport | null,
  window: number,
  threshold = AUTOCOMPACT_PERCENT,
): ContextUsage | null {
  if (stored) return stored;
  if (!measured || !Number.isFinite(measured.used) || measured.used <= 0) return null;
  const reported = measured.window && measured.window > 0 ? measured.window : window;
  return contextUsage(measured.used, reconcileWindow(measured.used, reported), threshold);
}

/**
 * Largest window each model family supports. The agent picks a share of this number
 * (25/50/75/100%), which is then passed to the executor as its context window.
 */
const MAX_CONTEXT_WINDOWS: Array<[RegExp, number]> = [
  [/\[1m\]/i, 1_000_000],
  [/^gpt-6(\.\d+)?(-|$)/i, 872_000],
  [/^gpt-5(\.\d+)?-codex-max/i, 1_000_000],
  [/^(gpt-5|codex)/i, 400_000],
  [/claude/i, 200_000],
  [/^o[134]/i, 200_000],
];

/** Window presets offered in the agent editor. */
export const CONTEXT_WINDOW_SHARES = [25, 50, 75, 100] as const;

/** Largest context window a model supports, in tokens. */
export function maxContextWindowFor(model: string | null | undefined, reported?: number | null): number {
  if (typeof reported === "number" && Number.isFinite(reported) && reported > 0) return Math.round(reported);
  const name = model ?? "";
  for (const [pattern, tokens] of MAX_CONTEXT_WINDOWS) if (pattern.test(name)) return tokens;
  return DEFAULT_CONTEXT_WINDOW;
}

/** Concrete window for a preset share, rounded to whole thousands like the UI label. */
export function contextWindowForShare(maximum: number, share: number): number {
  const base = Number.isFinite(maximum) && maximum > 0 ? maximum : DEFAULT_CONTEXT_WINDOW;
  const ratio = Number.isFinite(share) ? Math.min(100, Math.max(1, share)) : 100;
  return Math.round((base * ratio) / 100 / 1000) * 1000;
}

/** Validate an agent-selected window: an integer inside the model's maximum, or null. */
export function normalizeContextWindow(value: unknown, maximum: number): number | null {
  if (value === null || value === undefined) return null;
  const tokens = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(tokens) || !Number.isSafeInteger(Math.round(tokens))) throw new Error("invalid_context_window");
  const rounded = Math.round(tokens);
  if (rounded <= 0) return null;
  // A window bigger than the model supports would let a session grow past its real ceiling.
  if (rounded > Math.round(maximum)) throw new Error("context_window_too_large");
  if (rounded < 8_000) throw new Error("context_window_too_small");
  return rounded;
}
