import path from "node:path";
import { constants, type Stats } from "node:fs";
import { open, mkdir, lstat, realpath, unlink, type FileHandle } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import sharp from "sharp";
import type { OfficeAttachment } from "../../shared/office-contracts.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";
import { OfficeError } from "./errors.ts";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_ENCODED_LENGTH = Math.ceil(MAX_IMAGE_BYTES / 3) * 4;
const MAX_PIXELS = 40_000_000;
const MAX_METADATA_BYTES = 4096;
const MAX_ATTACHMENTS = 4;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const AGENT_ID = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/;
const MIME_INFO = {
  "image/png": { extension: "png", format: "png" },
  "image/jpeg": { extension: "jpg", format: "jpeg" },
  "image/webp": { extension: "webp", format: "webp" },
} as const;
type ImageMime = OfficeAttachment["mimeType"];
interface AttachmentMetadata {
  id: string;
  agentId: string;
  name: string;
  mimeType: ImageMime;
  size: number;
}
interface AttachmentDirectory {
  handle: FileHandle;
  absolutePath: string;
}

function isMime(value: unknown): value is ImageMime {
  return typeof value === "string" && Object.hasOwn(MIME_INFO, value);
}
function requireAgentId(agentId: string): void {
  if (typeof agentId !== "string" || !AGENT_ID.test(agentId)) throw new OfficeError("invalid_agent_id");
}
function requireId(id: unknown): asserts id is string {
  if (typeof id !== "string" || !UUID.test(id)) throw new OfficeError("invalid_attachment_id");
}
function invalidStorage(): never {
  throw new OfficeError("attachment_storage_path_invalid", 403);
}
function storageError(error: unknown): OfficeError {
  if (error instanceof OfficeError) return error;
  const code = (error as NodeJS.ErrnoException)?.code;
  if (code === "ENOENT") return new OfficeError("attachment_not_found", 404);
  if (["ELOOP", "EMLINK", "ENOTDIR"].includes(code ?? ""))
    return new OfficeError("attachment_storage_path_invalid", 403);
  if (code === "EACCES" || code === "EPERM") return new OfficeError("attachment_storage_denied", 403);
  return new OfficeError("attachment_storage_failed", 500);
}
function directoryAnchor(handle: FileHandle): string {
  // Directory descriptors pin each parent. User-controlled intermediate symlinks
  // are never traversed by a subsequent file operation.
  return `${process.platform === "linux" ? "/proc/self/fd" : "/dev/fd"}/${handle.fd}`;
}
function fileName(id: string, mimeType: ImageMime): string {
  return `${id}.${MIME_INFO[mimeType].extension}`;
}
function cleanName(input: string, mimeType: ImageMime): string {
  const leaf = input.normalize("NFC").split(/[\\/]/).pop() ?? "";
  const cleaned = Array.from(leaf.replace(/[\p{Cc}\p{Cf}\u2028\u2029]/gu, "").trim())
    .slice(0, 160)
    .join("");
  return cleaned && cleaned !== "." && cleaned !== ".." ? cleaned : `image.${MIME_INFO[mimeType].extension}`;
}
function decodeBase64(value: unknown): Buffer {
  if (typeof value !== "string" || !value || value.length % 4 !== 0) throw new OfficeError("invalid_attachment_base64");
  if (value.length > MAX_ENCODED_LENGTH) throw new OfficeError("attachment_too_large", 413);
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(value)) throw new OfficeError("invalid_attachment_base64");
  const buffer = Buffer.from(value, "base64");
  if (buffer.length > MAX_IMAGE_BYTES) throw new OfficeError("attachment_too_large", 413);
  // Buffer's decoder accepts missing padding and noncanonical padding bits;
  // requiring an exact round trip rejects those forms as well as empty input.
  if (!buffer.length || buffer.toString("base64") !== value) throw new OfficeError("invalid_attachment_base64");
  return buffer;
}
function magicMime(buffer: Buffer): ImageMime {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])))
    return "image/png";
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return "image/jpeg";
  if (
    buffer.length >= 12 &&
    buffer.toString("ascii", 0, 4) === "RIFF" &&
    buffer.toString("ascii", 8, 12) === "WEBP" &&
    buffer.readUInt32LE(4) + 8 === buffer.length
  )
    return "image/webp";
  throw new OfficeError("unsupported_attachment_type", 415);
}
async function validateImage(buffer: Buffer, expectedMime?: ImageMime): Promise<ImageMime> {
  const mimeType = magicMime(buffer);
  if (expectedMime !== undefined && expectedMime !== mimeType) throw new OfficeError("attachment_mime_mismatch");
  try {
    // Input is always a magic-checked in-memory raster, never a path or SVG.
    const decoder = sharp(buffer, { limitInputPixels: MAX_PIXELS, failOn: "warning", sequentialRead: true });
    const metadata = await decoder.metadata();
    if (
      metadata.format !== MIME_INFO[mimeType].format ||
      !metadata.width ||
      !metadata.height ||
      metadata.width * metadata.height > MAX_PIXELS ||
      (metadata.pages ?? 1) !== 1
    )
      throw new OfficeError("invalid_attachment_image");
    // metadata() alone cannot detect truncated/invalid pixel data. stats()
    // forces full decoding without retaining a 40MP raw output buffer.
    await decoder.timeout({ seconds: 5 }).stats();
    return mimeType;
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    throw new OfficeError("invalid_attachment_image");
  }
}
function requireRegular(info: Stats, maxBytes: number): void {
  if (!info.isFile() || info.nlink !== 1 || (info.mode & 0o7777) !== 0o600) invalidStorage();
  if (!Number.isSafeInteger(info.size) || info.size <= 0 || info.size > maxBytes)
    throw new OfficeError("invalid_attachment_file");
}
async function checkUnchanged(handle: FileHandle, before: Stats, maxBytes: number): Promise<void> {
  const after = await handle.stat();
  requireRegular(after, maxBytes);
  if (
    after.dev !== before.dev ||
    after.ino !== before.ino ||
    after.size !== before.size ||
    after.mtimeMs !== before.mtimeMs ||
    after.ctimeMs !== before.ctimeMs
  )
    throw new OfficeError("attachment_changed", 409);
}
async function readBounded(handle: FileHandle, limit: number): Promise<{ bytes: Buffer; info: Stats }> {
  const info = await handle.stat();
  requireRegular(info, limit);
  const bytes = Buffer.alloc(info.size);
  let offset = 0;
  while (offset < bytes.length) {
    const result = await handle.read(bytes, offset, bytes.length - offset, offset);
    if (!result.bytesRead) throw new OfficeError("attachment_changed", 409);
    offset += result.bytesRead;
  }
  await checkUnchanged(handle, info, limit);
  return { bytes, info };
}

/** Agent-local raster attachments; image contents never become database fields. */
export class AttachmentStore {
  #paths: WorkspacePaths;
  #redact: (value: string) => string;
  constructor(
    paths: WorkspacePaths,
    redact: (value: string) => string,
    private layoutVersion: 1 | 2 = 1,
  ) {
    this.#paths = paths;
    this.#redact = redact;
  }
  #name(input: string, mimeType: ImageMime): string {
    return cleanName(this.#redact(input), mimeType);
  }
  async #withDirectory<T>(
    agentId: string,
    create: boolean,
    operation: (directory: AttachmentDirectory) => Promise<T>,
  ): Promise<T> {
    requireAgentId(agentId);
    if (!["linux", "darwin"].includes(process.platform) || !constants.O_NOFOLLOW || !constants.O_DIRECTORY)
      throw new OfficeError("attachment_storage_unsupported", 503);
    const root = path.resolve(this.#paths.root);
    if (root !== this.#paths.root || this.#paths.agents !== path.join(root, "agents")) invalidStorage();
    const handles: Array<{ handle: FileHandle; absolutePath: string }> = [];
    try {
      if ((await realpath(root)) !== root || (await lstat(root)).isSymbolicLink()) invalidStorage();
      const rootHandle = await open(root, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
      handles.push({ handle: rootHandle, absolutePath: root });
      let current = handles[0];
      const components =
        this.layoutVersion === 2 ? ["agents", agentId, "profile", "attachments"] : ["agents", agentId, "attachments"];
      for (const component of components) {
        if ((await realpath(directoryAnchor(current.handle))) !== current.absolutePath) invalidStorage();
        const entry = path.join(directoryAnchor(current.handle), component);
        if (create) {
          try {
            await mkdir(entry, { mode: 0o700 });
          } catch (error) {
            if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
          }
        }
        const handle = await open(entry, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
        current = { handle, absolutePath: path.join(current.absolutePath, component) };
        handles.push(current);
        if (create) await handle.chmod(0o700);
      }
      const assertDirectories = async () => {
        for (const directory of handles) {
          const [actual, entry] = await Promise.all([directory.handle.stat(), lstat(directory.absolutePath)]);
          if (
            !actual.isDirectory() ||
            !entry.isDirectory() ||
            entry.isSymbolicLink() ||
            actual.nlink < 1 ||
            actual.dev !== entry.dev ||
            actual.ino !== entry.ino ||
            (directory.absolutePath !== root && (actual.mode & 0o7777) !== 0o700) ||
            (await realpath(directory.absolutePath)) !== directory.absolutePath ||
            (await realpath(directoryAnchor(directory.handle))) !== directory.absolutePath
          )
            invalidStorage();
        }
      };
      await assertDirectories();
      const result = await operation(current);
      await assertDirectories();
      return result;
    } catch (error) {
      throw storageError(error);
    } finally {
      await Promise.all(handles.reverse().map(({ handle }) => handle.close().catch(() => {})));
    }
  }
  async #openFile(directory: AttachmentDirectory, name: string): Promise<FileHandle> {
    return open(
      path.join(directoryAnchor(directory.handle), name),
      constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
    );
  }
  async #load(
    directory: AttachmentDirectory,
    agentId: string,
    id: string,
  ): Promise<{ handle: FileHandle; attachment: OfficeAttachment }> {
    const metadataHandle = await this.#openFile(directory, `${id}.json`);
    let metadata: AttachmentMetadata;
    try {
      const { bytes } = await readBounded(metadataHandle, MAX_METADATA_BYTES);
      let parsed: unknown;
      try {
        parsed = JSON.parse(bytes.toString("utf8"));
      } catch {
        throw new OfficeError("invalid_attachment_metadata");
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
        throw new OfficeError("invalid_attachment_metadata");
      const candidate = parsed as Record<string, unknown>;
      if (
        Object.keys(candidate).sort().join(",") !== "agentId,id,mimeType,name,size" ||
        candidate.id !== id ||
        candidate.agentId !== agentId ||
        !isMime(candidate.mimeType) ||
        typeof candidate.name !== "string" ||
        candidate.name.length > 640 ||
        candidate.name !== cleanName(candidate.name, candidate.mimeType) ||
        typeof candidate.size !== "number" ||
        !Number.isSafeInteger(candidate.size) ||
        candidate.size <= 0 ||
        candidate.size > MAX_IMAGE_BYTES
      )
        throw new OfficeError("invalid_attachment_metadata");
      metadata = candidate as unknown as AttachmentMetadata;
    } finally {
      await metadataHandle.close();
    }
    const handle = await this.#openFile(directory, fileName(id, metadata.mimeType));
    try {
      const { bytes, info } = await readBounded(handle, MAX_IMAGE_BYTES);
      if (info.size !== metadata.size) throw new OfficeError("invalid_attachment_metadata");
      await validateImage(bytes, metadata.mimeType);
      await checkUnchanged(handle, info, MAX_IMAGE_BYTES);
      return { handle, attachment: this.#attachment(metadata) };
    } catch (error) {
      await handle.close();
      throw error;
    }
  }
  #attachment(metadata: AttachmentMetadata): OfficeAttachment {
    return {
      id: metadata.id,
      name: this.#name(metadata.name, metadata.mimeType),
      mimeType: metadata.mimeType,
      size: metadata.size,
      url: `/api/office/agents/${metadata.agentId}/attachments/${metadata.id}`,
    };
  }
  async upload(
    agentId: string,
    body: { name?: unknown; mimeType?: unknown; dataBase64?: unknown },
  ): Promise<OfficeAttachment> {
    requireAgentId(agentId);
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new OfficeError("invalid_attachment");
    if (body.name !== undefined && (typeof body.name !== "string" || body.name.length > 4096))
      throw new OfficeError("invalid_attachment_name");
    if (body.mimeType !== undefined && !isMime(body.mimeType))
      throw new OfficeError("unsupported_attachment_type", 415);
    const bytes = decodeBase64(body.dataBase64);
    const mimeType = await validateImage(bytes, body.mimeType as ImageMime | undefined);
    const metadata: AttachmentMetadata = {
      id: randomUUID(),
      agentId,
      name: this.#name(typeof body.name === "string" ? body.name : "", mimeType),
      mimeType,
      size: bytes.length,
    };
    return this.#withDirectory(agentId, true, async (directory) => {
      const imagePath = path.join(directoryAnchor(directory.handle), fileName(metadata.id, mimeType));
      const metadataPath = path.join(directoryAnchor(directory.handle), `${metadata.id}.json`);
      const created: string[] = [];
      try {
        for (const [destination, content] of [
          [imagePath, bytes],
          [metadataPath, Buffer.from(JSON.stringify(metadata))],
        ] as const) {
          const handle = await open(
            destination,
            constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
            0o600,
          );
          created.push(destination);
          try {
            await handle.chmod(0o600);
            const before = await handle.stat();
            if (!before.isFile() || before.nlink !== 1) invalidStorage();
            await handle.writeFile(content);
            await handle.sync();
            const written = await handle.stat();
            requireRegular(written, destination === imagePath ? MAX_IMAGE_BYTES : MAX_METADATA_BYTES);
            if (written.size !== content.length) throw new OfficeError("attachment_changed", 409);
          } finally {
            await handle.close();
          }
        }
        return this.#attachment(metadata);
      } catch (error) {
        await Promise.all(created.map((destination) => unlink(destination).catch(() => {})));
        throw error;
      }
    });
  }
  async resolve(agentId: string, ids: unknown): Promise<{ attachments: OfficeAttachment[]; paths: string[] }> {
    requireAgentId(agentId);
    if (ids === undefined || ids === null) return { attachments: [], paths: [] };
    if (!Array.isArray(ids)) throw new OfficeError("invalid_attachment_ids");
    if (ids.length > MAX_ATTACHMENTS) throw new OfficeError("too_many_attachments");
    for (const id of ids) requireId(id);
    if (new Set(ids).size !== ids.length) throw new OfficeError("duplicate_attachment_ids");
    if (!ids.length) return { attachments: [], paths: [] };
    return this.#withDirectory(agentId, false, async (directory) => {
      const attachments: OfficeAttachment[] = [];
      const paths: string[] = [];
      for (const id of ids) {
        const { handle, attachment } = await this.#load(directory, agentId, id);
        try {
          attachments.push(attachment);
          paths.push(path.join(directory.absolutePath, fileName(id, attachment.mimeType)));
        } finally {
          await handle.close();
        }
      }
      return { attachments, paths };
    });
  }
  async open(agentId: string, id: string): Promise<{ handle: FileHandle; attachment: OfficeAttachment }> {
    requireAgentId(agentId);
    requireId(id);
    let loaded: { handle: FileHandle; attachment: OfficeAttachment } | undefined;
    try {
      return await this.#withDirectory(agentId, false, async (directory) => {
        loaded = await this.#load(directory, agentId, id);
        return loaded;
      });
    } catch (error) {
      await loaded?.handle.close().catch(() => {});
      throw error;
    }
  }
}
