import type { IncomingMessage } from "node:http";
import { opendir, realpath } from "node:fs/promises";
import path from "node:path";
import type { LocalDirectory, LocalFileEntry } from "../../shared/office-contracts.ts";
import { OfficeError } from "./errors.ts";
import { localPreviewType } from "./local-file-preview.ts";

const ENTRY_LIMIT = 5000;

export function isLocalFileBrowserRequest(req: IncomingMessage, runtimeOrigin: string): boolean {
  if (
    req.socket.localAddress !== "127.0.0.1" ||
    req.socket.remoteAddress !== "127.0.0.1" ||
    req.headers.forwarded ||
    Object.keys(req.headers).some((name) => name.startsWith("x-forwarded-")) ||
    (req.headers["sec-fetch-site"] && req.headers["sec-fetch-site"] !== "same-origin")
  ) return false;
  const localHosts = [new URL(runtimeOrigin).host, new URL(runtimeOrigin.replace("127.0.0.1", "localhost")).host];
  return localHosts.some((host) => req.headers.host === host && req.headers.origin === `http://${host}`);
}

export function resolveLocalDirectoryPath(root: string, input: unknown, paths = path): string {
  if (typeof input !== "string" || input.length > 4096 || input.includes("\0"))
    throw new OfficeError("local_directory_invalid");
  if (paths.sep === "\\") {
    const driveAbsolute = /^[a-z]:[\\/]/i.test(input);
    const invalidWindowsPath = (value: string) =>
      /[<>|?*":]/.test(value) ||
      value.split(/[\\/]/).some((part) => /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\s*\.|$)/i.test(part.trimEnd()));
    if ((!driveAbsolute && /^[\\/]/.test(input)) || invalidWindowsPath(driveAbsolute ? input.slice(2) : input))
      throw new OfficeError("local_directory_invalid");
  } else if (input.startsWith("//")) {
    throw new OfficeError("local_directory_invalid");
  }
  return paths.resolve(root, input);
}

export async function browseLocalDirectory(root: string, input: unknown): Promise<LocalDirectory> {
  const requested = resolveLocalDirectoryPath(root, input);
  const relativePath = (target: string) => {
    const relative = path.relative(root, target);
    return path.isAbsolute(relative) ? null : relative || ".";
  };
  try {
    const canonical = await realpath(requested);
    const directoryPath = process.platform === "win32" ? resolveLocalDirectoryPath(root, canonical) : canonical;
    const entries: LocalFileEntry[] = [];
    const directory = await opendir(directoryPath);
    let truncated = false;
    for await (const item of directory) {
      if (entries.length === ENTRY_LIMIT) {
        truncated = true;
        break;
      }
      const itemPath = path.join(directoryPath, item.name);
      entries.push({
        name: item.name,
        path: itemPath,
        relativePath: relativePath(itemPath),
        kind: item.isDirectory() ? "directory" : item.isSymbolicLink() ? "link" : "file",
        preview: item.isFile() ? localPreviewType(item.name)?.kind : undefined,
      });
    }
    entries.sort((left, right) =>
      Number(right.kind === "directory") - Number(left.kind === "directory") ||
      left.name.localeCompare(right.name, undefined, { numeric: true }),
    );
    const parent = path.dirname(directoryPath);
    return { path: directoryPath, relativePath: relativePath(directoryPath), parent: parent === directoryPath ? null : parent, entries, truncated };
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    switch ((error as NodeJS.ErrnoException).code) {
      case "ENOENT":
        throw new OfficeError("local_directory_missing", 404);
      case "ENOTDIR":
        throw new OfficeError("local_directory_not_folder");
      case "EACCES":
      case "EPERM":
        throw new OfficeError("local_directory_denied", 403);
      default:
        throw new OfficeError("local_directory_unavailable", 500);
    }
  }
}
