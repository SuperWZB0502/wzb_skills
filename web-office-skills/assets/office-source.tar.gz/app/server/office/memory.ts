import path from "node:path";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import type { AgentProfile } from "../../shared/office-contracts.ts";
import { agentLayout, type LayoutVersion } from "./agent-layout.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";

/** Cap injected into each prompt: rules + notes must stay a summary, not a log. */
export const MEMORY_LIMIT = 6000;
const RULES_BLOCK = /<!-- RULES:BEGIN[^>]*-->[\s\S]*?<!-- RULES:END -->/;
const LEGACY_LAYOUT_BLOCK = /(?:\r?\n){0,2}^<!-- LAYOUT:BEGIN[^>\r\n]*-->\r?\n[\s\S]*?^<!-- LAYOUT:END -->(?=\r?$)/gm;
const SECRET = /(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY)/;

const ROLE_LABELS: Record<string, string> = {
  boss: "老板",
  se: "系统工程师",
  pl: "项目负责人",
  developer: "开发工程师",
  tester: "测试工程师",
};

export interface MemoryState {
  path: string;
  text: string;
  truncated: boolean;
  blocked: boolean;
  created: boolean;
  synced: boolean;
}

export async function readCompanyFile(root: string, relative: string): Promise<{ text: string; hash: string }> {
  const text = await readFile(path.join(root, relative), "utf8").catch(() => "");
  return { text: text.trim(), hash: createHash("sha256").update(text).digest("hex") };
}

export const readCompanyRules = (root: string) => readCompanyFile(root, "company/rules.md");

function memoryTemplate(profile: AgentProfile, layout: ReturnType<typeof agentLayout>, root: string) {
  return [
    `# 长期记忆 · ${profile.name}`,
    "",
    "## 角色与边界",
    `- 你是 ${profile.name}，岗位：${ROLE_LABELS[profile.jobFunction] ?? profile.jobFunction}。`,
    `- 工作区：${layout.work}`,
    `- 交接文件：${layout.resume}`,
    "",
    "## 技能与资源",
    `- 公司技能库：${path.join(root, "skills")}（Anthropic 规范、按方向分类）；先用 office_list_skills，再 office_read_skill（支持“方向/技能名”）。`,
    "- 公司知识库：office_search_conversations / office_read_conversation。",
    "",
    "## 约定（自己维护，可追加）",
    "- 新会话开始时先读这份记忆；有长期有效的结论（偏好、约定、路径、坑）补到这里，过时内容及时删改。",
    "- 记忆只写摘要，不写密钥、不写一次性细节；总长度不超过 6KB。",
    "",
  ].join("\n");
}

function syncCompanyRules(existing: string, rules: { text: string; hash: string }): string {
  const begin = `<!-- RULES:BEGIN sha256:${rules.hash.slice(0, 12)} -->`;
  const block = `${begin}\n${rules.text || "(公司规章文件缺失)"}\n<!-- RULES:END -->`;
  const current = RULES_BLOCK.exec(existing)?.[0];
  if (current) return current.startsWith(begin) ? existing : existing.replace(RULES_BLOCK, () => block);
  const lines = existing.split("\n");
  if (lines[0]?.startsWith("# ")) return [lines[0], "", block, "", ...lines.slice(1)].join("\n");
  return `${block}\n\n${existing}`;
}

/**
 * Long-term memory for one agent: managed company rules plus the agent's own notes.
 * Created on demand and refreshed from the company rules file.
 */
export async function loadAgentMemory(
  paths: WorkspacePaths,
  profile: AgentProfile,
  layoutVersion: LayoutVersion,
): Promise<MemoryState> {
  const layout = agentLayout(paths, profile.id, layoutVersion);
  const file = path.join(layout.profile, "memory.md");
  const rules = await readCompanyRules(paths.root);
  const original = await readFile(file, "utf8").catch(() => null);
  const created = original === null;
  const unmigrated = original ?? memoryTemplate(profile, layout, paths.root);
  const existing = syncCompanyRules(unmigrated.replace(LEGACY_LAYOUT_BLOCK, ""), rules);
  const synced = existing !== original;
  if (synced) {
    await mkdir(layout.profile, { recursive: true, mode: 0o700 });
    await writeFile(file, existing, { mode: 0o600 });
  }
  const blocked = SECRET.test(existing);
  let text = blocked ? `（长期记忆含疑似密钥，已拒绝注入；请清理 ${file}）` : existing.trim();
  let truncated = false;
  if (text.length > MEMORY_LIMIT) {
    text = text.slice(0, MEMORY_LIMIT) + `\n…（已截断，完整内容见 ${file}）`;
    truncated = true;
  }
  return { path: file, text, truncated, blocked, created, synced };
}

/** Used when a new agent is created so the file exists before its first run. */
export async function initializeAgentMemory(
  paths: WorkspacePaths,
  profile: AgentProfile,
  layoutVersion: LayoutVersion,
) {
  return loadAgentMemory(paths, profile, layoutVersion);
}
