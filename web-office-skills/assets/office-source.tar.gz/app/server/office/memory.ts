import path from "node:path";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import type { AgentProfile } from "../../shared/office-contracts.ts";
import { agentLayout, type LayoutVersion } from "./agent-layout.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";

/** Cap injected into each prompt: rules + notes must stay a summary, not a log. */
export const MEMORY_LIMIT = 6000;
const MANAGED = ["RULES", "LAYOUT"] as const;
type ManagedName = (typeof MANAGED)[number];
const blockPattern = (name: ManagedName) => new RegExp(`<!-- ${name}:BEGIN[^>]*-->[\\s\\S]*?<!-- ${name}:END -->`);
const SECRET = /(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY)/;

const ROLE_LABELS: Record<string, string> = {
  boss: "老板",
  se: "系统工程师",
  pl: "项目负责人",
  developer: "开发工程师",
  tester: "测试工程师",
};

export interface MemoryState {
  path: string;
  text: string;
  truncated: boolean;
  blocked: boolean;
  created: boolean;
  synced: boolean;
}

export async function readCompanyFile(root: string, relative: string): Promise<{ text: string; hash: string }> {
  const text = await readFile(path.join(root, relative), "utf8").catch(() => "");
  return { text: text.trim(), hash: createHash("sha256").update(text).digest("hex") };
}

export const readCompanyRules = (root: string) => readCompanyFile(root, "company/rules.md");
export const readDevLayout = (root: string) => readCompanyFile(root, "company/dev-work-layout.md");

function memoryTemplate(profile: AgentProfile, layout: ReturnType<typeof agentLayout>, root: string) {
  return [
    `# 长期记忆 · ${profile.name}`,
    "",
    "## 角色与边界",
    `- 你是 ${profile.name}，岗位：${ROLE_LABELS[profile.jobFunction] ?? profile.jobFunction}。`,
    `- 工作区：${layout.work}`,
    `- 交接文件：${layout.resume}`,
    "",
    "## 技能与资源",
    `- 公司技能库：${path.join(root, "skills")}（Anthropic 规范、按方向分类）；先用 office_list_skills，再 office_read_skill（支持“方向/技能名”）。`,
    "- 公司知识库：office_search_conversations / office_read_conversation。",
    "",
    "## 约定（自己维护，可追加）",
    "- 新会话开始时先读这份记忆；有长期有效的结论（偏好、约定、路径、坑）补到这里，过时内容及时删改。",
    "- 记忆只写摘要，不写密钥、不写一次性细节；总长度不超过 6KB。",
    "",
  ].join("\n");
}

function renderBlock(name: ManagedName, content: { text: string; hash: string }, missing: string) {
  const begin = `<!-- ${name}:BEGIN sha256:${content.hash.slice(0, 12)} -->`;
  const end = `<!-- ${name}:END -->`;
  return `${begin}\n${content.text || missing}\n${end}`;
}

/** Insert after the last managed block (or right after the title) so blocks keep a stable order. */
function insertBlock(existing: string, block: string): string {
  const ends = [/<!-- RULES:END -->/g, /<!-- LAYOUT:END -->/g];
  let last: { index: number; size: number } | null = null;
  for (const pattern of ends) {
    const match = [...existing.matchAll(pattern)].pop();
    if (match && (!last || match.index! > last.index)) last = { index: match.index!, size: match[0].length };
  }
  if (last) {
    const at = last.index + last.size;
    return `${existing.slice(0, at)}\n\n${block}${existing.slice(at)}`;
  }
  const lines = existing.split("\n");
  if (lines[0]?.startsWith("# ")) return [lines[0], "", block, "", ...lines.slice(1)].join("\n");
  return `${block}\n\n${existing}`;
}

function syncBlock(
  existing: string,
  name: ManagedName,
  content: { text: string; hash: string },
  missing: string,
): { text: string; changed: boolean } {
  const pattern = blockPattern(name);
  const block = renderBlock(name, content, missing);
  const current = pattern.exec(existing)?.[0];
  if (current) {
    if (current.includes(`sha256:${content.hash.slice(0, 12)}`)) return { text: existing, changed: false };
    return { text: existing.replace(pattern, block), changed: true };
  }
  return { text: insertBlock(existing, block), changed: true };
}

function stripBlock(existing: string, name: ManagedName): { text: string; changed: boolean } {
  const pattern = blockPattern(name);
  if (!pattern.test(existing)) return { text: existing, changed: false };
  return {
    text:
      existing
        .replace(pattern, "")
        .replace(/\n{3,}/g, "\n\n")
        .trim() + "\n",
    changed: true,
  };
}

/**
 * Long-term memory for one agent: company rules (managed block, refreshed when the
 * rules file changes) plus the agent's own notes. Created on demand, never throws.
 */
export async function loadAgentMemory(
  paths: WorkspacePaths,
  profile: AgentProfile,
  layoutVersion: LayoutVersion,
): Promise<MemoryState> {
  const layout = agentLayout(paths, profile.id, layoutVersion);
  const file = path.join(layout.profile, "memory.md");
  const rules = await readCompanyRules(paths.root);
  let existing: string | null = await readFile(file, "utf8").catch(() => null);
  const created = existing === null;
  let synced = false;
  if (existing === null) existing = memoryTemplate(profile, layout, paths.root);
  const rulesSync = syncBlock(existing, "RULES", rules, "(公司规章文件缺失)");
  existing = rulesSync.text;
  synced ||= rulesSync.changed;
  // The project layout applies to developer roles only; other roles keep their memory untouched.
  if (profile.jobFunction === "developer") {
    const devLayout = await readDevLayout(paths.root);
    const layoutSync = syncBlock(existing, "LAYOUT", devLayout, "(开发岗规范文件缺失)");
    existing = layoutSync.text;
    synced ||= layoutSync.changed;
  } else {
    const stripped = stripBlock(existing, "LAYOUT");
    existing = stripped.text;
    synced ||= stripped.changed;
  }
  if (created || synced) {
    await mkdir(layout.profile, { recursive: true, mode: 0o700 });
    await writeFile(file, existing, { mode: 0o600 });
  }
  const blocked = SECRET.test(existing);
  let text = blocked ? `（长期记忆含疑似密钥，已拒绝注入；请清理 ${file}）` : existing.trim();
  let truncated = false;
  if (text.length > MEMORY_LIMIT) {
    text = text.slice(0, MEMORY_LIMIT) + `\n…（已截断，完整内容见 ${file}）`;
    truncated = true;
  }
  return { path: file, text, truncated, blocked, created, synced };
}

/** Used when a new agent is created so the file exists before its first run. */
export async function initializeAgentMemory(
  paths: WorkspacePaths,
  profile: AgentProfile,
  layoutVersion: LayoutVersion,
) {
  return loadAgentMemory(paths, profile, layoutVersion);
}
