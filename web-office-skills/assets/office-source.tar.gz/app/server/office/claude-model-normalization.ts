/** Claude context-window badges are CLI selection metadata, not upstream model IDs. */
export function normalizeClaudeModelId(model: string): string {
  return model.replace(/\[(?:1|2)m\]$/i, "");
}

/** Preserve opaque provider ID spelling; only the CLI's known badge is case insensitive. */
export function claudeCliModelId(model: string): string {
  return model.replace(/\[([12])m\]$/i, (_, size: string) => `[${size}m]`);
}

export function isClaudeModelAlias(model: string): boolean {
  return /^(?:sonnet|opus|haiku|fable|best|opusplan|default|inherit)$/.test(normalizeClaudeModelId(model));
}

/** Return the pinned wire ID, or null if the CLI attempted an unrelated model. */
export function resolveClaudeProxyModel(configured: string, requested: string): string | null {
  const selected = normalizeClaudeModelId(configured);
  const actual = normalizeClaudeModelId(requested);
  if (!selected) return null;
  if (!actual || actual === selected) return selected;
  // Native aliases may resolve to a full dated/versioned ID in the same family.
  // Custom relay models never acquire this alias permission.
  if (
    /^(?:sonnet|opus|haiku|fable)$/.test(selected) &&
    new RegExp(`^claude-(?:[0-9]+(?:[.-][0-9]+)*-)?${selected}(?:-|$)`).test(actual)
  )
    return actual;
  return null;
}
