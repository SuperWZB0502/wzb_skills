import { OfficeError } from "./errors.ts";

/** Streaming redaction retains suffixes so a secret split across chunks cannot leak. */
export class SecretRedactor {
  private buffer = "";
  private readonly values: string[];
  constructor(secrets: string[]) {
    this.values = [
      ...new Set(secrets.filter(Boolean).flatMap((s) => [s, encodeURIComponent(s), Buffer.from(s).toString("base64")])),
    ].sort((a, b) => b.length - a.length);
  }
  push(chunk: string): string {
    this.buffer += chunk;
    const keep = Math.max(1, ...this.values.map((s) => s.length)) - 1;
    let at = 0;
    let output = "";
    while (at < this.buffer.length - keep) {
      const value = this.values.find((s) => this.buffer.startsWith(s, at));
      if (value) {
        output += "[REDACTED]";
        at += value.length;
      } else output += this.buffer[at++];
    }
    this.buffer = this.buffer.slice(at);
    return output;
  }
  flush(): string {
    let result = this.buffer;
    this.buffer = "";
    for (const value of this.values) result = result.split(value).join("[REDACTED]");
    return result;
  }
}
export function redact(text: string, secrets: string[]): string {
  const filter = new SecretRedactor(secrets);
  return filter.push(text) + filter.flush();
}

function redactValue(value: unknown, secrets: string[]): unknown {
  if (typeof value === "string") return redact(value, secrets);
  if (Array.isArray(value)) return value.map((item) => redactValue(item, secrets));
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [redact(key, secrets), redactValue(item, secrets)]),
    );
  return value;
}
function parseJson(data: string): unknown {
  try {
    return JSON.parse(data);
  } catch {
    throw new OfficeError("invalid_model_response", 502);
  }
}
/** Decode JSON escapes before matching secrets; never forward a partly inspected frame. */
export class ModelResponseRedactor {
  private buffer = "";
  private readonly deltas = new Map<
    string,
    { filter: SecretRedactor; template: Record<string, unknown>; nestedField?: string }
  >();
  constructor(
    private readonly format: "json" | "sse",
    private readonly secrets: string[],
  ) {}
  push(chunk: string): string {
    this.buffer += chunk;
    if (this.format === "json") {
      this.bound(this.buffer, 12 * 1024 * 1024);
      return "";
    }
    let result = "";
    for (;;) {
      const end = /\r\n\r\n|\n\n|\r\r/.exec(this.buffer);
      if (!end) break;
      const frame = this.buffer.slice(0, end.index);
      this.bound(frame, 2 * 1024 * 1024);
      this.buffer = this.buffer.slice(end.index + end[0].length);
      result += this.frame(frame);
    }
    this.bound(this.buffer, 2 * 1024 * 1024);
    return result;
  }
  flush(): string {
    const remaining = this.buffer;
    this.buffer = "";
    if (this.format === "json") return JSON.stringify(redactValue(parseJson(remaining), this.secrets));
    return (remaining ? this.frame(remaining) : "") + this.drainDeltas();
  }
  private bound(value: string, bytes: number): void {
    if (Buffer.byteLength(value, "utf8") > bytes) throw new OfficeError("model_response_too_large", 502);
  }
  private drainDeltas(predicate: (template: Record<string, unknown>) => boolean = () => true): string {
    let result = "";
    for (const [key, stream] of this.deltas) {
      if (!predicate(stream.template)) continue;
      const delta = stream.filter.flush();
      this.deltas.delete(key);
      if (delta) {
        const value = stream.nestedField
          ? {
              ...stream.template,
              delta: { ...(stream.template.delta as Record<string, unknown>), [stream.nestedField]: delta },
            }
          : { ...stream.template, delta };
        result +=
          (stream.nestedField ? "event: content_block_delta\n" : "") + "data: " + JSON.stringify(value) + "\n\n";
      }
    }
    return result;
  }
  private frame(frame: string): string {
    const lines = frame.split(/\r\n|\r|\n/);
    const data = lines
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).replace(/^ /, ""))
      .join("\n");
    if (!lines.some((line) => line.startsWith("data:"))) return redact(frame, this.secrets) + "\n\n";
    let prefix = "";
    let cleaned = data;
    if (data === "[DONE]") prefix = this.drainDeltas();
    else if (data !== "") {
      const parsed = parseJson(data);
      const event =
        parsed && typeof parsed === "object" && !Array.isArray(parsed)
          ? (parsed as Record<string, unknown>)
          : undefined;
      let value = redactValue(parsed, this.secrets);
      if (event && typeof event.type === "string") {
        if (
          event.type === "content_block_delta" &&
          event.delta &&
          typeof event.delta === "object" &&
          !Array.isArray(event.delta)
        ) {
          if (!Number.isSafeInteger(event.index) || Number(event.index) < 0)
            throw new OfficeError("invalid_model_response", 502);
          const delta = event.delta as Record<string, unknown>;
          if (typeof delta.type !== "string" || delta.type.length > 128)
            throw new OfficeError("invalid_model_response", 502);
          const cleanedDelta = { ...((value as Record<string, unknown>).delta as Record<string, unknown>) };
          for (const [field, text] of Object.entries(delta)) {
            if (field === "type" || typeof text !== "string") continue;
            const metadata = { type: "content_block_delta", index: event.index, delta: { type: delta.type } };
            const key = JSON.stringify(["anthropic", event.index, delta.type, field]);
            let stream = this.deltas.get(key);
            if (!stream) {
              if (this.deltas.size >= 128) throw new OfficeError("model_response_too_large", 502);
              stream = {
                filter: new SecretRedactor(this.secrets),
                template: redactValue(metadata, this.secrets) as Record<string, unknown>,
                nestedField: field,
              };
              this.deltas.set(key, stream);
            }
            cleanedDelta[field] = stream.filter.push(text);
          }
          value = { ...(value as Record<string, unknown>), delta: cleanedDelta };
        } else if (
          event.type === "content_block_start" &&
          event.content_block &&
          typeof event.content_block === "object" &&
          !Array.isArray(event.content_block)
        ) {
          const block = event.content_block as Record<string, unknown>;
          const field = block.type === "text" ? "text" : block.type === "thinking" ? "thinking" : undefined;
          if (field && typeof block[field] === "string") {
            if (!Number.isSafeInteger(event.index) || Number(event.index) < 0)
              throw new OfficeError("invalid_model_response", 502);
            const subtype = field === "text" ? "text_delta" : "thinking_delta";
            const key = JSON.stringify(["anthropic", event.index, subtype, field]);
            if (this.deltas.has(key) || this.deltas.size >= 128) throw new OfficeError("invalid_model_response", 502);
            const stream = {
              filter: new SecretRedactor(this.secrets),
              template: { type: "content_block_delta", index: event.index, delta: { type: subtype } },
              nestedField: field,
            };
            this.deltas.set(key, stream);
            value = {
              ...(value as Record<string, unknown>),
              content_block: {
                ...((value as Record<string, unknown>).content_block as Record<string, unknown>),
                [field]: stream.filter.push(String(block[field])),
              },
            };
          }
        } else if (event.type === "content_block_stop") {
          prefix = this.drainDeltas(
            (template) => template.type === "content_block_delta" && template.index === event.index,
          );
        } else if (event.type === "message_stop" || event.type === "message_start") {
          prefix = this.drainDeltas();
        } else if (event.type.endsWith(".delta") && typeof event.delta === "string") {
          const metadata = Object.fromEntries(
            ["type", "response_id", "item_id", "output_index", "content_index"]
              .filter((name) => event[name] !== undefined)
              .map((name) => [name, event[name]]),
          );
          const key = JSON.stringify(metadata);
          if (key.length > 2048) throw new OfficeError("invalid_model_response", 502);
          let stream = this.deltas.get(key);
          if (!stream) {
            if (this.deltas.size >= 128) throw new OfficeError("model_response_too_large", 502);
            stream = {
              filter: new SecretRedactor(this.secrets),
              template: redactValue(metadata, this.secrets) as Record<string, unknown>,
            };
            this.deltas.set(key, stream);
          }
          value = { ...(value as Record<string, unknown>), delta: stream.filter.push(event.delta) };
        } else if (event.type.endsWith(".done")) {
          const deltaType = event.type.replace(/\.done$/, ".delta");
          prefix = this.drainDeltas(
            (template) =>
              template.type === deltaType &&
              ["response_id", "item_id", "output_index", "content_index"].every(
                (name) => event[name] === undefined || template[name] === event[name],
              ),
          );
        } else if (["response.completed", "response.failed", "response.incomplete"].includes(event.type))
          prefix = this.drainDeltas();
      }
      cleaned = JSON.stringify(value);
    }
    // SSE permits multiline data. Re-serialize it as a single JSON line.
    let inserted = false;
    return (
      prefix +
      lines
        .flatMap((line) => {
          if (!line.startsWith("data:")) return [redact(line, this.secrets)];
          if (inserted) return [];
          inserted = true;
          return ["data: " + cleaned];
        })
        .join("\n") +
      "\n\n"
    );
  }
}
