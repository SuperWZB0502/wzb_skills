import path from "node:path";
import { lstat, readFile, readdir, realpath } from "node:fs/promises";
import { OfficeError } from "./errors.ts";

/**
 * Company skills follow the Anthropic Agent Skills layout: skills/<name>/SKILL.md with a
 * YAML frontmatter (name, description, optional license/metadata). These helpers only read.
 */
const NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;
const MAX_BODY_LINES = 700;
const MAX_FILE_BYTES = 256 * 1024;

export interface SkillSummary {
  name: string;
  category: string | null;
  description: string;
  license: string | null;
  version: string | null;
  owner: string | null;
  files: number;
  valid: boolean;
  problems: string[];
}

export interface SkillFrontmatter {
  data: Record<string, string>;
  metadata: Record<string, string>;
  body: string;
}

function unquote(value: string): string {
  const trimmed = value.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))
    return trimmed.slice(1, -1);
  return trimmed;
}

/** Minimal YAML frontmatter reader for the documented skill fields; unknown keys are ignored. */
export function parseSkillFrontmatter(text: string): SkillFrontmatter {
  if (!text.startsWith("---\n")) return { data: {}, metadata: {}, body: text };
  const end = text.indexOf("\n---", 4);
  if (end < 0) return { data: {}, metadata: {}, body: text };
  const header = text.slice(4, end);
  const body = text.slice(end + 4).replace(/^\r?\n/, "");
  const data: Record<string, string> = {};
  const metadata: Record<string, string> = {};
  let nested: Record<string, string> | null = null;
  for (const line of header.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith("#")) continue;
    const indented = /^\s+/.test(line);
    const match = /^\s*([A-Za-z0-9_.-]+)\s*:\s*(.*)$/.exec(line);
    if (!match) continue;
    const [, key, raw] = match;
    const value = unquote(raw);
    if (!indented) {
      nested = null;
      if (key === "metadata") {
        nested = metadata;
        continue;
      }
      data[key] = value;
      continue;
    }
    if (nested) nested[key] = value;
  }
  return { data, metadata, body };
}

async function skillDirectories(root: string): Promise<string[]> {
  const base = path.join(root, "skills");
  let entries: string[] = [];
  try {
    entries = await readdir(base);
  } catch {
    return [];
  }
  const found: string[] = [];
  for (const entry of entries.sort()) {
    if (entry.startsWith(".")) continue;
    const info = await lstat(path.join(base, entry)).catch(() => null);
    if (info?.isDirectory()) found.push(entry);
  }
  return found;
}

/** A category is a folder without SKILL.md whose subfolders are skills. */
async function categoryDirectories(root: string): Promise<Array<{ category: string; skills: string[] }>> {
  const base = path.join(root, "skills");
  const groups: Array<{ category: string; skills: string[] }> = [];
  for (const directory of await skillDirectories(root)) {
    if (await hasSkillFile(path.join(base, directory))) continue;
    let children: string[] = [];
    try {
      children = await readdir(path.join(base, directory));
    } catch {
      continue;
    }
    const skills: string[] = [];
    for (const child of children.sort()) {
      if (child.startsWith(".")) continue;
      const info = await lstat(path.join(base, directory, child)).catch(() => null);
      if (info?.isDirectory() && (await hasSkillFile(path.join(base, directory, child))))
        skills.push(path.join(directory, child));
    }
    if (skills.length) groups.push({ category: directory, skills });
  }
  return groups;
}

async function hasSkillFile(directory: string): Promise<boolean> {
  const info = await lstat(path.join(directory, "SKILL.md")).catch(() => null);
  return Boolean(info?.isFile());
}

export async function listSkills(root: string): Promise<SkillSummary[]> {
  const base = path.join(root, "skills");
  const skills: SkillSummary[] = [];
  const entries: Array<{ directory: string; category: string | null }> = [];
  for (const directory of await skillDirectories(root)) {
    if (await hasSkillFile(path.join(base, directory))) entries.push({ directory, category: null });
    else if (!(await categoryDirectories(root)).some((group) => group.category === directory)) continue;
  }
  for (const group of await categoryDirectories(root))
    for (const directory of group.skills) entries.push({ directory, category: group.category });
  for (const { directory, category } of entries) {
    const skillFile = path.join(base, directory, "SKILL.md");
    let text: string;
    try {
      const info = await lstat(skillFile);
      if (!info.isFile() || info.isSymbolicLink()) continue;
      if (info.size > MAX_FILE_BYTES) continue;
      text = await readFile(skillFile, "utf8");
    } catch {
      continue;
    }
    const { data, metadata, body } = parseSkillFrontmatter(text);
    const problems: string[] = [];
    const leaf = path.basename(directory);
    const name = data.name ?? "";
    const description = data.description ?? "";
    if (!NAME.test(leaf)) problems.push("目录名必须是 1-64 位小写字母/数字/连字符");
    if (!name) problems.push("缺少 frontmatter name");
    else if (name !== leaf) problems.push("frontmatter name 与目录名不一致");
    if (!description) problems.push("缺少 frontmatter description");
    else if (description.length > 1024) problems.push("description 超过 1024 字符");
    if (body.split("\n").length > MAX_BODY_LINES) problems.push(`正文超过 ${MAX_BODY_LINES} 行，建议移到 references/`);
    let files = 0;
    const walk = async (relative: string, depth: number) => {
      if (depth > 4) return;
      let names: string[] = [];
      try {
        names = await readdir(path.join(base, directory, relative));
      } catch {
        return;
      }
      for (const entry of names) {
        const info = await lstat(path.join(base, directory, relative, entry)).catch(() => null);
        if (!info) continue;
        if (info.isDirectory()) await walk(path.join(relative, entry), depth + 1);
        else if (info.isFile()) files += 1;
      }
    };
    await walk("", 0);
    skills.push({
      name: name || leaf,
      category,
      description,
      license: data.license || null,
      version: metadata.version || null,
      owner: metadata.owner || null,
      files,
      valid: problems.length === 0,
      problems,
    });
  }
  return skills;
}

export async function readSkillFile(root: string, name: unknown, file: unknown = "SKILL.md") {
  if (typeof name !== "string") throw new OfficeError("invalid_skill_name", 400);
  const parts = name.trim().split("/").filter(Boolean);
  if (parts.length === 0 || parts.length > 2 || parts.some((part) => !NAME.test(part)))
    throw new OfficeError("invalid_skill_name", 400);
  const skillsRoot = path.join(root, "skills");
  let directory: string;
  if (parts.length === 2) {
    directory = path.join(skillsRoot, parts[0], parts[1]);
  } else {
    const flat = path.join(skillsRoot, parts[0]);
    if (await hasSkillFile(flat)) directory = flat;
    else {
      const matches = (await categoryDirectories(root)).map((group) => path.join(skillsRoot, group.category, parts[0]));
      const existing: string[] = [];
      for (const candidate of matches) if (await hasSkillFile(candidate)) existing.push(candidate);
      if (existing.length === 0) throw new OfficeError("skill_not_found", 404);
      if (existing.length > 1) throw new OfficeError("ambiguous_skill_name", 409);
      directory = existing[0];
    }
  }
  let base: string;
  try {
    base = await realpath(directory);
  } catch {
    throw new OfficeError("skill_not_found", 404);
  }
  const relative = typeof file === "string" && file.trim() ? file.trim() : "SKILL.md";
  if (relative.includes("\0") || relative.includes("\\") || path.isAbsolute(relative))
    throw new OfficeError("invalid_skill_path", 400);
  if (relative.split("/").some((part) => !part || part === "." || part === ".." || part.startsWith(".")))
    throw new OfficeError("invalid_skill_path", 400);
  const target = path.join(base, ...relative.split("/"));
  let real: string;
  try {
    real = await realpath(target);
  } catch {
    throw new OfficeError("skill_file_not_found", 404);
  }
  const relation = path.relative(base, real);
  if (!relation || relation.startsWith("..") || path.isAbsolute(relation))
    throw new OfficeError("invalid_skill_path", 400);
  const info = await lstat(real);
  if (!info.isFile()) throw new OfficeError("skill_file_not_found", 404);
  if (info.size > MAX_FILE_BYTES) throw new OfficeError("skill_file_too_large", 413);
  const buffer = await readFile(real);
  if (buffer.includes(0)) throw new OfficeError("skill_file_not_text", 415);
  return {
    name: parts[parts.length - 1],
    category: parts.length === 2 ? parts[0] : null,
    path: relation.split(path.sep).join("/"),
    content: buffer.toString("utf8"),
  };
}
