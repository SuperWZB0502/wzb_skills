import { readdir, readFile } from "node:fs/promises";

export interface ProcessIdentity {
  pid: number;
  started: string;
}
interface ProcessInfo extends ProcessIdentity {
  parent: number;
}
async function processInfo(pid: number): Promise<ProcessInfo | undefined> {
  try {
    const stat = await readFile(`/proc/${pid}/stat`, "utf8");
    // comm can itself contain whitespace and parentheses; fields follow its last ')'.
    const fields = stat
      .slice(stat.lastIndexOf(")") + 2)
      .trim()
      .split(/\s+/);
    if (fields.length < 20 || !/^\d+$/.test(fields[19])) return;
    return { pid, parent: Number(fields[1]), started: fields[19] };
  } catch (error) {
    if (["ENOENT", "ESRCH", "EACCES", "EPERM"].includes((error as NodeJS.ErrnoException).code ?? "")) return;
    throw error;
  }
}

/** Includes the root. Snapshot before terminating its parent so PPIDs still identify the task. */
export async function snapshotProcessTree(pid: number, expectedStart?: string): Promise<ProcessIdentity[]> {
  if (process.platform !== "linux" || !Number.isInteger(pid) || pid <= 1 || pid === process.pid) return [];
  const names = (await readdir("/proc")).filter((name) => /^\d+$/.test(name));
  const entries: ProcessInfo[] = [];
  for (let offset = 0; offset < names.length; offset += 64) {
    const batch = await Promise.all(names.slice(offset, offset + 64).map((name) => processInfo(Number(name))));
    for (const entry of batch) if (entry) entries.push(entry);
  }
  const root = entries.find((entry) => entry.pid === pid);
  if (!root || (expectedStart !== undefined && root.started !== expectedStart)) return [];
  const selected = new Set([pid]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const entry of entries) {
      if (selected.has(entry.parent) && !selected.has(entry.pid)) {
        selected.add(entry.pid);
        changed = true;
      }
    }
  }
  return entries
    .filter((entry) => selected.has(entry.pid))
    .map(({ pid: member, started }) => ({ pid: member, started }));
}

/** PID reuse must never redirect a delayed stop signal to an unrelated process. */
export async function signalProcessIdentities(identities: ProcessIdentity[], signal: NodeJS.Signals): Promise<void> {
  if (process.platform !== "linux") return;
  const results = await Promise.allSettled(
    identities.map(async (identity) => {
      if (identity.pid <= 1 || identity.pid === process.pid) return;
      const current = await processInfo(identity.pid);
      if (!current || current.started !== identity.started) return;
      try {
        process.kill(identity.pid, signal);
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ESRCH") throw error;
      }
    }),
  );
  const failure = results.find((result) => result.status === "rejected");
  if (failure?.status === "rejected") throw failure.reason;
}
