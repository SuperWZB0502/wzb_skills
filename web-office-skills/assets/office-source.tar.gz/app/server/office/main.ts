import { parseArgs } from "node:util";
import path from "node:path";
import { startOfficeHost } from "./runtime-host.ts";
const { values } = parseArgs({
  options: { root: { type: "string" }, port: { type: "string" }, mode: { type: "string" } },
});
if (!values.root) throw new Error("Explicit --root required");
const root = path.resolve(values.root);
process.chdir(root);
try {
  const host = await startOfficeHost({
    workspaceRoot: root,
    port: Number(values.port ?? 18080),
    defaultView: values.mode === "chat" ? "chat" : "office",
  });
  console.log(JSON.stringify({ event: "ready", ...host.status() }));
  const stop = () => {
    void host.close().then(() => process.exit(0));
  };
  process.once("SIGTERM", stop);
  process.once("SIGINT", stop);
} catch (error) {
  console.error(error instanceof Error ? error.message : "Startup failed");
  process.exitCode = 1;
}
