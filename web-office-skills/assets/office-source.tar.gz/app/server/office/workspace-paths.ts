import path from "node:path";
import { chmod, lstat, mkdir, readlink, realpath } from "node:fs/promises";
import { OfficeError } from "./errors.ts";

export interface WorkspacePaths {
  root: string;
  app: string;
  state: string;
  logs: string;
  projects: string;
  agents: string;
  shared: string;
  artifacts: string;
  releases: string;
  cache: string;
  tmp: string;
  installStaging: string;
}
const managed = {
  app: "app",
  state: "state",
  logs: "logs",
  projects: "projects",
  agents: "agents",
  shared: "shared",
  artifacts: "artifacts",
  releases: "releases",
  cache: "cache",
  tmp: "tmp",
  installStaging: ".install-staging",
} as const;
function inside(root: string, candidate: string): boolean {
  const relative = path.relative(root, candidate);
  return relative === "" || (relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}
function outside(): never {
  throw new OfficeError("workspace_path_outside", 403);
}

/** Resolve existing ancestors as well as missing descendants, without traversing an outside link. */
export async function resolveWorkspacePath(paths: WorkspacePaths, input: string): Promise<string> {
  if (typeof input !== "string" || input.includes("\0")) throw new OfficeError("invalid_workspace_path");
  const root = path.resolve(paths.root);
  if ((await realpath(root)) !== root) outside();
  const requested = path.resolve(root, input);
  if (!inside(root, requested)) outside();
  let pending = path.relative(root, requested).split(path.sep).filter(Boolean);
  let current = root;
  let links = 0;
  while (pending.length) {
    const next = path.join(current, pending.shift()!);
    let info;
    try {
      info = await lstat(next);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return path.join(next, ...pending);
      throw error;
    }
    if (info.isSymbolicLink()) {
      if (++links > 40) throw new OfficeError("workspace_symlink_loop", 403);
      const target = path.resolve(path.dirname(next), await readlink(next));
      if (!inside(root, target)) outside();
      pending = [...path.relative(root, target).split(path.sep).filter(Boolean), ...pending];
      current = root;
    } else {
      if (pending.length && !info.isDirectory()) throw new OfficeError("workspace_parent_not_directory");
      current = next;
    }
  }
  return current;
}

export async function createWorkspacePaths(rootInput: string): Promise<WorkspacePaths> {
  if (typeof rootInput !== "string" || !path.isAbsolute(rootInput) || rootInput.includes("\0"))
    throw new OfficeError("invalid_workspace_root");
  const root = path.resolve(rootInput);
  // Verify the nearest existing ancestor before recursive mkdir can follow a link.
  let ancestor = root;
  for (;;) {
    try {
      if ((await realpath(ancestor)) !== ancestor) outside();
      break;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      const parent = path.dirname(ancestor);
      if (parent === ancestor) throw error;
      ancestor = parent;
    }
  }
  await mkdir(root, { recursive: true, mode: 0o700 });
  if ((await realpath(root)) !== root) outside();
  const paths = { root } as WorkspacePaths;
  // Check all locations before creating any managed directory.
  for (const [key, name] of Object.entries(managed)) {
    paths[key as keyof typeof managed] = await resolveWorkspacePath(paths, name);
    try {
      if ((await lstat(path.join(root, name))).isSymbolicLink())
        throw new OfficeError("workspace_managed_symlink", 403);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  for (const key of Object.keys(managed) as Array<keyof typeof managed>) {
    await mkdir(paths[key], { recursive: true, mode: 0o700 });
  }
  await chmod(paths.state, 0o700);
  return paths;
}
