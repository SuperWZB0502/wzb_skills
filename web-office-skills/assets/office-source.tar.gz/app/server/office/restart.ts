import path from "node:path";
import { spawn } from "node:child_process";

/**
 * Ask the workspace CLI to restart the runtime (`office.mjs restart`: stop → wait → start).
 *
 * The helper runs detached so it survives the shutdown it triggers, and its environment is
 * stripped of credential-looking variables, mirroring `office.mjs start`. The caller answers
 * the HTTP request first: the runtime this process belongs to is going to exit.
 */
export function spawnRestart(
  root: string,
  scriptPath: string = path.join(root, "scripts", "office.mjs"),
): Promise<{ pid: number }> {
  return new Promise((resolve, reject) => {
    const env = { ...process.env };
    for (const key of Object.keys(env))
      if (/(?:API[_-]?KEY|TOKEN|SECRET|PASSWORD|AUTHORIZATION)/i.test(key)) delete env[key];
    const child = spawn(process.execPath, [scriptPath, "restart", "--root", root], {
      cwd: root,
      env,
      detached: true,
      windowsHide: true,
      stdio: "ignore",
    });
    child.once("error", reject);
    child.once("spawn", () => {
      child.unref();
      resolve({ pid: child.pid ?? 0 });
    });
  });
}
