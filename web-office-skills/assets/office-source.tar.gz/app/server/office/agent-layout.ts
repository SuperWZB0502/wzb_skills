import path from "node:path";
import { readFile, readdir, writeFile } from "node:fs/promises";
import type { WorkspacePaths } from "./workspace-paths.ts";
import { OfficeError } from "./errors.ts";

export type LayoutVersion = 1 | 2;
export const LAYOUT_FILE = path.join("state", "layout-version.json");

/**
 * Per-agent storage layout.
 *
 * v1 (legacy): profile files in agents/<id>, CLI homes under state/claude|codex/<id>,
 *              work in projects/<id>, cache in cache/agents/<id>.
 * v2: everything under agents/<id>/{profile,sessions,work,cache}; projects/ keeps shared
 *     repositories and per-agent worktrees only.
 */
export interface AgentLayout {
  version: LayoutVersion;
  agentId: string;
  root: string;
  profile: string;
  attachments: string;
  resume: string;
  home: string;
  config: string;
  stateDir: string;
  data: string;
  claude: string;
  codex: string;
  work: string;
  cache: string;
}

export function agentLayout(paths: WorkspacePaths, agentId: string, version: LayoutVersion): AgentLayout {
  if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(agentId)) throw new Error("invalid_agent_id");
  const root = path.join(paths.agents, agentId);
  if (version === 2) {
    const profile = path.join(root, "profile");
    const toolHome = path.join(profile, "tool-home");
    return {
      version,
      agentId,
      root,
      profile,
      attachments: path.join(profile, "attachments"),
      resume: path.join(profile, "resume.md"),
      home: path.join(toolHome, "home"),
      config: path.join(toolHome, "config"),
      stateDir: path.join(toolHome, "state"),
      data: path.join(toolHome, "data"),
      claude: path.join(root, "sessions", "claude"),
      codex: path.join(root, "sessions", "codex"),
      work: path.join(root, "work"),
      cache: path.join(root, "cache"),
    };
  }
  return {
    version,
    agentId,
    root,
    profile: root,
    attachments: path.join(root, "attachments"),
    resume: path.join(root, "resume.md"),
    home: path.join(root, ".home"),
    config: path.join(root, ".config"),
    stateDir: path.join(root, ".state"),
    data: path.join(root, ".data"),
    claude: path.join(paths.state, "claude", agentId),
    codex: path.join(paths.state, "codex", agentId),
    work: path.join(paths.projects, agentId),
    cache: path.join(paths.cache, "agents", agentId),
  };
}

async function exists(target: string): Promise<boolean> {
  try {
    await readdir(target);
    return true;
  } catch {
    try {
      await readFile(target);
      return true;
    } catch {
      return false;
    }
  }
}

async function nonEmpty(target: string): Promise<boolean> {
  try {
    return (await readdir(target)).length > 0;
  } catch {
    return false;
  }
}

/** Missing version file: legacy markers decide, otherwise a fresh install uses v2. */
export async function detectLayoutVersion(paths: WorkspacePaths): Promise<LayoutVersion> {
  // A half-finished migration must be fixed (rollback or re-apply) before serving again.
  try {
    const journal = JSON.parse(await readFile(path.join(paths.root, "state", "layout-migration.json"), "utf8"));
    if (journal && journal.done !== true) throw new OfficeError("layout_migration_incomplete", 503);
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  try {
    const parsed = JSON.parse(await readFile(path.join(paths.root, LAYOUT_FILE), "utf8"));
    const version = Number(parsed?.version);
    if (version === 1 || version === 2) return version;
  } catch {
    /* fall through to detection */
  }
  if ((await nonEmpty(path.join(paths.state, "claude"))) || (await nonEmpty(path.join(paths.state, "codex")))) return 1;
  let agents: string[] = [];
  try {
    agents = await readdir(paths.agents);
  } catch {
    agents = [];
  }
  for (const agent of agents) {
    for (const legacy of ["resume.md", ".home", "attachments"])
      if (await exists(path.join(paths.agents, agent, legacy))) return 1;
    if (await nonEmpty(path.join(paths.agents, agent, "profile"))) return 2;
  }
  return 2;
}

export async function writeLayoutVersion(root: string, version: LayoutVersion, extra: Record<string, unknown> = {}) {
  await writeFile(
    path.join(root, LAYOUT_FILE),
    JSON.stringify({ version, updatedAt: new Date().toISOString(), ...extra }, null, 2) + "\n",
    { mode: 0o600 },
  );
}
