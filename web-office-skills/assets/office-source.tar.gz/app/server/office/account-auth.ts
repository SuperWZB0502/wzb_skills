import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { OfficeError } from "./errors.ts";

// Public native Claude Code OAuth client metadata, confirmed against installed 2.1.311.
// The PKCE verifier, authorization code and returned tokens never leave process memory.
const CLAUDE_CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
const CLAUDE_AUTH_URL = "https://claude.com/cai/oauth/authorize";
const CLAUDE_TOKEN_URL = "https://platform.claude.com/v1/oauth/token";
const CLAUDE_REDIRECT_URL = "https://platform.claude.com/oauth/code/callback";
const LOGIN_TTL = 10 * 60 * 1000;
interface PendingLogin {
  providerId: string;
  verifier: string;
  state: string;
  expiresAt: number;
  exchanging: boolean;
}
export interface ClaudeAccountToken {
  accessToken: string;
  expiresAt: number;
}
function equal(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

/** Manual-code PKCE authorization, matching `claude setup-token` without disk persistence. */
export class ClaudeAccountAuth {
  private pending = new Map<string, PendingLogin>();
  private credentials = new Map<string, ClaudeAccountToken>();
  private closing = false;
  private requests = new Map<string, AbortController>();
  start(providerId: string) {
    if (this.closing) throw new OfficeError("runtime_stopping", 409);
    this.clear(providerId);
    for (const [id, login] of this.pending) if (login.expiresAt <= Date.now()) this.pending.delete(id);
    const loginId = randomUUID();
    const verifier = randomBytes(32).toString("base64url");
    const state = randomBytes(32).toString("base64url");
    const expiresAt = Date.now() + LOGIN_TTL;
    const authUrl = new URL(CLAUDE_AUTH_URL);
    authUrl.search = new URLSearchParams({
      code: "true",
      client_id: CLAUDE_CLIENT_ID,
      response_type: "code",
      redirect_uri: CLAUDE_REDIRECT_URL,
      scope: "user:inference",
      code_challenge: createHash("sha256").update(verifier).digest("base64url"),
      code_challenge_method: "S256",
      state,
    }).toString();
    this.pending.set(loginId, { providerId, verifier, state, expiresAt, exchanging: false });
    return { loginId, authUrl: authUrl.href, expiresAt };
  }
  async complete(providerId: string, loginId: string, rawCode: string): Promise<ClaudeAccountToken> {
    const login = this.pending.get(loginId);
    if (!login || login.providerId !== providerId) throw new OfficeError("login_not_found", 404);
    if (login.expiresAt <= Date.now()) {
      this.pending.delete(loginId);
      throw new OfficeError("login_expired", 409);
    }
    if (login.exchanging) throw new OfficeError("login_in_progress", 409);
    if (typeof rawCode !== "string" || rawCode.length > 8192) throw new OfficeError("invalid_login_code", 400);
    const [code, state, extra] = rawCode.trim().split("#");
    if (!code || !state || extra !== undefined || !equal(state, login.state))
      throw new OfficeError("invalid_login_code", 400);
    login.exchanging = true;
    const controller = new AbortController();
    this.requests.set(loginId, controller);
    const timeout = setTimeout(() => controller.abort(), 30000);
    try {
      const response = await fetch(CLAUDE_TOKEN_URL, {
        method: "POST",
        headers: { "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify({
          grant_type: "authorization_code",
          code,
          state: login.state,
          redirect_uri: CLAUDE_REDIRECT_URL,
          client_id: CLAUDE_CLIENT_ID,
          code_verifier: login.verifier,
          expires_in: 31536000,
        }),
        signal: controller.signal,
        redirect: "error",
      });
      if (!response.ok) {
        await response.body?.cancel().catch(() => {});
        throw new OfficeError("account_token_exchange_failed", 502);
      }
      if (Number(response.headers.get("content-length") ?? "0") > 65536)
        throw new OfficeError("account_token_response_invalid", 502);
      const reader = response.body?.getReader();
      if (!reader) throw new OfficeError("account_token_response_invalid", 502);
      let total = 0;
      const chunks: Uint8Array[] = [];
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          total += value.length;
          if (total > 65536) {
            await reader.cancel();
            throw new OfficeError("account_token_response_invalid", 502);
          }
          chunks.push(value);
        }
      } finally {
        reader.releaseLock();
      }
      let value: Record<string, unknown>;
      try {
        value = JSON.parse(Buffer.concat(chunks).toString("utf8")) as Record<string, unknown>;
      } catch {
        throw new OfficeError("account_token_response_invalid", 502);
      }
      if (
        typeof value.access_token !== "string" ||
        !value.access_token ||
        value.access_token.length > 32768 ||
        typeof value.expires_in !== "number" ||
        !Number.isFinite(value.expires_in) ||
        value.expires_in <= 0
      )
        throw new OfficeError("account_token_response_invalid", 502);
      if (this.closing || this.pending.get(loginId) !== login) throw new OfficeError("login_cancelled", 409);
      const credential = { accessToken: value.access_token, expiresAt: Date.now() + value.expires_in * 1000 };
      this.credentials.set(providerId, credential);
      return credential;
    } catch (error) {
      if (error instanceof OfficeError) throw error;
      throw new OfficeError("account_token_exchange_failed", 502);
    } finally {
      clearTimeout(timeout);
      this.requests.delete(loginId);
      this.pending.delete(loginId);
    }
  }
  cancel(providerId: string, loginId: string) {
    if (this.pending.get(loginId)?.providerId !== providerId) throw new OfficeError("login_not_found", 404);
    this.requests.get(loginId)?.abort();
    this.pending.delete(loginId);
  }
  clear(providerId?: string) {
    for (const [id, login] of this.pending)
      if (!providerId || login.providerId === providerId) {
        this.requests.get(id)?.abort();
        this.pending.delete(id);
      }
    if (providerId) this.credentials.delete(providerId);
    else this.credentials.clear();
  }
  credential(providerId: string): ClaudeAccountToken | undefined {
    const credential = this.credentials.get(providerId);
    if (credential && credential.expiresAt <= Date.now()) {
      this.credentials.delete(providerId);
      return;
    }
    return credential;
  }
  status(providerId: string) {
    return { authenticated: !!this.credential(providerId) };
  }
  secrets() {
    return [...this.credentials.values()].map((credential) => credential.accessToken);
  }
  close() {
    this.closing = true;
    this.clear();
  }
}
