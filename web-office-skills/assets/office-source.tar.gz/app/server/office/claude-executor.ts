import { access, readFile } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import { OfficeError } from "./errors.ts";
import { claudeCliModelId, isClaudeModelAlias } from "./claude-model-normalization.ts";

export const CLAUDE_REASONING_EFFORTS = ["low", "medium", "high", "xhigh", "max"] as const;
export interface ClaudeImageInput {
  mimeType: "image/png" | "image/jpeg" | "image/webp";
  dataBase64: string;
}
export interface OfficeMcpLaunch {
  command: string;
  args: string[];
  env: Record<string, string>;
}
export interface ClaudeInvocationOptions {
  model: string;
  reasoningEffort?: string | null;
  prompt: string;
  threadId?: string | null;
  sessionId?: string;
  images?: ClaudeImageInput[];
  proxyBaseUrl: string;
  proxyToken: string;
  authMode: "api_key" | "account";
  executionMode: "sandboxed" | "account";
  readOnly?: boolean;
  team?: OfficeMcpLaunch;
  writableDirs?: string[];
}

/** Resolve binaries only; never execute the user's launcher or load its settings/auth. */
export async function resolveClaudeBinary(override?: string, workspaceRoot?: string): Promise<string> {
  let configuredBinary: string | undefined;
  if (workspaceRoot) {
    try {
      const configuration = JSON.parse(await readFile(path.join(workspaceRoot, "workspace.json"), "utf8"));
      if (typeof configuration.cliPaths?.["claude-code"] === "string")
        configuredBinary = configuration.cliPaths["claude-code"];
    } catch {
      // A first installation may not have a local configuration yet.
    }
  }
  const candidates = [
    override,
    process.env.CLAUDE_CLI,
    configuredBinary,
    ...(process.env.PATH ?? "").split(path.delimiter).map((dir) => path.join(dir, "claude")),
  ].filter((candidate): candidate is string => !!candidate && path.isAbsolute(candidate));
  for (const candidate of candidates) {
    try {
      await access(candidate, constants.X_OK);
      return candidate;
    } catch {
      // Try the next installation location without reading any account configuration.
    }
  }
  throw new OfficeError("claude_binary_not_found", 503);
}

/** Secrets are supplied as scoped proxy capabilities in env, never command arguments or settings. */
export function buildClaudeInvocation(options: ClaudeInvocationOptions) {
  if (options.reasoningEffort && !CLAUDE_REASONING_EFFORTS.includes(options.reasoningEffort as never))
    throw new OfficeError("unsupported_reasoning_effort", 409);
  if ((options.images?.length ?? 0) > 4) throw new OfficeError("too_many_attachments", 400);
  const model = claudeCliModelId(options.model);
  const args = [
    "--print",
    "--input-format",
    "stream-json",
    "--output-format",
    "stream-json",
    "--verbose",
    "--include-partial-messages",
    "--setting-sources",
    "",
    "--strict-mcp-config",
    "--no-chrome",
    "--disable-slash-commands",
    "--permission-prompts",
    "none",
    "--model",
    model,
  ];
  // Bare mode deliberately excludes OAuth, so it is only suitable for API proxy runs.
  if (options.authMode === "api_key") args.push("--bare");
  if (options.reasoningEffort) args.push("--effort", options.reasoningEffort);
  if (options.threadId) args.push("--resume", options.threadId);
  else if (options.sessionId) args.push("--session-id", options.sessionId);
  const settings: Record<string, unknown> = {
    disableAllHooks: true,
    autoUpdatesChannel: "stable",
    enableAllProjectMcpServers: false,
    sandbox: {
      enabled: options.executionMode !== "account",
      autoAllowBashIfSandboxed: true,
      allowUnsandboxedCommands: false,
      filesystem: { allowWrite: options.writableDirs ?? [] },
    },
  };
  if (options.readOnly) {
    args.push("--permission-mode", "dontAsk", "--tools", "Read,Glob,Grep");
  } else if (options.executionMode === "account") {
    args.push("--dangerously-skip-permissions");
  } else {
    args.push("--permission-mode", "dontAsk");
  }
  args.push("--settings", JSON.stringify(settings));
  const teamConfig = options.team
    ? {
        command: options.team.command,
        args: options.team.args,
        env: Object.fromEntries(Object.keys(options.team.env).map((key) => [key, "${" + key + "}"])),
      }
    : null;
  args.push(
    "--mcp-config",
    JSON.stringify({ mcpServers: options.readOnly || !teamConfig ? {} : { office: teamConfig } }),
  );
  const content: unknown[] = [{ type: "text", text: options.prompt }];
  for (const image of options.images ?? []) {
    if (
      !["image/png", "image/jpeg", "image/webp"].includes(image.mimeType) ||
      image.dataBase64.length > 7 * 1024 * 1024
    )
      throw new OfficeError("invalid_attachment", 400);
    content.push({ type: "image", source: { type: "base64", media_type: image.mimeType, data: image.dataBase64 } });
  }
  const stdin =
    JSON.stringify({
      type: "user",
      message: { role: "user", content },
      session_id: options.threadId ?? options.sessionId ?? "",
      parent_tool_use_id: null,
    }) + "\n";
  const env: NodeJS.ProcessEnv = {
    ...options.team?.env,
    ANTHROPIC_BASE_URL: options.proxyBaseUrl,
    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1",
    DISABLE_AUTOUPDATER: "1",
    DISABLE_TELEMETRY: "1",
    DISABLE_ERROR_REPORTING: "1",
    ...(options.authMode === "account"
      ? { CLAUDE_CODE_OAUTH_TOKEN: options.proxyToken }
      : { ANTHROPIC_API_KEY: options.proxyToken }),
  };
  if (options.authMode === "api_key" && !isClaudeModelAlias(model)) {
    // A single relay model may stand in for every Claude tier. Keep auxiliary
    // requests and subagents on this identity's selected model rather than
    // silently falling back to a built-in Anthropic model the service lacks.
    Object.assign(env, {
      ANTHROPIC_MODEL: model,
      ANTHROPIC_DEFAULT_SONNET_MODEL: model,
      ANTHROPIC_DEFAULT_OPUS_MODEL: model,
      ANTHROPIC_DEFAULT_HAIKU_MODEL: model,
      ANTHROPIC_DEFAULT_FABLE_MODEL: model,
      ANTHROPIC_SMALL_FAST_MODEL: model,
      CLAUDE_CODE_SUBAGENT_MODEL: model,
      CLAUDE_CODE_NO_MODEL_FALLBACK: "1",
    });
  }
  return { args, stdin, env };
}

type Json = Record<string, unknown>;
const object = (value: unknown): Json =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as Json) : {};
const textContent = (value: unknown): string =>
  typeof value === "string"
    ? value
    : Array.isArray(value)
      ? value
          .map(object)
          .filter((block) => block.type === "text")
          .map((block) => String(block.text ?? ""))
          .join("\n")
      : "";

/** Translate public activity into the existing Codex JSON event shape; omit all thinking payloads. */
export class ClaudeEventParser {
  private tools = new Map<string, Json>();
  private deltas = new Map<string, string>();
  private completedMessages = new Set<string>();
  private assistantSeen = false;
  private streamMessage = "message";
  push(rawLine: string): Json[] {
    let event: Json;
    try {
      event = object(JSON.parse(rawLine));
    } catch {
      return [];
    }
    const output: Json[] = [];
    if (event.type === "system" && event.subtype === "init" && typeof event.session_id === "string") {
      output.push({ type: "thread.started", thread_id: event.session_id }, { type: "turn.started" });
    } else if (event.type === "assistant") {
      const message = object(event.message);
      const blocks = Array.isArray(message.content) ? message.content.map(object) : [];
      const id = String(message.id ?? event.uuid ?? "assistant");
      const text = textContent(blocks);
      if (text && !this.completedMessages.has(id)) {
        this.completedMessages.add(id);
        this.assistantSeen = true;
        output.push({ type: "item.completed", item: { id, type: "agent_message", text } });
        for (const key of this.deltas.keys()) if (key.startsWith(id + ":")) this.deltas.delete(key);
      }
      for (const block of blocks) {
        if (block.type === "thinking" || block.type === "redacted_thinking")
          output.push({ type: "item.started", item: { id: "thinking", type: "reasoning" } });
        if (block.type !== "tool_use") continue;
        const toolId = String(block.id ?? "tool");
        const name = String(block.name ?? "工具");
        const input = object(block.input);
        const item: Json =
          name === "Bash"
            ? {
                id: toolId,
                type: "command_execution",
                command: String(input.command ?? ""),
                status: "in_progress",
                aggregated_output: "",
              }
            : {
                id: toolId,
                type: "mcp_tool_call",
                server: "claude",
                tool: name,
                arguments: input,
                status: "in_progress",
              };
        this.tools.set(toolId, item);
        output.push({ type: "item.started", item });
      }
    } else if (event.type === "user") {
      const message = object(event.message);
      for (const block of Array.isArray(message.content) ? message.content.map(object) : []) {
        if (block.type !== "tool_result") continue;
        const id = String(block.tool_use_id ?? "");
        const item = this.tools.get(id);
        if (!item) continue;
        const text = textContent(block.content).slice(-6000);
        const result = {
          ...item,
          status: block.is_error ? "failed" : "completed",
          ...(item.type === "command_execution"
            ? { aggregated_output: text }
            : { result: { content: [{ type: "text", text }] } }),
        };
        output.push({ type: "item.completed", item: result });
        this.tools.delete(id);
      }
    } else if (event.type === "stream_event") {
      const stream = object(event.event);
      const delta = object(stream.delta);
      if (stream.type === "message_start") {
        this.streamMessage = String(object(stream.message).id ?? "message");
        this.deltas.clear();
      } else if (delta.type === "thinking_delta" || object(stream.content_block).type === "thinking") {
        output.push({ type: "item.started", item: { id: "thinking", type: "reasoning" } });
      } else if (stream.type === "content_block_delta" && delta.type === "text_delta") {
        const key = `${this.streamMessage}:${String(stream.index ?? 0)}`;
        const chunk = ((this.deltas.get(key) ?? "") + String(delta.text ?? "")).slice(-6000);
        if (this.deltas.size < 64 || this.deltas.has(key)) this.deltas.set(key, chunk);
        const text = [...this.deltas.values()].join("\n").slice(-6000);
        output.push({ type: "item.updated", item: { id: this.streamMessage, type: "agent_message", text } });
      }
    } else if (event.type === "result") {
      if (event.is_error || event.subtype !== "success") {
        output.push({ type: "turn.failed", error: { message: "Claude Code 执行失败，请检查模型服务和账户状态" } });
      } else {
        if (!this.assistantSeen && typeof event.result === "string" && event.result) {
          this.assistantSeen = true;
          output.push({ type: "item.completed", item: { id: "result", type: "agent_message", text: event.result } });
        }
        output.push({ type: "turn.completed" });
      }
    }
    return output;
  }
}
