import { constants, type Stats } from "node:fs";
import { createHash, randomUUID } from "node:crypto";
import {
  open,
  lstat,
  realpath,
  readdir,
  readlink,
  unlink,
  mkdir,
  rename,
  rmdir,
  type FileHandle,
} from "node:fs/promises";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import type { DeletedConversationResources } from "./agent-repository.ts";
import { OfficeError } from "./errors.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const AGENT = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/;
const LIMIT = 128 * 1024 * 1024;
type Entry = { relative: string; location: string; parent: FileHandle; name: string; info: Stats };
type Rewrite = { entry: Entry; content: string };
type Metadata = { entry: Entry; ids: string[] };
const quote = (name: string) => '"' + name.replace(/"/g, '""') + '"';
const missing = (error: unknown) => (error as NodeJS.ErrnoException).code === "ENOENT";
function refuse(code = "conversation_cleanup_unsafe_path"): never {
  throw new OfficeError(code, 409);
}
function regular(info: Stats) {
  if (!info.isFile() || info.nlink !== 1) refuse();
}
function identity(a: Stats, b: Stats) {
  return a.dev === b.dev && a.ino === b.ino;
}
const anchor = (handle: FileHandle) => `/proc/self/fd/${handle.fd}`;

/** Pins each parent directory and refuses all symlink/hardlink traversal, including inside-root aliases. */
class CleanupScope {
  private handles = new Map<string, FileHandle>();
  constructor(private paths: WorkspacePaths) {}
  async directory(relative: string, create = false): Promise<FileHandle | undefined> {
    if (this.handles.has(relative)) return this.handles.get(relative);
    if (process.platform !== "linux" || !constants.O_NOFOLLOW || !constants.O_DIRECTORY)
      refuse("conversation_cleanup_platform_unsupported");
    if (!relative) {
      if (path.resolve(this.paths.root) !== this.paths.root || (await realpath(this.paths.root)) !== this.paths.root)
        refuse();
      const handle = await open(this.paths.root, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
      this.handles.set("", handle);
      return handle;
    }
    if (path.isAbsolute(relative) || relative.split(path.sep).some((part) => !part || part === "." || part === ".."))
      refuse();
    const parentRelative = path.dirname(relative) === "." ? "" : path.dirname(relative);
    const parent = await this.directory(parentRelative, create);
    if (!parent) return;
    const location = path.join(anchor(parent), path.basename(relative));
    try {
      if (create) {
        try {
          await mkdir(location, { mode: 0o700 });
        } catch (error) {
          if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
        }
      }
      const handle = await open(location, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
      const info = await handle.stat();
      if (!info.isDirectory() || (await realpath(anchor(handle))) !== path.join(this.paths.root, relative)) {
        await handle.close();
        refuse();
      }
      this.handles.set(relative, handle);
      return handle;
    } catch (error) {
      if (missing(error)) return;
      throw error;
    }
  }
  async file(relative: string): Promise<Entry | undefined> {
    const parentRelative = path.dirname(relative) === "." ? "" : path.dirname(relative);
    const parent = await this.directory(parentRelative);
    if (!parent) return;
    const name = path.basename(relative);
    const location = path.join(anchor(parent), name);
    try {
      const info = await lstat(location);
      regular(info);
      return { relative, location, parent, name, info };
    } catch (error) {
      if (missing(error)) return;
      throw error;
    }
  }
  async unchanged(entry: Entry) {
    const info = await lstat(entry.location);
    regular(info);
    if (
      !identity(info, entry.info) ||
      info.size !== entry.info.size ||
      info.mtimeMs !== entry.info.mtimeMs ||
      info.ctimeMs !== entry.info.ctimeMs
    )
      refuse("conversation_cleanup_file_changed");
    if ((await realpath(anchor(entry.parent))) !== path.dirname(path.join(this.paths.root, entry.relative))) refuse();
  }
  async read(entry: Entry): Promise<string> {
    if (entry.info.size > LIMIT) refuse("conversation_cleanup_metadata_too_large");
    const handle = await open(entry.location, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    try {
      const info = await handle.stat();
      regular(info);
      if (!identity(info, entry.info)) refuse("conversation_cleanup_file_changed");
      const content = await handle.readFile("utf8");
      await this.unchanged(entry);
      return content;
    } finally {
      await handle.close();
    }
  }
  async rewrite(entry: Entry, content: string) {
    await this.unchanged(entry);
    const temporary = path.join(anchor(entry.parent), `.cleanup-${randomUUID()}.tmp`);
    const handle = await open(
      temporary,
      constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
      0o600,
    );
    try {
      await handle.writeFile(content, "utf8");
      await handle.sync();
      await this.unchanged(entry);
      const temporaryInfo = await lstat(temporary);
      regular(temporaryInfo);
      if (!identity(temporaryInfo, await handle.stat())) refuse();
      await rename(temporary, entry.location);
      await entry.parent.sync();
    } finally {
      await handle.close();
      await unlink(temporary).catch((error) => {
        if (!missing(error)) throw error;
      });
    }
  }
  async remove(entry: Entry) {
    await this.unchanged(entry);
    await unlink(entry.location);
    await entry.parent.sync();
  }
  async names(relative: string): Promise<string[]> {
    const handle = await this.directory(relative);
    return handle ? readdir(anchor(handle)) : [];
  }
  async close() {
    await Promise.allSettled([...this.handles.values()].reverse().map((handle) => handle.close()));
  }
}

function removeJsonlRecords(content: string, ids: Set<string>) {
  let changed = false;
  const lines = content.split("\n");
  const kept: string[] = [];
  for (const line of lines) {
    if (!line.trim()) {
      kept.push(line);
      continue;
    }
    let value: Record<string, unknown>;
    try {
      value = JSON.parse(line) as Record<string, unknown>;
      if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
    } catch {
      refuse("conversation_cleanup_unknown_metadata_format");
    }
    const identityKeys = ["session_id", "sessionId", "thread_id", "threadId", "id"];
    const values = identityKeys.filter((key) => typeof value[key] === "string").map((key) => value[key] as string);
    if (!values.length) refuse("conversation_cleanup_unknown_metadata_format");
    if (values.some((id) => ids.has(id))) changed = true;
    else kept.push(line);
  }
  return changed ? kept.join("\n") : null;
}

/** Plan only exact rows; quote discovered schema identifiers and bind every thread value. */
function sqliteOperations(db: DatabaseSync, ids: string[]) {
  const operations: Array<{ sql: string; values: string[] }> = [];
  const placeholders = ids.map(() => "?").join(",");
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
  let knownThreadTable = false;
  for (const tableRow of tables) {
    const table = String(tableRow.name);
    const columns = db.prepare(`PRAGMA table_info(${quote(table)})`).all();
    const names = columns.map((column) => String(column.name));
    const canonical = table === "threads" || table === "sessions";
    const identityColumns = names.filter((name) =>
      /^(?:thread_id|threadId|session_id|sessionId|parent_thread_id|child_thread_id|last_checked_thread_id)$/.test(
        name,
      ),
    );
    if (canonical) {
      const key = names.includes("id")
        ? "id"
        : names.includes("thread_id")
          ? "thread_id"
          : names.includes("session_id")
            ? "session_id"
            : null;
      if (!key) refuse("conversation_cleanup_unknown_metadata_schema");
      knownThreadTable = true;
      operations.push({ sql: `DELETE FROM ${quote(table)} WHERE ${quote(key)} IN (${placeholders})`, values: ids });
      if (names.includes("attached_thread_parent_id"))
        operations.push({
          sql: `UPDATE ${quote(table)} SET "attached_thread_parent_id"=NULL WHERE "attached_thread_parent_id" IN (${placeholders})`,
          values: ids,
        });
      continue;
    }
    if (identityColumns.length) {
      operations.push({
        sql: `DELETE FROM ${quote(table)} WHERE ${identityColumns.map((column) => `${quote(column)} IN (${placeholders})`).join(" OR ")}`,
        values: identityColumns.flatMap(() => ids),
      });
    } else {
      // Unknown metadata must not silently retain a deleted session's embedded context.
      // Fail closed if target identity occurs in an unrecognized table/payload.
      for (const column of columns) {
        const name = String(column.name);
        if (!/TEXT|BLOB|CHAR|CLOB|^$/i.test(String(column.type))) continue;
        const query = db.prepare(`SELECT 1 FROM ${quote(table)} WHERE instr(CAST(${quote(name)} AS TEXT),?)>0 LIMIT 1`);
        if (ids.some((id) => query.get(id))) refuse("conversation_cleanup_unknown_metadata_schema");
      }
    }
  }
  if (!knownThreadTable) refuse("conversation_cleanup_unknown_metadata_schema");
  // Delete auxiliary rows first; foreign key CASCADE also handles current known schemas.
  return operations.sort(
    (a, b) =>
      Number(/^DELETE FROM "(?:threads|sessions)" /.test(a.sql)) -
      Number(/^DELETE FROM "(?:threads|sessions)" /.test(b.sql)),
  );
}

async function sqliteMetadata(scope: CleanupScope, metadata: Metadata, apply: boolean) {
  const entry = metadata.entry;
  await scope.unchanged(entry);
  // Anchor both directory and main file. Verify the descriptor opened by SQLite
  // belongs to the prechecked inode before permitting any database mutation.
  const pinned = await open(entry.location, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  let db: DatabaseSync | undefined;
  try {
    regular(await pinned.stat());
    const before = new Map<string, string>();
    for (const fd of await readdir("/proc/self/fd")) {
      try {
        before.set(fd, await readlink(`/proc/self/fd/${fd}`));
      } catch (error) {
        if (!missing(error)) throw error;
      }
    }
    db = new DatabaseSync(entry.location, { readOnly: !apply });
    const databaseFile = String(
      db
        .prepare("PRAGMA database_list")
        .all()
        .find((row) => row.name === "main")?.file ?? "",
    );
    if ((await realpath(databaseFile)) !== (await realpath(entry.location))) refuse();
    let verified = false;
    for (const fd of await readdir("/proc/self/fd")) {
      if (!/^\d+$/.test(fd)) continue;
      try {
        const target = await readlink(`/proc/self/fd/${fd}`);
        if (before.get(fd) === target) continue;
        if (target !== path.join(await realpath(anchor(entry.parent)), entry.name)) continue;
        // /proc entries themselves are symlinks; open their pinned target for fstat.
        const opened = await open(`/proc/self/fd/${fd}`, constants.O_RDONLY | constants.O_NONBLOCK);
        try {
          const actual = await opened.stat();
          regular(actual);
          if (!identity(actual, entry.info)) refuse();
          verified = true;
        } finally {
          await opened.close();
        }
      } catch (error) {
        if (missing(error)) continue;
        throw error;
      }
    }
    if (!verified) refuse("conversation_cleanup_sqlite_descriptor_unverified");
    await scope.unchanged(entry);
    db.exec("PRAGMA trusted_schema=OFF; PRAGMA busy_timeout=5000");
    const operations = sqliteOperations(db, metadata.ids);
    if (!apply) return;
    db.exec("PRAGMA secure_delete=ON; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; BEGIN IMMEDIATE");
    try {
      for (const operation of operations) db.prepare(operation.sql).run(...operation.values);
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    const checkpoint = db.prepare("PRAGMA wal_checkpoint(TRUNCATE)").get();
    if (checkpoint && Number(checkpoint.busy ?? 0) !== 0) refuse("conversation_cleanup_checkpoint_busy");
  } finally {
    db?.close();
    await pinned.close();
  }
}

/** Only invoke after the host has reserved these exact, no-longer-shared resources. Idempotent on retry. */
export async function purgeConversationFiles(
  paths: WorkspacePaths,
  agentId: string,
  plan: DeletedConversationResources,
  layoutVersion: 1 | 2 = 1,
): Promise<{ removedFiles: number }> {
  if (
    !AGENT.test(agentId) ||
    !plan ||
    !Array.isArray(plan.nativeThreads) ||
    !Array.isArray(plan.runIds) ||
    !Array.isArray(plan.attachments)
  )
    refuse("invalid_conversation_cleanup_plan");
  for (const thread of plan.nativeThreads)
    if (
      !UUID.test(thread.threadId) ||
      (thread.providerId !== null && !UUID.test(thread.providerId)) ||
      !["codex", "claude-code"].includes(thread.executor)
    )
      refuse("invalid_conversation_cleanup_plan");
  if (
    plan.runIds.some((id) => !UUID.test(id)) ||
    plan.attachments.some((attachment) => attachment.agentId !== agentId || !UUID.test(attachment.id))
  )
    refuse("invalid_conversation_cleanup_plan");
  const scope = new CleanupScope(paths);
  const removals = new Map<string, Entry>();
  const rewrites: Rewrite[] = [];
  const metadata: Metadata[] = [];
  const directories: Array<{ relative: string; parent: FileHandle; info: Stats }> = [];
  const idsByRoot = new Map<string, Set<string>>();
  let scanned = 0;
  const add = async (relative: string) => {
    const entry = await scope.file(relative);
    if (entry) removals.set(relative, entry);
  };
  const walk = async (relative: string, ids: Set<string>, owned = false, depth = 0): Promise<void> => {
    if (depth > 20) refuse("conversation_cleanup_tree_too_deep");
    const dir = await scope.directory(relative);
    if (!dir) return;
    for (const name of await scope.names(relative)) {
      if (++scanned > 100000) refuse("conversation_cleanup_tree_too_large");
      const candidate = path.join(relative, name);
      const info = await lstat(path.join(anchor(dir), name));
      if (info.isSymbolicLink()) refuse();
      const matches = [...ids].some(
        (id) =>
          name === id || name.startsWith(id + ".") || name.startsWith(id + "-") || name.endsWith("-" + id + ".jsonl"),
      );
      const unknownTargetName = [...ids].some((id) => {
        const index = name.indexOf(id);
        return (
          index >= 0 &&
          (index === 0 || name[index - 1] === "-") &&
          (index + id.length === name.length || [".", "-"].includes(name[index + id.length]))
        );
      });
      if (!owned && unknownTargetName && (!matches || (info.isDirectory() && !ids.has(name))))
        refuse("conversation_cleanup_unknown_native_format");
      if (info.isDirectory()) {
        const selected = owned || ids.has(name);
        await walk(candidate, ids, selected, depth + 1);
        if (selected) directories.push({ relative: candidate, parent: dir, info });
      } else if (owned || matches) {
        regular(info);
        if (!owned && !/\.(jsonl|json|sh|md|txt)$/.test(name)) refuse("conversation_cleanup_unknown_native_format");
        await add(candidate);
      }
    }
  };
  try {
    const journalDirectory = await scope.directory(path.join("state", "conversation-cleanup"), true);
    if (!journalDirectory) refuse();
    const fingerprint = createHash("sha256").update(JSON.stringify({ agentId, plan })).digest("hex");
    const journalName = fingerprint + ".json";
    const journalPath = path.join(anchor(journalDirectory), journalName);
    const journalContent = JSON.stringify({ version: 1, agentId, plan }) + "\n";
    try {
      const journal = await open(
        journalPath,
        constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW,
        0o600,
      );
      try {
        await journal.writeFile(journalContent, "utf8");
        await journal.sync();
      } finally {
        await journal.close();
      }
      await journalDirectory.sync();
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      const existing = await scope.file(path.join("state", "conversation-cleanup", journalName));
      if (!existing || (await scope.read(existing)) !== journalContent) refuse("conversation_cleanup_journal_conflict");
    }
    for (const thread of plan.nativeThreads) {
      const roots =
        thread.executor === "codex"
          ? [
              layoutVersion === 2
                ? path.join("agents", agentId, "sessions", "codex")
                : path.join("state", "codex", agentId),
              ...(thread.providerId ? [path.join("state", "account-services", thread.providerId, "codex")] : []),
            ]
          : [
              layoutVersion === 2
                ? path.join("agents", agentId, "sessions", "claude")
                : path.join("state", "claude", agentId),
            ];
      for (const root of roots) {
        const ids = idsByRoot.get(root) ?? new Set<string>();
        ids.add(thread.threadId);
        idsByRoot.set(root, ids);
      }
    }
    for (const [root, ids] of idsByRoot) {
      if (!(await scope.directory(root))) continue;
      const claude =
        root.includes(path.join("sessions", "claude")) || root.startsWith(path.join("state", "claude") + path.sep);
      const directories = claude
        ? ["projects", "file-history", "todos", "tasks", "session-env"]
        : ["sessions", "archived_sessions", "shell_snapshots", "memories", "threads"];
      for (const directory of directories) await walk(path.join(root, directory), ids);
      for (const name of ["history.jsonl", "session_index.jsonl"]) {
        const entry = await scope.file(path.join(root, name));
        if (!entry) continue;
        const content = removeJsonlRecords(await scope.read(entry), ids);
        if (content !== null) rewrites.push({ entry, content });
      }
      if (!claude)
        for (const name of await scope.names(root)) {
          if (!/^state_\d+\.sqlite$/.test(name)) continue;
          const entry = await scope.file(path.join(root, name));
          if (!entry) continue;
          for (const suffix of ["-wal", "-shm", "-journal"]) await scope.file(path.join(root, name + suffix));
          metadata.push({ entry, ids: [...ids] });
        }
    }
    for (const attachment of plan.attachments)
      for (const extension of ["json", "png", "jpg", "webp"])
        await add(
          layoutVersion === 2
            ? path.join("agents", agentId, "profile", "attachments", `${attachment.id}.${extension}`)
            : path.join("agents", agentId, "attachments", `${attachment.id}.${extension}`),
        );
    for (const runId of plan.runIds) await add(path.join("logs", `${runId}.log`));
    const resume = await scope.file(
      layoutVersion === 2
        ? path.join("agents", agentId, "profile", "resume.md")
        : path.join("agents", agentId, "resume.md"),
    );
    if (resume && plan.runIds.length) {
      const content = await scope.read(resume);
      const ids = new Set(plan.runIds);
      const sections = content.split(/(?=^## )/m);
      const kept = sections
        .filter((section) => {
          const heading = section.split("\n", 1)[0];
          const match = /^## [^\r\n]* · ([0-9a-f-]{36})\s*$/i.exec(heading);
          return !match || !ids.has(match[1]);
        })
        .join("");
      if (kept !== content) rewrites.push({ entry: resume, content: kept });
    }
    // Validate every candidate and schema before performing the first removal.
    for (const entry of removals.values()) await scope.unchanged(entry);
    for (const value of metadata) await sqliteMetadata(scope, value, false);
    for (const value of metadata) await sqliteMetadata(scope, value, true);
    for (const rewrite of rewrites) await scope.rewrite(rewrite.entry, rewrite.content);
    let removedFiles = 0;
    for (const entry of removals.values()) {
      await scope.remove(entry);
      removedFiles++;
    }
    for (const directory of directories) {
      const location = path.join(anchor(directory.parent), path.basename(directory.relative));
      const info = await lstat(location);
      if (!info.isDirectory() || info.isSymbolicLink() || !identity(info, directory.info)) refuse();
      await rmdir(location);
      await directory.parent.sync();
    }
    await unlink(journalPath);
    await journalDirectory.sync();
    return { removedFiles };
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    throw new OfficeError("conversation_cleanup_failed_retry_required", 409);
  } finally {
    await scope.close();
  }
}
