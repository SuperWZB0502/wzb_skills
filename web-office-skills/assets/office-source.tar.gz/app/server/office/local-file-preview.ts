import { constants } from "node:fs";
import { lstat, open, realpath } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";
import type { LocalTextPreview } from "../../shared/office-contracts.ts";
import { OfficeError } from "./errors.ts";
import { resolveLocalDirectoryPath } from "./local-file-browser.ts";

const TEXT_LIMIT = 256 * 1024;
const IMAGE_LIMIT = 20 * 1024 * 1024;
const PIXEL_LIMIT = 20_000_000;

type PreviewType =
  | { kind: "markdown" | "text" }
  | { kind: "image"; format: "png" | "jpeg" | "webp"; contentType: string };

const markdown = { kind: "markdown" } as const;
const text = { kind: "text" } as const;
const jpeg = { kind: "image", format: "jpeg", contentType: "image/jpeg" } as const;
const formats = new Map<string, PreviewType>([
  [".md", markdown], [".markdown", markdown], [".txt", text], [".sh", text],
  [".jpg", jpeg], [".jpeg", jpeg],
  [".png", { kind: "image", format: "png", contentType: "image/png" }],
  [".webp", { kind: "image", format: "webp", contentType: "image/webp" }],
]);

export function localPreviewType(name: string): PreviewType | undefined {
  return formats.get(path.extname(name).toLowerCase());
}

function animatedPng(data: Buffer) {
  for (let offset = 8; offset + 12 <= data.length;) {
    const length = data.readUInt32BE(offset);
    const name = data.toString("ascii", offset + 4, offset + 8);
    if (name === "acTL") return true;
    if (name === "IDAT" || length > data.length - offset - 12) break;
    offset += length + 12;
  }
  return false;
}

export async function readLocalFilePreview(root: string, input: unknown, expected: "text" | "image"):
  Promise<LocalTextPreview | { kind: "image"; data: Buffer; contentType: string }> {
  const target = resolveLocalDirectoryPath(root, input);
  const type = localPreviewType(target);
  if (!type || (expected === "image") !== (type.kind === "image"))
    throw new OfficeError("local_preview_unsupported", 415);
  try {
    if (!(await lstat(target)).isFile()) throw new OfficeError("local_preview_unsupported", 415);
    const canonical = await realpath(target);
    resolveLocalDirectoryPath(root, canonical);
    if (localPreviewType(canonical) !== type) throw new OfficeError("local_preview_unsupported", 415);
    const file = await open(canonical, constants.O_RDONLY | (process.platform === "win32" ? 0 : constants.O_NONBLOCK));
    try {
      const info = await file.stat();
      if (!info.isFile()) throw new OfficeError("local_preview_unsupported", 415);
      if (type.kind === "image" && info.size > IMAGE_LIMIT) throw new OfficeError("local_preview_too_large", 413);
      const limit = type.kind === "image" ? IMAGE_LIMIT : TEXT_LIMIT;
      const buffer = Buffer.allocUnsafe(Math.min(info.size, limit + 1));
      let offset = 0;
      while (offset < buffer.length) {
        const { bytesRead } = await file.read(buffer, offset, buffer.length - offset, offset);
        if (!bytesRead) break;
        offset += bytesRead;
      }
      const data = buffer.subarray(0, offset);
      if (type.kind !== "image") {
        const truncated = info.size > TEXT_LIMIT;
        const content = new TextDecoder("utf-8", { fatal: true }).decode(data.subarray(0, TEXT_LIMIT), { stream: truncated });
        if (content.includes("\0")) throw new OfficeError("local_preview_unsupported", 415);
        return { kind: type.kind, text: content, truncated };
      }
      const metadata = await sharp(data, { limitInputPixels: PIXEL_LIMIT, animated: true }).metadata();
      if (metadata.format !== type.format || !metadata.width || !metadata.height)
        throw new OfficeError("local_preview_unsupported", 415);
      if (metadata.width * metadata.height > PIXEL_LIMIT || (metadata.pages ?? 1) > 1 ||
          (type.format === "png" && animatedPng(data)))
        throw new OfficeError("local_preview_too_large", 413);
      return { kind: "image", data, contentType: type.contentType };
    } finally {
      await file.close();
    }
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    const code = (error as NodeJS.ErrnoException).code;
    if (code === "ENOENT") throw new OfficeError("local_directory_missing", 404);
    if (code === "EACCES" || code === "EPERM") throw new OfficeError("local_directory_denied", 403);
    throw new OfficeError("local_preview_unsupported", 415);
  }
}
