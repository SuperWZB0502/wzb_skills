import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { OfficeError } from "./errors.ts";
import { snapshotProcessTree, signalProcessIdentities } from "./process-tree.ts";
import type { OfficeMcpLaunch } from "./claude-executor.ts";

type Json = Record<string, unknown>;
const object = (value: unknown): Json =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as Json) : {};
interface RpcCall {
  resolve(value: Json): void;
  reject(error: Error): void;
  timeout: ReturnType<typeof setTimeout>;
}
interface ActiveTurn {
  turnId: string | null;
  cancelled: boolean;
  onStarted(): void;
  onEvent(event: Json): void;
  finish(error?: Error): void;
  items: Map<string, Json>;
}
export interface CodexAccountDriverOptions {
  binary?: string;
  home: string;
  codexHome: string;
  tmpDir: string;
  onFailure?(): void;
}
export interface CodexAccountRunOptions {
  threadId?: string | null;
  model: string;
  reasoningEffort?: string | null;
  cwd: string;
  prompt: string;
  imagePaths?: string[];
  executionMode: "sandboxed" | "account";
  readOnly?: boolean;
  writableRoots?: string[];
  shellEnvironment?: Record<string, string>;
  team?: OfficeMcpLaunch;
  signal?: AbortSignal;
  onEvent(event: Json): void;
}

/** One official-account app-server per service, multiplexing independent agent threads. */
export class CodexAccountDriver {
  private child?: ChildProcessWithoutNullStreams;
  private ready?: Promise<void>;
  private closing = false;
  private sequence = 0;
  private calls = new Map<number, RpcCall>();
  private turns = new Map<string, ActiveTurn>();
  private pendingLoginId?: string;
  private authenticated = false;
  private loginFailure = false;
  constructor(private options: CodexAccountDriverOptions) {}

  private async initialize() {
    if (this.closing) throw new OfficeError("runtime_stopping", 409);
    return (this.ready ??= this.launch().catch((error) => {
      this.ready = undefined;
      throw error;
    }));
  }
  private async launch() {
    await Promise.all(
      [this.options.home, this.options.codexHome, this.options.tmpDir].map((dir) =>
        mkdir(dir, { recursive: true, mode: 0o700 }),
      ),
    );
    if (this.closing) throw new OfficeError("runtime_stopping", 409);
    const child = spawn(
      this.options.binary ?? "codex",
      [
        "-c",
        'cli_auth_credentials_store="ephemeral"',
        "-c",
        'approval_policy="never"',
        "-c",
        'model_provider="openai"',
        "-c",
        "suppress_unstable_features_warning=true",
        ...(process.platform === "win32" ? ["-c", 'windows.sandbox="unelevated"'] : []),
        "app-server",
      ],
      {
        cwd: this.options.home,
        env: {
          PATH: process.env.PATH,
          LANG: "C.UTF-8",
          HOME: this.options.home,
          ...(process.platform === "win32" ? {
            SystemRoot: process.env.SystemRoot,
            ComSpec: process.env.ComSpec,
            PATHEXT: process.env.PATHEXT,
            USERPROFILE: this.options.home,
          } : {}),
          CODEX_HOME: this.options.codexHome,
          TMPDIR: this.options.tmpDir,
          TMP: this.options.tmpDir,
          TEMP: this.options.tmpDir,
          XDG_CONFIG_HOME: path.join(this.options.home, ".config"),
          XDG_CACHE_HOME: path.join(this.options.home, ".cache"),
          XDG_STATE_HOME: path.join(this.options.home, ".state"),
          XDG_DATA_HOME: path.join(this.options.home, ".data"),
          NO_COLOR: "1",
        },
        stdio: ["pipe", "pipe", "pipe"],
        detached: process.platform !== "win32",
      },
    );
    this.child = child;
    let pending = "";
    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      pending += chunk;
      if (pending.length > 8 * 1024 * 1024) {
        pending = "";
        this.fail(new OfficeError("account_protocol_overflow", 502));
        child.kill("SIGKILL");
        return;
      }
      let offset: number;
      while ((offset = pending.indexOf("\n")) >= 0) {
        const line = pending.slice(0, offset);
        pending = pending.slice(offset + 1);
        try {
          this.receive(object(JSON.parse(line)));
        } catch {
          /* Never log raw app-server output or credentials. */
        }
      }
    });
    child.stderr.resume();
    child.stdin.on("error", () => {});
    child.once("error", () => this.fail(new OfficeError("codex_account_spawn_failed", 503)));
    child.once("close", () => {
      if (this.child !== child) return;
      this.child = undefined;
      this.ready = undefined;
      this.fail(new OfficeError("codex_account_closed", 503));
    });
    try {
      await this.rpc("initialize", {
        clientInfo: { name: "personal_web_office", title: "Personal Web Office", version: "1.0.0" },
        capabilities: {},
      });
      this.send({ method: "initialized", params: {} });
    } catch (error) {
      if (this.child === child) this.child = undefined;
      child.kill("SIGKILL");
      throw error;
    }
  }
  private send(value: Json) {
    if (!this.child || this.child.stdin.destroyed) throw new OfficeError("codex_account_closed", 503);
    this.child.stdin.write(JSON.stringify(value) + "\n");
  }
  private rpc(method: string, params: Json, timeoutMs = 30000): Promise<Json> {
    if (this.closing) return Promise.reject(new OfficeError("runtime_stopping", 409));
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.calls.delete(id);
        reject(new OfficeError("account_request_timeout", 504));
      }, timeoutMs);
      this.calls.set(id, { resolve, reject, timeout });
      try {
        this.send({ id, method, params });
      } catch (error) {
        clearTimeout(timeout);
        this.calls.delete(id);
        reject(error);
      }
    });
  }
  private fail(error: Error) {
    this.authenticated = false;
    this.pendingLoginId = undefined;
    for (const call of this.calls.values()) {
      clearTimeout(call.timeout);
      call.reject(error);
    }
    this.calls.clear();
    for (const active of this.turns.values()) active.finish(error);
    this.turns.clear();
    if (!this.closing) this.options.onFailure?.();
  }
  private receive(message: Json) {
    if (typeof message.id === "number" && !message.method) {
      const call = this.calls.get(message.id);
      if (!call) return;
      this.calls.delete(message.id);
      clearTimeout(call.timeout);
      if (message.error) call.reject(new OfficeError("account_request_failed", 502));
      else call.resolve(object(message.result));
      return;
    }
    const method = String(message.method ?? "");
    const params = object(message.params);
    // This web UI never implicitly approves interactive requests from an account session.
    if (message.id !== undefined) {
      if (method.endsWith("/requestApproval")) this.send({ id: message.id, result: { decision: "decline" } });
      else
        this.send({
          id: message.id,
          error: { code: -32601, message: "Interactive requests are unavailable in this session" },
        });
      return;
    }
    if (method === "account/login/completed") {
      if (params.loginId === this.pendingLoginId) {
        this.authenticated = params.success === true;
        this.loginFailure = params.success !== true;
        this.pendingLoginId = undefined;
      }
      return;
    }
    if (method === "account/updated") {
      if (params.authMode === null) this.authenticated = false;
      return;
    }
    const threadId = typeof params.threadId === "string" ? params.threadId : "";
    const active = this.turns.get(threadId);
    if (!active) return;
    const incomingTurnId = typeof params.turnId === "string" ? params.turnId : String(object(params.turn).id ?? "");
    if (active.turnId && incomingTurnId && active.turnId !== incomingTurnId) return;
    if (method === "turn/started") {
      active.turnId = String(object(params.turn).id ?? incomingTurnId);
      active.onEvent({ type: "turn.started" });
      active.onStarted();
    } else if (method === "item/started" || method === "item/completed") {
      const item = this.item(object(params.item));
      if (!item) return;
      if (method === "item/completed") active.items.delete(String(item.id));
      else if (active.items.size < 512) active.items.set(String(item.id), item);
      active.onEvent({ type: method === "item/started" ? "item.started" : "item.completed", item });
    } else if (method === "item/agentMessage/delta") {
      const id = String(params.itemId ?? "message");
      const previous = active.items.get(id);
      const item = {
        id,
        type: "agent_message",
        text: (String(previous?.text ?? "") + String(params.delta ?? "")).slice(-6000),
      };
      if (active.items.size < 512 || active.items.has(id)) active.items.set(id, item);
      active.onEvent({ type: "item.updated", item });
    } else if (method === "item/commandExecution/outputDelta") {
      const id = String(params.itemId ?? "command");
      const previous = active.items.get(id);
      if (previous) {
        const item = {
          ...previous,
          aggregated_output: (String(previous.aggregated_output ?? "") + String(params.delta ?? "")).slice(-6000),
        };
        active.items.set(id, item);
        active.onEvent({ type: "item.updated", item });
      }
    } else if (method.startsWith("item/reasoning/")) {
      active.onEvent({ type: "item.started", item: { id: String(params.itemId ?? "reasoning"), type: "reasoning" } });
    } else if (method === "turn/completed") {
      const turn = object(params.turn);
      if (turn.status === "failed" && !active.cancelled) {
        active.onEvent({ type: "turn.failed", error: { message: "Codex 账户执行失败，请检查账户与模型状态" } });
        active.finish(new OfficeError("codex_account_run_failed", 502));
      } else {
        active.onEvent({ type: "turn.completed" });
        active.finish();
      }
    } else if (method === "error" && params.willRetry !== true) {
      if (active.cancelled) return; // Only turn/completed proves an interrupted turn has ended.
      active.onEvent({ type: "turn.failed", error: { message: "Codex 账户执行失败，请检查账户与模型状态" } });
      active.finish(new OfficeError("codex_account_run_failed", 502));
    }
  }
  private item(item: Json): Json | null {
    const id = String(item.id ?? "item");
    const status = item.status === "inProgress" ? "in_progress" : item.status;
    switch (item.type) {
      case "agentMessage":
        return { id, type: "agent_message", text: String(item.text ?? "") };
      case "reasoning":
        return { id, type: "reasoning" };
      case "commandExecution":
        return {
          id,
          type: "command_execution",
          command: String(item.command ?? ""),
          aggregated_output: String(item.aggregatedOutput ?? "").slice(-6000),
          status,
        };
      case "fileChange":
        return { id, type: "file_change", status, changes: item.changes };
      case "mcpToolCall":
        return {
          id,
          type: "mcp_tool_call",
          status,
          server: item.server,
          tool: item.tool,
          arguments: item.arguments,
          result: item.result,
        };
      case "webSearch":
        return { id, type: "web_search", query: String(item.query ?? "") };
      default:
        return null;
    }
  }
  async startLogin(): Promise<{ loginId: string; verificationUrl: string; userCode: string }> {
    await this.initialize();
    if (this.pendingLoginId) await this.cancelLogin(this.pendingLoginId);
    const result = await this.rpc("account/login/start", { type: "chatgptDeviceCode" });
    if (
      result.type !== "chatgptDeviceCode" ||
      typeof result.loginId !== "string" ||
      typeof result.verificationUrl !== "string" ||
      typeof result.userCode !== "string"
    )
      throw new OfficeError("account_login_response_invalid", 502);
    const url = new URL(result.verificationUrl);
    if (url.protocol !== "https:" || !["auth.openai.com", "openai.com", "chatgpt.com"].includes(url.hostname))
      throw new OfficeError("account_login_response_invalid", 502);
    this.pendingLoginId = result.loginId;
    this.loginFailure = false;
    return { loginId: result.loginId, verificationUrl: result.verificationUrl, userCode: result.userCode };
  }
  async loginStatus(): Promise<{ authenticated: boolean; pending: boolean; failed: boolean; email?: string }> {
    if (!this.child || !this.ready) return { authenticated: false, pending: false, failed: this.loginFailure };
    await this.ready;
    const result = await this.rpc("account/read", { refreshToken: false });
    const account = object(result.account);
    this.authenticated = account.type === "chatgpt";
    return {
      authenticated: this.authenticated,
      pending: !!this.pendingLoginId,
      failed: this.loginFailure,
      ...(typeof account.email === "string" ? { email: account.email } : {}),
    };
  }
  async cancelLogin(loginId: string) {
    await this.initialize();
    if (loginId !== this.pendingLoginId) throw new OfficeError("login_not_found", 404);
    await this.rpc("account/login/cancel", { loginId });
    this.pendingLoginId = undefined;
  }
  async listModels(): Promise<Json[]> {
    await this.initialize();
    if (!(await this.loginStatus()).authenticated) throw new OfficeError("account_login_required", 409);
    const output: Json[] = [];
    let cursor: string | null = null;
    for (let page = 0; page < 10; page++) {
      const result = await this.rpc("model/list", { cursor, limit: 100, includeHidden: false });
      if (!Array.isArray(result.data)) throw new OfficeError("account_model_response_invalid", 502);
      output.push(...result.data.slice(0, 100).map(object));
      cursor = typeof result.nextCursor === "string" ? result.nextCursor : null;
      if (!cursor) break;
    }
    return output;
  }
  async execute(options: CodexAccountRunOptions) {
    await this.initialize();
    if (options.signal?.aborted) throw new OfficeError("run_cancelled", 409);
    const status = await this.loginStatus();
    if (!status.authenticated) throw new OfficeError("account_login_required", 409);
    if (options.threadId && this.turns.has(options.threadId)) throw new OfficeError("conversation_busy", 409);
    const config: Json = {
      cli_auth_credentials_store: "ephemeral",
      model_provider: "openai",
      approval_policy: "never",
      "mcp_servers.office":
        options.readOnly || !options.team
          ? { enabled: false }
          : {
              ...options.team,
              default_tools_approval_mode: "auto",
              tools: { office_request_git_commit: { approval_mode: "approve" } },
            },
      "sandbox_workspace_write.writable_roots": options.writableRoots ?? [options.cwd],
      "sandbox_workspace_write.exclude_slash_tmp": true,
      "sandbox_workspace_write.exclude_tmpdir_env_var": true,
      "sandbox_workspace_write.network_access": false,
      ...(options.shellEnvironment ? { "shell_environment_policy.set": options.shellEnvironment } : {}),
    };
    const sandbox = options.readOnly
      ? "read-only"
      : options.executionMode === "account"
        ? "danger-full-access"
        : "workspace-write";
    const response = await this.rpc(options.threadId ? "thread/resume" : "thread/start", {
      ...(options.threadId ? { threadId: options.threadId, excludeTurns: true } : { ephemeral: false }),
      model: options.model,
      modelProvider: "openai",
      cwd: options.cwd,
      approvalPolicy: "never",
      sandbox,
      config,
    });
    const threadId = String(object(response.thread).id ?? "");
    if (!threadId) throw new OfficeError("account_thread_response_invalid", 502);
    if (this.turns.has(threadId)) throw new OfficeError("conversation_busy", 409);
    let resolveDone!: () => void;
    let rejectDone!: (error: Error) => void;
    const done = new Promise<void>((resolve, reject) => {
      resolveDone = resolve;
      rejectDone = reject;
    });
    // The RPC can fail before the caller receives this promise; mark it handled immediately.
    void done.catch(() => {});
    let finished = false;
    let cancelRequested = false;
    let markStarted!: () => void;
    const started = new Promise<void>((resolve) => {
      markStarted = resolve;
    });
    const active: ActiveTurn = {
      turnId: null,
      cancelled: false,
      onStarted: () => {},
      onEvent: options.onEvent,
      items: new Map(),
      finish: (error) => {
        if (finished) return;
        finished = true;
        this.turns.delete(threadId);
        options.signal?.removeEventListener("abort", onAbort);
        if (error) rejectDone(error);
        else resolveDone();
      },
    };
    this.turns.set(threadId, active);
    let stopAttempt: Promise<void> | undefined;
    const abort = (): Promise<void> => {
      if (finished) return Promise.resolve();
      if (stopAttempt) return stopAttempt;
      active.cancelled = true;
      cancelRequested = true;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const interruptAndWait = async () => {
        await started;
        if (finished) return;
        if (active.turnId)
          await Promise.race([done, this.rpc("turn/interrupt", { threadId, turnId: active.turnId }, 8000)]);
        // RPC acceptance is not task completion: retain the live record until its terminal notification.
        await done;
      };
      const attempt = Promise.race([
        interruptAndWait(),
        new Promise<void>((_, reject) => {
          timer = setTimeout(() => reject(new OfficeError("stop_timeout", 503)), 8000);
        }),
      ]).finally(() => {
        if (timer) clearTimeout(timer);
      });
      stopAttempt = attempt;
      void attempt.catch(() => {
        if (stopAttempt === attempt) stopAttempt = undefined;
      });
      return attempt;
    };
    const onAbort = () => {
      // A failed/slow interrupt never marks the turn finished or releases its per-thread queue.
      void abort().catch(() => {});
    };
    active.onStarted = () => {
      if (active.cancelled && active.turnId && !finished)
        void this.rpc("turn/interrupt", { threadId, turnId: active.turnId }, 8000).catch(() => {});
    };
    options.signal?.addEventListener("abort", onAbort, { once: true });
    try {
      if (options.signal?.aborted) throw new OfficeError("run_cancelled", 409);
      options.onEvent({ type: "thread.started", thread_id: threadId });
      const result = await this.rpc("turn/start", {
        threadId,
        input: [
          { type: "text", text: options.prompt },
          ...(options.imagePaths ?? []).map((image) => ({ type: "localImage", path: image })),
        ],
        model: options.model,
        effort: options.reasoningEffort ?? null,
        cwd: options.cwd,
        approvalPolicy: "never",
        summary: "none",
        sandboxPolicy: options.readOnly
          ? { type: "readOnly" }
          : options.executionMode === "account"
            ? { type: "dangerFullAccess" }
            : {
                type: "workspaceWrite",
                writableRoots: options.writableRoots ?? [options.cwd],
                networkAccess: false,
                excludeSlashTmp: true,
                excludeTmpdirEnvVar: true,
              },
      });
      active.turnId = String(object(result.turn).id ?? active.turnId ?? "");
      markStarted();
      if (!active.turnId) throw new OfficeError("account_turn_response_invalid", 502);
      if (cancelRequested || options.signal?.aborted) void abort().catch(() => {});
      return { threadId, done, abort };
    } catch (error) {
      markStarted();
      if (
        !finished &&
        error instanceof OfficeError &&
        ["account_request_timeout", "account_turn_response_invalid"].includes(error.code)
      ) {
        // A timed-out start may still execute remotely. Keep the thread registered
        // even before its first acknowledgement so late lifecycle events remain owned.
        if (cancelRequested || options.signal?.aborted) void abort().catch(() => {});
        return { threadId, done, abort };
      }
      if (active.turnId && !finished) {
        // The server announced this turn before a delayed/failed start response.
        // Preserve its execution handle; an interrupt error cannot prove it ended.
        void abort().catch(() => {});
        return { threadId, done, abort };
      }
      active.finish(error instanceof Error ? error : new OfficeError("codex_account_run_failed", 502));
      throw error;
    }
  }
  async close() {
    if (this.closing) return;
    this.closing = true;
    const child = this.child;
    this.fail(new OfficeError("runtime_stopping", 409));
    if (!child?.pid) return;
    const identities = await snapshotProcessTree(child.pid).catch(() => []);
    child.stdin.end();
    await signalProcessIdentities(identities, "SIGTERM").catch(() => {});
    child.kill("SIGTERM");
    await new Promise<void>((resolve) => {
      if (child.exitCode !== null || child.signalCode !== null) return resolve();
      const timer = setTimeout(resolve, 1500);
      child.once("close", () => {
        clearTimeout(timer);
        resolve();
      });
    });
    await signalProcessIdentities(identities, "SIGKILL").catch(() => {});
    if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    this.child = undefined;
  }
}
