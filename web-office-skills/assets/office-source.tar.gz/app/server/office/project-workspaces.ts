import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { mkdir, open, stat, unlink } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { OfficeError } from "./errors.ts";
import { safeWrite } from "./safe-io.ts";
import { snapshotProcessTree, signalProcessIdentities, type ProcessIdentity } from "./process-tree.ts";
import { resolveWorkspacePath, type WorkspacePaths } from "./workspace-paths.ts";

const execute = promisify(execFile);
const preparing = new Map<string, Promise<string>>();
function descendant(parent: string, candidate: string): boolean {
  const relative = path.relative(parent, candidate);
  return relative !== "" && relative !== ".." && !relative.startsWith(".." + path.sep) && !path.isAbsolute(relative);
}
async function projectsPath(paths: WorkspacePaths, input: string): Promise<string> {
  const canonical = await resolveWorkspacePath(paths, input);
  if (!descendant(paths.projects, canonical)) throw new OfficeError("project_path_required", 403);
  return canonical;
}
function checkAbort(signal?: AbortSignal): void {
  if (signal?.aborted) throw new OfficeError("project_preparation_cancelled", 409);
}
async function git(paths: WorkspacePaths, directory: string, args: string[], signal?: AbortSignal): Promise<string> {
  checkAbort(signal);
  const childAbort = new AbortController();
  const pending = execute(
    "git",
    [
      "--no-pager",
      "-c",
      "core.hooksPath=/dev/null",
      "-c",
      "core.fsmonitor=false",
      "-c",
      "submodule.recurse=false",
      "-c",
      "fetch.recurseSubmodules=false",
      "-c",
      "checkout.recurseSubmodules=false",
      "-c",
      "credential.helper=",
      "-C",
      directory,
      ...args,
    ],
    {
      encoding: "utf8",
      maxBuffer: 8 * 1024 * 1024,
      signal: childAbort.signal,
      timeout: 0,
      killSignal: "SIGKILL",
      env: {
        PATH: process.env.PATH,
        LANG: process.env.LANG ?? "C.UTF-8",
        HOME: path.join(paths.state, "git-home"),
        TMPDIR: paths.tmp,
        XDG_CONFIG_HOME: path.join(paths.state, "git-home"),
        XDG_CACHE_HOME: path.join(paths.cache, "git"),
        GIT_CONFIG_NOSYSTEM: "1",
        GIT_CONFIG_GLOBAL: "/dev/null",
        GIT_TERMINAL_PROMPT: "0",
        GIT_OPTIONAL_LOCKS: "0",
        GIT_CEILING_DIRECTORIES: paths.projects,
      },
    },
  );
  const identities = new Map<string, ProcessIdentity>();
  let rootStarted: string | undefined;
  let sampling: Promise<void> | undefined;
  let stopReason: "cancelled" | "timeout" | undefined;
  let stopping: Promise<void> | undefined;
  let stopFailure: unknown;
  const sample = (): Promise<void> => {
    if (sampling) return sampling;
    const pid = pending.child.pid;
    if (!pid) return Promise.resolve();
    const current = snapshotProcessTree(pid, rootStarted).then((found) => {
      const root = found.find((identity) => identity.pid === pid);
      if (!root || (rootStarted !== undefined && root.started !== rootStarted)) return;
      rootStarted ??= root.started;
      for (const identity of found) identities.set(identity.pid + ":" + identity.started, identity);
    });
    sampling = current;
    void current
      .finally(() => {
        if (sampling === current) sampling = undefined;
      })
      .catch(() => {});
    return current;
  };
  const stop = (reason: "cancelled" | "timeout"): Promise<void> => {
    if (stopping) return stopping;
    stopReason = reason;
    stopping = (async () => {
      try {
        if (sampling) await sampling;
        await sample();
      } catch (error) {
        stopFailure = error;
      }
      // Collect descendants while the parent's PPID chain still exists. The
      // private signal prevents execFile from killing it before this snapshot.
      childAbort.abort();
      try {
        await signalProcessIdentities([...identities.values()], "SIGKILL");
      } catch (error) {
        stopFailure = error;
      }
    })();
    return stopping;
  };
  const finishStop = async (): Promise<void> => {
    await stopping;
    // A periodic scan may have collected another descendant during shutdown.
    try {
      await sampling;
    } catch (error) {
      stopFailure = error;
    }
    try {
      await signalProcessIdentities([...identities.values()], "SIGKILL");
    } catch (error) {
      stopFailure = error;
    }
    if (stopFailure) throw new OfficeError("project_git_stop_failed", 503);
  };
  const abort = () => {
    void stop("cancelled");
  };
  const timer = setTimeout(() => {
    void stop("timeout");
  }, 5000);
  const sampler = setInterval(() => {
    void sample().catch(() => {});
  }, 250);
  timer.unref();
  sampler.unref();
  void sample().catch(() => {});
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) abort();
  try {
    const { stdout } = await pending;
    if (stopping) await stopping;
    if (stopReason)
      throw new OfficeError(
        stopReason === "timeout" ? "project_git_timeout" : "project_preparation_cancelled",
        stopReason === "timeout" ? 503 : 409,
      );
    checkAbort(signal);
    return stdout.trim();
  } catch (error) {
    if (stopping) await stopping;
    if (stopReason)
      throw new OfficeError(
        stopReason === "timeout" ? "project_git_timeout" : "project_preparation_cancelled",
        stopReason === "timeout" ? 503 : 409,
      );
    checkAbort(signal);
    const failure = error as { killed?: boolean; signal?: string };
    if (failure.killed || failure.signal === "SIGKILL") {
      await stop("timeout");
      throw new OfficeError("project_git_timeout", 503);
    }
    throw error;
  } finally {
    clearTimeout(timer);
    clearInterval(sampler);
    signal?.removeEventListener("abort", abort);
    if (stopping) await finishStop();
  }
}

async function hasConfig(
  paths: WorkspacePaths,
  directory: string,
  pattern: string,
  signal?: AbortSignal,
): Promise<boolean> {
  try {
    return Boolean(await git(paths, directory, ["config", "--includes", "--null", "--get-regexp", pattern], signal));
  } catch (error) {
    if ((error as { code?: unknown }).code === 1) return false;
    throw error;
  }
}
async function checkProgramConfig(paths: WorkspacePaths, directory: string, signal?: AbortSignal): Promise<void> {
  if (await hasConfig(paths, directory, /^filter\..*\.(clean|smudge|process)$/.source, signal))
    throw new OfficeError("project_git_filters_unsupported", 409);
  // A condition inactive in the source can activate filters in the new worktree.
  // Refuse that context switch rather than executing an unchecked checkout.
  if (await hasConfig(paths, directory, /^includeif\..*\.path$/.source, signal))
    throw new OfficeError("project_git_conditional_config_unsupported", 409);
}
async function metadataPath(paths: WorkspacePaths, input: string): Promise<string> {
  try {
    return await projectsPath(paths, input);
  } catch {
    throw new OfficeError("project_git_external_metadata", 403);
  }
}
async function commonDirectory(
  paths: WorkspacePaths,
  directory: string,
  signal?: AbortSignal,
): Promise<string | undefined> {
  let common: string;
  try {
    common = await git(paths, directory, ["rev-parse", "--path-format=absolute", "--git-common-dir"], signal);
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    const failure = error as { code?: number | string; stderr?: string };
    if (failure.code === 128 && failure.stderr?.includes("not a git repository")) return undefined;
    throw new OfficeError(
      failure.code === "ENOENT" ? "git_unavailable" : "project_git_invalid",
      failure.code === "ENOENT" ? 503 : 409,
    );
  }
  const canonical = await metadataPath(paths, path.resolve(directory, common));
  const gitDir = await git(paths, directory, ["rev-parse", "--absolute-git-dir"], signal);
  await metadataPath(paths, gitDir);
  // Worktree creation writes here; a valid common-dir must not hide an outside admin alias.
  await metadataPath(paths, path.join(canonical, "worktrees"));
  for (const name of ["HEAD", "refs", "objects", "config", "packed-refs"])
    await metadataPath(paths, path.join(canonical, name));
  const top = await git(paths, directory, ["rev-parse", "--show-toplevel"], signal);
  await metadataPath(paths, top);
  return canonical;
}
async function exists(directory: string): Promise<boolean> {
  try {
    await stat(directory);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}
interface WorktreeCompletion {
  version: 1;
  project: string;
  agentId: string;
  common: string;
  target: string;
}
async function validCompletion(filename: string, expected: WorktreeCompletion): Promise<boolean> {
  try {
    const handle = await open(filename, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    try {
      const info = await handle.stat();
      if (!info.isFile() || info.nlink !== 1 || info.size > 16384) return false;
      const actual = JSON.parse(await handle.readFile("utf8")) as Partial<WorktreeCompletion> | null;
      return (
        actual !== null &&
        Object.entries(expected).every(([key, value]) => actual[key as keyof WorktreeCompletion] === value)
      );
    } finally {
      await handle.close();
    }
  } catch {
    return false;
  }
}
async function prepareGit(
  paths: WorkspacePaths,
  project: string,
  agentId: string,
  common: string,
  signal?: AbortSignal,
): Promise<string> {
  checkAbort(signal);
  await checkProgramConfig(paths, project, signal);
  const hash = createHash("sha256").update(project).digest("hex").slice(0, 12);
  const intended = path.join(paths.projects, ".worktrees", hash, agentId);
  const target = await projectsPath(paths, intended);
  if (target !== intended) throw new OfficeError("project_worktree_alias", 403);
  const targetExists = await exists(target);
  const intendedMarker = path.join(paths.state, "worktrees", hash, agentId + ".json");
  let marker: string;
  try {
    marker = await resolveWorkspacePath(paths, intendedMarker);
    if (marker !== intendedMarker) throw new OfficeError("project_worktree_marker_invalid", 403);
  } catch (error) {
    if (targetExists) throw new OfficeError("project_worktree_incomplete", 409);
    throw error;
  }
  const completion: WorktreeCompletion = { version: 1, project, agentId, common, target };
  if (targetExists) {
    if (!(await validCompletion(marker, completion))) throw new OfficeError("project_worktree_incomplete", 409);
    const actual = await commonDirectory(paths, target, signal);
    if (actual !== common) throw new OfficeError("project_worktree_conflict", 409);
    const top = await git(paths, target, ["rev-parse", "--show-toplevel"], signal);
    if (path.resolve(top) !== target) throw new OfficeError("project_worktree_conflict", 409);
    return target;
  }
  await checkProgramConfig(paths, project, signal);
  const dirty = await git(
    paths,
    project,
    ["status", "--porcelain=v1", "--untracked-files=normal", "--ignore-submodules=all"],
    signal,
  );
  if (dirty) throw new OfficeError("project_source_dirty", 409);
  checkAbort(signal);
  await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
  await checkProgramConfig(paths, project, signal);
  // A previously removed tree must not reuse an old completion marker if this
  // creation is interrupted before checkout finishes. Preserve the worktree itself.
  try {
    await unlink(marker);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  try {
    await git(paths, project, ["worktree", "add", "--detach", "--", target, "HEAD"], signal);
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    throw new OfficeError("project_worktree_create_failed", 409);
  }
  if ((await commonDirectory(paths, target, signal)) !== common)
    throw new OfficeError("project_worktree_conflict", 409);
  const preparedTop = await git(paths, target, ["rev-parse", "--show-toplevel"], signal);
  if (path.resolve(preparedTop) !== target) throw new OfficeError("project_worktree_conflict", 409);
  await git(paths, target, ["rev-parse", "--verify", "HEAD"], signal);
  checkAbort(signal);
  await mkdir(path.dirname(marker), { recursive: true, mode: 0o700 });
  await safeWrite(paths, marker, JSON.stringify(completion) + "\n");
  return target;
}
/** Explicit Git projects get durable per-agent detached worktrees; ordinary folders stay shared. */
export async function prepareProjectWorkspace(
  paths: WorkspacePaths,
  agentId: string,
  projectPath?: string,
  signal?: AbortSignal,
  defaultWorkDir?: string,
): Promise<string> {
  checkAbort(signal);
  if (typeof agentId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(agentId))
    throw new OfficeError("invalid_agent_id");
  const requestedDefault = defaultWorkDir ?? path.join(paths.projects, agentId);
  const resolvedDefault = defaultWorkDir
    ? await resolveWorkspacePath(paths, defaultWorkDir)
    : await projectsPath(paths, requestedDefault);
  const project = projectPath ? await projectsPath(paths, projectPath) : resolvedDefault;
  if (projectPath === undefined && project !== requestedDefault) throw new OfficeError("project_worktree_alias", 403);
  checkAbort(signal);
  await mkdir(project, { recursive: true, mode: 0o700 });
  if (projectPath === undefined) return project;
  const common = await commonDirectory(paths, project, signal);
  if (!common) return project;
  try {
    await git(paths, project, ["rev-parse", "--verify", "HEAD"], signal);
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    if ((error as { code?: unknown }).code !== 128) throw new OfficeError("project_git_invalid", 409);
    return project;
  }
  const key = project + "\0" + agentId;
  const active = preparing.get(key);
  if (active) {
    if (!signal) return active;
    return new Promise<string>((resolve, reject) => {
      const abort = () => reject(new OfficeError("project_preparation_cancelled", 409));
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted) abort();
      void active.then(resolve, reject).finally(() => signal.removeEventListener("abort", abort));
    });
  }
  const pending = prepareGit(paths, project, agentId, common, signal);
  preparing.set(key, pending);
  try {
    return await pending;
  } finally {
    if (preparing.get(key) === pending) preparing.delete(key);
  }
}
