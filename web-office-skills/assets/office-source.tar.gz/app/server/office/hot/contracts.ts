import type { AgentProfile, TaskRuntimeEvent, ReleaseManifest } from "../../../shared/office-contracts.ts";
import type { PolicyPort } from "../policy-port.ts";
export type HotModuleName = "agent-summary" | "role-prompts";
export type HotModule =
  | { runtimeAbi: 1; name: "agent-summary"; summarize(event: TaskRuntimeEvent): string }
  | { runtimeAbi: 1; name: "role-prompts"; rolePrompt(profile: AgentProfile): string };
export interface HotRegistry extends PolicyPort {
  prepare(releaseDir: string, manifest: ReleaseManifest): Promise<{ id: string }>;
  activate(id: string): Promise<void>;
  discard(id: string): Promise<void>;
  activeVersion(): string;
  close(): Promise<void>;
}
