import { Worker } from "node:worker_threads";
import { OfficeError } from "../errors.ts";
export interface PolicyWorker {
  readonly threadId: number;
  readonly exited: Promise<number>;
  call(method: string, value: unknown): Promise<string>;
  close(): Promise<void>;
}
export async function createPolicyWorker(modules: Record<string, string>, timeoutMs = 2500): Promise<PolicyWorker> {
  const worker = new Worker(new URL("./worker-entry.mjs", import.meta.url), {
    workerData: { modules },
    env: {},
    execArgv: [],
    resourceLimits: { maxOldGenerationSizeMb: 48 },
  });
  const exited = new Promise<number>((resolve) => worker.once("exit", resolve));
  const threadId = worker.threadId;
  const pending = new Map<
    number,
    { resolve: (v: string) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> }
  >();
  let next = 0,
    dead = false;
  const fail = () => {
    dead = true;
    for (const p of pending.values()) {
      clearTimeout(p.timer);
      p.reject(new OfficeError("hot_worker_unavailable", 503));
    }
    pending.clear();
  };
  worker.on("error", fail);
  worker.on("exit", fail);
  try {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        cleanup();
        reject(new OfficeError("hot_candidate_timeout"));
      }, timeoutMs);
      const onError = () => {
        cleanup();
        reject(new OfficeError("hot_candidate_failed"));
      };
      const onMessage = (m: { ready?: boolean }) => {
        if (m.ready === undefined) return;
        cleanup();
        if(m.ready) resolve(); else reject(new OfficeError("hot_candidate_failed"));
      };
      const cleanup = () => {
        clearTimeout(timer);
        worker.off("message", onMessage);
        worker.off("error", onError);
        worker.off("exit", onError);
      };
      worker.on("message", onMessage);
      worker.once("error", onError);
      worker.once("exit", onError);
    });
  } catch (error) {
    await worker.terminate();
    throw error;
  }
  worker.on("message", (m: { id: number; result: string; error?: string }) => {
    const p = pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    clearTimeout(p.timer);
    if(m.error) p.reject(new OfficeError("hot_policy_failed")); else p.resolve(m.result);
  });
  return {
    threadId,
    exited,
    call(method, value) {
      if (dead) return Promise.reject(new OfficeError("hot_worker_unavailable", 503));
      return new Promise((resolve, reject) => {
        const id = ++next;
        const timer = setTimeout(() => {
          pending.delete(id);
          reject(new OfficeError("hot_policy_timeout", 503));
          void worker.terminate();
        }, timeoutMs);
        pending.set(id, { resolve, reject, timer });
        worker.postMessage({ id, method, value });
      });
    },
    async close() {
      fail();
      await worker.terminate();
    },
  };
}
