import { parentPort, workerData } from "node:worker_threads";
import { pathToFileURL } from "node:url";
const modules = {};
try {
  for (const [name, file] of Object.entries(workerData.modules)) {
    const mod = await import(pathToFileURL(file).href),
      method = name === "agent-summary" ? "summarize" : "rolePrompt";
    if (mod.runtimeAbi !== 1 || mod.name !== name || typeof mod[method] !== "function")
      throw Error("invalid_hot_module");
    const sample =
      name === "agent-summary"
        ? {
            seq: 0,
            eventId: "probe",
            agentId: "probe",
            taskId: null,
            runId: null,
            state: "idle",
            summary: "ready",
            at: 0,
          }
        : {
            id: "probe",
            name: "Probe",
            jobFunction: "developer",
            isBoss: false,
            gender: "",
            spriteNumber: null,
            providerId: null,
            model: null,
            reasoningEffort: null,
            credentialState: "required",
            credentialSlotId: null,
            workState: "idle",
            currentTaskId: null,
            currentWorkSummary: "",
          };
    const first = mod[method](sample),
      second = mod[method](sample);
    if (typeof first !== "string" || first !== second) throw Error("invalid_hot_result");
    modules[method] = mod[method];
  }
  parentPort.postMessage({ ready: true });
  parentPort.on("message", ({ id, method, value }) => {
    try {
      const result = modules[method](value);
      if (typeof result !== "string") throw Error();
      parentPort.postMessage({ id, result });
    } catch {
      parentPort.postMessage({ id, error: "hot_policy_failed" });
    }
  });
} catch {
  parentPort.postMessage({ ready: false, error: "hot_candidate_failed" });
  parentPort.close();
}
