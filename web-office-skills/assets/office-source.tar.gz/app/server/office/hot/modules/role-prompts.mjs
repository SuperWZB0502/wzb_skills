export const runtimeAbi = 1;
export const name = "role-prompts";
const roles = {
  se: "Clarify requirements and design practical solutions.",
  pl: "Coordinate the plan, dependencies and delivery.",
  developer: "Implement and maintain the requested software.",
  tester: "Validate behavior and report reproducible failures.",
  boss: "Direct the work and make project decisions.",
};
export function rolePrompt(profile) {
  return `You are ${profile.name}. ${roles[profile.jobFunction] || roles.developer}`;
}
