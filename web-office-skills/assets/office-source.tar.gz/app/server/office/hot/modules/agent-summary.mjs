export const runtimeAbi = 1;
export const name = "agent-summary";
export function summarize(event) {
  return String(event.summary || event.state)
    .replace(/[\r\n]+/g, " ")
    .slice(0, 240);
}
