import path from "node:path";
import { fileURLToPath } from "node:url";
import type { WorkspacePaths } from "../workspace-paths.ts";
import { resolveWorkspacePath } from "../workspace-paths.ts";
import { OfficeError } from "../errors.ts";
import type { HotRegistry } from "./contracts.ts";
import { createPolicyWorker, type PolicyWorker } from "./worker-host.ts";
export type { HotRegistry } from "./contracts.ts";
interface Generation {
  id: string;
  worker: PolicyWorker;
  modules: Record<string, string>;
  refs: number;
}
export async function createHotRegistry(paths: WorkspacePaths): Promise<HotRegistry> {
  const defaults = Object.fromEntries(
    ["agent-summary", "role-prompts"].map((name) => [
      name,
      fileURLToPath(new URL(`./modules/${name}.mjs`, import.meta.url)),
    ]),
  );
  let active: Generation = { id: "builtin-v1", worker: await createPolicyWorker(defaults), modules: defaults, refs: 0 };
  const generations = new Set<Generation>([active]),
    prepared = new Map<string, Generation>();
  const preparingIds = new Set<string>();
  const preparations = new Set<Promise<{ id: string }>>();
  let closed = false;
  const drain = (g: Generation) => {
    if (g !== active && g.refs === 0 && !prepared.has(g.id)) {
      generations.delete(g);
      void g.worker.close();
    }
  };
  return {
    acquire() {
      if (closed) throw new OfficeError("hot_registry_closed");
      const g = active;
      g.refs++;
      let released = false;
      const call = (method: string, value: unknown) =>
        released ? Promise.reject(new OfficeError("policy_lease_released")) : g.worker.call(method, value);
      return {
        version: g.id,
        summarize: (event) => call("summarize", event),
        rolePrompt: (profile) => call("rolePrompt", profile),
        release() {
          if (released) return;
          released = true;
          g.refs--;
          drain(g);
        },
      };
    },
    async prepare(releaseDir, manifest) {
      if (closed || prepared.has(manifest.id) || preparingIds.has(manifest.id))
        throw new OfficeError("hot_candidate_conflict");
      if (manifest.runtimeAbi !== 1 || manifest.schemaVersion !== 1) throw new OfficeError("incompatible_abi");
      preparingIds.add(manifest.id);
      const preparation = (async () => {
        try {
          const modules = { ...active.modules };
          for (const name of manifest.hotModules) {
            if (!["agent-summary", "role-prompts"].includes(name)) throw new OfficeError("invalid_hot_module");
            modules[name] = await resolveWorkspacePath(paths, path.join(releaseDir, "hot", `${name}.mjs`));
          }
          if (closed) throw new OfficeError("hot_registry_closed");
          const worker = await createPolicyWorker(modules);
          if (closed) {
            await worker.close();
            throw new OfficeError("hot_registry_closed");
          }
          const g = { id: manifest.id, worker, modules, refs: 0 };
          prepared.set(manifest.id, g);
          generations.add(g);
          return { id: manifest.id };
        } finally {
          preparingIds.delete(manifest.id);
        }
      })();
      preparations.add(preparation);
      try {
        return await preparation;
      } finally {
        preparations.delete(preparation);
      }
    },
    async activate(id) {
      const g = prepared.get(id);
      if (!g) throw new OfficeError("hot_candidate_missing");
      const old = active;
      active = g;
      prepared.delete(id);
      drain(old);
    },
    async discard(id) {
      const g = prepared.get(id);
      if (g) {
        prepared.delete(id);
        generations.delete(g);
        await g.worker.close();
      }
    },
    activeVersion() {
      return active.id;
    },
    async close() {
      closed = true;
      prepared.clear();
      await Promise.allSettled([...preparations]);
      await Promise.all([...generations].map((g) => g.worker.close()));
      generations.clear();
    },
  };
}
