/**
 * Browser-shell switches that the office exposes to the web UI.
 *
 * Both default to ON because they are the requested behaviour; set the environment variable to
 * `0/false/off/no` to fall back to the previous UI (a plain browser confirm, and no restart
 * entry point). Values are read when the runtime starts, so a change needs a restart.
 */

export interface UiFeatures {
  /** Site-styled confirm dialog for "压缩上下文" instead of `window.confirm`. */
  compactConfirm: boolean;
  /** Header entry that restarts the runtime through the workspace CLI. */
  restart: boolean;
}

const off = (value: string | undefined) => ["0", "false", "off", "no"].includes(String(value ?? "1").toLowerCase());

export function uiFeatures(env: NodeJS.ProcessEnv = process.env): UiFeatures {
  return {
    compactConfirm: !off(env.OFFICE_FEATURE_UI_COMPACT_CONFIRM),
    restart: !off(env.OFFICE_FEATURE_UI_RESTART),
  };
}
