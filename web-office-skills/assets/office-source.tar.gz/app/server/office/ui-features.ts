/**
 * Browser capabilities that the office exposes to the web UI.
 *
 * Compact confirmation and restart default to ON; set the environment variable to
 * `0/false/off/no` to fall back to the previous UI (a plain browser confirm, and no restart
 * entry point). Values are read when the runtime starts, so a change needs a restart.
 */

export interface UiFeatures {
  /** Site-styled confirm dialog for "压缩上下文" instead of `window.confirm`. */
  compactConfirm: boolean;
  /** Header entry that restarts the runtime through the workspace CLI. */
  restart: boolean;
  localFileBrowser: boolean;
  localFileWrite: boolean;
}

const off = (value: string | undefined) => ["0", "false", "off", "no"].includes(String(value ?? "1").toLowerCase());

export function uiFeatures(env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform): UiFeatures {
  const windows = platform === "win32";
  return {
    compactConfirm: !off(env.OFFICE_FEATURE_UI_COMPACT_CONFIRM),
    restart: !off(env.OFFICE_FEATURE_UI_RESTART),
    localFileBrowser: windows,
    localFileWrite: windows,
  };
}
