import path from "node:path";
import { createReadStream } from "node:fs";
import { lstat, realpath } from "node:fs/promises";
import type { Response } from "express";
import { OfficeError } from "./errors.ts";

/** Deliverables are read straight from the agent project workspace, never from runtime state. */
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const MAX_PATH_LENGTH = 512;
const AGENT_ID = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/;
const MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  svg: "image/svg+xml",
  pdf: "application/pdf",
  html: "text/html; charset=utf-8",
  htm: "text/html; charset=utf-8",
  css: "text/css; charset=utf-8",
  js: "text/javascript; charset=utf-8",
  mjs: "text/javascript; charset=utf-8",
  json: "application/json; charset=utf-8",
  txt: "text/plain; charset=utf-8",
  md: "text/markdown; charset=utf-8",
  csv: "text/csv; charset=utf-8",
  log: "text/plain; charset=utf-8",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ppt: "application/vnd.ms-powerpoint",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  doc: "application/msword",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  xls: "application/vnd.ms-excel",
  zip: "application/zip",
  mp4: "video/mp4",
  webm: "video/webm",
  mp3: "audio/mpeg",
  wav: "audio/wav",
};
const INLINE_IMAGES = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);
export type FileMode = "download" | "inline" | "view";

export interface AgentFile {
  absolute: string;
  relative: string;
  name: string;
  size: number;
  extension: string;
}

export function requireAgentWorkspaceId(agentId: string): string {
  if (typeof agentId !== "string" || !AGENT_ID.test(agentId)) throw new OfficeError("invalid_agent_id");
  return agentId;
}

/** Reject traversal, absolute paths, hidden segments and control characters before touching the disk. */
export function normalizeRelativeFile(input: unknown): string {
  if (typeof input !== "string") throw new OfficeError("invalid_file_path");
  const value = input.trim();
  if (!value || value.length > MAX_PATH_LENGTH) throw new OfficeError("invalid_file_path");
  if (value.includes("\0") || value.includes("\\")) throw new OfficeError("invalid_file_path");
  if (value.startsWith("/") || /^[a-zA-Z]:/.test(value)) throw new OfficeError("file_outside_workspace", 403);
  const segments = value.split("/");
  // A leading "./" is what assistants commonly write; anything else hidden or relative is refused.
  while (segments[0] === ".") segments.shift();
  if (
    !segments.length ||
    segments.some((segment) => !segment || segment === "." || segment === ".." || segment.startsWith("."))
  )
    throw new OfficeError("file_outside_workspace", 403);
  return segments.join("/");
}

function notFound(): never {
  throw new OfficeError("file_not_found", 404);
}

/**
 * Resolve `relative` inside the agent project workspace only. Symlinked parents or
 * final targets that escape the workspace are rejected after realpath resolution.
 */
export async function resolveAgentFile(workspaceRoot: string, input: unknown): Promise<AgentFile> {
  const relative = normalizeRelativeFile(input);
  let root: string;
  try {
    root = await realpath(workspaceRoot);
  } catch {
    throw new OfficeError("agent_workspace_missing", 404);
  }
  const target = path.join(root, ...relative.split("/"));
  let real: string;
  try {
    real = await realpath(target);
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code === "ENOENT" || code === "ENOTDIR") notFound();
    if (code === "ELOOP") throw new OfficeError("file_symlink_loop", 403);
    throw new OfficeError("file_read_failed", 500);
  }
  const inside = path.relative(root, real);
  if (!inside || inside.startsWith("..") || path.isAbsolute(inside))
    throw new OfficeError("file_outside_workspace", 403);
  let info;
  try {
    info = await lstat(real);
  } catch {
    notFound();
  }
  if (!info.isFile()) throw new OfficeError("file_not_regular", 403);
  if (info.size > MAX_FILE_BYTES) throw new OfficeError("file_too_large", 413);
  const name = path.basename(real);
  return {
    absolute: real,
    relative: inside.split(path.sep).join("/"),
    name,
    size: info.size,
    extension: path.extname(name).slice(1).toLowerCase(),
  };
}

export function mimeForFile(file: AgentFile): string {
  return MIME[file.extension] ?? "application/octet-stream";
}

/** Generated HTML is isolated: no same-origin scripting against the office API, no outbound requests. */
export function viewSecurityHeaders(file: AgentFile): Record<string, string> {
  const mime = mimeForFile(file);
  if (mime.startsWith("text/html"))
    return {
      "Content-Security-Policy":
        "sandbox allow-scripts allow-popups allow-forms; default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'none'; form-action 'none'; base-uri 'none'",
    };
  if (mime === "image/svg+xml")
    return { "Content-Security-Policy": "sandbox; default-src 'none'; style-src 'unsafe-inline'" };
  return {};
}

export function dispositionFor(file: AgentFile, mode: FileMode): "inline" | "attachment" {
  if (mode === "view") return "inline";
  if (mode === "inline" && INLINE_IMAGES.has(mimeForFile(file))) return "inline";
  return "attachment";
}

export function contentDisposition(file: AgentFile, mode: FileMode): string {
  const kind = dispositionFor(file, mode);
  const encoded = encodeURIComponent(file.name).replace(
    /['()]/g,
    (character) => "%" + character.charCodeAt(0).toString(16).toUpperCase(),
  );
  return `${kind}; filename*=UTF-8''${encoded}`;
}

/** Stream a validated file with explicit headers; never follows a path again after validation. */
export function sendAgentFile(res: Response, file: AgentFile, mode: FileMode): void {
  res.status(200);
  res.setHeader("Content-Type", mimeForFile(file));
  res.setHeader("Content-Length", String(file.size));
  res.setHeader("Content-Disposition", contentDisposition(file, mode));
  res.setHeader("Cache-Control", "no-store");
  for (const [name, value] of Object.entries(viewSecurityHeaders(file))) res.setHeader(name, value);
  const stream = createReadStream(file.absolute);
  stream.on("error", () => {
    if (!res.headersSent) res.status(500).json({ error: "file_read_failed" });
    else res.destroy();
  });
  stream.pipe(res);
}

export function parseFileMode(input: unknown): FileMode {
  return input === "view" || input === "inline" ? input : "download";
}
