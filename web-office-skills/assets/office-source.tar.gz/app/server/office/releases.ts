import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash, randomUUID } from "node:crypto";
import { gunzipSync } from "node:zlib";
import { cp, lstat, mkdir, readFile, readdir, rename, rm, writeFile } from "node:fs/promises";
import type { ReleaseManifest } from "../../shared/office-contracts.ts";
import { OfficeError } from "./errors.ts";
import { resolveWorkspacePath, type WorkspacePaths } from "./workspace-paths.ts";
import type { HotRegistry } from "./hot/contracts.ts";
export interface ReleaseResult {
  id: string;
  previousId: string | null;
  bootId: string;
  status: "active" | "rejected";
  reason?: "restart_required" | "incompatible_abi" | "invalid_files" | "candidate_failed";
}
export interface ReleaseManager {
  stage(bundlePath: string): Promise<ReleaseManifest>;
  apply(id: string): Promise<ReleaseResult>;
  rollback(id: string): Promise<ReleaseResult>;
  active(): { manifest: ReleaseManifest; frontendDir: string };
}
const hotNames = ["agent-summary", "role-prompts"] as const;
const sha = (data: Buffer | string) => createHash("sha256").update(data).digest("hex");
function safeRelative(name: string) {
  if (
    !name ||
    name.includes("\\") ||
    name.includes("\0") ||
    path.posix.isAbsolute(name) ||
    name.split("/").some((p) => p === ".." || p === "." || p === "")
  )
    throw new OfficeError("invalid_files");
  return name;
}
async function tree(dir: string, prefix = ""): Promise<Map<string, Buffer>> {
  const files = new Map<string, Buffer>();
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    safeRelative(rel);
    const full = path.join(dir, e.name);
    if (e.isSymbolicLink()) throw new OfficeError("invalid_files");
    if (e.isDirectory()) {
      for (const [k, v] of await tree(full, rel)) files.set(k, v);
    } else if (e.isFile()) files.set(rel, await readFile(full));
    else throw new OfficeError("invalid_files");
  }
  return files;
}
/** Parse only regular ustar files/directories; links and extension headers are rejected before writing. */
function untar(input: Buffer) {
  const data = gunzipSync(input, { maxOutputLength: 128 * 1024 * 1024 }),
    files = new Map<string, Buffer>();
  let offset = 0;
  while (offset + 512 <= data.length) {
    const h = data.subarray(offset, offset + 512);
    if (h.every((v) => v === 0)) break;
    let checksum = 0;
    for (let i = 0; i < 512; i++) checksum += i >= 148 && i < 156 ? 32 : h[i];
    if (parseInt(h.subarray(148, 156).toString().replace(/\0/g, "").trim(), 8) !== checksum)
      throw new OfficeError("invalid_files");
    const text = (a: number, b: number) => h.subarray(a, b).toString().split("\0")[0];
    const prefix = text(345, 500);
    let name = (prefix ? prefix + "/" : "") + text(0, 100);
    name = name.replace(/\/$/, "");
    safeRelative(name);
    const size = parseInt(text(124, 136).trim() || "0", 8),
      type = text(156, 157);
    if (
      !Number.isSafeInteger(size) ||
      size < 0 ||
      offset + 512 + size > data.length ||
      !["", "0", "5"].includes(type) ||
      files.has(name)
    )
      throw new OfficeError("invalid_files");
    if (type !== "5") files.set(name, Buffer.from(data.subarray(offset + 512, offset + 512 + size)));
    offset += 512 + Math.ceil(size / 512) * 512;
  }
  return files;
}
interface Stored {
  manifest: ReleaseManifest;
  dir: string;
  frontendDir: string;
}
export async function createReleaseManager(
  paths: WorkspacePaths,
  registry: HotRegistry,
  broadcast: (type: string, payload: unknown) => void,
  runtimeBootId?: string,
): Promise<ReleaseManager> {
  let bootId = runtimeBootId ?? "";
  try {
    if (!bootId) bootId = JSON.parse(await readFile(path.join(paths.state, "runtime.json"), "utf8")).bootId;
  } catch {
    bootId = randomUUID();
  }
  const pointer = await resolveWorkspacePath(paths, path.join(paths.releases, "active.json")),
    versions = new Map<string, Stored>();
  let lock = Promise.resolve();
  const serial = <T>(fn: () => Promise<T>): Promise<T> => {
    const result = lock.then(fn, fn);
    lock = result.then(
      () => {},
      () => {},
    );
    return result;
  };
  const initialDir = await resolveWorkspacePath(paths, path.join(paths.releases, "builtin-v1"));
  await mkdir(await resolveWorkspacePath(paths, path.join(initialDir, "hot")), { recursive: true });
  for (const name of hotNames)
    await cp(
      fileURLToPath(new URL(`./hot/modules/${name}.mjs`, import.meta.url)),
      path.join(initialDir, "hot", `${name}.mjs`),
    );
  const initialManifest: ReleaseManifest = {
    id: "builtin-v1",
    runtimeAbi: 1,
    schemaVersion: 1,
    kind: "combined",
    files: {},
    hotModules: [...hotNames],
  };
  let current: Stored = {
    manifest: initialManifest,
    dir: initialDir,
    frontendDir: path.join(paths.app, "dist-office"),
  };
  // Keep a stable initial snapshot for rollback even when later builds replace dist-office.
  try {
    await lstat(path.join(initialDir, "frontend"));
  } catch {
    try {
      await cp(await resolveWorkspacePath(paths, current.frontendDir), path.join(initialDir, "frontend"), {
        recursive: true,
        verbatimSymlinks: true,
      });
      await tree(path.join(initialDir, "frontend"));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  initialManifest.files = Object.fromEntries(
    [...(await tree(initialDir))].filter(([rel]) => rel !== "manifest.json").map(([rel, data]) => [rel, sha(data)]),
  );
  await writeFile(path.join(initialDir, "manifest.json"), JSON.stringify(initialManifest));
  versions.set("builtin-v1", { ...current, frontendDir: path.join(initialDir, "frontend") });
  const load = async (id: string): Promise<Stored> => {
    if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(id)) throw new OfficeError("invalid_release");
    if (versions.has(id)) return versions.get(id)!;
    const dir = await resolveWorkspacePath(paths, path.join(paths.releases, id));
    const manifest = JSON.parse(await readFile(path.join(dir, "manifest.json"), "utf8")) as ReleaseManifest;
    const stored = { manifest, dir, frontendDir: path.join(dir, "frontend") };
    versions.set(id, stored);
    return stored;
  };
  try {
    const saved = JSON.parse(await readFile(pointer, "utf8"));
    if (saved.id !== "builtin-v1") {
      const stored = await load(saved.id);
      if (
        stored.manifest.runtimeAbi !== 1 ||
        stored.manifest.schemaVersion !== 1 ||
        stored.manifest.kind === "restart-required"
      )
        throw new OfficeError("active_release_invalid");
      await tree(stored.dir);
      for (const [rel, hash] of Object.entries(stored.manifest.files)) {
        if (sha(await readFile(await resolveWorkspacePath(paths, path.join(stored.dir, safeRelative(rel))))) !== hash)
          throw new OfficeError("active_release_invalid");
      }
      await registry.prepare(stored.dir, { ...stored.manifest, hotModules: [...hotNames] });
      await registry.activate(saved.id);
      current = stored;
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw new OfficeError("active_release_invalid", 500);
  }
  const activate = async (id: string): Promise<ReleaseResult> => {
    const previousId = current.manifest.id;
    const rejected = (reason: ReleaseResult["reason"]): ReleaseResult => ({
      id,
      previousId,
      bootId,
      status: "rejected",
      reason,
    });
    let candidate: Stored;
    try {
      candidate = await load(id);
    } catch {
      return rejected("invalid_files");
    }
    if (candidate.manifest.kind === "restart-required" || candidate.manifest.schemaVersion !== 1)
      return rejected("restart_required");
    if (candidate.manifest.runtimeAbi !== 1) return rejected("incompatible_abi");
    if (id === current.manifest.id) return { id, previousId, bootId, status: "active" };
    const nextPointer = path.join(paths.releases, `.active-${randomUUID()}.json`);
    try {
      // Validate staged content again; no modified candidate can become active.
      for (const [rel, hash] of Object.entries(candidate.manifest.files)) {
        const file = await resolveWorkspacePath(paths, path.join(candidate.dir, safeRelative(rel)));
        if (sha(await readFile(file)) !== hash) throw new OfficeError("invalid_files");
      }
      await tree(candidate.dir);
      await Promise.all(["chat.html", "office.html"].map((name) => readFile(path.join(candidate.frontendDir, name))));
      await registry.prepare(candidate.dir, { ...candidate.manifest, hotModules: [...hotNames] });
      await writeFile(nextPointer, JSON.stringify({ id }), { mode: 0o600 });
      // No observable await between policy activation and the in-memory frontend switch.
      await rename(nextPointer, pointer);
      await registry.activate(id);
      current = candidate;
    } catch {
      await rm(nextPointer, { force: true });
      await registry.discard(id);
      await writeFile(pointer, JSON.stringify({ id: previousId }), { mode: 0o600 });
      return rejected("candidate_failed");
    }
    try {
      broadcast("office.release", { id, previousId, bootId, kind: candidate.manifest.kind });
    } catch {
      /* notification failure cannot undo a committed release */
    }
    return { id, previousId, bootId, status: "active" };
  };
  return {
    active() {
      return { manifest: structuredClone(current.manifest), frontendDir: current.frontendDir };
    },
    apply: (id) => serial(() => activate(id)),
    rollback: (id) => serial(() => activate(id)),
    stage: (bundlePath) =>
      serial(async () => {
        const stat = await lstat(bundlePath);
        if (stat.isSymbolicLink()) throw new OfficeError("invalid_files");
        let incoming: Map<string, Buffer>;
        try {
          incoming = stat.isDirectory() ? await tree(bundlePath) : untar(await readFile(bundlePath));
        } catch {
          throw new OfficeError("invalid_files");
        }
        let manifest: ReleaseManifest;
        try {
          manifest = JSON.parse(incoming.get("manifest.json")!.toString());
        } catch {
          throw new OfficeError("invalid_files");
        }
        if (
          !manifest ||
          !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(manifest.id) ||
          manifest.id === "builtin-v1" ||
          !manifest.files ||
          typeof manifest.files !== "object" ||
          Array.isArray(manifest.files) ||
          !Array.isArray(manifest.hotModules)
        )
          throw new OfficeError("invalid_files");
        const dir = await resolveWorkspacePath(paths, path.join(paths.releases, manifest.id));
        try {
          await lstat(dir);
          throw new OfficeError("release_exists", 409);
        } catch (error) {
          if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
        }
        if (incoming.size !== Object.keys(manifest.files).length + 1) throw new OfficeError("invalid_files");
        let front = false,
          hot = false,
          core = false,
          changed = false;
        const actualHot: string[] = [];
        for (const [rel, hash] of Object.entries(manifest.files)) {
          safeRelative(rel);
          const data = incoming.get(rel);
          if (!data || typeof hash !== "string" || !/^[a-f0-9]{64}$/.test(hash) || sha(data) !== hash)
            throw new OfficeError("invalid_files");
          const hotMatch = /^hot\/(agent-summary|role-prompts)\.mjs$/.exec(rel);
          if (rel.startsWith("frontend/")) front = true;
          else if (hotMatch) {
            hot = true;
            actualHot.push(hotMatch[1]);
          } else core = true;
          let base: string | undefined;
          if (rel.startsWith("frontend/")) base = path.join(current.frontendDir, rel.slice(9));
          else if (hotMatch) base = path.join(current.dir, rel);
          else base = await resolveWorkspacePath(paths, path.join(paths.root, rel));
          try {
            if (sha(await readFile(base)) !== hash) changed = true;
          } catch {
            changed = true;
          }
        }
        if (
          !changed ||
          manifest.hotModules.length !== actualHot.length ||
          new Set(manifest.hotModules).size !== actualHot.length ||
          manifest.hotModules.some((n) => !actualHot.includes(n))
        )
          throw new OfficeError("invalid_files");
        manifest.kind =
          core || manifest.runtimeAbi !== 1 || manifest.schemaVersion !== 1
            ? "restart-required"
            : front && hot
              ? "combined"
              : hot
                ? "hot-modules"
                : "frontend";
        const temp = await resolveWorkspacePath(paths, path.join(paths.releases, `.stage-${randomUUID()}`));
        await mkdir(temp, { recursive: true });
        try {
          await cp(path.join(current.dir, "hot"), path.join(temp, "hot"), { recursive: true, verbatimSymlinks: true });
          try {
            await tree(await resolveWorkspacePath(paths, current.frontendDir));
            await cp(await resolveWorkspacePath(paths, current.frontendDir), path.join(temp, "frontend"), {
              recursive: true,
              verbatimSymlinks: true,
            });
          } catch (error) {
            if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
          }
          for (const [rel, data] of incoming) {
            if (rel === "manifest.json") continue;
            const file = path.join(temp, rel);
            await mkdir(path.dirname(file), { recursive: true });
            await writeFile(file, data, { mode: 0o600 });
          }
          const effective = await tree(temp);
          manifest.files = Object.fromEntries(
            [...effective].filter(([rel]) => rel !== "manifest.json").map(([rel, data]) => [rel, sha(data)]),
          );
          await writeFile(path.join(temp, "manifest.json"), JSON.stringify(manifest), { mode: 0o600 });
          await rename(temp, dir);
        } catch (error) {
          await rm(temp, { recursive: true, force: true });
          throw error;
        }
        versions.set(manifest.id, { manifest, dir, frontendDir: path.join(dir, "frontend") });
        return structuredClone(manifest);
      }),
  };
}
