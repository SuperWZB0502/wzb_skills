import { createHash, randomBytes } from "node:crypto";
import { chmodSync, lstatSync, mkdirSync, realpathSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { OfficeError } from "./errors.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";

const MAX_AGE_SECONDS = 30 * 24 * 60 * 60;
const TOKEN_FORMAT = /^[a-f0-9]{64}$/;
const SIDECARS = ["", "-wal", "-shm", "-journal"] as const;

function tokenHash(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}
function csrfToken(token: string): string {
  return createHash("sha256").update("office-web-session:csrf:v1\0", "utf8").update(token, "utf8").digest("hex");
}
function checkFile(filename: string): boolean {
  try {
    const info = lstatSync(filename);
    if (info.isSymbolicLink()) throw new OfficeError("workspace_path_outside", 403);
    if (!info.isFile()) throw new OfficeError("session_file_not_regular", 403);
    if (info.nlink > 1) throw new OfficeError("workspace_hardlink_forbidden", 403);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

/** Persistent browser login checks only; model credentials never enter this store. */
export class SessionStore {
  #db: DatabaseSync;
  #closed = false;

  constructor(paths: WorkspacePaths) {
    if (
      path.resolve(paths.root) !== paths.root ||
      realpathSync(paths.root) !== paths.root ||
      paths.state !== path.join(paths.root, "state")
    )
      throw new OfficeError("workspace_path_outside", 403);
    try {
      const state = lstatSync(paths.state);
      if (state.isSymbolicLink()) throw new OfficeError("workspace_path_outside", 403);
      if (!state.isDirectory()) throw new OfficeError("workspace_state_invalid", 403);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      mkdirSync(paths.state, { mode: 0o700 });
    }
    if (realpathSync(paths.state) !== paths.state) throw new OfficeError("workspace_path_outside", 403);
    chmodSync(paths.state, 0o700);

    const filename = path.join(paths.state, "web-sessions.sqlite");
    // Validate every pre-existing sidecar before SQLite can open or mutate any of them.
    const existing = SIDECARS.map((suffix) => ({ filename: filename + suffix, exists: checkFile(filename + suffix) }));
    for (const file of existing) if (file.exists) chmodSync(file.filename, 0o600);

    const db = new DatabaseSync(filename);
    try {
      chmodSync(filename, 0o600);
      db.exec(`
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS browser_sessions (
          token_hash TEXT PRIMARY KEY NOT NULL CHECK(length(token_hash)=64),
          expires_at INTEGER NOT NULL CHECK(typeof(expires_at)='integer')
        );
        CREATE INDEX IF NOT EXISTS browser_sessions_expiry ON browser_sessions(expires_at);
      `);
      db.prepare("DELETE FROM browser_sessions WHERE expires_at<=?").run(Date.now());
      for (const suffix of SIDECARS) if (checkFile(filename + suffix)) chmodSync(filename + suffix, 0o600);
    } catch (error) {
      db.close();
      throw error;
    }
    this.#db = db;
  }

  #purgeExpired(): number {
    if (this.#closed) throw new OfficeError("session_store_closed", 503);
    const now = Date.now();
    this.#db.prepare("DELETE FROM browser_sessions WHERE expires_at<=?").run(now);
    return now;
  }

  create(): { token: string; csrfToken: string; maxAgeSeconds: number; expiresAt: number } {
    const now = this.#purgeExpired();
    const token = randomBytes(32).toString("hex");
    const expiresAt = now + MAX_AGE_SECONDS * 1000;
    this.#db
      .prepare("INSERT INTO browser_sessions(token_hash,expires_at) VALUES(?,?)")
      .run(tokenHash(token), expiresAt);
    return { token, csrfToken: csrfToken(token), maxAgeSeconds: MAX_AGE_SECONDS, expiresAt };
  }

  get(token: string): { csrfToken: string; expiresAt: number } | undefined {
    const now = this.#purgeExpired();
    if (typeof token !== "string" || !TOKEN_FORMAT.test(token)) return undefined;
    const row = this.#db
      .prepare("SELECT expires_at FROM browser_sessions WHERE token_hash=? AND expires_at>?")
      .get(tokenHash(token), now);
    if (!row) return undefined;
    return { csrfToken: csrfToken(token), expiresAt: Number(row.expires_at) };
  }

  revoke(token: string): void {
    this.#purgeExpired();
    if (typeof token !== "string" || !TOKEN_FORMAT.test(token)) return;
    this.#db.prepare("DELETE FROM browser_sessions WHERE token_hash=?").run(tokenHash(token));
  }

  close(): void {
    if (this.#closed) return;
    this.#db.close();
    this.#closed = true;
  }
}
