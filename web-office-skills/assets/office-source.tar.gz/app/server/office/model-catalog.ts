import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import {
  REASONING_EFFORTS,
  type ModelCapability,
  type ProviderCapabilities,
  type ProviderProfile,
  type ReasoningEffort,
} from "../../shared/office-contracts.ts";
import { normalizeClaudeModelId } from "./claude-model-normalization.ts";
import { maxContextWindowFor } from "./context-budget.ts";
import type { CredentialVault } from "./credential-vault.ts";
import { OfficeError } from "./errors.ts";
import { redact } from "./redactor.ts";
import { resolveWorkspacePath, type WorkspacePaths } from "./workspace-paths.ts";

const execute = promisify(execFile);
const CLAUDE_CLI_EFFORTS: ReasoningEffort[] = ["low", "medium", "high", "xhigh", "max"];
type RemoteModel = { id: string; name?: string; efforts?: ReasoningEffort[]; defaultEffort?: ReasoningEffort };
type Listing = { models: RemoteModel[]; state: NonNullable<ProviderCapabilities["catalogState"]>; message: string };
const isEffort = (value: unknown): value is ReasoningEffort => REASONING_EFFORTS.includes(value as ReasoningEffort);
const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
/** Largest window the bundled catalog declares for a model (`max_context_window`, else `context_window`). */
function bundledWindow(model: Record<string, unknown>): number | null {
  for (const key of ["max_context_window", "context_window"]) {
    const value = model[key];
    if (typeof value === "number" && Number.isFinite(value) && value > 0) return Math.round(value);
  }
  return null;
}
/**
 * Largest window for a listed model: the executor catalog when it knows the model, otherwise the
 * built-in family table. Drives the 25/50/75/100% presets in the agent editor.
 */
function windowFor(id: string, cli: Map<string, ModelCapability>): number {
  const bundled = cli.get(id)?.maxContextWindow;
  const table = maxContextWindowFor(id);
  return Math.max(typeof bundled === "number" && bundled > 0 ? bundled : 0, table);
}

function levels(value: unknown): ReasoningEffort[] | undefined {
  if (!Array.isArray(value)) return undefined;
  return [...new Set(value.map((item) => (typeof item === "string" ? item : record(item).effort)).filter(isEffort))];
}

/** Model metadata only. Keys are used solely in the selected executor's upstream authentication header. */
export class ModelCatalog {
  private cliPromise?: Promise<Map<string, ModelCapability>>;
  private cliAbort = new AbortController();
  private controllers = new Set<AbortController>();
  private pending = new Set<Promise<Listing>>();
  private cache = new Map<string, { pending: boolean; until: number; promise: Promise<Listing> }>();
  private closed = false;
  constructor(
    private paths: WorkspacePaths,
    private vault: CredentialVault,
    private binary = "codex",
  ) {}

  private cli(): Promise<Map<string, ModelCapability>> {
    return (this.cliPromise ??= (async () => {
      try {
        const home = path.join(this.paths.state, "catalog-cli");
        if ((await resolveWorkspacePath(this.paths, home)) !== home)
          throw new OfficeError("runtime_path_symlink_forbidden");
        await mkdir(home, { recursive: true, mode: 0o700 });
        const pending = execute(this.binary, ["debug", "models", "--bundled"], {
          timeout: 5000,
          windowsHide: true,
          maxBuffer: 8 * 1024 * 1024,
          signal: this.cliAbort.signal,
          killSignal: "SIGKILL",
          cwd: this.paths.root,
          env: {
            PATH: process.env.PATH,
            LANG: "C.UTF-8",
            CODEX_HOME: home,
            HOME: home,
            TMPDIR: this.paths.tmp,
            XDG_CACHE_HOME: path.join(this.paths.cache, "catalog-cli"),
          },
        });
        pending.child.stdin?.end();
        const { stdout } = await pending;
        const data = record(JSON.parse(stdout));
        const result = new Map<string, ModelCapability>();
        if (!Array.isArray(data.models)) return result;
        for (const raw of data.models) {
          const model = record(raw);
          if (typeof model.slug !== "string") continue;
          const efforts = levels(model.supported_reasoning_levels);
          if (!efforts) continue;
          result.set(model.slug, {
            id: model.slug,
            name: typeof model.display_name === "string" ? model.display_name : model.slug,
            maxContextWindow: bundledWindow(model),
            reasoningEfforts: efforts,
            defaultReasoningEffort:
              isEffort(model.default_reasoning_level) && efforts.includes(model.default_reasoning_level)
                ? model.default_reasoning_level
                : null,
            reasoningSource: "codex",
          });
        }
        return result;
      } catch {
        return new Map<string, ModelCapability>();
      }
    })());
  }

  private listing(provider: ProviderProfile, slotId: string | undefined, refresh: boolean): Promise<Listing> {
    // Account authorization is owned by the runtime's account capabilities path.
    // It must never fall back to an API-key slot, including a caller-supplied one.
    if (provider.authMode === "account")
      return Promise.resolve({
        models: [],
        state: "key_required",
        message: "账户尚未登录，请先在服务设置中完成账户登录；模型 ID 仍可手动填写。",
      });
    const credential = slotId ? this.vault.get(slotId) : undefined;
    if (!credential || credential.providerId !== provider.id || this.vault.status(slotId!) !== "configured")
      return Promise.resolve({
        models: [],
        state: "key_required",
        message: "请先为这个身份提供此模型服务的 API Key，随后会自动读取模型列表；也可手动填写模型 ID。",
      });
    const fingerprint = createHash("sha256")
      .update(
        JSON.stringify([
          provider.id,
          provider.executor ?? "codex",
          provider.authMode ?? "api_key",
          provider.baseUrl,
          slotId,
          credential.apiKey,
        ]),
      )
      .digest("hex");
    for (const [key, value] of this.cache) if (!value.pending && value.until < Date.now()) this.cache.delete(key);
    const existing = this.cache.get(fingerprint);
    if (existing && (existing.pending || (!refresh && existing.until > Date.now()))) return existing.promise;
    if (this.closed)
      return Promise.resolve({ models: [], state: "unavailable", message: "服务正在关闭，请稍后重新连接。" });
    const controller = new AbortController();
    this.controllers.add(controller);
    const promise = this.fetchModels(provider, credential.apiKey, controller).finally(() => {
      this.controllers.delete(controller);
      this.pending.delete(promise);
      const entry = this.cache.get(fingerprint);
      if (entry?.promise === promise) entry.pending = false;
    });
    this.pending.add(promise);
    if (this.cache.size >= 64) {
      const oldest = [...this.cache].find(([, entry]) => !entry.pending);
      if (oldest) this.cache.delete(oldest[0]);
    }
    this.cache.set(fingerprint, { pending: true, until: Date.now() + 60_000, promise });
    return promise;
  }

  private async fetchModels(provider: ProviderProfile, apiKey: string, controller: AbortController): Promise<Listing> {
    const failure = (state: Listing["state"], message: string): Listing => ({ models: [], state, message });
    try {
      const claude = provider.executor === "claude-code";
      const base = provider.baseUrl.replace(/\/+$/, "");
      // Anthropic-compatible relays often expose Messages under /anthropic but
      // keep their model catalog at a sibling OpenAI-compatible endpoint.
      // All candidates stay on the exact configured origin; never follow redirects.
      const endpoints = claude
        ? [base + (base.endsWith("/v1") ? "/models" : "/v1/models"), base + "/models"]
        : [base + "/models"];
      if (claude) {
        const url = new URL(base);
        if (/\/anthropic(?:\/v1)?$/.test(url.pathname)) {
          const parent = base.replace(/\/anthropic(?:\/v1)?$/, "");
          endpoints.push(parent + "/v1/models", parent + "/models");
        }
      }
      const headers: Record<string, string> = claude
        ? { "x-api-key": apiKey, "anthropic-version": "2023-06-01", Accept: "application/json" }
        : { Authorization: `Bearer ${apiKey}`, Accept: "application/json" };
      if (claude && new URL(base).hostname !== "api.anthropic.com") headers.Authorization = `Bearer ${apiKey}`;
      const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(10_000)]);
      let lastFailure = failure("unsupported", "此服务未提供模型列表接口，请在伙伴配置中填写模型 ID。");
      for (const endpoint of new Set(endpoints)) {
        if (signal.aborted) break;
        const result = await this.fetchModelListing(endpoint, headers, apiKey, controller, signal);
        if (result.state === "ready") return result;
        // Preserve a useful authentication error if later alternate paths are absent.
        if (result.state === "unauthorized" || lastFailure.state !== "unauthorized") lastFailure = result;
        if (result.state === "unavailable") break;
      }
      return lastFailure;
    } catch {
      return failure("unavailable", "读取模型列表失败或超时，请检查服务地址和网络，或在伙伴配置中填写模型 ID。");
    }
  }

  private async fetchModelListing(
    endpoint: string,
    headers: Record<string, string>,
    apiKey: string,
    controller: AbortController,
    signal: AbortSignal,
  ): Promise<Listing> {
    const failure = (state: Listing["state"], message: string): Listing => ({ models: [], state, message });
    try {
      const response = await fetch(endpoint, { headers, redirect: "error", signal });
      if (!response.ok) {
        await response.body?.cancel();
        if ([401, 403].includes(response.status))
          return failure(
            "unauthorized",
            "模型列表访问被拒绝，请检查 API Key 和列表读取权限；仍可在伙伴配置中填写模型 ID。",
          );
        if ([404, 405, 501].includes(response.status))
          return failure("unsupported", "此服务未提供模型列表接口，请在伙伴配置中填写模型 ID。");
        return failure("unavailable", "模型列表暂时不可用，请稍后刷新或在伙伴配置中填写模型 ID。");
      }
      if (!response.body) return failure("unsupported", "模型列表响应为空，可在伙伴配置中填写模型 ID。");
      const chunks: Uint8Array[] = [];
      let size = 0;
      for await (const chunk of response.body) {
        size += chunk.length;
        if (size > 2 * 1024 * 1024) {
          controller.abort();
          return failure("unavailable", "模型列表过大，可手动填写模型 ID。");
        }
        chunks.push(chunk);
      }
      let parsed: unknown;
      try {
        parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      } catch {
        return failure("unsupported", "此路径返回的内容不是模型列表，可在伙伴配置中填写模型 ID。");
      }
      const body = record(parsed);
      const rows = Array.isArray(parsed) ? parsed : (body.data ?? body.models);
      if (!Array.isArray(rows)) return failure("unsupported", "此服务返回的模型列表格式无法识别，可手动填写模型 ID。");
      const secrets = [...this.vault.secrets(), apiKey];
      const clean = (value: unknown, max: number): string | undefined => {
        if (typeof value !== "string" || !value.trim() || value.length > max) return;
        const trimmed = value.trim();
        if (
          [...trimmed].some((c) => c.charCodeAt(0) < 32 || c.charCodeAt(0) === 127) ||
          redact(trimmed, secrets) !== trimmed
        )
          return;
        return trimmed;
      };
      const models = new Map<string, RemoteModel>();
      for (const raw of rows.slice(0, 2000)) {
        const value = typeof raw === "string" ? { id: raw } : record(raw);
        const id = clean(value.id ?? value.slug, 256);
        if (!id) continue;
        const efforts = levels(
          value.supported_reasoning_levels ??
            value.supported_reasoning_efforts ??
            value.reasoning_efforts ??
            value.supportedReasoningEfforts,
        );
        const defaultValue =
          value.default_reasoning_level ?? value.default_reasoning_effort ?? value.defaultReasoningEffort;
        models.set(id, {
          id,
          name: clean(value.display_name ?? value.name, 256),
          efforts,
          defaultEffort: isEffort(defaultValue) ? defaultValue : undefined,
        });
      }
      return {
        models: [...models.values()],
        state: "ready",
        message: models.size
          ? `已读取 ${models.size} 个模型；列表可见性由当前 Key 和服务决定。`
          : "服务返回了空模型列表，可手动填写模型 ID。",
      };
    } catch {
      return failure("unavailable", "读取模型列表失败或超时，请检查服务地址和网络，或手动填写模型 ID。");
    }
  }

  async describe(
    provider: ProviderProfile,
    slotId?: string,
    model = "",
    refresh = false,
  ): Promise<ProviderCapabilities> {
    if (provider.executor === "claude-code") return this.describeClaude(provider, slotId, model, refresh);
    const previousCli = this.cliPromise;
    if (refresh && previousCli && !(await previousCli).size && this.cliPromise === previousCli && !this.closed)
      this.cliPromise = undefined;
    const [cli, listing] = await Promise.all([this.cli(), this.listing(provider, slotId, refresh)]);
    const union = REASONING_EFFORTS.filter((effort) =>
      [...cli.values()].some((entry) => entry.reasoningEfforts.includes(effort)),
    );
    const fallback = provider.authMode === "account" && !union.length ? [...REASONING_EFFORTS] : union;
    const capability = (id: string): ModelCapability => {
      const remote = listing.models.find((entry) => entry.id === id);
      const bundled = cli.get(id);
      if (remote?.efforts !== undefined)
        return {
          id,
          name: remote.name ?? bundled?.name,
          reasoningEfforts: remote.efforts,
          defaultReasoningEffort:
            remote.defaultEffort && remote.efforts.includes(remote.defaultEffort) ? remote.defaultEffort : null,
          reasoningSource: "provider",
        };
      if (bundled) return { ...bundled, name: remote?.name ?? bundled.name };
      return {
        id,
        name: remote?.name,
        reasoningEfforts: fallback,
        defaultReasoningEffort: null,
        reasoningSource: "unverified",
      };
    };
    const selected = model ? capability(model) : undefined;
    return {
      models: listing.models.map((entry) => entry.id),
      supportsResponses: true,
      reasoningEfforts: selected?.reasoningEfforts ?? (provider.authMode === "account" ? fallback : []),
      modelCapabilities: listing.models.map((entry) => capability(entry.id)),
      selectedModel: selected,
      contextWindows: Object.fromEntries(listing.models.map((entry) => [entry.id, windowFor(entry.id, cli)])),
      catalogState: listing.state,
      catalogMessage: listing.message,
      codexCatalogState: cli.size ? "ready" : "unavailable",
    };
  }

  private async describeClaude(
    provider: ProviderProfile,
    slotId: string | undefined,
    model: string,
    refresh: boolean,
  ): Promise<ProviderCapabilities> {
    const listing = await this.listing(provider, slotId, refresh);
    const capability = (id: string): ModelCapability => {
      const remote =
        listing.models.find((entry) => entry.id === id) ??
        listing.models.find((entry) => normalizeClaudeModelId(entry.id) === normalizeClaudeModelId(id));
      if (remote?.efforts !== undefined) {
        const efforts = remote.efforts.filter((effort) => CLAUDE_CLI_EFFORTS.includes(effort));
        return {
          id,
          name: remote.name,
          reasoningEfforts: efforts,
          defaultReasoningEffort:
            remote.defaultEffort && efforts.includes(remote.defaultEffort) ? remote.defaultEffort : null,
          reasoningSource: "provider",
        };
      }
      const normalized = id.toLowerCase();
      const alias = ["default", "claude", "sonnet", "opus", "haiku"].some(
        (value) => normalized === value || normalized.startsWith(value + "["),
      );
      return {
        id,
        name: remote?.name ?? `${id}（${alias ? "Claude 别名，" : ""}能力未核实）`,
        reasoningEfforts: [...CLAUDE_CLI_EFFORTS],
        defaultReasoningEffort: null,
        reasoningSource: "unverified",
      };
    };
    const selected = model ? capability(model) : undefined;
    const unknown =
      !selected ||
      selected.reasoningSource === "unverified" ||
      listing.models.some((entry) => entry.efforts === undefined);
    return {
      models: listing.models.map((entry) => entry.id),
      supportsResponses: false,
      reasoningEfforts: selected?.reasoningEfforts ?? [...CLAUDE_CLI_EFFORTS],
      modelCapabilities: listing.models.map((entry) => capability(entry.id)),
      selectedModel: selected,
      contextWindows: Object.fromEntries(listing.models.map((entry) => [entry.id, maxContextWindowFor(entry.id)])),
      catalogState: listing.state,
      catalogMessage:
        listing.message +
        (unknown ? " 思考档位未获服务明确确认；当前列出本机 Claude Code CLI 可传集合，不代表该模型或别名已验证。" : ""),
    };
  }
  async validateSelection(
    provider: ProviderProfile | undefined,
    slotId: string | undefined,
    model: unknown,
    effort: unknown,
  ): Promise<void> {
    if (!provider) return;
    if (
      provider.executor === "claude-code" &&
      effort !== null &&
      effort !== undefined &&
      !CLAUDE_CLI_EFFORTS.includes(effort as ReasoningEffort)
    )
      throw new OfficeError("unsupported_reasoning_effort", 400);
    if (typeof model !== "string" || !model || !isEffort(effort)) return;
    const selected = (await this.describe(provider, slotId, model)).selectedModel;
    if (selected && selected.reasoningSource !== "unverified" && !selected.reasoningEfforts.includes(effort))
      throw new OfficeError("unsupported_reasoning_effort", 400);
  }

  async close(): Promise<void> {
    this.closed = true;
    this.cliAbort.abort();
    for (const controller of this.controllers) controller.abort();
    await Promise.allSettled([...this.pending]);
    await this.cliPromise;
    this.cache.clear();
  }
}
