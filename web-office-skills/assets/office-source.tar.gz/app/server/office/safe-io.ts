import { constants, type Stats } from "node:fs";
import { lstat, open } from "node:fs/promises";
import path from "node:path";
import { OfficeError } from "./errors.ts";
import { resolveWorkspacePath, type WorkspacePaths } from "./workspace-paths.ts";

async function writeRuntimeFile(paths: WorkspacePaths, input: string, content: string, append: boolean): Promise<void> {
  if (typeof input !== "string" || input.includes("\0") || typeof content !== "string")
    throw new OfficeError("invalid_runtime_write");
  const candidate = path.resolve(paths.root, input);
  const parent = path.dirname(candidate);
  const canonicalParent = await resolveWorkspacePath(paths, parent);
  // Runtime-owned files must retain their intended location, including inside-root aliases.
  if (canonicalParent !== parent) throw new OfficeError("runtime_path_symlink_forbidden", 403);
  let existing: Stats | undefined;
  try {
    existing = await lstat(candidate);
    if (existing.isSymbolicLink()) throw new OfficeError("runtime_path_symlink_forbidden", 403);
    if (!existing.isFile() || existing.nlink !== 1) throw new OfficeError("runtime_file_not_regular", 403);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  const windows = process.platform === "win32";
  if (!windows && typeof constants.O_NOFOLLOW !== "number")
    throw new OfficeError("safe_runtime_io_unsupported", 503);
  // O_NOFOLLOW closes the final-component check/open race. Open without O_TRUNC so
  // fstat can refuse hard links or special files before changing their contents.
  const flags =
    constants.O_WRONLY |
    (windows ? (existing ? 0 : constants.O_CREAT | constants.O_EXCL) : constants.O_CREAT) |
    (constants.O_NOFOLLOW ?? 0) |
    (constants.O_NONBLOCK ?? 0) |
    (append ? constants.O_APPEND : 0);
  const handle = await open(candidate, flags, 0o600);
  try {
    const opened = await handle.stat();
    if (!opened.isFile() || opened.nlink !== 1) throw new OfficeError("runtime_file_not_regular", 403);
    if (windows) {
      // Windows Node lacks O_NOFOLLOW. With no truncate on open, validate the
      // actual handle against both the pre-open stat and the canonical path.
      const canonical = await resolveWorkspacePath(paths, candidate);
      const current = await lstat(candidate);
      if (
        canonical !== candidate || current.isSymbolicLink() ||
        current.dev !== opened.dev || current.ino !== opened.ino ||
        (existing && (existing.dev !== opened.dev || existing.ino !== opened.ino))
      ) throw new OfficeError("runtime_path_changed", 403);
    }
    await handle.chmod(0o600);
    if (!append) await handle.truncate(0);
    await handle.writeFile(content, { encoding: "utf8" });
  } finally {
    await handle.close();
  }
}
export async function safeAppend(paths: WorkspacePaths, input: string, content: string): Promise<void> {
  await writeRuntimeFile(paths, input, content, true);
}
export async function safeWrite(paths: WorkspacePaths, input: string, content: string): Promise<void> {
  await writeRuntimeFile(paths, input, content, false);
}
