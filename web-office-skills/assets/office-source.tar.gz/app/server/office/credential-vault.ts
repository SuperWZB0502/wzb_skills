import { randomUUID } from "node:crypto";
import type { CredentialState } from "../../shared/office-contracts.ts";
import { OfficeError } from "./errors.ts";
interface Credential {
  providerId: string;
  apiKey: string;
  invalid: boolean;
}
/** Process-local only. Returned snapshots can outlive revocation for an already acquired run. */
export class CredentialVault {
  #slots = new Map<string, Credential>();
  #providers = new Map<string, string>();
  put(providerId: string, apiKey: string, restoreSlotId?: string): string {
    if (typeof apiKey !== "string" || !apiKey.trim() || apiKey.length > 8192) throw new OfficeError("invalid_api_key");
    if (typeof providerId !== "string" || !providerId.trim() || providerId.length > 256)
      throw new OfficeError("invalid_provider");
    if (
      restoreSlotId !== undefined &&
      (typeof restoreSlotId !== "string" || !restoreSlotId || restoreSlotId.length > 256)
    )
      throw new OfficeError("invalid_credential_slot");
    const slotId = restoreSlotId ?? randomUUID();
    const knownProvider = this.#providers.get(slotId);
    if (knownProvider !== undefined && knownProvider !== providerId)
      throw new OfficeError("credential_provider_mismatch", 403);
    this.#providers.set(slotId, providerId);
    this.#slots.set(slotId, { providerId, apiKey, invalid: false });
    return slotId;
  }
  get(slotId: string | null): { providerId: string; apiKey: string } | undefined {
    const entry = slotId === null ? undefined : this.#slots.get(slotId);
    return entry ? { providerId: entry.providerId, apiKey: entry.apiKey } : undefined;
  }
  status(slotId: string | null): CredentialState {
    const entry = slotId === null ? undefined : this.#slots.get(slotId);
    return !entry ? "required" : entry.invalid ? "invalid" : "configured";
  }
  markInvalid(slotId: string): void {
    const entry = this.#slots.get(slotId);
    if (entry) entry.invalid = true;
  }
  revoke(slotId: string): void {
    this.#slots.delete(slotId);
  }
  revokeProvider(providerId: string): void {
    for (const [slotId, entry] of this.#slots) if (entry.providerId === providerId) this.#slots.delete(slotId);
  }
  clear(): void {
    this.#slots.clear();
  }
  /** Internal redactor input only; never expose from an API or serializable profile. */
  secrets(): string[] {
    return [...new Set([...this.#slots.values()].map((entry) => entry.apiKey))];
  }
}
