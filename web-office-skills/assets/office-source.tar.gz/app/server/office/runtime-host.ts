import express, { type Request, type Response, type NextFunction } from "express";
import http from "node:http";
import net from "node:net";
import { randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { mkdir, writeFile, readFile, chmod, lstat, unlink, readdir, stat, open } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { WebSocketServer, WebSocket } from "ws";
import {
  REASONING_EFFORTS,
  type ModelCapability,
  type ReasoningEffort,
  type AgentDraft,
  type AgentProfile,
  type MeetingSnapshot,
  type OfficeSnapshot,
  type ViewMode,
} from "../../shared/office-contracts.ts";
import { createWorkspacePaths, resolveWorkspacePath } from "./workspace-paths.ts";
import { OfficeStore } from "./agent-repository.ts";
import { CredentialVault } from "./credential-vault.ts";
import { ModelProxy } from "./model-proxy.ts";
import { ModelCatalog } from "./model-catalog.ts";
import { SessionStore } from "./session-store.ts";
import { AttachmentStore } from "./attachments.ts";
import { resolveCodexBinary } from "./codex-binary.ts";
import { listSkills, readSkillFile } from "./skills.ts";
import { agentLayout, detectLayoutVersion } from "./agent-layout.ts";
import { initializeAgentMemory } from "./memory.ts";
import { parseFileMode, resolveAgentFile, sendAgentFile } from "./workspace-files.ts";
import { ConversationContextStore } from "./conversation-context.ts";
import { ServiceRuntime } from "./service-runtime.ts";
import { purgeConversationFiles } from "./conversation-deletion.ts";
import { RunRegistry } from "./run-registry.ts";
import { OfficeError } from "./errors.ts";
import { redact } from "./redactor.ts";
import { createHotRegistry } from "./hot/registry.ts";
import { createReleaseManager } from "./releases.ts";
import { safeWrite } from "./safe-io.ts";

export interface OfficeHostOptions {
  workspaceRoot: string;
  host?: "127.0.0.1";
  port: number;
  defaultView: ViewMode;
  codexBinary?: string;
  executionMode?: "sandboxed" | "account";
}
const text = (value: unknown, max = 128000) => {
  if (typeof value !== "string" || !value.trim() || value.length > max) throw new OfficeError("invalid_text");
  return value.trim();
};
const eq = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
function cookies(req: http.IncomingMessage) {
  const entry = String(req.headers.cookie ?? "")
    .split(";")
    .map((s) => s.trim())
    .find((s) => s.startsWith("office_session="));
  return entry?.slice("office_session=".length) ?? "";
}
function trusted(req: http.IncomingMessage) {
  if (!req.headers.origin) return true;
  try {
    const origin = new URL(String(req.headers.origin));
    return (
      ["http:", "https:"].includes(origin.protocol) &&
      origin.host === req.headers.host &&
      ["127.0.0.1", "localhost", "[::1]"].includes(origin.hostname)
    );
  } catch {
    return false;
  }
}
export async function startOfficeHost(options: OfficeHostOptions) {
  const paths = await createWorkspacePaths(path.resolve(options.workspaceRoot));
  const controlDir = await resolveWorkspacePath(paths, "state/run");
  await mkdir(controlDir, { recursive: true, mode: 0o700 });
  const controlFile = await resolveWorkspacePath(paths, "state/run/control.sock");
  const socketPath = path.relative(process.cwd(), controlFile);
  if (Buffer.byteLength(socketPath) > 100) throw new OfficeError("control_path_too_long");
  try {
    const previous = await lstat(controlFile);
    if (!previous.isSocket()) throw new OfficeError("control_path_conflict");
    const alive = await new Promise<boolean>((resolve) => {
      const c = net.connect(socketPath);
      c.once("connect", () => {
        c.destroy();
        resolve(true);
      });
      c.once("error", () => resolve(false));
      c.setTimeout(500, () => {
        c.destroy();
        resolve(false);
      });
    });
    if (alive) throw new OfficeError("already_running", 409);
    await unlink(controlFile);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  const configFile = await resolveWorkspacePath(paths, "workspace.json");
  let config: Record<string, unknown> = {};
  try {
    config = JSON.parse(await readFile(configFile, "utf8"));
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw new OfficeError("invalid_workspace_config");
  }
  if (config.workspaceRoot && config.workspaceRoot !== paths.root) throw new OfficeError("workspace_root_mismatch");
  const executionMode = options.executionMode ?? config.executionMode ?? "sandboxed";
  if (!["sandboxed", "account"].includes(String(executionMode))) throw new OfficeError("invalid_execution_mode");
  await writeFile(
    configFile,
    JSON.stringify(
      {
        ...config,
        version: 1,
        workspaceRoot: paths.root,
        defaultView: options.defaultView,
        executionMode,
        port: options.port || config.port || 18080,
        installState: "ready",
      },
      null,
      2,
    ) + "\n",
    { mode: 0o600 },
  );
  const layoutVersion = await detectLayoutVersion(paths);
  const layoutFor = (agentId: string) => agentLayout(paths, agentId, layoutVersion);
  const store = new OfficeStore(paths);
  const vault = new CredentialVault();
  // Resolve the codex CLI once at startup so PATH inheritance cannot silently break it.
  const codexExecutable = await resolveCodexBinary(options.codexBinary, paths.root).catch(() => null);
  const codexBinary = codexExecutable?.path ?? options.codexBinary ?? "codex";
  const executorStatus = () => ({
    codex: codexExecutable
      ? {
          available: true,
          source: codexExecutable.source,
          version: codexExecutable.version,
          path: codexExecutable.path,
        }
      : { available: false, source: null, version: null, path: null },
  });
  const services = new ServiceRuntime(paths, store, vault, codexBinary);
  const safe = (value: string) => redact(value, [...vault.secrets(), ...services.secrets()]);
  const contexts = new ConversationContextStore(paths, store, safe);
  const bootId = randomUUID();
  const metadata = await resolveWorkspacePath(paths, "state/runtime.json");
  const sessions = new SessionStore(paths);
  let code = "";
  let codeExpires = 0;
  let closing = false;
  let origin = "";
  const wss = new WebSocketServer({ noServer: true });
  const socketSessions = new Map<WebSocket, { token: string; expiresAt: number }>();
  const background = new Set<Promise<unknown>>();
  const maintenanceProviders = new Set<string>();
  const decorate = (agent: AgentProfile): AgentProfile => ({
    ...agent,
    credentialState: services.credentialState(agent),
    currentRunId: ["working", "meeting", "waiting_input"].includes(agent.workState)
      ? (runs.active(agent.id)[0]?.runId ?? null)
      : null,
    currentConversationId: ["working", "meeting", "waiting_input"].includes(agent.workState)
      ? (runs.active(agent.id)[0]?.conversationId ?? null)
      : null,
  });
  const snapshot = (): OfficeSnapshot => ({
    bootId,
    workspaceRoot: paths.root,
    executionMode: executionMode as "sandboxed" | "account",
    lastSeq: store.lastSeq(),
    defaultView: options.defaultView,
    agents: store.listAgents().map(decorate),
    meetings: store.listMeetings(),
  });
  const broadcast = (type: string, payload: unknown) => {
    if (type === "office.agent") payload = decorate(payload as AgentProfile);
    const message = JSON.stringify({ type, payload });
    for (const ws of wss.clients) {
      if (ws.readyState !== WebSocket.OPEN) continue;
      if (Date.now() >= (socketSessions.get(ws)?.expiresAt ?? 0)) {
        ws.close(1008, "Session expired");
        continue;
      }
      if (ws.bufferedAmount > 1024 * 1024) {
        ws.close(1013, "Reconnect to catch up");
        continue;
      }
      ws.send(message);
    }
  };
  const policy = await createHotRegistry(paths);
  const releases = await createReleaseManager(paths, policy, broadcast, bootId);
  const proxy = new ModelProxy((agentId) => {
    const agent = store.getAgent(agentId);
    if (!agent || vault.status(agent.credentialSlotId) !== "configured") throw new OfficeError("key_required", 409);
    const slot = agent.credentialSlotId!;
    const value = vault.get(slot)!;
    const provider = store.getProvider(value.providerId);
    if (!provider || provider.id !== agent.providerId || !agent.model) throw new OfficeError("model_required", 409);
    return {
      apiKey: value.apiKey,
      baseUrl: provider.baseUrl,
      model: agent.model,
      wireApi: provider.wireApi,
      authMode: provider.authMode,
      onUnauthorized: () => {
        if (vault.get(slot)?.apiKey === value.apiKey) vault.markInvalid(slot);
      },
    };
  });
  await proxy.start();
  const modelCatalog = new ModelCatalog(paths, vault, codexBinary);
  const runs = new RunRegistry(
    paths,
    store,
    vault,
    proxy,
    policy,
    broadcast,
    codexBinary,
    executionMode as "sandboxed" | "account",
    (profile) =>
      modelCatalog.validateSelection(
        profile.providerId ? store.getProvider(profile.providerId) : undefined,
        profile.credentialSlotId ?? undefined,
        profile.model,
        profile.reasoningEffort,
      ),
    services,
    contexts,
    layoutVersion,
  );
  const agentWorktreeRoot = async (agentId: string) => {
    const base = path.join(paths.projects, ".worktrees");
    let hashes: string[] = [];
    try {
      hashes = await readdir(base);
    } catch {
      throw new OfficeError("file_not_found", 404);
    }
    let newest: { root: string; mtime: number } | null = null;
    for (const hash of hashes) {
      const candidate = path.join(base, hash, agentId);
      try {
        const info = await stat(candidate);
        if (info.isDirectory() && (!newest || info.mtimeMs > newest.mtime))
          newest = { root: candidate, mtime: info.mtimeMs };
      } catch {
        /* not this agent's worktree */
      }
    }
    if (!newest) throw new OfficeError("file_not_found", 404);
    return newest.root;
  };
  const app = express();
  app.disable("x-powered-by");
  app.use("/api/office/agents/:id/attachments", express.json({ limit: "8mb" }));
  app.use(express.json({ limit: "2mb" }));
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
  });
  const route = (fn: (req: Request, res: Response) => unknown) => (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve()
      .then(() => fn(req, res))
      .catch(next);
  };
  const requireAgent = (id: string) => {
    const agent = store.getAgent(id);
    if (!agent) throw new OfficeError("agent_not_found", 404);
    return agent;
  };
  const attachments = new AttachmentStore(paths, safe, layoutVersion);
  const issuePairingCode = () => {
    code = randomBytes(18).toString("hex");
    codeExpires = Date.now() + 5 * 60 * 1000;
    return code;
  };
  const modelReady = (id: string) => {
    const agent = requireAgent(id);
    if (services.credentialState(agent) !== "configured") throw new OfficeError("key_required", 409);
    if (!agent.model || !agent.providerId) throw new OfficeError("model_required", 409);
    return agent;
  };
  // Run-scoped team tools cannot access login, keys, creation/deletion or administrative updates.
  app.post(
    "/api/office/team",
    route(async (req, res) => {
      const capability = proxy.authorize(String(req.headers.authorization ?? "").replace(/^Bearer /, ""));
      if (!capability) throw new OfficeError("invalid_run_capability", 401);
      const sender = requireAgent(capability.agentId);
      const { tool, args = {} } = req.body ?? {};
      const permissions = runs.permissions(capability.runId);
      const runToken = String(req.headers.authorization ?? "").replace(/^Bearer /, "");
      if (tool === "office_search_conversations") {
        if (!permissions) throw new OfficeError("run_not_active", 409);
        const query = typeof args.search === "string" ? args.search.slice(0, 500).toLowerCase() : "";
        const conversations = store
          .listConversations()
          .filter(
            (conversation) =>
              !query ||
              [conversation.id, conversation.title, conversation.category, conversation.summary]
                .join(" ")
                .toLowerCase()
                .includes(query),
          )
          .slice(0, 100);
        res.json({ conversations });
        return;
      }
      if (tool === "office_read_conversation") {
        if (!permissions) throw new OfficeError("run_not_active", 409);
        const sourceId = text(args.conversationId, 256);
        if (deletingConversations.has(sourceId)) throw new OfficeError("conversation_busy", 409);
        const conversation = store.getConversation(sourceId);
        if (!conversation) throw new OfficeError("conversation_not_found", 404);
        const offset = Number(args.offset ?? 0),
          limit = Number(args.limit ?? 12000);
        if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(limit) || limit < 1 || limit > 24000)
          throw new OfficeError("invalid_context_cursor");
        const transcript = store
          .messages(conversation.agentId, conversation.id)
          .map((message) => `[${message.role}] ${message.content}`)
          .join("\n\n");
        contexts.recordRead(conversation.id, sender.id, permissions.conversationId);
        res.json({
          conversation,
          content: redact(safe(transcript.slice(offset, offset + limit)), [runToken]),
          nextOffset: offset + limit < transcript.length ? offset + limit : null,
          totalCharacters: transcript.length,
        });
        return;
      }
      if (["office_read_file", "office_write_file", "office_list_files"].includes(tool)) {
        if (!permissions) throw new OfficeError("run_not_active", 409);
        const input = text(args.path, 4096);
        if (redact(safe(input), [runToken]) !== input) throw new OfficeError("invalid_file_path");
        const file = await resolveWorkspacePath(paths, input);
        const allowed = [permissions.workDir, paths.shared, paths.artifacts, layoutFor(sender.id).profile];
        const memory = path.relative(paths.agents, file).split(path.sep);
        const colleagueMemory =
          tool === "office_read_file" &&
          memory.length === 2 &&
          ["resume.md", "README.md"].includes(memory[1]) &&
          Boolean(store.getRawAgent(memory[0]));
        if (
          !colleagueMemory &&
          !allowed.some((root) => {
            const rel = path.relative(root, file);
            return !path.isAbsolute(rel) && rel !== ".." && !rel.startsWith(".." + path.sep);
          })
        )
          throw new OfficeError("file_outside_agent_workspace", 403);
        if (tool === "office_write_file") {
          if (permissions.readOnly) throw new OfficeError("meeting_tools_read_only", 403);
          const content = redact(safe(typeof args.content === "string" ? args.content : ""), [runToken]);
          if (content.length > 2 * 1024 * 1024) throw new OfficeError("file_too_large", 413);
          await mkdir(path.dirname(file), { recursive: true });
          await safeWrite(paths, file, content);
          res.json({ ok: true, path: path.relative(paths.root, file) });
          return;
        }
        if (tool === "office_list_files") {
          res.json({
            entries: (await readdir(file, { withFileTypes: true })).map((entry) => ({
              name: entry.name,
              type: entry.isDirectory() ? "directory" : entry.isFile() ? "file" : "link",
            })),
          });
          return;
        }
        const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
        try {
          const info = await handle.stat();
          if (!info.isFile() || info.nlink !== 1 || info.size > 2 * 1024 * 1024)
            throw new OfficeError("file_not_readable");
          res.json({
            path: path.relative(paths.root, file),
            content: redact(safe(await handle.readFile("utf8")), [runToken]),
          });
        } finally {
          await handle.close();
        }
        return;
      }
      if (tool === "office_list_skills" || tool === "office_read_skill") {
        if (!permissions) throw new OfficeError("run_not_active", 409);
        if (tool === "office_list_skills") {
          res.json({ skills: await listSkills(paths.root) });
          return;
        }
        res.json(await readSkillFile(paths.root, args.name, args.file));
        return;
      }
      if (tool === "office_status") {
        res.json({
          agents: store.listAgents().map(decorate),
          inbox: store
            .messages(sender.id)
            .filter((message) => message.role === "system" && message.content.startsWith("来自 "))
            .slice(-20),
        });
        return;
      }
      if (!["office_message", "office_delegate"].includes(tool)) throw new OfficeError("unknown_team_tool");
      if (permissions?.readOnly && tool === "office_delegate") throw new OfficeError("meeting_tools_read_only", 403);
      const target = requireAgent(text(args.agentId, 120));
      const content = redact(safe(text(args.content)), [
        String(req.headers.authorization ?? "").replace(/^Bearer /, ""),
      ]);
      const msg = store.addMessage({
        agentId: target.id,
        role: "system",
        content: `来自 ${sender.name}：${content}`,
        runId: capability.runId,
      });
      if (tool === "office_message") {
        broadcast("office.message", { agentId: target.id });
        res.json({ messageId: msg.id });
        return;
      }
      if (
        target.id === sender.id ||
        deleting.has(target.id) ||
        runs.active(target.id).length ||
        store.listMeetings().some((meeting) => meeting.phase !== "ended" && meeting.participantIds.includes(target.id))
      )
        throw new OfficeError("target_agent_busy", 409);
      modelReady(target.id);
      const run = await runs.start({
        agentId: target.id,
        taskId: randomUUID(),
        kind: "task",
        projectPath: typeof args.projectPath === "string" ? args.projectPath : undefined,
        prompt: `${sender.name} 委派：${content}`,
        idempotencyKey: msg.id,
      });
      res.json({ messageId: msg.id, runId: run.runId });
    }),
  );
  app.get("/healthz", (_req, res) =>
    res.json({
      ok: true,
      executors: {
        codex: { available: Boolean(codexExecutable), version: codexExecutable?.version ?? null },
      },
      backup: backupInfo,
    }),
  );
  app.get("/api/office/session", (req, res) => {
    const session = sessions.get(cookies(req));
    if (!session) {
      res.status(401).json({ error: "unauthorized" });
      return;
    }
    res.json({ authenticated: true, csrfToken: session.csrfToken });
  });
  app.post("/api/office/session", (req, res) => {
    const input = String(req.body?.pairingCode ?? "");
    if (!trusted(req) || !code || Date.now() > codeExpires || !eq(input, code)) {
      res.status(401).json({ error: "invalid_pairing_code" });
      return;
    }
    code = "";
    const session = sessions.create();
    res.setHeader(
      "Set-Cookie",
      `office_session=${session.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${session.maxAgeSeconds}${req.secure ? "; Secure" : ""}`,
    );
    res.setHeader("Cache-Control", "no-store");
    res.json({ csrfToken: session.csrfToken });
  });
  app.use("/api", (req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    const session = sessions.get(cookies(req));
    if (!session) {
      res.status(401).json({ error: "unauthorized" });
      return;
    }
    if (
      !trusted(req) ||
      (!["GET", "HEAD"].includes(req.method) && !eq(String(req.headers["x-csrf-token"] ?? ""), session.csrfToken))
    ) {
      res.status(403).json({ error: "request_rejected" });
      return;
    }
    next();
  });
  app.post("/api/office/session/logout", (req, res) => {
    const token = cookies(req);
    sessions.revoke(token);
    for (const [ws, session] of socketSessions) if (session.token === token) ws.close(1008, "Logged out");
    res.setHeader(
      "Set-Cookie",
      `office_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${req.secure ? "; Secure" : ""}`,
    );
    res.json({ ok: true });
  });
  app.get("/api/office/snapshot", (_req, res) => res.json(snapshot()));
  app.get("/api/office/agents/archived", (req, res) =>
    res.json({
      agents: req.query.includeDismissed === "true" ? store.listHistoricalAgents() : store.listArchivedAgents(),
    }),
  );
  const publicProvider = (provider: ReturnType<OfficeStore["addProvider"]>) => ({
    ...provider,
    credentialState: services.credentialState(provider),
  });
  const bindProviderSlot = (providerId: string, slotId: string) => {
    const provider = store.setProviderSlot(providerId, slotId);
    for (const agent of store.listAgents())
      if (agent.providerId === providerId && !deleting.has(agent.id)) store.bindCredential(agent.id, slotId);
    return provider;
  };
  const activeProvider = (providerId: string) =>
    maintenanceProviders.has(providerId) || runs.active().some((run) => run.providerId === providerId);
  const requireProvider = (id: string) => {
    const provider = store.getProvider(id);
    if (!provider) throw new OfficeError("provider_not_found", 404);
    return provider;
  };
  app.get("/api/office/providers", (_req, res) => res.json({ providers: store.listProviders().map(publicProvider) }));
  app.post(
    "/api/office/providers",
    route((req, res) => {
      const key = req.body?.apiKey;
      if (key !== undefined && (typeof key !== "string" || !key.trim() || key.length > 8192))
        throw new OfficeError("invalid_api_key");
      if (req.body?.authMode === "account" && key) throw new OfficeError("invalid_auth_mode");
      let provider = store.addProvider(req.body);
      if (key) provider = bindProviderSlot(provider.id, vault.put(provider.id, key));
      broadcast("office.snapshot", snapshot());
      res.status(201).json({ provider: publicProvider(provider) });
    }),
  );
  app.put(
    "/api/office/providers/:id/credential",
    route((req, res) => {
      const provider = requireProvider(String(req.params.id));
      if (provider.authMode !== "api_key") throw new OfficeError("invalid_auth_mode");
      const slot = vault.put(provider.id, req.body?.apiKey, provider.credentialSlotId ?? undefined);
      const updated = bindProviderSlot(provider.id, slot);
      broadcast("office.snapshot", snapshot());
      res.json({ provider: publicProvider(updated) });
    }),
  );
  app.delete(
    "/api/office/providers/:id",
    route(async (req, res) => {
      const provider = requireProvider(String(req.params.id));
      store.deleteProvider(provider.id);
      broadcast("office.snapshot", snapshot());
      const cleanup = (async () => {
        await runs.whenProviderIdle(provider.id);
        try {
          await services.clearProvider(provider.id);
        } finally {
          vault.revokeProvider(provider.id);
        }
      })();
      background.add(cleanup);
      void cleanup
        .finally(() => background.delete(cleanup))
        .catch(() => {
          // The provider stays unavailable; shutdown also clears all remaining runtime credentials.
        });
      res.json({ ok: true });
    }),
  );
  app.post(
    "/api/office/providers/:id/auth/start",
    route(async (req, res) => {
      const id = String(req.params.id);
      requireProvider(id);
      if (activeProvider(id)) throw new OfficeError("provider_busy", 409);
      res.json({ flow: await services.startLogin(id) });
    }),
  );
  app.get(
    "/api/office/providers/:id/auth/status",
    route(async (req, res) => {
      const id = String(req.params.id);
      requireProvider(id);
      const flow = await services.loginStatus(
        id,
        typeof req.query.loginId === "string" ? req.query.loginId : undefined,
      );
      if (flow.state === "completed") broadcast("office.snapshot", snapshot());
      res.json({ flow });
    }),
  );
  app.post(
    "/api/office/providers/:id/auth/complete",
    route(async (req, res) => {
      const id = String(req.params.id);
      requireProvider(id);
      const flow = await services.completeLogin(id, text(req.body?.loginId, 256), text(req.body?.code, 8192));
      broadcast("office.snapshot", snapshot());
      res.json({ flow });
    }),
  );
  app.delete(
    "/api/office/providers/:id/auth",
    route(async (req, res) => {
      const id = String(req.params.id);
      requireProvider(id);
      if (activeProvider(id)) throw new OfficeError("provider_busy", 409);
      await services.cancelLogin(id, typeof req.body?.loginId === "string" ? req.body.loginId : undefined);
      broadcast("office.snapshot", snapshot());
      res.json({ ok: true });
    }),
  );
  app.get(
    "/api/office/providers/:id/capabilities",
    route(async (req, res) => {
      const provider = store.getProvider(String(req.params.id));
      if (!provider) throw new OfficeError("provider_not_found", 404);
      const agent = typeof req.query.agentId === "string" ? requireAgent(req.query.agentId) : undefined;
      const slotId =
        typeof req.query.slotId === "string"
          ? text(req.query.slotId, 256)
          : agent?.providerId === provider.id
            ? (agent.credentialSlotId ?? undefined)
            : (provider.credentialSlotId ?? undefined);
      const model =
        typeof req.query.model === "string" && req.query.model.trim() ? safe(text(req.query.model, 256)) : "";
      const description = await modelCatalog.describe(provider, slotId, model, req.query.refresh === "1");
      if (provider.authMode === "account" && services.credentialState(provider) === "configured") {
        description.catalogState = "ready";
        description.catalogMessage = "账户已登录。模型可手填；具体可用性由当前账户和执行器决定。";
        if (provider.executor === "codex") {
          try {
            const models = await services.listAccountModels(provider.id);
            const capabilities: ModelCapability[] = models
              .filter((entry) => typeof entry.id === "string" && !entry.hidden)
              .map((entry) => {
                const raw = Array.isArray(entry.supportedReasoningEfforts) ? entry.supportedReasoningEfforts : [];
                const efforts = raw
                  .map((value) =>
                    typeof value === "string" ? value : (value as { reasoningEffort?: unknown })?.reasoningEffort,
                  )
                  .filter((value): value is ReasoningEffort => REASONING_EFFORTS.includes(value as ReasoningEffort));
                return {
                  id: String(entry.model ?? entry.id),
                  name: typeof entry.displayName === "string" ? entry.displayName : undefined,
                  reasoningEfforts: efforts,
                  defaultReasoningEffort: REASONING_EFFORTS.includes(entry.defaultReasoningEffort as ReasoningEffort)
                    ? (entry.defaultReasoningEffort as ReasoningEffort)
                    : null,
                  reasoningSource: "provider",
                };
              });
            if (capabilities.length) {
              description.models = capabilities.map((entry) => entry.id);
              description.modelCapabilities = capabilities;
              description.selectedModel = capabilities.find((entry) => entry.id === model) ?? description.selectedModel;
              description.reasoningEfforts = description.selectedModel?.reasoningEfforts ?? [];
              description.catalogMessage = "已读取当前Codex账户的模型目录。";
            }
          } catch {
            description.catalogMessage = "账户已登录，模型目录暂不可用，可手填模型ID。";
          }
        }
      }
      res.json(description);
    }),
  );
  app.post(
    "/api/office/credentials",
    route((req, res) => {
      const { providerId, apiKey, restoreSlotId } = req.body ?? {};
      if (!store.getProvider(providerId)) throw new OfficeError("provider_not_found", 404);
      if (
        restoreSlotId &&
        !store.listAgents().some((a) => a.credentialSlotId === restoreSlotId && a.providerId === providerId)
      )
        throw new OfficeError("invalid_credential_slot", 403);
      const slotId = vault.put(providerId, apiKey, restoreSlotId);
      broadcast("office.snapshot", snapshot());
      res.status(201).json({ slotId, state: "configured" });
    }),
  );
  app.delete(
    "/api/office/credentials/:slotId",
    route((req, res) => {
      vault.revoke(String(req.params.slotId));
      broadcast("office.snapshot", snapshot());
      res.json({ ok: true });
    }),
  );
  app.put(
    "/api/office/agents/:id/credential",
    route((req, res) => {
      const agent = requireAgent(String(req.params.id));
      if (deleting.has(agent.id)) throw new OfficeError("agent_deleting", 409);
      const value = vault.get(req.body?.slotId);
      if (!value || value.providerId !== agent.providerId) throw new OfficeError("invalid_credential_slot");
      const updated = store.bindCredential(agent.id, req.body.slotId);
      broadcast("office.agent", updated);
      res.json({ agent: decorate(updated) });
    }),
  );
  app.post(
    "/api/office/agents",
    route(async (req, res) => {
      if (req.body?.providerId && !store.getProvider(req.body.providerId))
        throw new OfficeError("provider_not_found", 404);
      await modelCatalog.validateSelection(
        typeof req.body?.providerId === "string" ? store.getProvider(req.body.providerId) : undefined,
        undefined,
        req.body?.model,
        req.body?.reasoningEffort,
      );
      const agent = store.createAgent(req.body as AgentDraft);
      await initializeAgentMemory(paths, agent, layoutVersion).catch(() => {});
      if (agent.providerId)
        store.bindCredential(agent.id, store.getProvider(agent.providerId)?.credentialSlotId ?? null);
      broadcast("office.snapshot", snapshot());
      res.status(201).json({ agent: decorate(requireAgent(agent.id)) });
    }),
  );
  app.patch(
    "/api/office/agents/:id",
    route(async (req, res) => {
      if (req.body?.providerId && !store.getProvider(req.body.providerId))
        throw new OfficeError("provider_not_found", 404);
      const previous = requireAgent(String(req.params.id));
      if (deleting.has(previous.id)) throw new OfficeError("agent_deleting", 409);
      if (req.body && (Object.hasOwn(req.body, "model") || Object.hasOwn(req.body, "reasoningEffort"))) {
        const candidate = { ...previous, ...req.body };
        await modelCatalog.validateSelection(
          typeof candidate.providerId === "string" ? store.getProvider(candidate.providerId) : undefined,
          candidate.providerId === previous.providerId ? (previous.credentialSlotId ?? undefined) : undefined,
          candidate.model,
          candidate.reasoningEffort,
        );
        const current = requireAgent(previous.id);
        if (
          ["providerId", "model", "reasoningEffort", "credentialSlotId"].some(
            (key) => current[key as keyof AgentProfile] !== previous[key as keyof AgentProfile],
          )
        )
          throw new OfficeError("agent_config_changed", 409);
      }
      if (deleting.has(previous.id)) throw new OfficeError("agent_deleting", 409);
      const agent = store.patchAgent(previous.id, req.body);
      if (agent.providerId !== previous.providerId)
        store.bindCredential(
          agent.id,
          agent.providerId ? (store.getProvider(agent.providerId)?.credentialSlotId ?? null) : null,
        );
      const result = decorate(requireAgent(agent.id));
      broadcast("office.agent", result);
      res.json({ agent: result });
    }),
  );
  app.post(
    "/api/office/agents/:id/clone",
    route((req, res) => {
      const source = requireAgent(String(req.params.id));
      if (deleting.has(source.id)) throw new OfficeError("agent_deleting", 409);
      const agent = store.cloneAgent(source.id, req.body?.name ?? `${source.name} 副本`, req.body?.jobFunction);
      void initializeAgentMemory(paths, agent, layoutVersion).catch(() => {});
      broadcast("office.snapshot", snapshot());
      res.status(201).json({ agent: decorate(agent) });
    }),
  );
  const deleting = new Set<string>();
  app.delete(
    "/api/office/agents/:id",
    route(async (req, res) => {
      const agent = store.getRawAgent(String(req.params.id));
      if (!agent) throw new OfficeError("agent_not_found", 404);
      if (agent.isBoss) throw new OfficeError("boss_protected", 403);
      if (store.getAgentLifecycle(agent.id) === "dismissed") throw new OfficeError("agent_dismissed", 409);
      if (deleting.has(agent.id)) throw new OfficeError("agent_deleting", 409);
      if (runs.active(agent.id).length && req.query.stop !== "true") throw new OfficeError("agent_busy", 409);
      const unlock = runs.lockAgents([agent.id]);
      deleting.add(agent.id);
      try {
        await runs.stopAgent(agent.id);
        if (runs.active(agent.id).length) throw new OfficeError("agent_busy", 409);
        if (store.getAgent(agent.id)) store.updateWork(agent.id, "idle", "任务已停止");
        store.archiveAgent(agent.id);
        broadcast("office.snapshot", snapshot());
        res.json({ ok: true });
      } finally {
        deleting.delete(agent.id);
        unlock();
      }
    }),
  );
  app.delete(
    "/api/office/agents/:id/dismiss",
    route(async (req, res) => {
      const agent = store.getRawAgent(String(req.params.id));
      if (!agent) throw new OfficeError("agent_not_found", 404);
      if (agent.isBoss) throw new OfficeError("boss_protected", 403);
      if (store.getAgentLifecycle(agent.id) === "active") throw new OfficeError("agent_not_archived", 409);
      if (deleting.has(agent.id)) throw new OfficeError("agent_deleting", 409);
      const unlock = runs.lockAgents([agent.id]);
      deleting.add(agent.id);
      try {
        await runs.stopAgent(agent.id);
        if (runs.active(agent.id).length) throw new OfficeError("agent_busy", 409);
        store.dismissAgent(agent.id);
        if (agent.credentialSlotId && !store.hasCredentialSlotReference(agent.credentialSlotId))
          vault.revoke(agent.credentialSlotId);
        broadcast("office.snapshot", snapshot());
        res.json({ ok: true });
      } finally {
        deleting.delete(agent.id);
        unlock();
      }
    }),
  );
  app.get(
    "/api/office/agents/:id/messages",
    route((req, res) => {
      res.json({ messages: store.messages(String(req.params.id)) });
    }),
  );
  const deletingConversations = new Set<string>();
  const requireConversation = (id: string) => {
    const conversation = store.getConversation(id);
    if (!conversation) throw new OfficeError("conversation_not_found", 404);
    return conversation;
  };
  const decorateConversation = (conversation: ReturnType<OfficeStore["createConversation"]>) => ({
    ...conversation,
    readers: contexts.readers(conversation.id),
  });
  const conversationBusy = (id: string) => runs.active().some((run) => run.conversationId === id);
  app.get(
    "/api/office/agents/:id/conversations",
    route((req, res) => {
      const id = String(req.params.id);
      if (!store.getRawAgent(id)) throw new OfficeError("agent_not_found", 404);
      res.json({ conversations: store.listConversations(id).map(decorateConversation) });
    }),
  );
  app.post(
    "/api/office/agents/:id/conversations",
    route((req, res) => {
      const agent = requireAgent(String(req.params.id));
      res.status(201).json({
        conversation: decorateConversation(
          store.createConversation(
            agent.id,
            typeof req.body?.title === "string" ? safe(text(req.body.title, 160)) : undefined,
          ),
        ),
      });
    }),
  );
  app.get(
    "/api/office/conversations",
    route((req, res) => {
      const query = typeof req.query.search === "string" ? req.query.search.slice(0, 500).trim().toLowerCase() : "";
      const category = typeof req.query.category === "string" ? req.query.category : "";
      const agentId = typeof req.query.agentId === "string" ? req.query.agentId : undefined;
      const conversations = store
        .listConversations(agentId)
        .filter(
          (conversation) =>
            (!category || conversation.category === category) &&
            (!query ||
              [
                conversation.id,
                conversation.title,
                conversation.category,
                conversation.summary,
                store.getRawAgent(conversation.agentId)?.name,
              ]
                .join(" ")
                .toLowerCase()
                .includes(query)),
        );
      res.json({ conversations: conversations.map(decorateConversation) });
    }),
  );
  app.get(
    "/api/office/conversations/:id/messages",
    route((req, res) => {
      const conversation = requireConversation(String(req.params.id));
      res.json({
        conversation: decorateConversation(conversation),
        messages: store.messages(conversation.agentId, conversation.id),
      });
    }),
  );
  app.patch(
    "/api/office/conversations/:id",
    route((req, res) => {
      const id = String(req.params.id);
      requireConversation(id);
      res.json({
        conversation: decorateConversation(
          store.patchConversation(id, {
            ...(typeof req.body?.title === "string" ? { title: safe(text(req.body.title, 160)) } : {}),
            ...(typeof req.body?.category === "string" ? { category: safe(text(req.body.category, 80)) } : {}),
          }),
        ),
      });
    }),
  );
  app.get(
    "/api/office/conversations/:id/context",
    route((req, res) => {
      const conversation = requireConversation(String(req.params.id));
      res.json({ references: contexts.references(conversation.id) });
    }),
  );
  app.post(
    "/api/office/conversations/:id/context",
    route((req, res) => {
      const conversation = requireConversation(String(req.params.id));
      requireAgent(conversation.agentId);
      if (conversationBusy(conversation.id) || deletingConversations.has(conversation.id))
        throw new OfficeError("conversation_busy", 409);
      for (const id of Array.isArray(req.body?.sourceConversationIds) ? req.body.sourceConversationIds : [])
        if (deletingConversations.has(id)) throw new OfficeError("conversation_busy", 409);
      res.json({ references: contexts.add(conversation.id, req.body?.sourceConversationIds) });
    }),
  );
  const acquireCleanupScope = (
    conversationIds: string[],
    plans: Array<ReturnType<OfficeStore["previewConversationDeletion"]>>,
    extraAgentIds: string[] = [],
  ) => {
    const agentIds = new Set([
      ...extraAgentIds,
      ...conversationIds.map((id) => store.getConversation(id)?.agentId).filter((id): id is string => !!id),
    ]);
    const providerIds = new Set(
      plans
        .flatMap((plan) => plan.nativeThreads.map((thread) => thread.providerId))
        .filter((id): id is string => !!id && store.getRawProvider(id)?.authMode === "account"),
    );
    for (const agent of store.listAgents())
      if (agent.providerId && providerIds.has(agent.providerId)) agentIds.add(agent.id);
    if (
      runs
        .active()
        .some((run) => agentIds.has(run.agentId) || Boolean(run.providerId && providerIds.has(run.providerId))) ||
      [...providerIds].some((id) => maintenanceProviders.has(id))
    )
      throw new OfficeError("conversation_busy", 409);
    const release = runs.lockAgents([...agentIds]);
    providerIds.forEach((id) => maintenanceProviders.add(id));
    return () => {
      release();
      providerIds.forEach((id) => maintenanceProviders.delete(id));
    };
  };
  const deletionDirectory = await resolveWorkspacePath(paths, "state/deletions");
  await mkdir(deletionDirectory, { recursive: true, mode: 0o700 });
  const saveDeletion = async (data: unknown) => {
    const journal = await resolveWorkspacePath(paths, `state/deletions/${randomUUID()}.json`);
    await safeWrite(paths, journal, JSON.stringify(data));
    return journal;
  };
  const resetNativeContext = async (conversationId: string) => {
    const conversation = store.getConversation(conversationId);
    if (!conversation) return;
    const preview = store.previewConversationDeletion(conversationId);
    const plan = { nativeThreads: preview.nativeThreads, runIds: [], attachments: [] };
    const journal = await saveDeletion({
      version: 1,
      kind: "reset",
      agentId: conversation.agentId,
      conversationId,
      createdAt: conversation.createdAt,
      plan,
    });
    try {
      store.resetConversationThreads(conversationId);
      await purgeConversationFiles(paths, conversation.agentId, plan, layoutVersion);
      await unlink(journal);
    } catch {
      const id = path.basename(journal);
      pendingCleanups.set(id, { id, conversationId, message: "上下文缓存清理未完成，请重试。" });
      throw new OfficeError("conversation_cleanup_pending", 409);
    }
  };
  app.delete(
    "/api/office/conversations/:id/context/:referenceId",
    route(async (req, res) => {
      const conversation = requireConversation(String(req.params.id));
      requireAgent(conversation.agentId);
      const release = acquireCleanupScope([conversation.id], [store.previewConversationDeletion(conversation.id)]);
      try {
        await resetNativeContext(conversation.id);
        contexts.remove(conversation.id, String(req.params.referenceId));
        res.json({ ok: true });
      } finally {
        release();
      }
    }),
  );
  app.delete(
    "/api/office/conversations/:id",
    route(async (req, res) => {
      const conversation = requireConversation(String(req.params.id));
      const targets = contexts.affectedTargets(conversation.id).filter((id) => !!store.getConversation(id));
      if (deletingConversations.has(conversation.id)) throw new OfficeError("conversation_busy", 409);
      const plan = store.previewConversationDeletion(conversation.id);
      const release = acquireCleanupScope(
        [conversation.id, ...targets],
        [plan, ...targets.map((id) => store.previewConversationDeletion(id))],
      );
      deletingConversations.add(conversation.id);
      let journal: string | undefined;
      try {
        journal = await saveDeletion({
          version: 1,
          kind: "delete",
          agentId: conversation.agentId,
          conversationId: conversation.id,
          createdAt: conversation.createdAt,
          targets,
          plan,
        });
        store.deleteConversation(conversation.id);
        await purgeConversationFiles(paths, conversation.agentId, plan, layoutVersion);
        for (const id of targets) await resetNativeContext(id);
        contexts.purge(conversation.id);
        await unlink(journal);
        broadcast("office.snapshot", snapshot());
        res.json({ ok: true });
      } catch (error) {
        if (journal) {
          const id = path.basename(journal);
          pendingCleanups.set(id, {
            id,
            conversationId: conversation.id,
            message: "会话记录已移除，存储文件清理待重试。",
          });
          throw new OfficeError("conversation_cleanup_pending", 409);
        }
        throw error;
      } finally {
        deletingConversations.delete(conversation.id);
        release();
      }
    }),
  );
  const pendingCleanups = new Map<string, { id: string; conversationId?: string; message: string }>();
  const cleanupInFlight = new Set<string>();
  const readDeletionJob = async (file: string) => {
    const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    let job: {
      version: number;
      kind: "delete" | "reset";
      agentId: string;
      conversationId: string;
      createdAt: number;
      targets?: string[];
      plan: ReturnType<OfficeStore["previewConversationDeletion"]>;
    };
    try {
      const info = await handle.stat();
      if (!info.isFile() || info.nlink !== 1 || info.size > 1024 * 1024)
        throw new OfficeError("invalid_deletion_journal", 503);
      job = JSON.parse(await handle.readFile("utf8"));
    } finally {
      await handle.close();
    }
    if (
      job.version !== 1 ||
      !["delete", "reset"].includes(job.kind) ||
      !Array.isArray(job.plan?.nativeThreads) ||
      !Array.isArray(job.plan?.runIds) ||
      !Array.isArray(job.plan?.attachments)
    )
      throw new OfficeError("invalid_deletion_journal", 503);
    return job;
  };
  const executeDeletionJob = async (file: string, job: Awaited<ReturnType<typeof readDeletionJob>>) => {
    const current = store.getConversation(job.conversationId);
    if (current && (current.createdAt !== job.createdAt || current.agentId !== job.agentId))
      throw new OfficeError("deletion_journal_identity_changed", 503);
    if (current) {
      if (job.kind === "delete") store.deleteConversation(job.conversationId);
      else store.resetConversationThreads(job.conversationId);
    }
    await purgeConversationFiles(paths, job.agentId, job.plan, layoutVersion);
    if (job.kind === "delete") {
      for (const id of job.targets ?? []) await resetNativeContext(id);
      contexts.purge(job.conversationId);
    }
    await unlink(file);
  };
  const retryCleanup = async (id: string) => {
    if (!/^[a-f0-9-]{36}\.json$/.test(id)) throw new OfficeError("invalid_deletion_journal");
    if (cleanupInFlight.has(id)) throw new OfficeError("conversation_busy", 409);
    cleanupInFlight.add(id);
    let release: (() => void) | undefined;
    try {
      const file = await resolveWorkspacePath(paths, path.join(deletionDirectory, id));
      const job = await readDeletionJob(file);
      const targets = (job.targets ?? []).filter((value) => !!store.getConversation(value));
      release = acquireCleanupScope(
        [job.conversationId, ...targets],
        [job.plan, ...targets.map((value) => store.previewConversationDeletion(value))],
        [job.agentId],
      );
      await executeDeletionJob(file, job);
      pendingCleanups.delete(id);
    } finally {
      release?.();
      cleanupInFlight.delete(id);
    }
  };
  // A cleanup failure keeps its journal and a visible retry action; the remaining office stays usable.
  for (const entry of await readdir(deletionDirectory, { withFileTypes: true })) {
    if (!/^[a-f0-9-]{36}\.json$/.test(entry.name) || !entry.isFile())
      throw new OfficeError("invalid_deletion_journal", 503);
    try {
      await retryCleanup(entry.name);
    } catch {
      pendingCleanups.set(entry.name, { id: entry.name, message: "会话存储清理未完成，请在服务空闲时重试。" });
    }
  }
  app.get("/api/office/conversation-cleanups", (_req, res) => res.json({ cleanups: [...pendingCleanups.values()] }));
  app.post(
    "/api/office/conversation-cleanups/:id/retry",
    route(async (req, res) => {
      const id = String(req.params.id);
      if (!pendingCleanups.has(id)) throw new OfficeError("cleanup_not_found", 404);
      try {
        await retryCleanup(id);
        broadcast("office.snapshot", snapshot());
        res.json({ ok: true });
      } catch {
        throw new OfficeError("conversation_cleanup_pending", 409);
      }
    }),
  );
  app.get(
    "/api/office/agents/:id/progress",
    route((req, res) => {
      const id = String(req.params.id);
      if (!store.getRawAgent(id)) throw new OfficeError("agent_not_found", 404);
      const after = Number(req.query.afterSeq ?? 0);
      if (!Number.isSafeInteger(after) || after < 0) throw new OfficeError("invalid_progress_cursor");
      res.json({
        events: store.progress(
          id,
          after,
          typeof req.query.conversationId === "string" ? req.query.conversationId : undefined,
        ),
      });
    }),
  );
  const pendingMessages = new Map<string, Promise<{ messageId: string; runId: string; conversationId: string }>>();
  app.post(
    "/api/office/agents/:id/attachments",
    route(async (req, res) => {
      const id = String(req.params.id);
      requireAgent(id);
      if (deleting.has(id)) throw new OfficeError("agent_deleting", 409);
      res.status(201).json({ attachment: await attachments.upload(id, req.body) });
    }),
  );
  app.get(
    "/api/office/agents/:id/attachments/:attachmentId",
    route(async (req, res) => {
      const id = String(req.params.id);
      if (!store.getRawAgent(id)) throw new OfficeError("agent_not_found", 404);
      const { handle, attachment } = await attachments.open(id, String(req.params.attachmentId));
      try {
        const data = await handle.readFile();
        if (data.length !== attachment.size) throw new OfficeError("attachment_changed", 409);
        res.setHeader("Content-Type", attachment.mimeType);
        res.setHeader("Content-Length", data.length);
        res.send(data);
      } finally {
        await handle.close();
      }
    }),
  );
  // Deliverables (images, decks, HTML, archives) produced in the agent workspace can be
  // opened or downloaded straight from a chat link. Paths stay inside projects/<agent>.
  app.get(
    "/api/office/agents/:id/files",
    route(async (req, res) => {
      const id = String(req.params.id);
      if (!store.getRawAgent(id)) throw new OfficeError("agent_not_found", 404);
      const requested = req.query.path;
      let root = layoutFor(id).work;
      try {
        const file = await resolveAgentFile(root, requested);
        sendAgentFile(res, file, parseFileMode(req.query.mode));
        return;
      } catch (error) {
        if (!(error instanceof OfficeError) || error.code !== "file_not_found") throw error;
      }
      // Files produced inside a shared project live in this agent's own worktree.
      root = await agentWorktreeRoot(id);
      const file = await resolveAgentFile(root, requested);
      sendAgentFile(res, file, parseFileMode(req.query.mode));
    }),
  );
  app.post(
    "/api/office/agents/:id/messages",
    route(async (req, res) => {
      const id = String(req.params.id);
      const conversationId =
        typeof req.body?.conversationId === "string" ? req.body.conversationId : store.defaultConversation(id).id;
      const conversation = requireConversation(conversationId);
      if (conversation.agentId !== id) throw new OfficeError("conversation_not_found", 404);
      if (deletingConversations.has(conversationId)) throw new OfficeError("conversation_busy", 409);
      const rawContent = req.body?.content;
      if (typeof rawContent !== "string" || rawContent.length > 128000) throw new OfficeError("invalid_text");
      const content = safe(rawContent.trim());
      const key = text(req.body?.idempotencyKey, 160);
      const requestKey = id + ":" + conversationId + ":" + key;
      const previous = store.messageRequest(id, key, conversationId);
      if (previous) {
        res.status(202).json(previous);
        return;
      }
      if (deleting.has(id)) throw new OfficeError("agent_deleting", 409);
      modelReady(id);
      let pending = pendingMessages.get(requestKey);
      if (!pending) {
        pending = (async () => {
          const images = await attachments.resolve(id, req.body?.attachmentIds ?? []);
          if (!content && !images.attachments.length) throw new OfficeError("invalid_text");
          if (deleting.has(id)) throw new OfficeError("agent_deleting", 409);
          modelReady(id);
          const run = await runs.start({
            agentId: id,
            conversationId,
            taskId: null,
            kind: "chat",
            prompt: content || "请分析随本条消息提供的图片。",
            idempotencyKey: key,
            imagePaths: images.paths,
            projectPath: req.body.projectPath,
            timeoutMs: req.body.timeoutMs,
          });
          const result = store.addRequestedMessage({
            agentId: id,
            content,
            attachments: images.attachments,
            runId: run.runId,
            key,
            conversationId,
          });
          broadcast("office.message", { agentId: id });
          return result;
        })();
        pendingMessages.set(requestKey, pending);
      }
      try {
        res.status(202).json(await pending);
      } finally {
        if (pendingMessages.get(requestKey) === pending) pendingMessages.delete(requestKey);
      }
    }),
  );
  app.post(
    "/api/office/runs/:id/stop",
    route(async (req, res) => {
      await runs.stop(String(req.params.id));
      res.json({ ok: true });
    }),
  );
  app.get(
    "/api/office/meetings/:id",
    route((req, res) => {
      const meeting = store.getMeeting(String(req.params.id));
      if (!meeting) throw new OfficeError("meeting_not_found", 404);
      const ids = new Set(meeting.messageIds);
      const messages = meeting.participantIds.flatMap((id) => store.messages(id)).filter((m) => ids.has(m.id));
      res.json({ meeting, messages });
    }),
  );
  app.post(
    "/api/office/meetings",
    route(async (req, res) => {
      const title = safe(text(req.body?.title, 500));
      const raw = req.body?.participantIds;
      if (!Array.isArray(raw) || raw.length < 2) throw new OfficeError("meeting_needs_participants");
      const participants = [...new Set(raw.map((id: unknown) => text(id, 120)))];
      if (participants.length < 2) throw new OfficeError("meeting_needs_participants");
      for (const id of participants) {
        modelReady(id);
        if (
          runs.active(id).length ||
          deleting.has(id) ||
          store.listMeetings().some((m) => m.phase !== "ended" && m.participantIds.includes(id))
        )
          throw new OfficeError("agent_busy", 409);
      }
      const meeting: MeetingSnapshot = {
        id: randomUUID(),
        taskId: randomUUID(),
        participantIds: participants,
        phase: "kickoff",
        messageIds: [],
      };
      store.putMeeting(meeting, title);
      for (const id of participants) store.updateWork(id, "meeting", title, meeting.taskId);
      broadcast("office.snapshot", snapshot());
      const job = (async () => {
        let context = "";
        try {
          for (const id of participants) {
            if (closing) break;
            const prompt = `团队会议：${title}\n已发言内容：\n${context || "你是首位发言者。"}\n请从自己的职能提出具体建议，明确交接事项。会议发言不要修改代码或委派任务。`;
            const run = await runs.start({
              agentId: id,
              taskId: meeting.taskId,
              kind: "meeting",
              prompt,
              idempotencyKey: `${meeting.id}:${id}`,
            });
            await run.done;
            const messages = store.messages(id).filter((m) => m.runId === run.runId);
            meeting.messageIds.push(...messages.map((m) => m.id));
            context += `\n${requireAgent(id).name}：${messages.map((m) => m.content).join("\n")}`;
            store.putMeeting(meeting, title);
            broadcast("office.meeting", meeting);
          }
        } finally {
          meeting.phase = "ended";
          store.putMeeting(meeting, title);
          for (const id of participants)
            if (store.getAgent(id) && !runs.active(id).length) store.updateWork(id, "idle", "当前暂无任务");
          broadcast("office.snapshot", snapshot());
        }
      })();
      background.add(job);
      void job.finally(() => background.delete(job)).catch(() => {});
      res.status(202).json({ meeting });
    }),
  );
  app.use("/api", (_req, res) => res.status(404).json({ error: "not_found" }));
  app.get("/", (_req, res) => res.redirect(options.defaultView === "chat" ? "/chat.html" : "/office.html"));
  app.use((req, res, next) =>
    express.static(releases.active().frontendDir, { index: false, redirect: false })(req, res, next),
  );
  app.use((_req, res) => res.status(404).send("页面尚未构建或资源不存在"));
  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (res.headersSent) {
      res.end();
      return;
    }
    res
      .status(error instanceof OfficeError ? error.status : 400)
      .json({ error: error instanceof OfficeError ? safe(error.code) : "invalid_request" });
  });
  const server = http.createServer(app);
  server.on("upgrade", (req, socket, head) => {
    const token = cookies(req);
    const session = sessions.get(token);
    if (req.url !== "/ws" || !session || !trusted(req)) {
      socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      socketSessions.set(ws, { token, expiresAt: session.expiresAt });
      ws.once("close", () => socketSessions.delete(ws));
      wss.emit("connection", ws, req);
      ws.send(JSON.stringify({ type: "office.snapshot", payload: snapshot() }));
    });
  });
  const expiryTimer = setInterval(() => {
    for (const [ws, session] of socketSessions) if (Date.now() >= session.expiresAt) ws.close(1008, "Session expired");
  }, 60000);
  expiryTimer.unref();
  try {
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(options.port, options.host ?? "127.0.0.1", () => {
        server.off("error", reject);
        resolve();
      });
    });
  } catch (error) {
    clearInterval(expiryTimer);
    await services.close();
    contexts.close();
    await modelCatalog.close();
    await proxy.close();
    await policy.close();
    sessions.close();
    vault.clear();
    store.close();
    throw error;
  }
  origin = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  runs.teamOrigin = origin;
  // Daily point-in-time snapshot (SQLite + native session files + agents/projects/skills).
  const backupInfo: { at: string | null; ok: boolean } = { at: null, ok: false };
  try {
    const latest = JSON.parse(await readFile(path.join(paths.root, "artifacts", "backups", "latest.json"), "utf8"));
    backupInfo.at = typeof latest.createdAt === "string" ? latest.createdAt : null;
    backupInfo.ok = latest.ok === true;
  } catch {
    /* first start, no backup yet */
  }
  let backupRunning = false;
  const runScheduledBackup = async () => {
    if (backupRunning || closing) return;
    backupRunning = true;
    try {
      if (backupInfo.at && Date.now() - Date.parse(backupInfo.at) < 24 * 60 * 60 * 1000) return;
      const { createOfficeBackup } = await import(
        pathToFileURL(path.join(paths.app, "scripts", "office-backup.mjs")).href
      );
      const result = await createOfficeBackup({ root: paths.root, keep: 7, reason: "daily" });
      backupInfo.at = result.createdAt;
      backupInfo.ok = true;
    } catch (error) {
      backupInfo.ok = false;
      console.error("daily_backup_failed", error instanceof Error ? error.message : String(error));
    } finally {
      backupRunning = false;
    }
  };
  const backupTimer = setInterval(() => void runScheduledBackup(), 60 * 60 * 1000);
  backupTimer.unref();
  void runScheduledBackup();
  const status = () => ({
    bootId,
    pid: process.pid,
    origin,
    workspaceRoot: paths.root,
    activeRuns: runs.active(),
    version: releases.active().manifest.id,
    executionMode,
    executors: executorStatus(),
    layoutVersion,
  });
  await writeFile(metadata, JSON.stringify(status()), { mode: 0o600 });
  let closePromise: Promise<void> | null = null;
  const close = () =>
    (closePromise ??= (async () => {
      closing = true;
      clearInterval(expiryTimer);
      clearInterval(backupTimer);
      code = "";
      for (const ws of wss.clients) ws.terminate();
      const stoppingRuns = runs.close();
      // A complete service stop owns every driver; closing them also resolves unacknowledged turns.
      await services.close();
      await stoppingRuns;
      await Promise.allSettled([...background]);
      await modelCatalog.close();
      await proxy.close();
      await policy.close();
      vault.clear();
      server.closeIdleConnections();
      server.closeAllConnections();
      await new Promise<void>((r) => server.close(() => r()));
      await new Promise<void>((r) => wss.close(() => r()));
      await new Promise<void>((r) => control.close(() => r()));
      store.close();
      contexts.close();
      sessions.close();
      await unlink(controlFile).catch(() => {});
      try {
        if (JSON.parse(await readFile(metadata, "utf8")).bootId === bootId) await unlink(metadata);
      } catch {
        /* Already removed. */
      }
    })());
  const control = net.createServer((socket) => {
    let input = "";
    socket.setTimeout(5000, () => socket.destroy());
    socket.on("data", (chunk) => {
      input += chunk;
      if (input.length > 16384) {
        socket.destroy();
        return;
      }
      const end = input.indexOf("\n");
      if (end < 0) return;
      const line = input.slice(0, end);
      input = "";
      // Release activation rewrites and re-hashes the whole frontend it before replying;
      // the 5s idle timer must not destroy the socket while an action is still running.
      socket.setTimeout(0);
      void (async () => {
        try {
          const { action, args = {} } = JSON.parse(line);
          if (action !== "status" && args.bootId !== bootId) throw new OfficeError("runtime_identity_mismatch", 409);
          let result: unknown;
          if (action === "status") result = status();
          else if (action === "pair") result = { pairingCode: issuePairingCode() };
          else if (action === "stop") {
            result = { stopping: true };
            setTimeout(() => void close(), 10).unref();
          } else if (action === "update") {
            const manifest = await releases.stage(text(args.bundle, 4096));
            result = await releases.apply(manifest.id);
          } else if (action === "rollback") result = await releases.rollback(text(args.release, 100));
          else if (action === "logs-prune") {
            const days = Number(args.olderThanDays ?? 14);
            if (!Number.isFinite(days) || days < 0) throw new OfficeError("invalid_retention");
            let count = 0;
            const active = new Set(runs.active().map((r) => r.runId + ".log"));
            for (const file of await readdir(paths.logs)) {
              if (!/^[a-f0-9-]{36}\.log$/.test(file) || active.has(file)) continue;
              const f = await resolveWorkspacePath(paths, path.join(paths.logs, file));
              if ((await stat(f)).mtimeMs < Date.now() - days * 86400000) {
                await unlink(f);
                count++;
              }
            }
            result = { removed: count };
          } else throw new OfficeError("unknown_control_action");
          socket.end(JSON.stringify({ ok: true, result }) + "\n");
        } catch (error) {
          socket.end(
            JSON.stringify({
              ok: false,
              error: error instanceof OfficeError ? safe(error.code) : "control_failed",
              status: error instanceof OfficeError ? error.status : 500,
            }) + "\n",
          );
        }
      })();
    });
  });
  await new Promise<void>((resolve, reject) => {
    control.once("error", reject);
    control.listen(socketPath, () => {
      control.off("error", reject);
      resolve();
    });
  });
  await chmod(controlFile, 0o600);
  return {
    origin,
    bootId,
    runtimePid: process.pid,
    controlSocketPath: controlFile,
    workspaceRoot: paths.root,
    issuePairingCode,
    status,
    close,
  };
}
