import { constants } from "node:fs";
import { access, readFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import path from "node:path";
import { OfficeError } from "./errors.ts";

export type CodexBinarySource = "override" | "env" | "workspace" | "path";

export interface CodexExecutable {
  path: string;
  source: CodexBinarySource;
  version: string | null;
}

const VERSION_PATTERN = /codex-cli\s+([0-9][0-9A-Za-z.+-]*)/;

async function probeVersion(binary: string): Promise<string | null> {
  return new Promise((resolve) => {
    execFile(
      binary,
      ["--version"],
      { timeout: 8000, maxBuffer: 256 * 1024, windowsHide: true, env: { PATH: process.env.PATH, LANG: "C.UTF-8" } },
      (error, stdout, stderr) => {
        if (error && !stdout) return resolve(null);
        resolve(VERSION_PATTERN.exec(String(stdout) + String(stderr))?.[1] ?? null);
      },
    );
  });
}

/**
 * Resolve the codex CLI the same way the claude executor does: an explicit value,
 * then CODEX_CLI, then workspace.json cliPaths.codex, then PATH. Depending on PATH
 * alone meant a container rebuild could silently break every codex agent.
 */
export async function resolveCodexBinary(override?: string, workspaceRoot?: string): Promise<CodexExecutable> {
  let configuredBinary: string | undefined;
  if (workspaceRoot) {
    try {
      const configuration = JSON.parse(await readFile(path.join(workspaceRoot, "workspace.json"), "utf8"));
      if (typeof configuration.cliPaths?.codex === "string")
        configuredBinary = path.resolve(workspaceRoot, configuration.cliPaths.codex);
    } catch {
      // A first installation may not have a local configuration yet.
    }
  }
  const candidates: Array<{ value: string; source: CodexBinarySource }> = [];
  if (override) candidates.push({ value: override, source: "override" });
  if (process.env.CODEX_CLI) candidates.push({ value: process.env.CODEX_CLI, source: "env" });
  if (configuredBinary) candidates.push({ value: configuredBinary, source: "workspace" });
  for (const directory of (process.env.PATH ?? "").split(path.delimiter))
    if (directory) candidates.push({ value: path.join(directory, "codex"), source: "path" });
  for (const candidate of candidates) {
    if (!path.isAbsolute(candidate.value)) continue;
    try {
      await access(candidate.value, constants.X_OK);
    } catch {
      continue;
    }
    return { path: candidate.value, source: candidate.source, version: await probeVersion(candidate.value) };
  }
  throw new OfficeError("codex_binary_not_found", 503);
}

/** Cheap repeatable check used before each run so a removed binary fails with a clear error. */
export async function codexBinaryUsable(binary: string): Promise<boolean> {
  if (path.isAbsolute(binary)) {
    try {
      await access(binary, constants.X_OK);
      return true;
    } catch {
      return false;
    }
  }
  for (const directory of (process.env.PATH ?? "").split(path.delimiter)) {
    if (!directory) continue;
    try {
      await access(path.join(directory, binary), constants.X_OK);
      return true;
    } catch {
      // keep looking
    }
  }
  return false;
}
