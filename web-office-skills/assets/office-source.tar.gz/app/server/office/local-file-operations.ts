import { execFile } from "node:child_process";
import { constants } from "node:fs";
import { copyFile, lstat, mkdir, mkdtemp, open, opendir, realpath, rm } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { OfficeError } from "./errors.ts";
import { resolveLocalDirectoryPath } from "./local-file-browser.ts";

const execute = promisify(execFile);
const protectedEntries = new Set([
  "app", "state", "logs", "agents", "company", "shared", "scripts", "releases", "cache",
  "artifacts", ".install-staging", "tmp", "workspace.json",
]);

function systemBinary(name: string) {
  return path.join(process.env.SystemRoot || "C:\\Windows", "System32", name);
}

async function windowsCommand(script: string, variables: Record<string, string>) {
  await execute(systemBinary("WindowsPowerShell/v1.0/powershell.exe"), [
    "-NoLogo", "-NoProfile", "-EncodedCommand", Buffer.from("$ErrorActionPreference='Stop'; " + script, "utf16le").toString("base64"),
  ], { windowsHide: true, timeout: 120_000, env: { ...process.env, ...variables } });
}

const recycleScript = `
if (-not [Environment]::UserInteractive) { throw 'No interactive Recycle Bin' }
$drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($env:OFFICE_FILE_TARGET))
if ($drive.DriveType -ne [IO.DriveType]::Fixed) { throw 'No fixed local Recycle Bin' }
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class OfficeRecycle
{
    [ComImport, Guid("947AAB5F-0A5C-4C13-B4D6-4BF7836FC9F8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IFileOperation
    {
        void Advise(IntPtr sink, out uint cookie);
        void Unadvise(uint cookie);
        void SetOperationFlags(uint flags);
        void SetProgressMessage(IntPtr message);
        void SetProgressDialog(IntPtr dialog);
        void SetProperties(IntPtr properties);
        void SetOwnerWindow(IntPtr owner);
        void ApplyPropertiesToItem(IntPtr item);
        void ApplyPropertiesToItems(IntPtr items);
        void RenameItem(IntPtr item, IntPtr newName, IntPtr sink);
        void RenameItems(IntPtr items, IntPtr newName);
        void MoveItem(IntPtr item, IntPtr destination, IntPtr newName, IntPtr sink);
        void MoveItems(IntPtr items, IntPtr destination);
        void CopyItem(IntPtr item, IntPtr destination, IntPtr newName, IntPtr sink);
        void CopyItems(IntPtr items, IntPtr destination);
        void DeleteItem(IntPtr item, IntPtr sink);
        void DeleteItems(IntPtr items);
        void NewItem(IntPtr destination, uint attributes, IntPtr name, IntPtr template, IntPtr sink);
        void PerformOperations();
        void GetAnyOperationsAborted([MarshalAs(UnmanagedType.Bool)] out bool aborted);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHCreateItemFromParsingName(string path, IntPtr bind, ref Guid iid, out IntPtr item);

    public static void Move(string path)
    {
        var operation = (IFileOperation)Activator.CreateInstance(Type.GetTypeFromCLSID(
            new Guid("3AD05575-8857-4850-9277-11B85BDB8E09")));
        IntPtr item = IntPtr.Zero;
        try
        {
            var iid = new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE");
            Marshal.ThrowExceptionForHR(SHCreateItemFromParsingName(path, IntPtr.Zero, ref iid, out item));
            const uint recycleOnDelete = 0x00080000, failOnError = 0x00100400;
            const uint noProgress = 0x0004, warnIfPermanent = 0x4000, onlySelectedItem = 0x2000;
            operation.SetOperationFlags(recycleOnDelete | failOnError | noProgress | warnIfPermanent | onlySelectedItem);
            operation.DeleteItem(item, IntPtr.Zero);
            operation.PerformOperations();
            bool aborted;
            operation.GetAnyOperationsAborted(out aborted);
            if (aborted) throw new OperationCanceledException();
        }
        finally
        {
            if (item != IntPtr.Zero) Marshal.Release(item);
            Marshal.ReleaseComObject(operation);
        }
    }
}
'@
[OfficeRecycle]::Move($env:OFFICE_FILE_TARGET)
`;

function within(base: string, target: string) {
  const relative = path.relative(base, target);
  return relative === "" || (!path.isAbsolute(relative) && relative !== ".." && !relative.startsWith(".." + path.sep));
}

async function guardWrite(root: string, target: string) {
  if (within(target, root) || path.dirname(target) === target) throw new OfficeError("local_file_protected", 403);
  for (let parent = path.dirname(target); ; parent = path.dirname(parent)) {
    const marker = await lstat(path.join(parent, "workspace.json")).catch(() => undefined);
    if (parent === root || (marker?.isFile() &&
      (await lstat(path.join(parent, "state")).catch(() => undefined))?.isDirectory())) {
      if (protectedEntries.has(path.relative(parent, target).split(path.sep)[0].toLowerCase()))
        throw new OfficeError("local_file_protected", 403);
      break;
    }
    if (path.dirname(parent) === parent) break;
  }
}

function pathInput(root: string, input: unknown) {
  if (typeof input !== "string" || !input ||
      input.split(/[\\/]/).some((part) => part !== "." && part !== ".." && /[. ]$/.test(part)))
    throw new OfficeError("local_directory_invalid");
  return resolveLocalDirectoryPath(root, input);
}

async function existing(root: string, input: unknown) {
  const target = pathInput(root, input);
  const info = await lstat(target);
  if (!info.isFile() && !info.isDirectory()) throw new OfficeError("local_file_special", 415);
  const canonical = pathInput(root, await realpath(target));
  return { target: canonical, info };
}

function childName(root: string, input: unknown) {
  if (typeof input !== "string" || input.length > 255 || input !== input.trim() ||
      input === "." || input === ".." || /[\\/\x00-\x1F]/.test(input))
    throw new OfficeError("local_file_name_invalid");
  pathInput(root, input);
  return input;
}

async function checkTree(directory: string) {
  const entries = await opendir(directory);
  for await (const entry of entries) {
    if (entry.isDirectory()) await checkTree(path.join(directory, entry.name));
    else if (!entry.isFile()) throw new OfficeError("local_file_special", 415);
  }
}

async function copyDirectory(source: string, destination: string) {
  await checkTree(source);
  const parent = path.dirname(destination);
  const stage = await mkdtemp(path.join(parent, ".office-copy-"));
  try {
    try {
      await execute(systemBinary("robocopy.exe"), [
        source, stage, "/E", "/XJ", "/SL", "/SJ", "/J", "/R:0", "/W:0", "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
      ], { windowsHide: true, timeout: 30 * 60_000 });
    } catch (error) {
      const code = (error as { code?: unknown }).code;
      if (typeof code !== "number" || code < 1 || code > 7) throw error;
    }
    await windowsCommand("[IO.Directory]::Move($env:OFFICE_FILE_SOURCE, $env:OFFICE_FILE_TARGET)", {
      OFFICE_FILE_SOURCE: stage, OFFICE_FILE_TARGET: destination,
    }).catch(async (error) => {
      if (await lstat(destination).catch(() => undefined)) throw new OfficeError("local_file_exists", 409);
      throw error;
    });
  } finally {
    const resolved = await realpath(stage).catch(() => undefined);
    if (resolved === stage && path.dirname(resolved) === parent && path.basename(resolved).startsWith(".office-copy-"))
      await rm(resolved, { recursive: true, force: true });
  }
}

export async function performLocalFileOperation(root: string, input: unknown) {
  if (process.platform !== "win32") throw new OfficeError("local_file_write_disabled", 403);
  if (!input || typeof input !== "object") throw new OfficeError("local_directory_invalid");
  const operation = input as Record<string, unknown>;
  try {
    if (operation.action === "delete") {
      const { target, info } = await existing(root, operation.path);
      await guardWrite(root, target);
      if (operation.permanent === true) {
        if (operation.confirmName !== path.basename(target)) throw new OfficeError("local_file_confirm_required", 409);
        await rm(target, { recursive: info.isDirectory() });
        return;
      }
      try {
        await windowsCommand(recycleScript, { OFFICE_FILE_TARGET: target });
      } catch {
        throw new OfficeError("local_file_recycle_unavailable", 409);
      }
      return;
    }
    if (operation.action !== "file" && operation.action !== "directory" && operation.action !== "paste")
      throw new OfficeError("local_directory_invalid");
    const directory = await existing(root, operation.directory);
    if (!directory.info.isDirectory()) throw new OfficeError("local_directory_not_folder");
    const source = operation.action === "paste" ? await existing(root, operation.source) : undefined;
    const name = childName(root, source ? path.basename(source.target) : operation.name);
    const target = path.join(directory.target, name);
    await guardWrite(root, target);
    if (!source) {
      if (operation.action === "directory") await mkdir(target);
      else await (await open(target, "wx")).close();
      return;
    }
    if (within(source.target, target)) throw new OfficeError("local_file_copy_inside", 409);
    await guardWrite(root, source.target);
    if (await lstat(target).catch(() => undefined)) throw new OfficeError("local_file_exists", 409);
    if (source.info.isDirectory()) await copyDirectory(source.target, target);
    else await copyFile(source.target, target, constants.COPYFILE_EXCL);
  } catch (error) {
    if (error instanceof OfficeError) throw error;
    switch ((error as NodeJS.ErrnoException).code) {
      case "EEXIST": throw new OfficeError("local_file_exists", 409);
      case "ENOENT": throw new OfficeError("local_directory_missing", 404);
      case "EPERM":
      case "EACCES": throw new OfficeError("local_directory_denied", 403);
      default: throw new OfficeError("local_file_operation_failed", 500);
    }
  }
}
