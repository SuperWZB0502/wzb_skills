/** Safe public errors carry stable codes and never incorporate request secrets. */
export class OfficeError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(code: string, status = 400) {
    super(code);
    this.name = "OfficeError";
    this.code = code;
    this.status = status;
  }
}
