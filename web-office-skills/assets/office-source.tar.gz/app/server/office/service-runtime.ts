import { chmod, mkdir } from "node:fs/promises";
import path from "node:path";
import type {
  AgentProfile,
  CredentialState,
  ProviderAuthFlow,
  ProviderProfile,
} from "../../shared/office-contracts.ts";
import type { OfficeStore } from "./agent-repository.ts";
import type { CredentialVault } from "./credential-vault.ts";
import { ClaudeAccountAuth } from "./account-auth.ts";
import { CodexAccountDriver } from "./codex-account-driver.ts";
import { OfficeError } from "./errors.ts";
import { resolveWorkspacePath, type WorkspacePaths } from "./workspace-paths.ts";

export interface RuntimeBinding {
  provider: ProviderProfile;
  apiKey?: string;
  driver?: CodexAccountDriver;
}
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Provider metadata persists in OfficeStore; every account flow and credential here is memory-only. */
export class ServiceRuntime {
  private claude = new ClaudeAccountAuth();
  private drivers = new Map<string, CodexAccountDriver>();
  private driverPreparation = new Map<string, Promise<CodexAccountDriver>>();
  private states = new Map<string, CredentialState>();
  private flows = new Map<string, ProviderAuthFlow>();
  private closed = false;
  constructor(
    private paths: WorkspacePaths,
    private store: OfficeStore,
    private vault: CredentialVault,
    private codexBinary = "codex",
  ) {}
  private provider(id: string) {
    if (this.closed) throw new OfficeError("runtime_stopping", 409);
    const provider = this.store.getProvider(id);
    if (!provider) throw new OfficeError("provider_not_found", 404);
    return provider;
  }
  private accountProvider(id: string) {
    const provider = this.provider(id);
    if (provider.authMode !== "account") throw new OfficeError("account_login_not_enabled", 409);
    if (provider.baseUrl) throw new OfficeError("account_custom_endpoint_forbidden", 400);
    return provider;
  }
  private selected(value: AgentProfile | ProviderProfile): { provider?: ProviderProfile; slotId: string | null } {
    if ("jobFunction" in value) {
      const provider = value.providerId ? this.store.getProvider(value.providerId) : undefined;
      return { provider, slotId: value.credentialSlotId ?? provider?.credentialSlotId ?? null };
    }
    return { provider: this.store.getProvider(value.id), slotId: value.credentialSlotId };
  }
  credentialState(value: AgentProfile | ProviderProfile): CredentialState {
    if (this.closed) return "required";
    const { provider, slotId } = this.selected(value);
    if (!provider) return "required";
    if (provider.authMode === "account") {
      if (provider.baseUrl) return "invalid";
      if (provider.executor === "claude-code") {
        if (this.states.get(provider.id) === "invalid") return "invalid";
        return this.claude.status(provider.id).authenticated ? "configured" : "required";
      }
      return this.states.get(provider.id) ?? "required";
    }
    const credential = this.vault.get(slotId);
    if (!credential || credential.providerId !== provider.id) return "required";
    return this.vault.status(slotId);
  }
  async capture(profile: AgentProfile): Promise<RuntimeBinding> {
    const provider = profile.providerId ? this.provider(profile.providerId) : undefined;
    if (!provider) throw new OfficeError("model_required", 409);
    if (provider.authMode === "api_key") {
      const { slotId } = this.selected(profile);
      const credential = this.vault.get(slotId);
      if (!credential || credential.providerId !== provider.id || this.vault.status(slotId) !== "configured")
        throw new OfficeError("key_required", 409);
      return { provider, apiKey: credential.apiKey };
    }
    this.accountProvider(provider.id);
    if (provider.executor === "claude-code") {
      const credential = this.claude.credential(provider.id);
      if (!credential || this.states.get(provider.id) === "invalid")
        throw new OfficeError("account_login_required", 409);
      return { provider, apiKey: credential.accessToken };
    }
    const driver = await this.driver(provider.id);
    const status = await driver.loginStatus();
    this.states.set(provider.id, status.authenticated ? "configured" : "required");
    if (!status.authenticated) throw new OfficeError("account_login_required", 409);
    return { provider, driver };
  }
  private driver(providerId: string): Promise<CodexAccountDriver> {
    const existing = this.drivers.get(providerId);
    if (existing) return Promise.resolve(existing);
    const pending = this.driverPreparation.get(providerId);
    if (pending) return pending;
    const prepare: Promise<CodexAccountDriver> = Promise.resolve().then(async () => {
      if (!UUID.test(providerId)) throw new OfficeError("invalid_provider", 400);
      const base = path.join(this.paths.state, "account-services", providerId);
      const locations = ["home", "codex", "tmp"].map((name) => path.join(base, name));
      for (const location of locations) {
        if ((await resolveWorkspacePath(this.paths, location)) !== location)
          throw new OfficeError("runtime_path_symlink_forbidden", 403);
        await mkdir(location, { recursive: true, mode: 0o700 });
        if ((await resolveWorkspacePath(this.paths, location)) !== location)
          throw new OfficeError("runtime_path_symlink_forbidden", 403);
        await chmod(location, 0o700);
      }
      if (this.closed || this.driverPreparation.get(providerId) !== prepare)
        throw new OfficeError("runtime_stopping", 409);
      const driver = new CodexAccountDriver({
        binary: this.codexBinary,
        home: locations[0],
        codexHome: locations[1],
        tmpDir: locations[2],
        onFailure: () => this.states.set(providerId, "required"),
      });
      this.drivers.set(providerId, driver);
      return driver;
    });
    this.driverPreparation.set(providerId, prepare);
    void prepare
      .finally(() => {
        if (this.driverPreparation.get(providerId) === prepare) this.driverPreparation.delete(providerId);
      })
      .catch(() => {});
    return prepare;
  }
  secrets() {
    return this.claude.secrets();
  }
  async listAccountModels(providerId: string) {
    const provider = this.accountProvider(providerId);
    if (provider.executor !== "codex" || this.credentialState(provider) !== "configured") return [];
    return (await this.driver(providerId)).listModels();
  }
  markInvalid(providerId: string) {
    this.states.set(providerId, "invalid");
  }
  async startLogin(providerId: string): Promise<ProviderAuthFlow> {
    const provider = this.accountProvider(providerId);
    let flow: ProviderAuthFlow;
    if (provider.executor === "claude-code") {
      const started = this.claude.start(providerId);
      flow = {
        ...started,
        state: "pending",
        requiresCode: true,
        message: "请在官方页面完成授权，将页面显示的完整授权码粘回此处。",
      };
    } else {
      const driver = await this.driver(providerId);
      const started = await driver.startLogin();
      flow = {
        loginId: started.loginId,
        state: "pending",
        authUrl: started.verificationUrl,
        userCode: started.userCode,
        requiresCode: false,
        expiresAt: Date.now() + 10 * 60 * 1000,
        message: "请打开官方页面，输入设备码并完成登录，网页会自动更新登录状态。",
      };
    }
    this.states.set(providerId, "required");
    this.flows.set(providerId, flow);
    return { ...flow };
  }
  async loginStatus(providerId: string, loginId?: string): Promise<ProviderAuthFlow> {
    const provider = this.accountProvider(providerId);
    let flow = this.flows.get(providerId);
    if (loginId && (!flow || flow.loginId !== loginId)) throw new OfficeError("login_not_found", 404);
    if (provider.executor === "claude-code") {
      if (this.claude.status(providerId).authenticated && this.states.get(providerId) !== "invalid")
        this.states.set(providerId, "configured");
    } else {
      const driver = this.drivers.get(providerId);
      if (driver) {
        const status = await driver.loginStatus();
        this.states.set(providerId, status.authenticated ? "configured" : "required");
        if (status.failed && flow?.state === "pending")
          flow = { loginId: flow.loginId, state: "failed", message: "账户授权失败，请重新发起登录。" };
      }
    }
    if (this.credentialState(provider) === "configured") {
      flow = { loginId: flow?.loginId ?? "", state: "completed", message: "账户已登录；服务重启后需要重新登录。" };
    } else if (flow?.state === "pending" && flow.expiresAt && flow.expiresAt <= Date.now()) {
      await this.cancelLogin(providerId, flow.loginId).catch(() => {});
      flow = { loginId: flow.loginId, state: "failed", message: "本次登录已过期，请重新发起登录。" };
    } else if (flow?.state === "completed") {
      flow = { loginId: flow.loginId, state: "failed", message: "账户登录已失效，请重新登录。" };
    }
    if (!flow) return { loginId: "", state: "failed", message: "尚未登录，请发起账户登录。" };
    this.flows.set(providerId, flow);
    return { ...flow };
  }
  async completeLogin(providerId: string, loginId: string, code: string): Promise<ProviderAuthFlow> {
    const provider = this.accountProvider(providerId);
    const flow = this.flows.get(providerId);
    if (!flow || flow.loginId !== loginId || flow.state !== "pending") throw new OfficeError("login_not_found", 404);
    if (provider.executor !== "claude-code") return this.loginStatus(providerId, loginId);
    try {
      await this.claude.complete(providerId, loginId, code);
      if (
        this.closed ||
        this.flows.get(providerId) !== flow ||
        this.store.getProvider(providerId)?.authMode !== "account"
      ) {
        this.claude.clear(providerId);
        throw new OfficeError("login_cancelled", 409);
      }
      this.states.set(providerId, "configured");
      const completed: ProviderAuthFlow = {
        loginId,
        state: "completed",
        message: "账户已登录；服务重启后需要重新登录。",
      };
      this.flows.set(providerId, completed);
      return { ...completed };
    } catch (error) {
      if (error instanceof OfficeError && error.code === "invalid_login_code") throw error;
      this.states.set(providerId, "required");
      const failed: ProviderAuthFlow = { loginId, state: "failed", message: "账户授权失败或已取消，请重新发起登录。" };
      if (this.flows.get(providerId) === flow) this.flows.set(providerId, failed);
      return failed;
    }
  }
  async cancelLogin(providerId: string, loginId?: string) {
    const provider = this.accountProvider(providerId);
    const flow = this.flows.get(providerId);
    if (loginId && flow?.loginId !== loginId) throw new OfficeError("login_not_found", 404);
    if (!flow || flow.state !== "pending") return;
    if (provider.executor === "claude-code") this.claude.cancel(providerId, flow.loginId);
    else await this.drivers.get(providerId)?.cancelLogin(flow.loginId);
    this.flows.set(providerId, { loginId: flow.loginId, state: "cancelled", message: "本次登录已取消。" });
  }
  async clearProvider(providerId: string) {
    this.claude.clear(providerId);
    this.flows.delete(providerId);
    this.states.delete(providerId);
    // Removing this marker also cancels an in-flight private-directory preparation.
    this.driverPreparation.delete(providerId);
    const driver = this.drivers.get(providerId);
    this.drivers.delete(providerId);
    await driver?.close();
  }
  async close() {
    if (this.closed) return;
    this.closed = true;
    this.claude.close();
    this.flows.clear();
    this.states.clear();
    this.driverPreparation.clear();
    const drivers = [...this.drivers.values()];
    this.drivers.clear();
    await Promise.allSettled(drivers.map((driver) => driver.close()));
  }
}
