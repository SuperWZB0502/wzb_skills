import { randomUUID } from "node:crypto";
import { chmodSync, lstatSync, realpathSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { REASONING_EFFORTS } from "../../shared/office-contracts.ts";
import type {
  AgentDraft,
  AgentLifecycle,
  AuthMode,
  ExecutorKind,
  HistoricalAgentIdentity,
  OfficeConversation,
  AgentProfile,
  JobFunction,
  MeetingSnapshot,
  OfficeMessage,
  OfficeAttachment,
  RunProgressEvent,
  ProviderProfile,
  ReasoningEffort,
  TaskRuntimeEvent,
  WorkState,
} from "../../shared/office-contracts.ts";
import type { WorkspacePaths } from "./workspace-paths.ts";
import { OfficeError } from "./errors.ts";

const jobs: ReadonlyArray<JobFunction> = ["se", "pl", "developer", "tester"];
const reasoning: ReadonlyArray<ReasoningEffort> = REASONING_EFFORTS;
const states: ReadonlyArray<WorkState> = ["idle", "working", "waiting_input", "meeting", "error", "offline"];
const fields = ["name", "jobFunction", "gender", "spriteNumber", "providerId", "model", "reasoningEffort"] as const;
type ThreadKind = "chat" | "task" | "meeting";
export interface ThreadBinding {
  providerId: string | null;
  executor: ExecutorKind;
}
type ProviderInput = {
  name: string;
  baseUrl?: string;
  executor?: ExecutorKind;
  authMode?: AuthMode;
  credentialSlotId?: string | null;
  wireApi?: ProviderProfile["wireApi"];
};
interface MessageRequest {
  messageId: string;
  runId: string;
  conversationId: string;
}
export interface DeletedConversationResources {
  nativeThreads: Array<{ threadId: string; providerId: string | null; executor: ExecutorKind }>;
  runIds: string[];
  attachments: Array<{ agentId: string; id: string }>;
}
const conversationSelect = `SELECT c.id,c.agent_id,c.title,c.created_at,c.updated_at,c.category,c.last_used_at,
  (SELECT COUNT(*) FROM office_messages m WHERE m.agent_id=c.agent_id AND m.conversation_id=c.id) AS message_count,
  COALESCE(
    (SELECT substr(json_extract(m.message,'$.content'),1,240) FROM office_messages m
      WHERE m.agent_id=c.agent_id AND m.conversation_id=c.id AND json_extract(m.message,'$.role')='assistant'
      AND json_type(m.message,'$.content')='text' AND length(trim(json_extract(m.message,'$.content')))>0 ORDER BY m.seq DESC LIMIT 1),
    (SELECT substr(json_extract(m.message,'$.content'),1,240) FROM office_messages m
      WHERE m.agent_id=c.agent_id AND m.conversation_id=c.id AND json_extract(m.message,'$.role')='user'
      AND json_type(m.message,'$.content')='text' AND length(trim(json_extract(m.message,'$.content')))>0 ORDER BY m.seq LIMIT 1),'') AS summary
  FROM office_conversations c`;

function text(value: unknown, code: string, maximum: number): string {
  // eslint-disable-next-line no-control-regex -- Profile fields must reject ASCII control characters.
  const containsControl = typeof value === "string" && /[\u0000-\u001f\u007f]/.test(value);
  if (typeof value !== "string" || !value.trim() || value.length > maximum || containsControl)
    throw new OfficeError(code);
  return value.trim();
}
function nullableText(value: unknown, code: string, maximum = 256): string | null {
  return value === null || value === undefined ? null : text(value, code, maximum);
}
function validateDraft(raw: unknown, boss = false): AgentDraft & { gender: string } {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new OfficeError("invalid_agent");
  const input = raw as Record<string, unknown>;
  const jobFunction = input.jobFunction;
  if (!jobs.includes(jobFunction as JobFunction) && !(boss && jobFunction === "boss"))
    throw new OfficeError("invalid_job_function");
  const sprite = input.spriteNumber ?? null;
  if (sprite !== null && (typeof sprite !== "number" || !Number.isSafeInteger(sprite) || sprite <= 0))
    throw new OfficeError("invalid_sprite");
  const effort = input.reasoningEffort ?? null;
  if (effort !== null && !reasoning.includes(effort as ReasoningEffort))
    throw new OfficeError("invalid_reasoning_effort");
  return {
    name: text(input.name, "invalid_agent_name", 120),
    jobFunction: jobFunction as AgentDraft["jobFunction"],
    gender: input.gender === undefined ? "unspecified" : text(input.gender, "invalid_gender", 40),
    spriteNumber: sprite as number | null,
    providerId: nullableText(input.providerId, "invalid_provider"),
    model: nullableText(input.model, "invalid_model"),
    reasoningEffort: effort as ReasoningEffort | null,
  };
}

/** Owns the office schema only. Never imports upstream startup, settings or authentication. */
export class OfficeStore {
  #db: DatabaseSync;
  #closed = false;
  constructor(paths: WorkspacePaths) {
    const relative = path.relative(paths.root, realpathSync(paths.state));
    if (
      realpathSync(paths.root) !== paths.root ||
      relative === ".." ||
      relative.startsWith(`..${path.sep}`) ||
      path.isAbsolute(relative)
    )
      throw new OfficeError("workspace_path_outside", 403);
    const filename = path.join(paths.state, "office.sqlite");
    for (const suffix of ["", "-wal", "-shm", "-journal"]) {
      try {
        const existing = lstatSync(filename + suffix);
        if (existing.isSymbolicLink()) throw new OfficeError("workspace_path_outside", 403);
        if (existing.isFile() && existing.nlink > 1) throw new OfficeError("workspace_hardlink_forbidden", 403);
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      }
    }
    this.#db = new DatabaseSync(filename);
    try {
      chmodSync(filename, 0o600);
      this.#db.exec(`
      PRAGMA journal_mode=WAL;
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS office_profiles (
        id TEXT PRIMARY KEY, job_function TEXT NOT NULL CHECK(job_function IN ('se','pl','developer','tester','boss')),
        is_boss INTEGER NOT NULL CHECK(is_boss IN (0,1)), lifecycle TEXT NOT NULL DEFAULT 'active' CHECK(lifecycle IN ('active','archived')),
        profile TEXT NOT NULL, CHECK((job_function='boss') = (is_boss=1))
      );
      CREATE UNIQUE INDEX IF NOT EXISTS office_single_boss ON office_profiles(is_boss) WHERE is_boss=1;
      CREATE TABLE IF NOT EXISTS office_threads(agent_id TEXT NOT NULL REFERENCES office_profiles(id),kind TEXT NOT NULL,thread_id TEXT NOT NULL,PRIMARY KEY(agent_id,kind));
      CREATE TABLE IF NOT EXISTS office_providers(id TEXT PRIMARY KEY, profile TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS office_messages(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,agent_id TEXT NOT NULL REFERENCES office_profiles(id),message TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS office_message_requests(agent_id TEXT NOT NULL REFERENCES office_profiles(id),request_key TEXT NOT NULL,message_id TEXT NOT NULL REFERENCES office_messages(id),run_id TEXT NOT NULL,PRIMARY KEY(agent_id,request_key));
      CREATE TABLE IF NOT EXISTS office_meetings(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,snapshot TEXT NOT NULL,title TEXT);
      CREATE TABLE IF NOT EXISTS office_events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT UNIQUE NOT NULL,event TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS office_progress(seq INTEGER PRIMARY KEY AUTOINCREMENT,agent_id TEXT NOT NULL,run_id TEXT NOT NULL,item_id TEXT NOT NULL,event TEXT NOT NULL,UNIQUE(run_id,item_id));
      CREATE INDEX IF NOT EXISTS office_progress_agent ON office_progress(agent_id,seq);
    `);
      const boss: AgentProfile = {
        id: "office-boss",
        name: "Boss",
        jobFunction: "boss",
        isBoss: true,
        gender: "unspecified",
        spriteNumber: 1,
        providerId: null,
        model: null,
        reasoningEffort: null,
        credentialState: "required",
        credentialSlotId: null,
        workState: "idle",
        currentTaskId: null,
        currentWorkSummary: "",
      };
      this.#db
        .prepare("INSERT OR IGNORE INTO office_profiles(id,job_function,is_boss,profile) VALUES(?,?,?,?)")
        .run(boss.id, "boss", 1, JSON.stringify(boss));
      this.#migrateConversations();
      for (const agent of this.listAgents()) {
        if (["working", "meeting", "waiting_input"].includes(agent.workState))
          this.updateWork(agent.id, "offline", "Interrupted by runtime restart", agent.currentTaskId);
      }
      for (const meeting of this.listMeetings()) {
        if (meeting.phase === "ended") continue;
        meeting.phase = "ended";
        for (const id of meeting.participantIds) {
          if (!this.getAgent(id)) continue;
          const message = this.addMessage({
            agentId: id,
            role: "system",
            content: "会议因运行层重启而中断，已有发言已保留。",
          });
          meeting.messageIds.push(message.id);
        }
        this.putMeeting(meeting);
      }
      const interrupted = this.#db.prepare("SELECT event FROM office_progress").all();
      for (const row of interrupted) {
        const event = JSON.parse(row.event as string) as RunProgressEvent;
        if (!["pending", "running"].includes(event.status)) continue;
        this.putProgress({ ...event, kind: "error", status: "failed", title: "任务因服务重启中断" });
      }
    } catch (error) {
      this.#closed = true;
      try {
        this.#db.close();
      } catch {
        /* Keep the original initialization failure. */
      }
      throw error;
    }
  }

  #migrateConversations(): void {
    this.#db.exec("BEGIN IMMEDIATE");
    try {
      const addColumn = (table: string, column: string, declaration: string) => {
        const columns = this.#db.prepare(`PRAGMA table_info(${table})`).all();
        if (!columns.some((value) => value.name === column))
          this.#db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${declaration}`);
      };
      addColumn(
        "office_providers",
        "lifecycle",
        "TEXT NOT NULL DEFAULT 'active' CHECK(lifecycle IN ('active','archived'))",
      );
      addColumn("office_messages", "conversation_id", "TEXT");
      addColumn("office_profiles", "dismissed", "INTEGER NOT NULL DEFAULT 0 CHECK(dismissed IN (0,1))");
      addColumn("office_message_requests", "conversation_id", "TEXT");
      addColumn("office_progress", "conversation_id", "TEXT");
      this.#db.exec(`
        CREATE TABLE IF NOT EXISTS office_conversations (
          id TEXT PRIMARY KEY, agent_id TEXT NOT NULL REFERENCES office_profiles(id), title TEXT NOT NULL,
          created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
          is_default INTEGER NOT NULL DEFAULT 0 CHECK(is_default IN (0,1))
        );
        CREATE UNIQUE INDEX IF NOT EXISTS office_single_default_conversation ON office_conversations(agent_id) WHERE is_default=1;
        CREATE INDEX IF NOT EXISTS office_conversations_agent ON office_conversations(agent_id,updated_at);
        CREATE INDEX IF NOT EXISTS office_messages_conversation ON office_messages(agent_id,conversation_id,seq);
        CREATE INDEX IF NOT EXISTS office_progress_conversation ON office_progress(agent_id,conversation_id,seq);
        CREATE TABLE IF NOT EXISTS office_native_threads (
          agent_id TEXT NOT NULL REFERENCES office_profiles(id), kind TEXT NOT NULL,
          conversation_id TEXT NOT NULL, binding_key TEXT NOT NULL, provider_id TEXT,
          executor TEXT NOT NULL CHECK(executor IN ('codex','claude-code')), thread_id TEXT NOT NULL,
          PRIMARY KEY(agent_id,kind,conversation_id,binding_key)
        );
        CREATE TABLE IF NOT EXISTS office_storage_migrations(name TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS office_deleted_conversations(id TEXT PRIMARY KEY);
      `);
      addColumn("office_conversations", "category", "TEXT NOT NULL DEFAULT '未分类'");
      addColumn("office_conversations", "last_used_at", "INTEGER");
      const now = Date.now();
      // Only identifiers and timestamp metadata are inspected; message bodies stay in SQLite.
      this.#db
        .prepare(
          `INSERT OR IGNORE INTO office_conversations(id,agent_id,title,created_at,updated_at,is_default)
        SELECT 'office-default:'||p.id,p.id,'默认会话',
          COALESCE((SELECT MIN(CASE WHEN json_type(m.message,'$.at') IN ('integer','real') THEN json_extract(m.message,'$.at') END) FROM office_messages m WHERE m.agent_id=p.id),?),
          COALESCE((SELECT MAX(CASE WHEN json_type(m.message,'$.at') IN ('integer','real') THEN json_extract(m.message,'$.at') END) FROM office_messages m WHERE m.agent_id=p.id),?),1
        FROM office_profiles p
        WHERE NOT EXISTS(SELECT 1 FROM office_conversations c WHERE c.agent_id=p.id AND c.is_default=1)
          AND NOT EXISTS(SELECT 1 FROM office_deleted_conversations d WHERE d.id='office-default:'||p.id)`,
        )
        .run(now, now);
      for (const row of this.#db
        .prepare(
          "SELECT p.id FROM office_profiles p WHERE NOT EXISTS(SELECT 1 FROM office_conversations c WHERE c.agent_id=p.id AND c.is_default=1)",
        )
        .all())
        this.defaultConversation(String(row.id));
      this.#db.exec(`
        UPDATE office_messages SET conversation_id=(SELECT id FROM office_conversations c WHERE c.agent_id=office_messages.agent_id AND c.is_default=1)
          WHERE conversation_id IS NULL;
        UPDATE office_messages SET message=json_set(message,'$.conversationId',conversation_id)
          WHERE conversation_id IS NOT NULL AND json_extract(message,'$.conversationId') IS NOT conversation_id;
        UPDATE office_message_requests SET conversation_id=COALESCE(
          (SELECT conversation_id FROM office_messages m WHERE m.id=office_message_requests.message_id),
          (SELECT id FROM office_conversations c WHERE c.agent_id=office_message_requests.agent_id AND c.is_default=1))
          WHERE conversation_id IS NULL;
        UPDATE office_progress SET conversation_id=COALESCE(
          json_extract(event,'$.conversationId'),
          (SELECT id FROM office_conversations c WHERE c.agent_id=office_progress.agent_id AND c.is_default=1))
          WHERE conversation_id IS NULL;
        UPDATE office_progress SET event=json_set(event,'$.conversationId',conversation_id)
          WHERE conversation_id IS NOT NULL AND json_extract(event,'$.conversationId') IS NOT conversation_id;
        UPDATE office_conversations SET last_used_at=(
          SELECT MAX(CASE WHEN json_type(m.message,'$.at') IN ('integer','real') THEN json_extract(m.message,'$.at') END)
          FROM office_messages m WHERE m.conversation_id=office_conversations.id) WHERE last_used_at IS NULL;
        UPDATE office_conversations SET updated_at=MAX(updated_at,COALESCE(
          (SELECT MAX(CASE WHEN json_type(m.message,'$.at') IN ('integer','real') THEN json_extract(m.message,'$.at') END) FROM office_messages m WHERE m.conversation_id=office_conversations.id),updated_at));
      `);
      if (
        !this.#db.prepare("SELECT 1 FROM office_storage_migrations WHERE name='conversation_native_threads_v1'").get()
      ) {
        const threads = this.#db
          .prepare(
            `SELECT t.agent_id,t.kind,t.thread_id,json_extract(p.profile,'$.providerId') AS provider_id
          FROM office_threads t JOIN office_profiles p ON p.id=t.agent_id`,
          )
          .all();
        const insert = this.#db.prepare(`INSERT OR IGNORE INTO office_native_threads
          (agent_id,kind,conversation_id,binding_key,provider_id,executor,thread_id) VALUES(?,?,?,?,?,'codex',?)`);
        for (const row of threads) {
          const providerId = typeof row.provider_id === "string" ? row.provider_id : null;
          insert.run(
            String(row.agent_id),
            String(row.kind),
            row.kind === "chat" ? "office-default:" + String(row.agent_id) : "",
            JSON.stringify([providerId, "codex"]),
            providerId,
            String(row.thread_id),
          );
        }
        this.#db.prepare("INSERT INTO office_storage_migrations(name) VALUES('conversation_native_threads_v1')").run();
      }
      this.#db.exec("COMMIT");
    } catch (error) {
      this.#db.exec("ROLLBACK");
      throw error;
    }
  }
  #conversation(row: Record<string, unknown> | undefined): OfficeConversation | undefined {
    return row
      ? {
          id: String(row.id),
          agentId: String(row.agent_id),
          title: String(row.title),
          createdAt: Number(row.created_at),
          updatedAt: Number(row.updated_at),
          messageCount: Number(row.message_count),
          category: typeof row.category === "string" ? row.category : "未分类",
          summary: String(row.summary ?? "").slice(0, 240),
          lastUsedAt: row.last_used_at === null || row.last_used_at === undefined ? null : Number(row.last_used_at),
        }
      : undefined;
  }
  #conversationFor(agentId: string, conversationId?: string | null): OfficeConversation {
    const conversation =
      conversationId === undefined || conversationId === null
        ? this.defaultConversation(agentId)
        : this.getConversation(text(conversationId, "invalid_conversation_id", 256));
    if (!conversation) throw new OfficeError("conversation_not_found", 404);
    if (conversation.agentId !== agentId) throw new OfficeError("conversation_agent_mismatch", 403);
    return conversation;
  }
  #threadBinding(agentId: string, binding?: ThreadBinding): ThreadBinding {
    if (binding) {
      if (!["codex", "claude-code"].includes(binding.executor)) throw new OfficeError("invalid_executor");
      return { providerId: nullableText(binding.providerId, "invalid_provider"), executor: binding.executor };
    }
    const agent = this.getRawAgent(agentId);
    if (!agent) throw new OfficeError("agent_not_found", 404);
    return {
      providerId: agent.providerId,
      executor: agent.providerId ? (this.getRawProvider(agent.providerId)?.executor ?? "codex") : "codex",
    };
  }
  #read(row: unknown): AgentProfile | undefined {
    if (!row) return undefined;
    return {
      gender: "unspecified",
      spriteNumber: null,
      providerId: null,
      model: null,
      reasoningEffort: null,
      credentialSlotId: null,
      workState: "offline",
      currentTaskId: null,
      currentRunId: null,
      currentConversationId: null,
      currentWorkSummary: "",
      ...JSON.parse((row as { profile: string }).profile),
      credentialState: "required",
    };
  }
  #require(id: string): AgentProfile {
    const agent = this.getAgent(id);
    if (!agent) throw new OfficeError("agent_not_found", 404);
    return agent;
  }
  #save(agent: AgentProfile): AgentProfile {
    this.#db
      .prepare("UPDATE office_profiles SET job_function=?,is_boss=?,profile=? WHERE id=? AND lifecycle='active'")
      .run(agent.jobFunction, Number(agent.isBoss), JSON.stringify(agent), agent.id);
    return { ...agent };
  }
  listAgents(): AgentProfile[] {
    return this.#db
      .prepare("SELECT profile FROM office_profiles WHERE lifecycle='active' ORDER BY rowid")
      .all()
      .map((row) => this.#read(row)!);
  }
  listArchivedAgents(): AgentProfile[] {
    return this.#db
      .prepare("SELECT profile FROM office_profiles WHERE lifecycle='archived' AND dismissed=0 ORDER BY rowid DESC")
      .all()
      .map((row) => ({ ...this.#read(row)!, credentialSlotId: null, currentRunId: null }));
  }
  listHistoricalAgents(): HistoricalAgentIdentity[] {
    return this.#db
      .prepare(
        "SELECT id,job_function,json_extract(profile,'$.name') AS name,is_boss FROM office_profiles WHERE lifecycle='archived' ORDER BY rowid DESC",
      )
      .all()
      .map((row) => ({
        id: String(row.id),
        name: String(row.name),
        jobFunction: row.job_function as JobFunction,
        isBoss: Boolean(row.is_boss),
      }));
  }
  getAgentLifecycle(id: string): AgentLifecycle | undefined {
    const row = this.#db.prepare("SELECT lifecycle,dismissed FROM office_profiles WHERE id=?").get(id);
    return row ? (row.dismissed ? "dismissed" : (row.lifecycle as AgentLifecycle)) : undefined;
  }
  hasCredentialSlotReference(slotId: string): boolean {
    return Boolean(
      this.#db
        .prepare(
          "SELECT 1 FROM office_profiles WHERE dismissed=0 AND json_extract(profile,'$.credentialSlotId')=? UNION ALL SELECT 1 FROM office_providers WHERE lifecycle='active' AND json_extract(profile,'$.credentialSlotId')=? LIMIT 1",
        )
        .get(slotId, slotId),
    );
  }
  getAgent(id: string): AgentProfile | undefined {
    return this.#read(
      this.#db.prepare("SELECT profile FROM office_profiles WHERE id=? AND lifecycle='active'").get(id),
    );
  }
  getRawAgent(id: string): AgentProfile | undefined {
    return this.#read(this.#db.prepare("SELECT profile FROM office_profiles WHERE id=?").get(id));
  }
  createAgent(draft: AgentDraft): AgentProfile {
    const config = validateDraft(draft);
    if (config.providerId && !this.getProvider(config.providerId)) throw new OfficeError("provider_not_found", 404);
    if (!config.providerId) {
      config.model = null;
      config.reasoningEffort = null;
    }
    const agent: AgentProfile = {
      ...config,
      id: randomUUID(),
      isBoss: false,
      credentialState: "required",
      credentialSlotId: null,
      workState: "idle",
      currentTaskId: null,
      currentWorkSummary: "",
    };
    this.#db.exec("SAVEPOINT office_create_agent");
    try {
      this.#db
        .prepare("INSERT INTO office_profiles(id,job_function,is_boss,profile) VALUES(?,?,0,?)")
        .run(agent.id, agent.jobFunction, JSON.stringify(agent));
      this.defaultConversation(agent.id);
      this.#db.exec("RELEASE office_create_agent");
      return agent;
    } catch (error) {
      this.#db.exec("ROLLBACK TO office_create_agent; RELEASE office_create_agent");
      throw error;
    }
  }
  patchAgent(id: string, rawPartial: unknown): AgentProfile {
    const agent = this.#require(id);
    if (!rawPartial || typeof rawPartial !== "object" || Array.isArray(rawPartial))
      throw new OfficeError("invalid_agent");
    const input = rawPartial as Record<string, unknown>;
    if (
      Object.hasOwn(input, "isBoss") ||
      (agent.isBoss && Object.hasOwn(input, "jobFunction") && input.jobFunction !== "boss")
    )
      throw new OfficeError("boss_protected", 403);
    const next: Record<string, unknown> = { ...agent };
    for (const field of fields) if (Object.hasOwn(input, field)) next[field] = input[field];
    const config = validateDraft(next, agent.isBoss);
    if (config.providerId && !this.getProvider(config.providerId)) throw new OfficeError("provider_not_found", 404);
    if (!config.providerId) {
      config.model = null;
      config.reasoningEffort = null;
    }
    const changedProvider = config.providerId !== agent.providerId;
    return this.#save({
      ...agent,
      ...config,
      jobFunction: next.jobFunction as JobFunction,
      ...(changedProvider
        ? {
            credentialSlotId: null,
            model: Object.hasOwn(input, "model") ? config.model : null,
            reasoningEffort: Object.hasOwn(input, "reasoningEffort") ? config.reasoningEffort : null,
          }
        : {}),
    });
  }
  cloneAgent(id: string, name: string, jobFunction?: AgentDraft["jobFunction"]): AgentProfile {
    const source = this.#require(id);
    if (source.isBoss && !jobFunction) throw new OfficeError("boss_protected", 403);
    const clone = this.createAgent({
      name,
      jobFunction: jobFunction ?? (source.jobFunction as AgentDraft["jobFunction"]),
      gender: source.gender,
      spriteNumber: source.spriteNumber,
      providerId: source.providerId,
      model: source.model,
      reasoningEffort: source.reasoningEffort,
    });
    return this.bindCredential(clone.id, source.credentialSlotId);
  }
  archiveAgent(id: string): void {
    const agent = this.getRawAgent(id);
    if (!agent) throw new OfficeError("agent_not_found", 404);
    if (agent.isBoss) throw new OfficeError("boss_protected", 403);
    const lifecycle = this.getAgentLifecycle(id);
    if (lifecycle === "dismissed") throw new OfficeError("agent_dismissed", 409);
    if (lifecycle === "archived") return;
    if (this.getAgent(id) && ["working", "meeting", "waiting_input"].includes(agent.workState))
      throw new OfficeError("agent_busy", 409);
    this.#db.prepare("UPDATE office_profiles SET lifecycle='archived',profile=? WHERE id=? AND lifecycle='active'").run(
      JSON.stringify({
        ...agent,
        workState: "offline",
        currentTaskId: null,
        currentRunId: null,
        currentConversationId: null,
        currentWorkSummary: "",
      }),
      id,
    );
  }
  dismissAgent(id: string): void {
    const agent = this.getRawAgent(id);
    if (!agent) throw new OfficeError("agent_not_found", 404);
    if (agent.isBoss) throw new OfficeError("boss_protected", 403);
    const lifecycle = this.getAgentLifecycle(id);
    if (lifecycle === "active") throw new OfficeError("agent_not_archived", 409);
    if (lifecycle === "dismissed") return;
    const historicalIdentity: HistoricalAgentIdentity = {
      id: agent.id,
      name: agent.name,
      jobFunction: agent.jobFunction,
      isBoss: false,
    };
    this.#db.exec("PRAGMA secure_delete=ON");
    this.#db
      .prepare("UPDATE office_profiles SET dismissed=1,profile=? WHERE id=? AND lifecycle='archived'")
      .run(JSON.stringify(historicalIdentity), id);
    this.#checkpointDeletion();
  }
  bindCredential(agentId: string, slotId: string | null): AgentProfile {
    const agent = this.#require(agentId);
    return this.#save({ ...agent, credentialSlotId: nullableText(slotId, "invalid_credential_slot") });
  }
  updateWork(id: string, state: WorkState, summary: string, taskId: string | null = null): AgentProfile {
    const agent = this.#require(id);
    if (!states.includes(state) || typeof summary !== "string" || summary.length > 10000)
      throw new OfficeError("invalid_work_state");
    return this.#save({
      ...agent,
      workState: state,
      currentWorkSummary: summary,
      currentTaskId: nullableText(taskId, "invalid_task_id"),
    });
  }
  createConversation(agentId: string, title = "新会话"): OfficeConversation {
    this.#require(agentId);
    const cleanTitle = text(title, "invalid_conversation_title", 160);
    const id = randomUUID(),
      now = Date.now();
    this.#db
      .prepare(
        "INSERT INTO office_conversations(id,agent_id,title,created_at,updated_at,is_default) VALUES(?,?,?,?,?,0)",
      )
      .run(id, agentId, cleanTitle, now, now);
    return this.getConversation(id)!;
  }
  getConversation(id: string): OfficeConversation | undefined {
    return this.#conversation(this.#db.prepare(conversationSelect + " WHERE c.id=?").get(id));
  }
  defaultConversation(agentId: string): OfficeConversation {
    if (!this.getRawAgent(agentId)) throw new OfficeError("agent_not_found", 404);
    const existing = this.#conversation(
      this.#db.prepare(conversationSelect + " WHERE c.agent_id=? AND c.is_default=1").get(agentId),
    );
    if (existing) return existing;
    const legacyId = "office-default:" + agentId;
    const id = this.#db.prepare("SELECT 1 FROM office_deleted_conversations WHERE id=?").get(legacyId)
        ? randomUUID()
        : legacyId,
      now = Date.now();
    this.#db
      .prepare(
        "INSERT OR IGNORE INTO office_conversations(id,agent_id,title,created_at,updated_at,is_default) VALUES(?,?,'默认会话',?,?,1)",
      )
      .run(id, agentId, now, now);
    return this.#conversation(
      this.#db.prepare(conversationSelect + " WHERE c.agent_id=? AND c.is_default=1").get(agentId),
    )!;
  }
  listConversations(agentId?: string): OfficeConversation[] {
    const rows =
      agentId === undefined
        ? this.#db.prepare(conversationSelect + " ORDER BY c.updated_at DESC,c.created_at DESC,c.id").all()
        : this.#db
            .prepare(conversationSelect + " WHERE c.agent_id=? ORDER BY c.updated_at DESC,c.created_at DESC,c.id")
            .all(agentId);
    return rows.map((row) => this.#conversation(row)!);
  }
  renameConversation(id: string, title: string): OfficeConversation {
    return this.patchConversation(id, { title });
  }
  patchConversation(id: string, patch: { title?: string; category?: string }): OfficeConversation {
    const current = this.#db.prepare("SELECT title,category FROM office_conversations WHERE id=?").get(id);
    if (!current) throw new OfficeError("conversation_not_found", 404);
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) throw new OfficeError("invalid_conversation");
    const title = Object.hasOwn(patch, "title")
      ? text(patch.title, "invalid_conversation_title", 160)
      : String(current.title);
    const category = Object.hasOwn(patch, "category")
      ? text(patch.category ?? "未分类", "invalid_conversation_category", 80)
      : String(current.category);
    this.#db
      .prepare("UPDATE office_conversations SET title=?,category=?,updated_at=MAX(updated_at,?) WHERE id=?")
      .run(title, category, Date.now(), id);
    return this.getConversation(id)!;
  }
  #nativePlan(conversationId: string): {
    agentId: string;
    all: DeletedConversationResources["nativeThreads"];
    orphan: DeletedConversationResources["nativeThreads"];
  } {
    const conversation = this.#db.prepare("SELECT agent_id FROM office_conversations WHERE id=?").get(conversationId);
    if (!conversation) throw new OfficeError("conversation_not_found", 404);
    const agentId = String(conversation.agent_id);
    const rows = this.#db
      .prepare(
        "SELECT thread_id,provider_id,executor FROM office_native_threads WHERE agent_id=? AND conversation_id=?",
      )
      .all(agentId, conversationId);
    const all = [
      ...new Map(
        rows.map((row) => {
          const value = {
            threadId: String(row.thread_id),
            providerId: row.provider_id === null ? null : String(row.provider_id),
            executor: String(row.executor) as ExecutorKind,
          };
          return [JSON.stringify([value.threadId, value.providerId, value.executor]), value] as const;
        }),
      ).values(),
    ];
    const other = this.#db.prepare(
      "SELECT 1 FROM office_native_threads WHERE thread_id=? AND provider_id IS ? AND executor=? AND NOT(agent_id=? AND conversation_id=?) LIMIT 1",
    );
    return {
      agentId,
      all,
      orphan: all.filter(
        (thread) => !other.get(thread.threadId, thread.providerId, thread.executor, agentId, conversationId),
      ),
    };
  }
  #deletionPlan(conversationId: string): {
    agentId: string;
    allNative: DeletedConversationResources["nativeThreads"];
    resources: DeletedConversationResources;
  } {
    const native = this.#nativePlan(conversationId),
      agentId = native.agentId;
    const runs = this.#db
      .prepare(
        `SELECT DISTINCT run_id FROM (
      SELECT json_extract(message,'$.runId') AS run_id FROM office_messages WHERE agent_id=? AND conversation_id=?
      UNION SELECT run_id FROM office_progress WHERE agent_id=? AND conversation_id=?)
      WHERE typeof(run_id)='text' AND length(run_id)>0`,
      )
      .all(agentId, conversationId, agentId, conversationId)
      .map((row) => String(row.run_id));
    const attachments = this.#db
      .prepare(
        `SELECT DISTINCT CASE WHEN a.type='object' THEN json_extract(a.value,'$.id') END AS attachment_id
      FROM office_messages m,json_each(m.message,'$.attachments') a WHERE m.agent_id=? AND m.conversation_id=? AND a.type='object'`,
      )
      .all(agentId, conversationId)
      .map((row) => row.attachment_id)
      .filter((value): value is string => typeof value === "string" && Boolean(value));
    const otherRun = this.#db
      .prepare(`SELECT 1 FROM office_messages WHERE json_extract(message,'$.runId')=? AND NOT(agent_id=? AND conversation_id IS ?)
      UNION ALL SELECT 1 FROM office_progress WHERE run_id=? AND NOT(agent_id=? AND conversation_id IS ?) LIMIT 1`);
    const otherAttachment = this.#db
      .prepare(`SELECT 1 FROM office_messages m,json_each(m.message,'$.attachments') a WHERE m.agent_id=? AND m.conversation_id IS NOT ?
      AND a.type='object' AND CASE WHEN a.type='object' THEN json_extract(a.value,'$.id') END=? LIMIT 1`);
    return {
      agentId,
      allNative: native.all,
      resources: {
        nativeThreads: native.orphan,
        runIds: runs.filter((runId) => !otherRun.get(runId, agentId, conversationId, runId, agentId, conversationId)),
        attachments: attachments
          .filter((id) => !otherAttachment.get(agentId, conversationId, id))
          .map((id) => ({ agentId, id })),
      },
    };
  }
  #removeNativeMappings(
    agentId: string,
    conversationId: string,
    threads: DeletedConversationResources["nativeThreads"],
  ): void {
    this.#db
      .prepare("DELETE FROM office_native_threads WHERE agent_id=? AND conversation_id=?")
      .run(agentId, conversationId);
    const removeLegacy = this.#db.prepare(
      "DELETE FROM office_threads WHERE agent_id=? AND kind='chat' AND thread_id=?",
    );
    for (const thread of threads) removeLegacy.run(agentId, thread.threadId);
  }
  #checkpointDeletion(): void {
    try {
      this.#db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    } catch {
      /* Other readers may temporarily retain WAL pages. */
    }
  }
  previewConversationDeletion(id: string): DeletedConversationResources {
    return this.#deletionPlan(text(id, "invalid_conversation_id", 256)).resources;
  }
  resetConversationThreads(id: string): DeletedConversationResources {
    const conversationId = text(id, "invalid_conversation_id", 256);
    this.#db.exec("PRAGMA secure_delete=ON; BEGIN IMMEDIATE");
    let result: DeletedConversationResources;
    try {
      const native = this.#nativePlan(conversationId);
      this.#removeNativeMappings(native.agentId, conversationId, native.all);
      result = { nativeThreads: native.orphan, runIds: [], attachments: [] };
      this.#db.exec("COMMIT");
    } catch (error) {
      this.#db.exec("ROLLBACK");
      throw error;
    }
    this.#checkpointDeletion();
    return result;
  }
  deleteConversation(id: string): DeletedConversationResources {
    const conversationId = text(id, "invalid_conversation_id", 256);
    this.#db.exec("PRAGMA secure_delete=ON; BEGIN IMMEDIATE");
    let result: DeletedConversationResources;
    try {
      const plan = this.#deletionPlan(conversationId),
        agentId = plan.agentId;
      // Preserve meetings and other participants' messages, removing only dangling IDs.
      this.#db
        .prepare(
          `UPDATE office_meetings SET snapshot=json_set(snapshot,'$.messageIds',json(COALESCE((
        SELECT json_group_array(r.value) FROM json_each(office_meetings.snapshot,'$.messageIds') r
        WHERE NOT EXISTS(SELECT 1 FROM office_messages m WHERE m.agent_id=? AND m.conversation_id=? AND m.id=r.value)), '[]')))
        WHERE EXISTS(SELECT 1 FROM json_each(office_meetings.snapshot,'$.messageIds') r
        JOIN office_messages m ON m.id=r.value WHERE m.agent_id=? AND m.conversation_id=?)`,
        )
        .run(agentId, conversationId, agentId, conversationId);
      this.#db
        .prepare(
          `DELETE FROM office_message_requests WHERE (agent_id=? AND conversation_id=?) OR message_id IN
        (SELECT id FROM office_messages WHERE agent_id=? AND conversation_id=?)`,
        )
        .run(agentId, conversationId, agentId, conversationId);
      this.#db
        .prepare("DELETE FROM office_messages WHERE agent_id=? AND conversation_id=?")
        .run(agentId, conversationId);
      this.#db
        .prepare("DELETE FROM office_progress WHERE agent_id=? AND conversation_id=?")
        .run(agentId, conversationId);
      this.#removeNativeMappings(agentId, conversationId, plan.allNative);
      const removeEvents = this.#db.prepare("DELETE FROM office_events WHERE json_extract(event,'$.runId')=?");
      for (const runId of plan.resources.runIds) removeEvents.run(runId);
      this.#db.prepare("INSERT OR IGNORE INTO office_deleted_conversations(id) VALUES(?)").run(conversationId);
      this.#db.prepare("DELETE FROM office_conversations WHERE id=?").run(conversationId);
      result = plan.resources;
      this.#db.exec("COMMIT");
    } catch (error) {
      this.#db.exec("ROLLBACK");
      throw error;
    }
    this.#checkpointDeletion();
    return result;
  }
  setThread(
    agentId: string,
    kind: ThreadKind,
    threadId: string,
    conversationId?: string | null,
    binding?: ThreadBinding,
  ): void {
    this.#require(agentId);
    if (!["chat", "task", "meeting"].includes(kind)) throw new OfficeError("invalid_thread_kind");
    const validated = text(threadId, "invalid_thread_id", 256);
    const conversation =
      kind === "chat" || (conversationId !== undefined && conversationId !== null)
        ? this.#conversationFor(agentId, conversationId).id
        : "";
    const service = this.#threadBinding(agentId, binding);
    this.#db
      .prepare(
        `INSERT INTO office_native_threads(agent_id,kind,conversation_id,binding_key,provider_id,executor,thread_id)
      VALUES(?,?,?,?,?,?,?) ON CONFLICT(agent_id,kind,conversation_id,binding_key) DO UPDATE SET thread_id=excluded.thread_id`,
      )
      .run(
        agentId,
        kind,
        conversation,
        JSON.stringify([service.providerId, service.executor]),
        service.providerId,
        service.executor,
        validated,
      );
  }
  getThread(agentId: string, kind: ThreadKind, conversationId?: string | null, binding?: ThreadBinding): string | null {
    if (!this.getRawAgent(agentId)) return null;
    if (!["chat", "task", "meeting"].includes(kind)) throw new OfficeError("invalid_thread_kind");
    const conversation =
      kind === "chat" || (conversationId !== undefined && conversationId !== null)
        ? this.#conversationFor(agentId, conversationId).id
        : "";
    const service = this.#threadBinding(agentId, binding);
    return (
      (
        this.#db
          .prepare(
            "SELECT thread_id FROM office_native_threads WHERE agent_id=? AND kind=? AND conversation_id=? AND binding_key=?",
          )
          .get(agentId, kind, conversation, JSON.stringify([service.providerId, service.executor])) as
          | { thread_id: string }
          | undefined
      )?.thread_id ?? null
    );
  }
  #provider(row: Record<string, unknown> | undefined): ProviderProfile | undefined {
    if (!row) return undefined;
    const stored = JSON.parse(row.profile as string) as Partial<ProviderProfile>;
    const executor = stored.executor ?? "codex";
    const authMode = stored.authMode ?? "api_key";
    return {
      id: String(row.id),
      name: String(stored.name),
      baseUrl: stored.baseUrl ?? "",
      executor,
      authMode,
      credentialSlotId: stored.credentialSlotId ?? null,
      wireApi: stored.wireApi ?? (executor === "claude-code" ? "messages" : "responses"),
    };
  }
  addProvider(input: ProviderInput): ProviderProfile {
    const name = text(input?.name, "invalid_provider_name", 120);
    const executor = input.executor ?? "codex",
      authMode = input.authMode ?? "api_key";
    if (!["codex", "claude-code"].includes(executor)) throw new OfficeError("invalid_executor");
    if (!["api_key", "account"].includes(authMode)) throw new OfficeError("invalid_auth_mode");
    const wireApi = executor === "claude-code" ? "messages" : "responses";
    if (input.wireApi !== undefined && input.wireApi !== wireApi) throw new OfficeError("unsupported_wire_api");
    const slot = nullableText(input.credentialSlotId, "invalid_credential_slot");
    if (authMode === "account" && slot !== null) throw new OfficeError("account_provider_slot_unsupported");
    const rawBaseUrl = input.baseUrl ?? "";
    if (typeof rawBaseUrl !== "string") throw new OfficeError("invalid_provider_url");
    if (authMode === "account" && rawBaseUrl.trim()) throw new OfficeError("account_provider_url_unsupported");
    let baseUrl = "";
    if (authMode === "api_key") {
      let url: URL;
      try {
        url = new URL(rawBaseUrl);
      } catch {
        throw new OfficeError("invalid_provider_url");
      }
      if (
        !["http:", "https:"].includes(url.protocol) ||
        url.username ||
        url.password ||
        url.search ||
        url.hash ||
        /[?#]/.test(rawBaseUrl)
      )
        throw new OfficeError("invalid_provider_url");
      baseUrl = url.toString().replace(/\/+$/, "");
    }
    const profile: ProviderProfile = {
      id: randomUUID(),
      name,
      baseUrl,
      wireApi,
      executor,
      authMode,
      credentialSlotId: slot,
    };
    this.#db.prepare("INSERT INTO office_providers(id,profile) VALUES(?,?)").run(profile.id, JSON.stringify(profile));
    return profile;
  }
  listProviders(): ProviderProfile[] {
    return this.#db
      .prepare("SELECT id,profile FROM office_providers WHERE lifecycle='active' ORDER BY rowid")
      .all()
      .map((row) => this.#provider(row)!);
  }
  getProvider(id: string): ProviderProfile | undefined {
    return this.#provider(
      this.#db.prepare("SELECT id,profile FROM office_providers WHERE id=? AND lifecycle='active'").get(id),
    );
  }
  getRawProvider(id: string): ProviderProfile | undefined {
    return this.#provider(this.#db.prepare("SELECT id,profile FROM office_providers WHERE id=?").get(id));
  }
  setProviderSlot(id: string, slotId: string | null): ProviderProfile {
    const provider = this.getProvider(id);
    if (!provider) throw new OfficeError("provider_not_found", 404);
    const slot = nullableText(slotId, "invalid_credential_slot");
    if (provider.authMode === "account" && slot !== null) throw new OfficeError("account_provider_slot_unsupported");
    const updated = { ...provider, credentialSlotId: slot };
    this.#db
      .prepare("UPDATE office_providers SET profile=? WHERE id=? AND lifecycle='active'")
      .run(JSON.stringify(updated), id);
    return updated;
  }
  deleteProvider(id: string): void {
    if (!this.getProvider(id)) throw new OfficeError("provider_not_found", 404);
    this.#db.exec("BEGIN IMMEDIATE");
    try {
      this.#db
        .prepare(
          `UPDATE office_profiles SET profile=json_set(profile,
        '$.providerId',NULL,'$.credentialSlotId',NULL,'$.model',NULL,'$.reasoningEffort',NULL,'$.credentialState','required')
        WHERE json_extract(profile,'$.providerId')=?`,
        )
        .run(id);
      this.#db.prepare("UPDATE office_providers SET lifecycle='archived' WHERE id=?").run(id);
      this.#db.exec("COMMIT");
    } catch (error) {
      this.#db.exec("ROLLBACK");
      throw error;
    }
  }
  addMessage(input: {
    agentId: string;
    role: OfficeMessage["role"];
    content: string;
    runId?: string | null;
    attachments?: OfficeAttachment[];
    conversationId?: string | null;
  }): OfficeMessage {
    this.#require(input.agentId);
    if (!["user", "assistant", "system"].includes(input.role) || typeof input.content !== "string")
      throw new OfficeError("invalid_message");
    const conversation = this.#conversationFor(input.agentId, input.conversationId);
    const message: OfficeMessage = {
      id: randomUUID(),
      agentId: input.agentId,
      role: input.role,
      content: input.content,
      at: Date.now(),
      conversationId: conversation.id,
      ...(input.runId === undefined ? {} : { runId: nullableText(input.runId, "invalid_run_id") }),
      ...(input.attachments?.length ? { attachments: input.attachments.map((item) => ({ ...item })) } : {}),
    };
    this.#db
      .prepare("INSERT INTO office_messages(id,agent_id,message,conversation_id) VALUES(?,?,?,?)")
      .run(message.id, message.agentId, JSON.stringify(message), conversation.id);
    this.#db
      .prepare(
        "UPDATE office_conversations SET updated_at=MAX(updated_at,?),last_used_at=MAX(COALESCE(last_used_at,0),?) WHERE id=?",
      )
      .run(message.at, message.at, conversation.id);
    return message;
  }
  messages(agentId: string, conversationId?: string | null): OfficeMessage[] {
    const rows =
      conversationId === undefined
        ? this.#db.prepare("SELECT message FROM office_messages WHERE agent_id=? ORDER BY seq").all(agentId)
        : this.#db
            .prepare("SELECT message FROM office_messages WHERE agent_id=? AND conversation_id=? ORDER BY seq")
            .all(agentId, this.#conversationFor(agentId, conversationId).id);
    return rows.map((row) => JSON.parse(row.message as string));
  }
  messageRequest(agentId: string, key: string, conversationId?: string | null): MessageRequest | undefined {
    const conversation = this.#conversationFor(agentId, conversationId);
    const row = this.#db
      .prepare(
        "SELECT message_id,run_id,conversation_id FROM office_message_requests WHERE agent_id=? AND request_key=?",
      )
      .get(agentId, key);
    if (!row) return undefined;
    if (row.conversation_id !== conversation.id) throw new OfficeError("message_request_conversation_conflict", 409);
    return { messageId: String(row.message_id), runId: String(row.run_id), conversationId: conversation.id };
  }
  addRequestedMessage(input: {
    agentId: string;
    content: string;
    attachments: OfficeAttachment[];
    runId: string;
    key: string;
    conversationId?: string | null;
  }): MessageRequest {
    const conversation = this.#conversationFor(input.agentId, input.conversationId);
    const key = text(input.key, "invalid_request_key", 160);
    this.#db.exec("BEGIN IMMEDIATE");
    try {
      const previous = this.messageRequest(input.agentId, key, conversation.id);
      if (previous) {
        this.#db.exec("COMMIT");
        return previous;
      }
      const message = this.addMessage({ ...input, conversationId: conversation.id, role: "user" });
      this.#db
        .prepare(
          "INSERT INTO office_message_requests(agent_id,request_key,message_id,run_id,conversation_id) VALUES(?,?,?,?,?)",
        )
        .run(input.agentId, key, message.id, input.runId, conversation.id);
      this.#db.exec("COMMIT");
      return { messageId: message.id, runId: input.runId, conversationId: conversation.id };
    } catch (error) {
      this.#db.exec("ROLLBACK");
      throw error;
    }
  }
  putMeeting(snapshot: MeetingSnapshot, title?: string): void {
    if (
      !snapshot ||
      !["kickoff", "review", "ended"].includes(snapshot.phase) ||
      !Array.isArray(snapshot.participantIds) ||
      !Array.isArray(snapshot.messageIds)
    )
      throw new OfficeError("invalid_meeting");
    const clean: MeetingSnapshot = {
      id: text(snapshot.id, "invalid_meeting", 256),
      taskId: text(snapshot.taskId, "invalid_task_id", 256),
      participantIds: snapshot.participantIds.map((id) => text(id, "invalid_agent_id", 256)),
      phase: snapshot.phase,
      messageIds: snapshot.messageIds.map((id) => text(id, "invalid_message_id", 256)),
    };
    const cleanTitle = title === undefined ? null : text(title, "invalid_meeting_title", 256);
    this.#db
      .prepare(
        "INSERT INTO office_meetings(id,snapshot,title) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET snapshot=excluded.snapshot,title=COALESCE(excluded.title,office_meetings.title)",
      )
      .run(clean.id, JSON.stringify(clean), cleanTitle);
  }
  getMeeting(id: string): MeetingSnapshot | undefined {
    const row = this.#db.prepare("SELECT snapshot FROM office_meetings WHERE id=?").get(id);
    return row ? JSON.parse(row.snapshot as string) : undefined;
  }
  listMeetings(): MeetingSnapshot[] {
    return this.#db
      .prepare("SELECT snapshot FROM office_meetings ORDER BY seq")
      .all()
      .map((row) => JSON.parse(row.snapshot as string));
  }
  appendEvent(input: Omit<TaskRuntimeEvent, "seq">): TaskRuntimeEvent {
    if (!input || !states.includes(input.state) || typeof input.summary !== "string" || !Number.isFinite(input.at))
      throw new OfficeError("invalid_event");
    const event: Omit<TaskRuntimeEvent, "seq"> = {
      eventId: text(input.eventId, "invalid_event_id", 256),
      agentId: text(input.agentId, "invalid_agent_id", 256),
      taskId: nullableText(input.taskId, "invalid_task_id"),
      runId: nullableText(input.runId, "invalid_run_id"),
      state: input.state,
      summary: input.summary,
      at: input.at,
    };
    const result = this.#db
      .prepare("INSERT INTO office_events(event_id,event) VALUES(?,?)")
      .run(event.eventId, JSON.stringify(event));
    return { ...event, seq: Number(result.lastInsertRowid) };
  }
  putProgress(input: Omit<RunProgressEvent, "seq" | "at">): RunProgressEvent {
    const conversationId = this.getRawAgent(input.agentId)
      ? this.#conversationFor(input.agentId, input.conversationId).id
      : null;
    const event = {
      ...input,
      conversationId,
      title: input.title.slice(0, 240),
      detail: input.detail?.slice(-6000),
      at: Date.now(),
    };
    this.#db
      .prepare(
        `INSERT INTO office_progress(agent_id,run_id,item_id,event,conversation_id) VALUES(?,?,?,?,?)
      ON CONFLICT(run_id,item_id) DO UPDATE SET seq=excluded.seq,event=excluded.event,conversation_id=excluded.conversation_id`,
      )
      .run(input.agentId, input.runId, input.itemId, JSON.stringify(event), conversationId);
    const row = this.#db
      .prepare("SELECT seq FROM office_progress WHERE run_id=? AND item_id=?")
      .get(input.runId, input.itemId)!;
    this.#db
      .prepare(
        "DELETE FROM office_progress WHERE agent_id=? AND seq NOT IN (SELECT seq FROM office_progress WHERE agent_id=? ORDER BY seq DESC LIMIT 400)",
      )
      .run(input.agentId, input.agentId);
    return { ...event, seq: Number(row.seq) };
  }
  progress(agentId: string, afterSeq = 0, conversationId?: string | null): RunProgressEvent[] {
    const rows =
      conversationId === undefined
        ? this.#db
            .prepare(
              "SELECT seq,event FROM (SELECT seq,event FROM office_progress WHERE agent_id=? AND seq>? ORDER BY seq DESC LIMIT 400) ORDER BY seq",
            )
            .all(agentId, afterSeq)
        : this.#db
            .prepare(
              "SELECT seq,event FROM (SELECT seq,event FROM office_progress WHERE agent_id=? AND conversation_id=? AND seq>? ORDER BY seq DESC LIMIT 400) ORDER BY seq",
            )
            .all(agentId, this.#conversationFor(agentId, conversationId).id, afterSeq);
    return rows.map((row) => ({ ...JSON.parse(row.event as string), seq: Number(row.seq) }));
  }
  lastSeq(): number {
    return Number(
      (this.#db.prepare("SELECT COALESCE(MAX(seq),0) AS seq FROM office_events").get() as { seq: number }).seq,
    );
  }
  close(): void {
    if (!this.#closed) {
      this.#db.close();
      this.#closed = true;
    }
  }
}
