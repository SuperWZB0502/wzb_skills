import http from "node:http";
import { randomBytes } from "node:crypto";
import { once } from "node:events";
import { ModelResponseRedactor, redact } from "./redactor.ts";
import { OfficeError } from "./errors.ts";
import { resolveClaudeProxyModel } from "./claude-model-normalization.ts";

export interface ProxyCredential {
  apiKey: string;
  baseUrl: string;
  model: string;
  wireApi?: "responses" | "messages";
  authMode?: "api_key" | "account";
  onUnauthorized?: () => void;
}
export interface RunCapability {
  runId: string;
  baseUrl: string;
  token: string;
  revoke(): void;
}
interface Entry extends ProxyCredential {
  agentId: string;
  runId: string;
  token: string;
  teamOnly?: boolean;
}
/**
 * Best-effort upstream error text for the executor. Reads at most 8 KB, keeps `error.message`
 * (or the raw body when it is not JSON) and strips anything that looks like a credential.
 */
async function upstreamErrorDetail(
  upstream: { body: ReadableStream<Uint8Array> | null },
  secrets: string[],
): Promise<{ message: string; type: string } | null> {
  try {
    if (!upstream.body) return null;
    const reader = upstream.body.getReader();
    const decoder = new TextDecoder();
    let raw = "";
    let bytes = 0;
    while (bytes < 8192) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      raw += decoder.decode(value, { stream: true });
    }
    await reader.cancel().catch(() => {});
    raw += decoder.decode();
    const text = raw.trim();
    if (!text) return null;
    let message = "";
    let type = "api_error";
    try {
      const parsed = JSON.parse(text) as {
        error?: { message?: unknown; type?: unknown } | string;
        message?: unknown;
        type?: unknown;
      };
      const error = parsed?.error;
      message = String(
        (typeof error === "string" ? error : error?.message) ??
          (typeof parsed?.message === "string" ? parsed.message : "") ??
          "",
      );
      const reported = (typeof error === "object" ? error?.type : undefined) ?? parsed?.type;
      if (typeof reported === "string" && /^[a-z0-9_.:-]{1,64}$/i.test(reported)) type = reported;
    } catch {
      message = text;
    }
    const safe = redact(message.replace(/\s+/g, " ").trim(), secrets).slice(0, 400);
    return safe ? { message: safe, type } : null;
  } catch {
    return null;
  }
}

export class ModelProxy {
  private readonly entries = new Map<string, Entry>();
  private readonly aborts = new Set<AbortController>();
  private server: http.Server;
  private origin = "";
  constructor(private readonly credential: (agentId: string) => ProxyCredential) {
    this.server = http.createServer((req, res) => {
      void this.handle(req, res);
    });
  }
  async start(): Promise<void> {
    await new Promise<void>((resolve, reject) => {
      this.server.once("error", reject);
      this.server.listen(0, "127.0.0.1", () => {
        this.server.off("error", reject);
        resolve();
      });
    });
    this.origin = `http://127.0.0.1:${(this.server.address() as { port: number }).port}`;
  }
  issue(agentId: string, runId: string, capturedCredential?: ProxyCredential): RunCapability {
    const value = capturedCredential ?? this.credential(agentId);
    const token = randomBytes(32).toString("hex");
    this.entries.set(token, { ...value, agentId, runId, token });
    return {
      runId,
      baseUrl: `${this.origin}/runs/${encodeURIComponent(runId)}${value.wireApi === "messages" ? "" : "/v1"}`,
      token,
      revoke: () => {
        this.entries.delete(token);
      },
    };
  }
  issueTeam(agentId: string, runId: string): RunCapability {
    const token = randomBytes(32).toString("hex");
    this.entries.set(token, { agentId, runId, token, apiKey: "", baseUrl: "", model: "", teamOnly: true });
    return {
      runId,
      baseUrl: `${this.origin}/runs/${encodeURIComponent(runId)}`,
      token,
      revoke: () => {
        this.entries.delete(token);
      },
    };
  }
  authorize(token: string): { agentId: string; runId: string } | null {
    const entry = this.entries.get(token);
    return entry ? { agentId: entry.agentId, runId: entry.runId } : null;
  }
  private async handle(req: http.IncomingMessage, res: http.ServerResponse): Promise<void> {
    const authorization = typeof req.headers.authorization === "string" ? req.headers.authorization : "";
    const token = /^Bearer /i.test(authorization)
      ? authorization.slice(7)
      : typeof req.headers["x-api-key"] === "string"
        ? req.headers["x-api-key"]
        : "";
    const entry = this.entries.get(token);
    const fail = (status: number, message: string, type = "office_proxy_error") => {
      if (!res.headersSent) {
        res.writeHead(status, { "content-type": "application/json" });
        res.end(JSON.stringify({ error: { message, type } }));
      } else res.destroy();
    };
    // SDK beta endpoints append ?beta=true. Authorize the pathname rather
    // than comparing the complete request target to the route allowlist.
    let requestUrl: URL;
    try {
      requestUrl = new URL(req.url ?? "/", "http://office-proxy.invalid");
    } catch {
      fail(400, "Invalid model request URL");
      return;
    }
    if (!entry || !requestUrl.pathname.startsWith(`/runs/${encodeURIComponent(entry.runId)}/v1/`)) {
      fail(401, "Run capability expired or invalid");
      return;
    }
    if (entry.teamOnly) {
      fail(403, "This capability only authorizes office tools");
      return;
    }
    const suffix = requestUrl.pathname.slice(`/runs/${encodeURIComponent(entry.runId)}/v1`.length);
    const messages = entry.wireApi === "messages";
    const allowedRoutes = messages ? ["/messages", "/messages/count_tokens"] : ["/responses", "/responses/compact"];
    const supportedQuery =
      !requestUrl.search ||
      (messages && requestUrl.searchParams.size === 1 && requestUrl.searchParams.get("beta") === "true");
    if (req.method !== "POST" || !allowedRoutes.includes(suffix) || !supportedQuery) {
      fail(404, "Unsupported model route");
      return;
    }
    const controller = new AbortController();
    this.aborts.add(controller);
    const abort = () => controller.abort();
    res.on("close", abort);
    try {
      let bytes = 0;
      const chunks: Buffer[] = [];
      for await (const chunk of req) {
        bytes += chunk.length;
        if (bytes > 32 * 1024 * 1024) throw new OfficeError("request_too_large", 413);
        chunks.push(Buffer.from(chunk));
      }
      let body: Record<string, unknown>;
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString());
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error();
        body = parsed;
      } catch {
        throw new OfficeError("invalid_model_request");
      }
      const requestedModel = typeof body.model === "string" ? body.model : "";
      if (messages) {
        const wireModel = resolveClaudeProxyModel(entry.model, requestedModel);
        if (wireModel === null) throw new OfficeError("model_mismatch", 403);
        body.model = wireModel;
      } else {
        if (requestedModel && requestedModel !== entry.model) throw new OfficeError("model_mismatch", 403);
        body.model = entry.model;
      }
      const headers: Record<string, string> = { "content-type": "application/json" };
      if (messages) {
        headers["anthropic-version"] = "2023-06-01";
        if (entry.authMode === "account") headers.Authorization = `Bearer ${entry.apiKey}`;
        else {
          headers["x-api-key"] = entry.apiKey;
          // Non-Anthropic relays commonly accept bearer credentials instead of x-api-key.
          if (new URL(entry.baseUrl).hostname !== "api.anthropic.com") headers.Authorization = `Bearer ${entry.apiKey}`;
        }
      } else headers.Authorization = `Bearer ${entry.apiKey}`;
      const passthrough = messages
        ? [
            "accept",
            "anthropic-version",
            "anthropic-beta",
            "user-agent",
            "x-app",
            "x-stainless-lang",
            "x-stainless-package-version",
            "x-stainless-os",
            "x-stainless-arch",
            "x-stainless-runtime",
            "x-stainless-runtime-version",
          ]
        : ["accept", "openai-beta", "x-codex-turn-state", "session_id"];
      for (const name of passthrough)
        if (typeof req.headers[name] === "string" && req.headers[name].length < 4096)
          headers[name] = req.headers[name] as string;
      if (messages && entry.authMode === "account") {
        const beta = new Set(
          (headers["anthropic-beta"] ?? "")
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean),
        );
        beta.add("oauth-2025-04-20");
        headers["anthropic-beta"] = [...beta].join(",");
      }
      const base = entry.baseUrl.replace(/\/+$/, "");
      const target = messages ? base.replace(/\/v1$/, "") + "/v1" + suffix : base + suffix;
      const upstream = await fetch(target + requestUrl.search, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
        signal: controller.signal,
        redirect: "manual",
      });
      if (!upstream.ok) {
        if (upstream.status === 401) entry.onUnauthorized?.();
        // The executor recovers from specific conditions (prompt too long → compact, 429 → wait)
        // by reading the upstream message. Replacing every failure with one generic sentence hid
        // a full context window and left a dead session unrecoverable.
        const detail = await upstreamErrorDetail(upstream, [entry.apiKey, entry.token]);
        fail(
          upstream.status >= 300 && upstream.status < 400 ? 502 : upstream.status,
          detail?.message ?? "Model service rejected request; check credentials, model and endpoint",
          detail?.type,
        );
        return;
      }
      const mediaType = (upstream.headers.get("content-type") ?? "application/json").split(";")[0].trim().toLowerCase();
      if (mediaType !== "application/json" && mediaType !== "text/event-stream") {
        await upstream.body?.cancel();
        throw new OfficeError("invalid_model_response", 502);
      }
      const write = async (part: string) => {
        if (!part) return;
        if (!res.headersSent)
          res.writeHead(upstream.status, { "content-type": mediaType, "cache-control": "no-store" });
        if (!res.write(part)) await once(res, "drain", { signal: controller.signal });
      };
      if (upstream.body) {
        const reader = upstream.body.getReader();
        const decoder = new TextDecoder();
        const filter = new ModelResponseRedactor(mediaType === "text/event-stream" ? "sse" : "json", [
          entry.apiKey,
          entry.token,
        ]);
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          await write(filter.push(decoder.decode(value, { stream: true })));
        }
        await write(filter.push(decoder.decode()) + filter.flush());
      }
      if (!res.headersSent) res.writeHead(upstream.status, { "content-type": mediaType, "cache-control": "no-store" });
      res.end();
    } catch (error) {
      if (!controller.signal.aborted)
        fail(
          error instanceof OfficeError ? error.status : 502,
          error instanceof OfficeError ? error.code : "Model service unavailable",
        );
    } finally {
      res.off("close", abort);
      controller.abort();
      this.aborts.delete(controller);
    }
  }
  async close(): Promise<void> {
    for (const c of this.aborts) c.abort();
    this.entries.clear();
    this.server.closeAllConnections();
    await new Promise<void>((r) => this.server.close(() => r()));
  }
}
