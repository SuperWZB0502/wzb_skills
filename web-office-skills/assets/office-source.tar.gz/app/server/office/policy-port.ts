import type { AgentProfile, TaskRuntimeEvent } from "../../shared/office-contracts.ts";
export interface PolicyLease {
  version: string;
  summarize(event: TaskRuntimeEvent): Promise<string>;
  rolePrompt(profile: AgentProfile): Promise<string>;
  release(): void;
}
export interface PolicyPort {
  acquire(): PolicyLease;
}
