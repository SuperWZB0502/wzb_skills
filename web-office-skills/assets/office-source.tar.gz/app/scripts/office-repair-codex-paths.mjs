#!/usr/bin/env node
/**
 * Codex stores absolute rollout paths in its own SQLite state. After the per-agent
 * layout migration those paths point at the old locations, so resuming an old thread
 * fails with "no rollout found". Rewrite every text column that mentions an old path.
 */
import path from "node:path";
import { readdir, stat } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";

export async function repairCodexPaths(rootInput, { dryRun = false, log = console.log } = {}) {
const root = path.resolve(rootInput);
const agentsDir = path.join(root, "agents");

const replacements = (agentId) => [
  [
    path.join(root, "state", "codex", agentId),
    path.join(root, "agents", agentId, "sessions", "codex"),
  ],
  [
    path.join(root, "state", "claude", agentId),
    path.join(root, "agents", agentId, "sessions", "claude"),
  ],
];

let files = 0;
let updates = 0;
for (const agentId of await readdir(agentsDir).catch(() => [])) {
  const base = path.join(agentsDir, agentId, "sessions", "codex");
  let entries = [];
  try {
    entries = await readdir(base);
  } catch {
    continue;
  }
  for (const name of entries) {
    if (!name.endsWith(".sqlite")) continue;
    const file = path.join(base, name);
    const info = await stat(file).catch(() => null);
    if (!info?.isFile()) continue;
    const db = new DatabaseSync(file);
    try {
      const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((row) => String(row.name));
      for (const table of tables) {
        const columns = db.prepare(`PRAGMA table_info("${table}")`).all().filter((column) => /CHAR|TEXT|CLOB/i.test(String(column.type)));
        for (const column of columns) {
          for (const [from, to] of replacements(agentId)) {
            const changed = dryRun
              ? db.prepare(`SELECT COUNT(*) AS n FROM "${table}" WHERE instr("${column.name}", ?) > 0`).get(from).n
              : db.prepare(`UPDATE "${table}" SET "${column.name}" = replace("${column.name}", ?, ?) WHERE instr("${column.name}", ?) > 0`).run(from, to, from).changes;
            if (changed) {
              updates += Number(changed);
              log(`${dryRun ? "would update" : "updated"} ${changed} row(s) in ${path.relative(root, file)} :: ${table}.${column.name}`);
            }
          }
        }
      }
    } finally {
      db.close();
    }
    files += 1;
  }
}
return { ok: true, dryRun, databases: files, updates };
}

if (process.argv[1] && import.meta.url === (await import("node:url")).pathToFileURL(path.resolve(process.argv[1])).href) {
  const result = await repairCodexPaths(process.argv[2] ?? process.cwd(), { dryRun: process.argv.includes("--dry-run") });
  process.stdout.write(JSON.stringify(result) + "\n");
}
