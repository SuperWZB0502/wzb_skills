#!/usr/bin/env node
/**
 * Scaffolding for the per-project work layout described in docs/dev-work-layout.md.
 * Generates the numbered project/feature/sub-feature/experiment skeleton plus README and
 * document placeholders, and can validate or finalize (commit) a main feature.
 */
import path from "node:path";
import { execFileSync } from "node:child_process";
import { access, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";

const NAME = /^(\d{2})-([^\s/\\]{1,14})$/;
const STATUS = ["待开发", "待验证", "已采纳", "已否决"];
const REQUIRED_DOCS = ["README.md", "设计文档.md", "实现文档.md", "测试文档.md"];

const args = process.argv.slice(2);
const command = args[0];
const flag = (name, fallback) => {
  const index = args.indexOf(`--${name}`);
  return index >= 0 ? args[index + 1] : fallback;
};
const workRoot = path.resolve(flag("work", process.cwd()));

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}
function requireName(value, label) {
  if (!value || !NAME.test(value)) throw Error(`invalid_${label}: 需为「两位编号-名称」，名称 1-14 字且不含空格或斜杠`);
  return value;
}
const exists = async (target) => {
  try {
    await access(target);
    return true;
  } catch {
    return false;
  }
};
const writeIfMissing = async (file, content) => {
  if (await exists(file)) return false;
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, content, { mode: 0o600 });
  return true;
};

const projectDir = (project) => path.join(workRoot, project);
const featureDir = (project, feature) => path.join(projectDir(project), "feature", feature);
const testFeatureDir = (project, feature) => path.join(projectDir(project), "test", feature);

const templates = {
  project: (name) =>
    `# ${name}\n\n## 项目说明\n\n<!-- 200 字以内：这个项目解决什么问题、边界是什么。 -->\n\n## 目录结构\n\n| 目录 | 用途 |\n| --- | --- |\n| \`code/\` | 项目代码（本项目的 git 仓库） |\n| \`test/\` | 实验中间产物（不进 git） |\n| \`feature/\` | 设计/实现/测试文档与特性清单 |\n\n## 当前状态\n\n- 创建时间：${new Date().toISOString().slice(0, 10)}\n- 进行中的主特性：（待补充）\n`,
  code: (name) =>
    `# 代码目录 · ${name}\n\n本项目唯一 git 仓库根目录；提交以主特性为最小粒度，内容为定稿代码 + \`docs/\` 下的《特性文档.md》。\n`,
  gitignore: () => `node_modules/\n__pycache__/\n*.pyc\n.venv/\ndist/\nbuild/\n*.log\n.env\n.env.*\n.DS_Store\n`,
  testRoot: (name) =>
    `# 实验目录 · ${name}\n\n仅存放实验中间产物（日志、memory、profiling、模型输出等），**不进 git**。\n\n- \`<编号-主特性>/\`：该特性的实验总览（README.md + 实验进展.md）\n  - \`<编号-实验名>/\`：一次实验的全部输出都放这里（含 README.md）\n`,
  featureRoot: (name) =>
    `# 特性目录 · ${name}\n\n| 编号 | 主特性 | 状态 | 说明 |\n| --- | --- | --- | --- |\n\n主特性完成后更新本表。\n`,
  mainFeature: (name) =>
    `# ${name}\n\n## 特性简介\n\n<!-- 500 字以内：这个特性做什么、为什么做、收益是什么。 -->\n\n## 特性开关\n\n| 开关名 | 默认值 | 生效方式 |\n| --- | --- | --- |\n| （待补充） | 关闭 | 环境变量 |\n\n## 子特性\n\n| 编号 | 子特性 | 一句话说明 |\n| --- | --- | --- |\n`,
  subFeature: (name) =>
    `# ${name}\n\n## 特性简介\n\n<!-- 200 字以内：这个子特性做什么。 -->\n\n## 特性开关\n\n| 开关名 | 默认值 | 生效方式 |\n| --- | --- | --- |\n| （待补充） | 关闭 | 环境变量 |\n\n## 文件汇总\n\n| 序号 | 文件名 | 功能介绍 |\n| --- | --- | --- |\n`,
  design: (name, role = "主特性") =>
    `# 设计文档 · ${name}\n\n- 角色：${role}\n\n## 背景与目标\n\n## 方案概述\n\n## 关键设计\n\n## 风险与取舍\n`,
  implementation: (name, role = "主特性") =>
    `# 实现文档 · ${name}\n\n- 角色：${role}\n\n## 实现概述\n\n## 关键改动\n\n## 配置与开关\n\n## 已知限制\n`,
  testing: (name, role = "主特性") =>
    `# 测试文档 · ${name}\n\n- 角色：${role}\n\n## 测试范围\n\n## 用例与结果\n\n| 序号 | 用例 | 结果 | 备注 |\n| --- | --- | --- | --- |\n\n## 结论\n`,
  progress: (name) =>
    `# 开发进展 · ${name}\n\n| 序号 | 特性名称 | 简要描述 | 收益 | 状态 |\n| --- | --- | --- | --- | --- |\n`,
  testFeature: (name) =>
    `# 实验总览 · ${name}\n\n- 每个实验一个子目录 \`<编号-实验名>/\`，本次全部输出只放该目录。\n- 每次实验后在实验进展.md 追加一行。\n`,
  experiments: (name) =>
    `# 实验进展 · ${name}\n\n| 序号 | 实验名称 | 实验目的 | 实验结论 | 日期 |\n| --- | --- | --- | --- | --- |\n`,
  experiment: (name) =>
    `# ${name}\n\n## 实验目的\n\n## 配置与参数\n\n## 结论\n\n## 产物清单\n\n| 文件 | 说明 |\n| --- | --- |\n`,
};

async function newProject(name) {
  const dir = projectDir(name);
  await mkdir(path.join(dir, "code", "docs"), { recursive: true });
  await mkdir(path.join(dir, "test"), { recursive: true });
  await mkdir(path.join(dir, "feature"), { recursive: true });
  await writeIfMissing(path.join(dir, "README.md"), templates.project(name));
  await writeIfMissing(path.join(dir, "code", "README.md"), templates.code(name));
  await writeIfMissing(path.join(dir, "code", ".gitignore"), templates.gitignore());
  await writeIfMissing(path.join(dir, "test", "README.md"), templates.testRoot(name));
  await writeIfMissing(path.join(dir, "feature", "README.md"), templates.featureRoot(name));
  const git = path.join(dir, "code");
  if (!(await exists(path.join(git, ".git")))) {
    try {
      execFileSync("git", ["init", "-q"], { cwd: git });
    } catch {
      /* git is optional for scaffolding */
    }
  }
  return { project: name, dir };
}

async function newFeature(project, feature) {
  const dir = featureDir(project, feature);
  await mkdir(dir, { recursive: true });
  await writeIfMissing(path.join(dir, "README.md"), templates.mainFeature(feature));
  await writeIfMissing(path.join(dir, "设计文档.md"), templates.design(feature));
  await writeIfMissing(path.join(dir, "实现文档.md"), templates.implementation(feature));
  await writeIfMissing(path.join(dir, "测试文档.md"), templates.testing(feature));
  await writeIfMissing(path.join(dir, "开发进展.md"), templates.progress(feature));
  const tests = testFeatureDir(project, feature);
  await mkdir(tests, { recursive: true });
  await writeIfMissing(path.join(tests, "README.md"), templates.testFeature(feature));
  await writeIfMissing(path.join(tests, "实验进展.md"), templates.experiments(feature));
  return { project, feature, dir };
}

async function newSubfeature(project, feature, sub) {
  const dir = path.join(featureDir(project, feature), sub);
  await mkdir(dir, { recursive: true });
  await writeIfMissing(path.join(dir, "README.md"), templates.subFeature(sub));
  await writeIfMissing(path.join(dir, "设计文档.md"), templates.design(sub, "子特性"));
  await writeIfMissing(path.join(dir, "实现文档.md"), templates.implementation(sub, "子特性"));
  await writeIfMissing(path.join(dir, "测试文档.md"), templates.testing(sub, "子特性"));
  const progress = path.join(featureDir(project, feature), "开发进展.md");
  if (await exists(progress)) {
    const text = await readFile(progress, "utf8");
    if (!text.includes(sub)) {
      const rows = text.split("\n").filter((line) => line.startsWith("| ")).length - 2;
      await writeFile(progress, `${text.trimEnd()}\n| ${rows + 1} | ${sub} | （待补充） | （待补充） | 待开发 |\n`, {
        mode: 0o600,
      });
    }
  }
  return { project, feature, sub, dir };
}

async function newExperiment(project, feature, name) {
  const dir = path.join(testFeatureDir(project, feature), name);
  await mkdir(dir, { recursive: true });
  await writeIfMissing(path.join(dir, "README.md"), templates.experiment(name));
  const log = path.join(testFeatureDir(project, feature), "实验进展.md");
  if (await exists(log)) {
    const text = await readFile(log, "utf8");
    if (!text.includes(name)) {
      const rows = text.split("\n").filter((line) => line.startsWith("| ")).length - 2;
      await writeFile(
        log,
        `${text.trimEnd()}\n| ${rows + 1} | ${name} | （待补充） | （待补充） | ${new Date().toISOString().slice(0, 10)} |\n`,
        { mode: 0o600 },
      );
    }
  }
  return { project, feature, experiment: name, dir };
}

async function checkProject(project, root = workRoot, { development = false, finalizing } = {}) {
  const errors = [];
  const warnings = [];
  const pending = [];
  const dir = path.join(root, project);
  if (!(await exists(dir))) return { project, errors: [`项目目录不存在: ${project}`], warnings, pending };
  const code = path.join(dir, "code");
  if (!(await exists(path.join(dir, "README.md")))) errors.push(`${project}: 缺少项目 README.md`);
  for (const sub of ["code", "test", "feature"]) {
    if (!(await exists(path.join(dir, sub)))) errors.push(`${project}: 缺少 ${sub}/`);
    else if (!(await exists(path.join(dir, sub, "README.md")))) errors.push(`${project}/${sub}: 缺少 README.md`);
  }
  if (!(await exists(path.join(code, ".git"))))
    errors.push(`${project}/code: 未初始化 git（规范要求 code/ 为本项目唯一 git 仓库）`);
  else {
    try {
      const { modified, untracked, unstaged, conflicts } = gitChanges(code);
      const summarize = (files) => `${files.slice(0, 5).join("、")}${files.length > 5 ? ` 等 ${files.length} 项` : ""}`;
      if (conflicts.length) errors.push(`${project}/code: 存在 Git 冲突 ${summarize(conflicts)}`);
      if (finalizing && !development) {
        const generated = `docs/${finalizing}-特性文档.md`;
        const outsideIndex = [...unstaged, ...untracked].filter((name) => name !== generated);
        if (outsideIndex.length)
          errors.push(`${project}/code: 有未暂存或未跟踪的文件 ${summarize(outsideIndex)}；定稿前只暂存本特性文件，另行处理其余改动`);
      } else {
        const target = development ? pending : errors;
        if (modified.length) target.push(`${project}/code: 已跟踪文件有未提交改动 ${summarize(modified)}`);
        if (untracked.length) target.push(`${project}/code: 有未跟踪文件 ${summarize(untracked)}`);
      }
    } catch {
      errors.push(`${project}/code: 无法读取 Git 状态`);
    }
  }
  const featuresRoot = path.join(dir, "feature");
  for (const entry of await readdir(featuresRoot, { withFileTypes: true }).catch(() => [])) {
    if (!entry.isDirectory()) continue;
    const feature = entry.name;
    if (!NAME.test(feature)) errors.push(`${project}/feature/${feature}: 编号或名称不合规`);
    const featurePath = path.join(featuresRoot, feature);
    for (const doc of [...REQUIRED_DOCS, "开发进展.md"]) {
      if (!(await exists(path.join(featurePath, doc)))) errors.push(`${project}/feature/${feature}: 缺少 ${doc}`);
    }
    const progress = path.join(featurePath, "开发进展.md");
    if (await exists(progress)) {
      for (const line of (await readFile(progress, "utf8")).split("\n")) {
        if (!line.startsWith("|") || /^\|\s*-+/.test(line) || line.includes("特性名称")) continue;
        const status = line
          .split("|")
          .map((cell) => cell.trim())
          .at(-2);
        if (status && !STATUS.includes(status))
          errors.push(`${feature}: 非法状态「${status}」（应为 ${STATUS.join("/")}）`);
      }
    }
    for (const sub of await readdir(featurePath, { withFileTypes: true })) {
      if (!sub.isDirectory()) continue;
      if (!NAME.test(sub.name)) errors.push(`${project}/feature/${feature}/${sub.name}: 子特性命名不合规`);
      for (const doc of REQUIRED_DOCS) {
        if (!(await exists(path.join(featurePath, sub.name, doc)))) errors.push(`${feature}/${sub.name}: 缺少 ${doc}`);
      }
      for (const deeper of await readdir(path.join(featurePath, sub.name), { withFileTypes: true })) {
        if (deeper.isDirectory() && NAME.test(deeper.name))
          errors.push(`${feature}/${sub.name}/${deeper.name}: 特性最多两级`);
      }
    }
    // 提交约定：主特性完成后要有拼好的《特性文档.md》，且它必须已提交到 code 仓库。
    const combined = path.join(featurePath, "特性文档.md");
    const docsDir = path.join(dir, "code", "docs");
    const docsFile = path.join(docsDir, `${feature}-特性文档.md`);
    const adopted = await (async () => {
      if (!(await exists(progress))) return false;
      return (await readFile(progress, "utf8")).split("\n").some(
        (line) =>
          line.startsWith("|") &&
          line
            .split("|")
            .map((cell) => cell.trim())
            .at(-2) === "已采纳",
      );
    })();
    if (feature !== finalizing && (await exists(combined))) {
      if (!(await exists(docsFile)))
        errors.push(`${project}/${feature}: code/docs 缺少 ${feature}-特性文档.md（未执行 finalize-feature）`);
      else if (!(await isGitCommitted(code, `docs/${feature}-特性文档.md`)))
        (development ? pending : errors).push(`${project}/${feature}: code/docs/${feature}-特性文档.md 未提交到 code 仓库`);
    } else if (feature !== finalizing && adopted) {
      warnings.push(`${project}/${feature}: 已有「已采纳」条目但未生成《特性文档.md》，请执行 finalize-feature`);
    }
    const tests = path.join(dir, "test", feature);
    if (await exists(tests)) {
      if (!(await exists(path.join(tests, "README.md")))) warnings.push(`${project}/test/${feature}: 缺少 README.md`);
      for (const experiment of await readdir(tests, { withFileTypes: true })) {
        if (experiment.isDirectory() && !(await exists(path.join(tests, experiment.name, "README.md"))))
          warnings.push(`${project}/test/${feature}/${experiment.name}: 缺少 README.md`);
      }
    }
  }
  return { project, errors, warnings, pending };
}

async function isGitCommitted(repo, relative) {
  try {
    execFileSync("git", ["cat-file", "-e", `HEAD:${relative}`], { cwd: repo, stdio: "pipe", windowsHide: true });
    return true;
  } catch {
    return false;
  }
}

function gitChanges(repo) {
  const output = execFileSync("git", ["status", "--porcelain=v1", "-z", "--no-renames", "--untracked-files=all"], {
    cwd: repo,
    encoding: "utf8",
    stdio: "pipe",
    windowsHide: true,
  });
  const modified = [];
  const untracked = [];
  const unstaged = [];
  const conflicts = [];
  for (const entry of output.split("\0")) {
    if (!entry) continue;
    const status = entry.slice(0, 2);
    const pathname = entry.slice(3);
    if (status === "??") untracked.push(pathname);
    else if (status.includes("U") || status === "AA" || status === "DD") conflicts.push(pathname);
    else {
      modified.push(pathname);
      if (status[1] !== " ") unstaged.push(pathname);
    }
  }
  return { modified, untracked, unstaged, conflicts };
}

/** Entries a project work directory may contain at its top level. Anything else is clutter. */
const WORK_ALLOWED = new Set(["README.md", "code", "test", "feature"]);

async function checkWorkRoot(root, project, options) {
  const errors = [];
  const warnings = [];
  let entries = [];
  try {
    entries = await readdir(root, { withFileTypes: true });
  } catch {
    return { root, projects: [], errors: [`工作目录不存在或不可读: ${root}`], warnings, pending: [] };
  }
  const strays = [];
  for (const entry of entries) {
    if (entry.name.startsWith(".")) continue;
    if (WORK_ALLOWED.has(entry.name)) continue;
    if (entry.isDirectory() && NAME.test(entry.name)) continue;
    strays.push(entry.name + (entry.isDirectory() ? "/" : ""));
  }
  strays.sort();
  if (strays.length)
    errors.push(
      `${root}: 顶层出现规范外条目 ${strays.join("、")}；工作区只允许 README.md、code/、test/、feature/ 与「两位编号-名称/」，其余内容应归入对应项目的 feature/ 或 test/`,
    );
  const projects = project
    ? [project]
    : entries.filter((entry) => entry.isDirectory() && NAME.test(entry.name)).map((entry) => entry.name);
  const results = [];
  for (const name of projects) results.push(await checkProject(name, root, options));
  return {
    root,
    projects: results,
    errors: [...errors, ...results.flatMap((result) => result.errors)],
    warnings: [...warnings, ...results.flatMap((result) => result.warnings)],
    pending: results.flatMap((result) => result.pending),
  };
}

/**
 * Every agent workspace under `<repo>/agents/<id>/work` is checked when the command runs from the
 * repository root; otherwise the current directory (or `--work`) is a single workspace. The old
 * behaviour only looked at the current directory, so running it from the repo root reported "ok"
 * for an empty, unrelated path and hid stray folders such as `work/out/`.
 */
/**
 * 一个 agent 只应检查自己的工作区：从当前目录向上找到 `agents/<id>/work`。
 * 只有显式加 `--all`（供人/管理员排查）才会扫描全部 agent，避免越界与无谓耗时。
 */
async function ownWorkRoot() {
  let dir = path.resolve(process.cwd());
  for (;;) {
    if (path.basename(dir) === "work" && path.basename(path.dirname(path.dirname(dir))) === "agents") return dir;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

async function checkAll(project) {
  const roots = [];
  const development = args.includes("--development");
  if (args.includes("--all")) {
    const repo = path.resolve(flag("work", process.cwd()));
    for (const entry of await readdir(path.join(repo, "agents"), { withFileTypes: true }).catch(() => [])) {
      if (!entry.isDirectory()) continue;
      const root = path.join(repo, "agents", entry.name, "work");
      if (await exists(root)) roots.push(root);
    }
    if (!roots.length) throw Error(`未找到任何 agent 工作区: ${repo}/agents/*/work`);
  } else {
    const own = await ownWorkRoot();
    const root = own ?? (flag("work") ? workRoot : null);
    if (!root)
      throw Error(
        "请在自身工作区（agents/<id>/work）内运行 check；如需指定路径用 --work <目录>；管理员排查全部工作区用 --all",
      );
    roots.push(root);
  }
  const results = [];
  for (const root of roots) results.push(await checkWorkRoot(root, project, { development }));
  const errors = results.flatMap((result) => result.errors);
  const warnings = results.flatMap((result) => result.warnings);
  return {
    ok: errors.length === 0,
    mode: development ? "development" : "strict",
    checked: results.map((result) => result.root),
    projects: results.flatMap((result) => result.projects),
    errors,
    warnings,
    pending: results.flatMap((result) => result.pending),
  };
}

async function readFeatureDocument(dir, doc, minimumLevel) {
  const file = path.join(dir, doc);
  const source = await readFile(file, "utf8").catch((error) => {
    if (error.code === "ENOENT") throw Error(`缺少 ${path.basename(dir)}/${doc}`);
    throw error;
  });
  const lines = source.replace(/^\uFEFF/, "").split(/\r?\n/);
  const hasTemplateTitle = lines[0]?.trimEnd() === `# ${path.basename(doc, ".md")} · ${path.basename(dir)}`;
  if (hasTemplateTitle) lines.shift();
  const offset = minimumLevel - (hasTemplateTitle ? 2 : 1);
  let fence = null;
  return lines
    .map((line) => {
      const delimiter = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
      if (fence) {
        if (delimiter && delimiter[1][0] === fence[0] && delimiter[1].length >= fence.length && !delimiter[2].trim())
          fence = null;
        return line;
      }
      if (delimiter) {
        fence = delimiter[1];
        return line;
      }
      return line.replace(/^( {0,3})(#{1,6})(?=[ \t]|$)/, (match, indent, heading) => {
        const level = Math.min(6, Math.max(minimumLevel, heading.length + offset));
        return indent + "#".repeat(level);
      });
    })
    .join("\n")
    .trim();
}

async function finalizeFeature(project, feature, { toggleReviewed }) {
  const dir = featureDir(project, feature);
  if (!(await exists(dir))) throw Error(`特性不存在: ${project}/${feature}`);
  const preflight = await checkWorkRoot(workRoot, project, { development: !toggleReviewed, finalizing: feature });
  if (preflight.errors.length) throw Error(preflight.errors.join("；"));
  const subfeatures = (await readdir(dir, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory() && NAME.test(entry.name))
    .map((entry) => entry.name)
    .sort();
  const chapters = [
    ["设计文档.md", "一、设计文档"],
    ["实现文档.md", "二、实现文档"],
    ["测试文档.md", "三、测试文档"],
  ];
  const parts = [];
  for (const [doc, title] of chapters) {
    const sections = [`## ${title}`];
    if (subfeatures.length) {
      if (!(await exists(path.join(dir, doc)))) throw Error(`缺少 ${feature}/${doc}`);
      for (const subfeature of subfeatures) {
        const content = await readFeatureDocument(path.join(dir, subfeature), doc, 4);
        sections.push(`### ${subfeature}`, content);
      }
    } else {
      sections.push(await readFeatureDocument(dir, doc, 3));
    }
    parts.push(sections.join("\n\n"));
  }
  const combined = [
    `# 特性文档 · ${feature}`,
    "",
    `- 项目：${project}`,
    `- 生成时间：${new Date().toISOString()}`,
    "",
    "**目录**",
    "",
    ...chapters.map(([, title], index) => `${index + 1}. [${title}](#${title.replace("、", "")})`),
    "",
    parts.join("\n\n---\n\n"),
    "",
  ].join("\n");
  await writeFile(path.join(dir, "特性文档.md"), combined, { mode: 0o600 });
  const docs = path.join(projectDir(project), "code", "docs");
  await mkdir(docs, { recursive: true });
  const target = path.join(docs, `${feature}-特性文档.md`);
  await writeFile(target, combined, { mode: 0o600 });
  if (!toggleReviewed) {
    return {
      ok: true,
      written: [path.join(dir, "特性文档.md"), target],
      committed: false,
      question:
        "请先与用户确认特性开关和提交范围；只暂存本特性文件，再带 --toggle-reviewed 重新执行。",
      check: await checkProject(project, workRoot, { development: true }),
    };
  }
  const code = path.join(projectDir(project), "code");
  let commit = null;
  if (await exists(path.join(code, ".git"))) {
    execFileSync("git", ["add", "--", `docs/${feature}-特性文档.md`], { cwd: code });
    const message = `feat(${project}): ${feature}`;
    const out = execFileSync(
      "git",
      ["-c", "user.name=web-agent", "-c", "user.email=web-agent@local", "commit", "-m", message],
      { cwd: code, encoding: "utf8" },
    ).trim();
    commit = { message, out };
  }
  const check = await checkProject(project, workRoot);
  return { ok: check.errors.length === 0, written: [path.join(dir, "特性文档.md"), target], committed: Boolean(commit), commit, check };
}

try {
  let result;
  if (command === "new-project") result = await newProject(requireName(flag("name"), "project"));
  else if (command === "new-feature")
    result = await newFeature(requireName(flag("project"), "project"), requireName(flag("name"), "feature"));
  else if (command === "new-subfeature")
    result = await newSubfeature(
      requireName(flag("project"), "project"),
      requireName(flag("feature"), "feature"),
      requireName(flag("name"), "subfeature"),
    );
  else if (command === "new-experiment")
    result = await newExperiment(
      requireName(flag("project"), "project"),
      requireName(flag("feature"), "feature"),
      requireName(flag("name"), "experiment"),
    );
  else if (command === "finalize-feature")
    result = await finalizeFeature(requireName(flag("project"), "project"), requireName(flag("feature"), "feature"), {
      toggleReviewed: args.includes("--toggle-reviewed"),
    });
  else if (command === "check") result = await checkAll(flag("project"));
  else
    throw Error(
      "用法: new-project|new-feature|new-subfeature|new-experiment|finalize-feature|check（参数见 docs/dev-work-layout.md）",
    );
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
  if ((command === "check" || command === "finalize-feature") && !result.ok) process.exitCode = 1;
} catch (error) {
  fail(error.message);
}
