#!/usr/bin/env node
/**
 * Regenerate skills/INDEX.md and the per-category README blocks.
 *
 * Layout: skills/<name>/SKILL.md is a standalone skill; skills/<category>/<name>/SKILL.md is a
 * categorised skill, described by skills/<category>/README.md (this script keeps the skill table
 * between the SKILLS:BEGIN/SKILLS:END markers up to date).
 */
import path from "node:path";
import { lstat, readFile, readdir, writeFile } from "node:fs/promises";

const root = path.resolve(process.argv[2] ?? path.join(import.meta.dirname, "..", ".."));
const base = path.join(root, "skills");
const NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;
const BEGIN = "<!-- SKILLS:BEGIN -->";
const END = "<!-- SKILLS:END -->";

const unquote = (value) => {
  const trimmed = value.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))
    return trimmed.slice(1, -1);
  return trimmed;
};

function parse(text) {
  const data = {};
  const metadata = {};
  if (!text.startsWith("---\n")) return { data, metadata };
  const end = text.indexOf("\n---", 4);
  if (end < 0) return { data, metadata };
  let nested = null;
  for (const line of text.slice(4, end).split(/\r?\n/)) {
    const match = /^\s*([A-Za-z0-9_.-]+)\s*:\s*(.*)$/.exec(line);
    if (!match) continue;
    const [, key, raw] = match;
    if (!/^\s+/.test(line)) {
      nested = null;
      if (key === "metadata") {
        nested = metadata;
        continue;
      }
      data[key] = unquote(raw);
    } else if (nested) nested[key] = unquote(raw);
  }
  return { data, metadata };
}

const isSkill = async (directory) => {
  const info = await lstat(path.join(directory, "SKILL.md")).catch(() => null);
  return Boolean(info?.isFile());
};

const countFiles = async (directory, depth = 0) => {
  if (depth > 4) return 0;
  let total = 0;
  for (const name of await readdir(directory).catch(() => [])) {
    const info = await lstat(path.join(directory, name)).catch(() => null);
    if (!info) continue;
    if (info.isDirectory()) total += await countFiles(path.join(directory, name), depth + 1);
    else if (info.isFile()) total += 1;
  }
  return total;
};

async function describe(directory, relative) {
  const text = await readFile(path.join(base, directory, "SKILL.md"), "utf8").catch(() => null);
  if (text === null) return null;
  const { data, metadata } = parse(text);
  const leaf = path.basename(directory);
  const problems = [];
  if (!NAME.test(leaf)) problems.push("目录名不合规");
  if (!data.name) problems.push("缺少 name");
  else if (data.name !== leaf) problems.push("name 与目录不一致");
  if (!data.description) problems.push("缺少 description");
  return {
    relative,
    name: leaf,
    description: (data.description ?? "").replace(/\|/g, "\\|"),
    version: metadata.version ?? "—",
    owner: metadata.owner ?? "—",
    files: await countFiles(path.join(base, directory)),
    valid: problems.length === 0,
    problems,
  };
}

const entries = [];
const categories = [];
for (const name of (await readdir(base).catch(() => [])).sort()) {
  if (name.startsWith(".") || name === "INDEX.md" || name === "README.md") continue;
  const directory = path.join(base, name);
  const info = await lstat(directory).catch(() => null);
  if (!info?.isDirectory()) continue;
  if (await isSkill(directory)) {
    const skill = await describe(name, name);
    if (skill) entries.push({ ...skill, category: null });
    continue;
  }
  const children = [];
  for (const child of (await readdir(directory).catch(() => [])).sort()) {
    if (child.startsWith(".")) continue;
    const childInfo = await lstat(path.join(directory, child)).catch(() => null);
    if (!childInfo?.isDirectory() || !(await isSkill(path.join(directory, child)))) continue;
    const skill = await describe(path.join(name, child), `${name}/${child}`);
    if (skill) children.push(skill);
  }
  if (children.length) {
    categories.push({ name, skills: children });
    entries.push(...children.map((skill) => ({ ...skill, category: name })));
  }
}

const row = (skill) =>
  `| [${skill.name}](<./${skill.relative}/SKILL.md>) | ${skill.description || "—"} | ${skill.version} | ${skill.owner} | ${skill.files} | ${skill.valid ? "✅" : "⚠️ " + skill.problems.join("；")} |`;
const header = [
  "| 技能 | 用途（description） | 版本 | 作者 | 文件数 | 结构校验 |",
  "| --- | --- | --- | --- | --- | --- |",
];

const lines = [
  "# 公司技能库索引",
  "",
  "按 Anthropic Agent Skills 规范管理：每个技能目录内必须有 `SKILL.md`，顶部 YAML frontmatter 至少包含 `name`（与目录名一致）和 `description`（何时使用）；细则放 `references/`，脚本放 `scripts/`，素材放 `assets/`。",
  "",
  "分类：`skills/<方向>/<技能>/SKILL.md`。方向目录里用 `README.md` 说明这个方向是做什么的，技能清单由本脚本自动维护。",
  "",
  "Agent 读取方式：`office_list_skills` 查看分类与技能，`office_read_skill` 接受 `技能名` 或 `方向/技能名`（只读）。",
  "",
  `重新生成：\`node app/scripts/skills-index.mjs <工作根>\`（本次 ${new Date().toISOString()}）。`,
  "",
];

for (const category of categories) {
  lines.push(`## 方向：${category.name}`, "", ...header, ...category.skills.map(row), "");
}
const flat = entries.filter((skill) => !skill.category);
if (flat.length) lines.push("## 未分类（顶层）", "", ...header, ...flat.map(row), "");
await writeFile(path.join(base, "INDEX.md"), lines.join("\n").replace(/\n{3,}/g, "\n\n"));

for (const category of categories) {
  const file = path.join(base, category.name, "README.md");
  const block = [...header, ...category.skills.map((skill) => row({ ...skill, relative: skill.name }))].join("\n");
  const existing = await readFile(file, "utf8").catch(() => null);
  if (existing === null) {
    const description = category.name;
    await writeFile(
      file,
      [
        "---",
        `name: ${category.name}`,
        `description: ${description} 方向的公司技能集合；在这里说明这个方向负责什么、何时使用其中的技能。`,
        "metadata:",
        "  owner: 待补充",
        "---",
        "",
        `# ${category.name}`,
        "",
        "## 这个方向是做什么的",
        "",
        "<!-- 在这里写 2-4 句：这个方向解决什么问题、边界是什么、什么时候应该用这里的技能。 -->",
        "",
        "## 技能清单",
        "",
        BEGIN,
        block,
        END,
        "",
      ].join("\n"),
    );
    continue;
  }
  if (existing.includes(BEGIN) && existing.includes(END)) {
    const updated = existing.replace(new RegExp(`${BEGIN}[\\s\\S]*?${END}`), `${BEGIN}\n${block}\n${END}`);
    await writeFile(file, updated);
  } else {
    await writeFile(file, `${existing.trimEnd()}\n\n## 技能清单\n\n${BEGIN}\n${block}\n${END}\n`);
  }
}

console.log(`indexed ${entries.length} skill(s) in ${categories.length} category(ies)`);
