#!/usr/bin/env node
import path from "node:path";
import { readFile, readdir, lstat, mkdir, writeFile, realpath } from "node:fs/promises";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { packArchive } from "./lib/archive.mjs";
export async function packageOfficeRelease({ workspaceRoot, id, frontendDir, hotModules = {}, output }) {
  const root = await realpath(workspaceRoot);
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(id) || id === "builtin-v1") throw Error("invalid_release_id");
  const dest = path.resolve(output ?? path.join(root, "artifacts", `${id}.tar.gz`));
  if (!dest.startsWith(root + path.sep)) throw Error("output_must_be_inside_workspace");
  const files = new Map();
  const walk = async (dir, prefix) => {
    for (const e of await readdir(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name),
        relative = `${prefix}/${e.name}`;
      if (e.isSymbolicLink()) throw Error("release_symlink_not_allowed");
      if (e.isDirectory()) await walk(full, relative);
      else if (e.isFile()) files.set(relative, await readFile(full));
      else throw Error("invalid_release_file");
    }
  };
  if (frontendDir) {
    if ((await lstat(frontendDir)).isSymbolicLink()) throw Error("release_symlink_not_allowed");
    await walk(frontendDir, "frontend");
    for (const name of ["chat.html", "office.html"])
      if (!files.has(`frontend/${name}`)) throw Error("both_frontend_entries_required");
  }
  for (const [name, file] of Object.entries(hotModules)) {
    if (!["agent-summary", "role-prompts"].includes(name) || (await lstat(file)).isSymbolicLink())
      throw Error("invalid_hot_module");
    files.set(`hot/${name}.mjs`, await readFile(file));
  }
  if (files.size === 0) throw Error("empty_release");
  const manifest = {
    id,
    runtimeAbi: 1,
    schemaVersion: 1,
    kind: frontendDir ? (Object.keys(hotModules).length ? "combined" : "frontend") : "hot-modules",
    hotModules: Object.keys(hotModules),
    files: Object.fromEntries(
      [...files].map(([name, data]) => [name, createHash("sha256").update(data).digest("hex")]),
    ),
  };
  files.set("manifest.json", Buffer.from(JSON.stringify(manifest, null, 2) + "\n"));
  await mkdir(path.dirname(dest), { recursive: true });
  if ((await realpath(path.dirname(dest))) !== path.dirname(dest)) throw Error("output_symlink_not_allowed");
  await writeFile(dest, packArchive(files), { flag: "wx", mode: 0o600 });
  return manifest;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const options = {};
    for (let i = 2; i < process.argv.length; i += 2) {
      const key = process.argv[i]?.replace(/^--/, "");
      if (
        !["root", "id", "frontend", "agent-summary", "role-prompts", "out"].includes(key) ||
        !process.argv[i + 1] ||
        key in options
      )
        throw Error("invalid_options");
      options[key] = process.argv[i + 1];
    }
    if (!options.root || !options.id) throw Error("--root and --id are required");
    const hotModules = {};
    for (const name of ["agent-summary", "role-prompts"]) if (options[name]) hotModules[name] = options[name];
    const result = await packageOfficeRelease({
      workspaceRoot: options.root,
      id: options.id,
      frontendDir: options.frontend,
      hotModules,
      output: options.out,
    });
    process.stdout.write(JSON.stringify(result, null, 2) + "\n");
  } catch (error) {
    process.stderr.write(error.message + "\n");
    process.exitCode = 1;
  }
}
