#!/usr/bin/env node
/**
 * One-shot migration of per-agent storage to agents/<id>/{profile,sessions,work,cache}.
 * Idempotent, journaled and reversible; refuses to run while the office is running.
 */
import path from "node:path";
import { constants } from "node:fs";
import { access, lstat, mkdir, readFile, readdir, rename, writeFile } from "node:fs/promises";
import { repairCodexPaths } from "./office-repair-codex-paths.mjs";

const args = process.argv.slice(2);
const option = (name, fallback) => {
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : fallback;
};
const root = path.resolve(option("--root", process.cwd()));
const mode = option("--mode", "apply");
if (!["plan", "apply", "rollback"].includes(mode)) throw Error("invalid_mode");
const JOURNAL = path.join(root, "state", "layout-migration.json");
const VERSION = path.join(root, "state", "layout-version.json");
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const exists = async (target) => {
  try {
    await lstat(target);
    return true;
  } catch {
    return false;
  }
};

async function listDirs(target) {
  try {
    const entries = await readdir(target, { withFileTypes: true });
    return entries.filter((entry) => entry.isDirectory()).map((entry) => entry.name);
  } catch {
    return [];
  }
}

async function agentIds() {
  const ids = new Set();
  const AGENT = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/;
  for (const name of await listDirs(path.join(root, "agents"))) if (AGENT.test(name)) ids.add(name);
  for (const base of ["state/claude", "state/codex", "cache/agents"]) for (const name of await listDirs(path.join(root, base))) ids.add(name);
  for (const name of await listDirs(path.join(root, "projects"))) if (UUID.test(name) || name === "office-boss") ids.add(name);
  return [...ids].sort();
}

const movesFor = (id) => [
  [path.join("agents", id, "resume.md"), path.join("agents", id, "profile", "resume.md")],
  [path.join("agents", id, "attachments"), path.join("agents", id, "profile", "attachments")],
  [path.join("agents", id, ".home"), path.join("agents", id, "profile", "tool-home", "home")],
  [path.join("agents", id, ".config"), path.join("agents", id, "profile", "tool-home", "config")],
  [path.join("agents", id, ".state"), path.join("agents", id, "profile", "tool-home", "state")],
  [path.join("agents", id, ".data"), path.join("agents", id, "profile", "tool-home", "data")],
  [path.join("state", "claude", id), path.join("agents", id, "sessions", "claude")],
  [path.join("state", "codex", id), path.join("agents", id, "sessions", "codex")],
  [path.join("projects", id), path.join("agents", id, "work")],
  [path.join("cache", "agents", id), path.join("agents", id, "cache")],
];

async function assertStopped() {
  try {
    const runtime = JSON.parse(await readFile(path.join(root, "state", "runtime.json"), "utf8"));
    process.kill(Number(runtime.pid), 0);
    throw Error("office_running_stop_it_first");
  } catch (error) {
    if (error?.code !== "ENOENT" && error?.code !== "ESRCH") throw error;
  }
}

async function plan() {
  const items = [];
  for (const id of await agentIds()) {
    for (const [from, to] of movesFor(id)) {
      if (!(await exists(path.join(root, from)))) continue;
      items.push({ agentId: id, from, to });
    }
  }
  return items;
}

async function apply() {
  await assertStopped();
  if (await exists(VERSION)) {
    const current = JSON.parse(await readFile(VERSION, "utf8"));
    if (current.version === 2) return { ok: true, already: true, moved: 0 };
  }
  const items = await plan();
  const journal = { version: 1, startedAt: new Date().toISOString(), done: false, moves: [] };
  await writeFile(JOURNAL, JSON.stringify(journal, null, 2) + "\n", { mode: 0o600 });
  let moved = 0;
  for (const item of items) {
    const source = path.join(root, item.from);
    const target = path.join(root, item.to);
    if (await exists(target)) throw Error(`layout_migration_conflict:${item.to}`);
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
    await rename(source, target);
    journal.moves.push({ ...item, at: new Date().toISOString() });
    await writeFile(JOURNAL, JSON.stringify(journal, null, 2) + "\n", { mode: 0o600 });
    moved += 1;
  }
  for (const id of await agentIds()) {
    const readme = path.join(root, "agents", id, "README.md");
    if (await exists(readme)) continue;
    await mkdir(path.dirname(readme), { recursive: true, mode: 0o700 }).catch(() => {});
    await writeFile(
      readme,
      [
        `# ${id}`,
        "",
        "| 目录 | 用途 |",
        "| --- | --- |",
        "| `profile/` | 身份资料：resume.md、memory.md、附件、工具 HOME |",
        "| `sessions/` | 原生会话（Claude / Codex），agent 不可写 |",
        "| `work/` | 工作区与产出（可下载） |",
        "| `cache/` | 工具缓存，可随时删除 |",
        "",
      ].join("\n"),
      { mode: 0o600 },
    ).catch(() => {});
  }
  // Codex keeps absolute rollout paths in its SQLite state; rewrite them to the new home.
  const repaired = await repairCodexPaths(root, { log: () => {} });
  journal.codexPathsRepaired = repaired.updates;
  journal.done = true;
  await writeFile(JOURNAL, JSON.stringify(journal, null, 2) + "\n", { mode: 0o600 });
  await writeFile(VERSION, JSON.stringify({ version: 2, updatedAt: new Date().toISOString() }, null, 2) + "\n", {
    mode: 0o600,
  });
  return { ok: true, moved, journal: JOURNAL };
}

async function rollback() {
  await assertStopped();
  const journal = JSON.parse(await readFile(JOURNAL, "utf8"));
  let moved = 0;
  for (const item of [...journal.moves].reverse()) {
    const source = path.join(root, item.to);
    const target = path.join(root, item.from);
    if (!(await exists(source))) continue;
    if (await exists(target)) throw Error(`layout_rollback_conflict:${item.from}`);
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
    await rename(source, target);
    moved += 1;
  }
  journal.done = true;
  journal.rolledBack = true;
  journal.rolledBackAt = new Date().toISOString();
  await writeFile(JOURNAL, JSON.stringify(journal, null, 2) + "\n", { mode: 0o600 });
  await writeFile(VERSION, JSON.stringify({ version: 1, updatedAt: new Date().toISOString(), rolledBack: true }, null, 2) + "\n", {
    mode: 0o600,
  });
  return { ok: true, moved };
}

try {
  if (mode === "plan") {
    const items = await plan();
    process.stdout.write(JSON.stringify({ ok: true, mode, moves: items, count: items.length }, null, 2) + "\n");
  } else if (mode === "rollback") {
    process.stdout.write(JSON.stringify(await rollback(), null, 2) + "\n");
  } else {
    process.stdout.write(JSON.stringify(await apply(), null, 2) + "\n");
  }
} catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
}
