#!/usr/bin/env node
/**
 * Point-in-time snapshot of the office: conversations (SQLite + native CLI transcripts),
 * agent handoff notes, workspace outputs and the shared skills library. Backups live under
 * artifacts/backups and never include credentials (API keys only exist in memory).
 */
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { lstat, mkdir, open, readdir, readFile, realpath, rm, unlink, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { packArchive } from "./lib/archive.mjs";

const MAX_FILE_BYTES = 50 * 1024 * 1024;
const MAX_TOTAL_BYTES = 200 * 1024 * 1024;
// Large repositories/outputs must not crowd out conversations and skills (and the
// archive packer refuses payloads over 256MB).
const MAX_PROJECT_BYTES = 40 * 1024 * 1024;
const MAX_SKIPPED_ENTRIES = 500;
const LOCK_STALE_MS = 30 * 60 * 1000;

const SKIP_DIRECTORIES = new Set(["node_modules", ".git", ".venv", "__pycache__", ".next", "dist", "build", ".cache"]);
const SKIP_FILES = new Set(["office-source.tar.gz"]);

const sha256 = (data) => createHash("sha256").update(data).digest("hex");

async function insideRoot(root, target) {
  const real = await realpath(target);
  const relative = path.relative(root, real);
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) throw Error("backup_path_outside_workspace");
  return real;
}

function note(skipped, path, reason, bytes) {
  if (skipped.length < MAX_SKIPPED_ENTRIES) skipped.push({ path, reason, bytes });
  else if (skipped.length === MAX_SKIPPED_ENTRIES) skipped.push({ path: "…", reason: "more_skipped_entries_omitted" });
}

async function walk(root, relative, files, skipped, state) {
  if (state.bytes > MAX_TOTAL_BYTES) {
    skipped.push({ path: relative, reason: "total_size_limit" });
    return;
  }
  const absolute = path.join(root, relative);
  let info;
  try {
    info = await lstat(absolute);
  } catch (error) {
    if (error.code === "ENOENT") return;
    throw error;
  }
  if (info.isSymbolicLink()) {
    skipped.push({ path: relative, reason: "symlink" });
    return;
  }
  // ustar 单条目上限：文件名 ≤100 字节、前缀 ≤155 字节、总计 ≤255。
  if (
    Buffer.byteLength(path.basename(relative)) > 100 ||
    Buffer.byteLength(path.dirname(relative)) > 155 ||
    Buffer.byteLength(relative) > 255
  ) {
    note(skipped, relative, "path_too_long", info.isFile() ? info.size : 0);
    return;
  }
  if (info.isDirectory()) {
    if (SKIP_DIRECTORIES.has(path.basename(relative)) || relative.split(path.sep).join("/") === "projects/.worktrees") {
      skipped.push({ path: relative, reason: "excluded_directory" });
      return;
    }
    // Per-agent layout: cache is disposable and Claude sessions need path flattening.
    if (/^agents[\\/][^\\/]+[\\/](cache|sessions)$/.test(relative)) {
      skipped.push({ path: relative, reason: "handled_separately" });
      return;
    }
    for (const name of (await readdir(absolute)).sort())
      await walk(root, path.join(relative, name), files, skipped, state);
    return;
  }
  if (!info.isFile()) return;
  if (SKIP_FILES.has(path.basename(relative))) {
    skipped.push({ path: relative, reason: "generated_archive" });
    return;
  }
  if (info.size > MAX_FILE_BYTES) {
    skipped.push({ path: relative, reason: "file_too_large", bytes: info.size });
    return;
  }
  const inProjects = relative.split(path.sep)[0] === "projects";
  if (inProjects && state.projectBytes + info.size > MAX_PROJECT_BYTES) {
    note(skipped, relative, "projects_budget", info.size);
    return;
  }
  if (state.bytes + info.size > MAX_TOTAL_BYTES) {
    note(skipped, relative, "total_size_limit", info.size);
    return;
  }
  const data = await readFile(await insideRoot(root, absolute));
  state.bytes += data.length;
  if (inProjects) state.projectBytes += data.length;
  files.set(relative.split(path.sep).join("/"), data);
}

/**
 * Claude session directories encode the whole workspace path, which exceeds the tar name
 * limits. Store them flat as sessions/claude/<agent>/<file> and keep the original path in
 * the manifest so a restore can put them back where the CLI expects them.
 */
async function walkClaudeSessions(root, agent, files, skipped, state, restorePaths, projectsRelative, archivePrefix) {
  const base = path.join(root, projectsRelative ?? path.join("state", "claude", agent, "projects"));
  const prefix = archivePrefix ?? `sessions/claude/${agent}`;
  const restoreRoot = projectsRelative ?? path.join("state", "claude", agent, "projects");
  let projects = [];
  try {
    projects = await readdir(base);
  } catch {
    return;
  }
  for (const project of projects) {
    const directory = path.join(base, project);
    let names = [];
    try {
      names = await readdir(directory);
    } catch {
      continue;
    }
    for (const name of names) {
      const source = path.join(directory, name);
      let info;
      try {
        info = await lstat(source);
      } catch {
        continue;
      }
      if (info.isDirectory()) {
        // Per-session folders (e.g. <threadId>/tool-results) hold outputs the transcript refers to.
        const archivedBase = `sessions/claude/${agent}/${name}`;
        const restoreBase = `state/claude/${agent}/projects/${project}/${name}`;
        const collect = async (directoryPath, suffix, depth) => {
          if (depth > 4) return;
          let inner = [];
          try {
            inner = await readdir(directoryPath);
          } catch {
            return;
          }
          for (const child of inner) {
            const childPath = path.join(directoryPath, child);
            const childSuffix = suffix ? `${suffix}/${child}` : child;
            let childInfo;
            try {
              childInfo = await lstat(childPath);
            } catch {
              continue;
            }
            if (childInfo.isDirectory()) {
              await collect(childPath, childSuffix, depth + 1);
              continue;
            }
            if (!childInfo.isFile() || childInfo.size > MAX_FILE_BYTES) {
              skipped.push({ path: `${restoreBase}/${childSuffix}`, reason: "file_too_large" });
              continue;
            }
            if (state.bytes + childInfo.size > MAX_TOTAL_BYTES) {
              skipped.push({ path: `${restoreBase}/${childSuffix}`, reason: "total_size_limit" });
              continue;
            }
            const data = await readFile(childPath);
            const archived = `${archivedBase}/${childSuffix}`;
            files.set(archived, data);
            restorePaths.set(archived, `${restoreBase}/${childSuffix}`);
            state.bytes += data.length;
          }
        };
        await collect(directory, "", 0);
        continue;
      }
      if (!info.isFile() || info.size > MAX_FILE_BYTES) {
        skipped.push({
          path: `state/claude/${agent}/projects/${project}/${name}`,
          reason: info.isFile() ? "file_too_large" : "not_a_file",
        });
        continue;
      }
      if (state.bytes + info.size > MAX_TOTAL_BYTES) {
        skipped.push({ path: `state/claude/${agent}/projects/${project}/${name}`, reason: "total_size_limit" });
        continue;
      }
      const data = await readFile(source);
      const archived = `${prefix}/${name}`;
      files.set(archived, data);
      restorePaths.set(archived, `${restoreRoot}/${project}/${name}`);
      state.bytes += data.length;
    }
  }
}

async function sqliteSnapshot(source, destination) {
  const db = new DatabaseSync(source);
  try {
    db.exec(`VACUUM INTO '${destination.replace(/'/g, "''")}'`);
  } finally {
    db.close();
  }
}

async function acquireLock(directory) {
  const lock = path.join(directory, ".backup.lock");
  try {
    const handle = await open(
      lock,
      constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
      0o600,
    );
    await handle.writeFile(JSON.stringify({ pid: process.pid, at: Date.now() }));
    await handle.close();
    return lock;
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    let stale = false;
    try {
      const info = JSON.parse(await readFile(lock, "utf8"));
      const alive = (() => {
        try {
          process.kill(Number(info.pid), 0);
          return true;
        } catch {
          return false;
        }
      })();
      stale = !alive || Date.now() - Number(info.at || 0) > LOCK_STALE_MS;
    } catch {
      stale = true;
    }
    if (!stale) throw Error("backup_already_running");
    await unlink(lock).catch(() => {});
    return acquireLock(directory);
  }
}

export async function createOfficeBackup({ root, keep = 7, reason = "manual" } = {}) {
  const workspaceRoot = await realpath(path.resolve(root ?? process.cwd()));
  const config = JSON.parse(await readFile(path.join(workspaceRoot, "workspace.json"), "utf8"));
  if (config.workspaceRoot !== workspaceRoot) throw Error("workspace_root_mismatch");
  const backups = path.join(workspaceRoot, "artifacts", "backups");
  await mkdir(backups, { recursive: true });
  const lock = await acquireLock(backups);
  const scratch = path.join(backups, `.tmp-${randomUUID()}`);
  try {
    await mkdir(scratch, { recursive: true });
    const files = new Map();
    const skipped = [];
    const state = { bytes: 0, projectBytes: 0 };
    for (const name of ["office", "web-sessions", "conversation-context"]) {
      const source = path.join(workspaceRoot, "state", `${name}.sqlite`);
      try {
        await lstat(source);
      } catch {
        continue;
      }
      const snapshot = path.join(scratch, `${name}.sqlite`);
      await sqliteSnapshot(source, snapshot);
      files.set(`sqlite/${name}.sqlite`, await readFile(snapshot));
      state.bytes += files.get(`sqlite/${name}.sqlite`).length;
    }
    for (const relative of ["agents", "projects", "skills", "versions"])
      await walk(workspaceRoot, relative, files, skipped, state);
    const restorePaths = new Map();
    let claudeAgents = [];
    try {
      claudeAgents = await readdir(path.join(workspaceRoot, "state", "claude"));
    } catch {
      claudeAgents = [];
    }
    for (const agent of claudeAgents)
      await walkClaudeSessions(workspaceRoot, agent, files, skipped, state, restorePaths);
    let codexAgents = [];
    try {
      codexAgents = await readdir(path.join(workspaceRoot, "state", "codex"));
    } catch {
      codexAgents = [];
    }
    for (const agent of codexAgents)
      await walk(workspaceRoot, path.join("state", "codex", agent, "sessions"), files, skipped, state);
    try {
      const configBytes = await readFile(path.join(workspaceRoot, "workspace.json"));
      files.set("workspace.json", configBytes);
      state.bytes += configBytes.length;
    } catch {
      skipped.push({ path: "workspace.json", reason: "missing" });
    }
    const createdAt = new Date().toISOString();
    const manifest = {
      formatVersion: 1,
      kind: "office-backup",
      createdAt,
      reason,
      workspaceRoot,
      officeVersion: config.officeVersion ?? null,
      nodeVersion: process.version,
      files: [...files].map(([name, data]) => ({
        path: name,
        bytes: data.length,
        sha256: sha256(data),
        ...(restorePaths.has(name) ? { restorePath: restorePaths.get(name) } : {}),
      })),
      skipped,
      totals: { entries: files.size, bytes: [...files.values()].reduce((sum, data) => sum + data.length, 0) },
    };
    files.set("backup-manifest.json", Buffer.from(JSON.stringify(manifest, null, 2) + "\n"));
    files.set(
      "README-restore.txt",
      Buffer.from(
        [
          "恢复方法：",
          "1) 停止网页服务：node scripts/office.mjs stop --root <工作根>",
          "2) 备份当前目录后，解包并用 sqlite/*.sqlite 覆盖 state/ 下同名文件；把 agents/、projects/、skills/、versions/ 覆盖回工作根",
          "3) 原生会话文件在 state/claude/<agent>/projects/、state/codex/<agent>/sessions/，按原路径覆盖",
          "4) 启动：node scripts/office.mjs start --root <工作根>",
          "",
          "说明：备份不含 API Key/OAuth（只存在服务内存里），也不含 cache/、工具二进制和运行日志。",
          "",
        ].join("\n"),
      ),
    );
    const archive = packArchive(files);
    const stamp = createdAt.replace(/[-:]/g, "").replace(/\..*$/, "").replace("T", "-");
    const name = `office-backup-${stamp}-${reason}-${randomUUID().slice(0, 8)}.tar.gz`;
    const destination = path.join(backups, name);
    const handle = await open(
      destination,
      constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
      0o600,
    );
    try {
      await handle.writeFile(archive);
      await handle.sync();
    } finally {
      await handle.close();
    }
    const digest = sha256(archive);
    await writeFile(`${destination}.sha256`, `${digest}  ${name}\n`, { mode: 0o600 });
    const result = {
      ok: true,
      file: destination,
      name,
      bytes: archive.length,
      sha256: digest,
      createdAt,
      reason,
      entries: files.size,
      skipped: skipped.length,
      keep,
    };
    await writeFile(path.join(backups, "latest.json"), JSON.stringify(result, null, 2) + "\n", { mode: 0o600 });
    const retention = await pruneBackups(backups, keep, name);
    return { ...result, removed: retention.removed };
  } finally {
    await rm(scratch, { recursive: true, force: true });
    await unlink(lock).catch(() => {});
  }
}

export async function pruneBackups(directory, keep, preserve) {
  const names = (await readdir(directory)).filter((name) => /^office-backup-.*\.tar\.gz$/.test(name));
  const stamped = [];
  for (const name of names) {
    try {
      stamped.push({ name, mtime: (await lstat(path.join(directory, name))).mtimeMs });
    } catch {
      /* vanished concurrently */
    }
  }
  stamped.sort((a, b) => b.mtime - a.mtime);
  const removed = [];
  for (const { name } of stamped.slice(Math.max(1, keep))) {
    if (name === preserve) continue;
    await rm(path.join(directory, name), { force: true });
    await rm(path.join(directory, `${name}.sha256`), { force: true });
    removed.push(name);
  }
  return { removed };
}

export async function lastBackupInfo(root) {
  try {
    const info = JSON.parse(await readFile(path.join(root, "artifacts", "backups", "latest.json"), "utf8"));
    return { at: info.createdAt ?? null, ok: info.ok === true, bytes: info.bytes ?? 0 };
  } catch {
    return { at: null, ok: false, bytes: 0 };
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const args = process.argv.slice(2);
  const option = (name) => {
    const index = args.indexOf(name);
    return index >= 0 ? args[index + 1] : undefined;
  };
  try {
    const result = await createOfficeBackup({
      root: option("--root") ?? process.cwd(),
      keep: Number(option("--keep") ?? 7),
      reason: option("--reason") ?? "manual",
    });
    // Rename is unnecessary: the archive is already written atomically under a unique name.
    process.stdout.write(JSON.stringify(result, null, 2) + "\n");
  } catch (error) {
    process.stderr.write(`${error.message}\n`);
    process.exitCode = 1;
  }
}
