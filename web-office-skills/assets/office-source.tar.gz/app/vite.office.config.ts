import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

// Audit actual Rollup module membership, including every transitive import.
const entryIsolationAudit: Plugin = {
  name: "office-entry-isolation-audit",
  generateBundle(_options, bundle) {
    const dependencies = (entry: string) => {
      const visited = new Set<string>();
      const modules = new Set<string>();
      const visit = (name: string) => {
        if (visited.has(name)) return;
        visited.add(name);
        const chunk = bundle[name];
        if (chunk?.type !== "chunk") return;
        Object.keys(chunk.modules).forEach((id) => modules.add(id.replace(process.cwd() + "/", "")));
        chunk.imports.forEach(visit);
        chunk.dynamicImports.forEach(visit);
      };
      visit(entry);
      return { chunks: [...visited], modules: [...modules].sort() };
    };
    const entries: Record<string, ReturnType<typeof dependencies>> = {};
    for (const chunk of Object.values(bundle)) {
      if (chunk.type === "chunk" && chunk.isEntry) entries[chunk.name] = dependencies(chunk.fileName);
    }
    const forbidden = entries.chat?.modules.filter((id) =>
      /pixi|OfficeCanvas|components\/office-view|src\/App\.tsx/.test(id),
    );
    if (forbidden?.length) this.error("Chat entry contains office rendering modules: " + forbidden.join(", "));
    this.emitFile({ type: "asset", fileName: "entry-isolation-audit.json", source: JSON.stringify(entries, null, 2) });
  },
};
export default defineConfig({
  plugins: [react(), entryIsolationAudit],
  build: {
    outDir: "dist-office",
    manifest: true,
    rollupOptions: {
      input: { chat: resolve(process.cwd(), "chat.html"), office: resolve(process.cwd(), "office.html") },
      // Let Rollup split the two entry graphs naturally. A manual Pixi chunk
      // can capture shared CommonJS helpers and make chat import the renderer.
    },
  },
  server: {
    host: "127.0.0.1",
    proxy: { "/api/office": "http://127.0.0.1:8792", "/ws": { target: "ws://127.0.0.1:8792", ws: true } },
  },
});
