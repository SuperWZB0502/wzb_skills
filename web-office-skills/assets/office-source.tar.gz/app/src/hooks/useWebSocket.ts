import { useCallback, useEffect, useRef, useState } from "react";
import { bootstrapSession } from "../api";
import type { WSEvent, WSEventType } from "../types";

type Listener = (payload: unknown) => void;

/** 重连退避：1s 起，指数增长，封顶 30s，带抖动避免多端同时打服务器。 */
export const RECONNECT_BASE_MS = 1_000;
export const RECONNECT_MAX_MS = 30_000;
/** 连接稳定这么久才把退避计数清零，避免「连上就断」时退避永远回到 1 秒。 */
export const STABLE_RESET_MS = 5_000;
/** 握手迟迟不完成就主动放弃，交给重连逻辑（半开连接不会自己触发 close）。 */
export const CONNECT_TIMEOUT_MS = 10_000;

/** 第 attempt 次重连前的等待毫秒数；抖动区间为计算值的 50%–100%。 */
export function nextReconnectDelay(
  attempt: number,
  random: () => number = Math.random,
): number {
  const safeAttempt = Number.isFinite(attempt) ? Math.max(0, Math.floor(attempt)) : 0;
  const ceiling = Math.min(RECONNECT_MAX_MS, RECONNECT_BASE_MS * 2 ** Math.min(safeAttempt, 8));
  return Math.round(ceiling * (0.5 + random() * 0.5));
}

export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null);
  const listenersRef = useRef<Map<WSEventType, Set<Listener>>>(new Map());
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    const url = `${proto}//${location.host}/ws`;
    let alive = true;
    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    let stableTimer: ReturnType<typeof setTimeout> | undefined;
    let connectTimer: ReturnType<typeof setTimeout> | undefined;
    let attempt = 0;
    let connecting = false;
    let forceSessionBootstrap = false;

    const clearTimer = (timer: ReturnType<typeof setTimeout> | undefined) => {
      if (timer !== undefined) clearTimeout(timer);
      return undefined;
    };
    const clearReconnect = () => {
      reconnectTimer = clearTimer(reconnectTimer);
    };
    const clearStable = () => {
      stableTimer = clearTimer(stableTimer);
    };
    const clearConnectTimeout = () => {
      connectTimer = clearTimer(connectTimer);
    };

    function scheduleReconnect(options: { immediate?: boolean } = {}) {
      if (!alive || connecting) return;
      clearReconnect();
      if (options.immediate) {
        // 用户回到前台 / 网络刚恢复：这是明确信号，不再等退避。
        attempt = 0;
        reconnectTimer = setTimeout(() => void connect(), 0);
        return;
      }
      // 离线时空转没有意义，等 online 事件把我们叫醒。
      if (typeof navigator !== "undefined" && navigator.onLine === false) return;
      const delay = nextReconnectDelay(attempt);
      attempt += 1;
      reconnectTimer = setTimeout(() => void connect(), delay);
    }

    async function connect() {
      if (!alive || connecting) return;
      connecting = true;
      clearReconnect();
      try {
        const forceBootstrap = forceSessionBootstrap;
        const bootstrapped = await bootstrapSession({
          promptOnUnauthorized: false,
          force: forceBootstrap,
        });
        if (!alive) {
          connecting = false;
          return;
        }
        if (!bootstrapped) {
          connecting = false;
          if (forceBootstrap) forceSessionBootstrap = false;
          scheduleReconnect();
          return;
        }
        forceSessionBootstrap = false;
      } catch {
        if (!alive) {
          connecting = false;
          return;
        }
        // Avoid force bootstrap busy-loop when unauthorized recovery itself fails.
        if (forceSessionBootstrap) forceSessionBootstrap = false;
        // ignore bootstrap errors; ws connect result will drive retry
        connecting = false;
        scheduleReconnect();
        return;
      }

      const ws = new WebSocket(url);
      socket = ws;
      wsRef.current = ws;
      clearConnectTimeout();
      connectTimer = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN) ws.close();
      }, CONNECT_TIMEOUT_MS);

      ws.onopen = () => {
        if (!alive) return;
        connecting = false;
        clearConnectTimeout();
        setConnected(true);
        // 稳定一小段时间后再清零退避，否则「一连就断」会一直按 1s 打。
        clearStable();
        stableTimer = setTimeout(() => {
          attempt = 0;
        }, STABLE_RESET_MS);
      };
      ws.onclose = (event) => {
        if (!alive) return;
        connecting = false;
        clearConnectTimeout();
        clearStable();
        setConnected(false);
        if (event.code === 1008) {
          forceSessionBootstrap = true;
        }
        scheduleReconnect();
      };
      ws.onerror = () => ws.close();
      ws.onmessage = (e) => {
        if (!alive) return;
        try {
          const evt: WSEvent = JSON.parse(e.data);
          const listeners = listenersRef.current.get(evt.type);
          if (listeners) {
            for (const fn of listeners) fn(evt.payload);
          }
        } catch {}
      };
    }

    // 回到前台 / 网络恢复 / 窗口获得焦点：立刻探一次，而不是傻等退避定时器。
    const reconnectIfNeeded = () => {
      if (!alive || connecting) return;
      if (socket?.readyState === WebSocket.OPEN) return;
      scheduleReconnect({ immediate: true });
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") reconnectIfNeeded();
    };
    const onOnline = () => reconnectIfNeeded();
    const onFocus = () => reconnectIfNeeded();

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("online", onOnline);
    window.addEventListener("focus", onFocus);

    void connect();

    return () => {
      alive = false;
      clearReconnect();
      clearStable();
      clearConnectTimeout();
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("focus", onFocus);
      socket?.close();
    };
  }, []);

  const on = useCallback((type: WSEventType, fn: Listener) => {
    if (!listenersRef.current.has(type)) {
      listenersRef.current.set(type, new Set());
    }
    listenersRef.current.get(type)!.add(fn);
    return () => {
      listenersRef.current.get(type)?.delete(fn);
    };
  }, []);

  return { connected, on };
}
