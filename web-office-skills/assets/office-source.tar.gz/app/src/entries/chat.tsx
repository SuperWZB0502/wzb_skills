import { createRoot } from "react-dom/client";
import { SessionGate } from "../office/SessionGate";
import { OfficeClientProvider } from "../office/OfficeClientProvider";
import { ChatWorkspace } from "../office/ChatWorkspace";
import "../office/office.css";
createRoot(document.getElementById("root")!).render(
  <SessionGate>
    <OfficeClientProvider>
      <ChatWorkspace mode="chat" />
    </OfficeClientProvider>
  </SessionGate>,
);
