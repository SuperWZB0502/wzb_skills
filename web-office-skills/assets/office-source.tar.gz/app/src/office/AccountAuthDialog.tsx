import { useCallback, useEffect, useRef, useState } from "react";
import type { ProviderAuthFlow, ProviderProfile } from "../../shared/office-contracts";
import { Modal } from "./Modal";
import { officeApi } from "./api";
export function closeBlankAuthWindow(window: Window | null) {
  try {
    if (window && !window.closed && window.location.href === "about:blank") window.close();
  } catch {
    // An already navigated official page belongs to the user.
  }
}
export function openBlankAuthWindow(): Window | null {
  try {
    const popup = window.open("about:blank", "_blank");
    if (popup) popup.opener = null;
    return popup;
  } catch {
    return null;
  }
}
export function AccountAuthDialog({
  provider,
  authWindow = null,
  onAuthenticated,
  onClose,
}: {
  provider: ProviderProfile;
  authWindow?: Window | null;
  onAuthenticated(provider: ProviderProfile): void | Promise<void>;
  onClose(): void;
}) {
  const [flow, setFlow] = useState<ProviderAuthFlow | null>(null),
    [error, setError] = useState("");
  const [pollError, setPollError] = useState("");
  const [code, setCode] = useState(""),
    [busy, setBusy] = useState(false);
  const alive = useRef(true);
  const popup = useRef(authWindow);
  const loginId = flow?.loginId;
  const flowState = flow?.state;
  const done = useRef(false),
    latestCallback = useRef(onAuthenticated);
  latestCallback.current = onAuthenticated;
  const start = useCallback(async () => {
    setBusy(true);
    setError("");
    setPollError("");
    setCode("");
    done.current = false;
    try {
      const result = await officeApi.startProviderAuth(provider.id);
      if (!alive.current) {
        if (result.flow.state === "pending")
          void officeApi.cancelProviderAuth(provider.id, result.flow.loginId).catch(() => {});
        return;
      }
      setFlow(result.flow);
      if (result.flow.state === "pending" && result.flow.authUrl && popup.current && !popup.current.closed) {
        try {
          popup.current.location.replace(result.flow.authUrl);
        } catch {
          closeBlankAuthWindow(popup.current);
        }
      } else closeBlankAuthWindow(popup.current);
    } catch (e) {
      closeBlankAuthWindow(popup.current);
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, [provider.id]);
  useEffect(() => {
    alive.current = true;
    void start();
    return () => {
      alive.current = false;
      closeBlankAuthWindow(popup.current);
      setCode("");
    };
  }, [start]);
  useEffect(() => {
    if (!loginId || flowState !== "pending") return;
    let alive = true;
    let inFlight = false;
    const timer = setInterval(async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const result = await officeApi.providerAuthStatus(provider.id, loginId);
        if (alive) {
          setFlow((current) =>
            current?.loginId === result.flow.loginId && current.state !== "pending" ? current : result.flow,
          );
          setPollError("");
        }
      } catch {
        if (alive) setPollError("暂时无法读取认证状态，正在重试。");
      } finally {
        inFlight = false;
      }
    }, 2000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [loginId, flowState, provider.id]);
  useEffect(() => {
    if (flowState !== "completed" || done.current) return;
    done.current = true;
    void officeApi
      .providers()
      .then(async (result) => {
        const updated = result.providers.find((item) => item.id === provider.id);
        if (!updated) throw new Error("认证已完成，但暂时无法读取服务配置。");
        await latestCallback.current(updated);
      })
      .catch((e) => setError((e as Error).message));
  }, [flowState, provider.id]);
  const close = useCallback(() => {
    closeBlankAuthWindow(popup.current);
    setCode("");
    if (flowState === "pending" && loginId) void officeApi.cancelProviderAuth(provider.id, loginId).catch(() => {});
    onClose();
  }, [loginId, flowState, provider.id, onClose]);
  return (
    <Modal
      title={provider.executor === "claude-code" ? "Claude Code 账户认证" : "Codex 账户认证"}
      subtitle={provider.name + " · 官方账户授权"}
      onClose={close}
    >
      <div className="dialog-form account-auth-flow">
        <p className="hint">
          本次官方账户授权流程提供地址与状态。请只在官方认证页面登录，不要把账户密码、API Key 或授权码发到聊天。
        </p>
        {!flow && busy && <div className="skeleton">正在启动认证流程…</div>}
        {flow && (
          <>
            <div className="auth-flow-state">
              <strong>
                {flow.state === "completed"
                  ? "账户认证已完成"
                  : flow.state === "failed"
                    ? "认证未完成"
                    : flow.state === "cancelled"
                      ? "认证已取消"
                      : "等待完成官方认证"}
              </strong>
              {flow.message && <p>{flow.message}</p>}
              {flow.expiresAt && <small>本次流程有效至 {new Date(flow.expiresAt).toLocaleTimeString("zh-CN")}</small>}
            </div>
            {flow.state === "pending" && flow.authUrl && (
              <>
                <a className="auth-official-link" href={flow.authUrl} target="_blank" rel="noopener noreferrer">
                  打开本次官方授权页面 ↗
                </a>
                <p className="hint">若浏览器未自动打开，请点击上方链接继续本次授权。</p>
              </>
            )}
            {flow.state === "pending" && flow.userCode && (
              <label>
                设备验证码
                <div className="auth-user-code">
                  <code>{flow.userCode}</code>
                  <button
                    type="button"
                    onClick={() =>
                      void navigator.clipboard
                        .writeText(flow.userCode!)
                        .catch(() => setError("无法自动复制，请手动选择上方验证码。"))
                    }
                  >
                    复制验证码
                  </button>
                </div>
              </label>
            )}
            {flow.state === "pending" && flow.requiresCode && (
              <form
                className="auth-code-form"
                onSubmit={async (event) => {
                  event.preventDefault();
                  setBusy(true);
                  setError("");
                  try {
                    setFlow((await officeApi.completeProviderAuth(provider.id, flow.loginId, code.trim())).flow);
                    setCode("");
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <label>
                  官方页面返回的授权码
                  <input
                    type="password"
                    autoComplete="off"
                    spellCheck={false}
                    required
                    value={code}
                    onChange={(event) => setCode(event.target.value)}
                    placeholder="仅在这里提交本次授权码"
                  />
                </label>
                <button className="primary" disabled={busy || !code.trim()}>
                  {busy ? "正在提交…" : "完成账户认证"}
                </button>
              </form>
            )}
          </>
        )}
        <p className="hint">账户凭据默认仅保存在本次运行内存中，服务重启后需要重新认证。</p>
        {(error || pollError) && (
          <p className="form-error" role="alert">
            {error || pollError}
          </p>
        )}
        <footer className="dialog-footer">
          <button onClick={close}>{flow?.state === "pending" ? "取消认证" : "关闭"}</button>
          {(!flow || flow.state === "failed" || flow.state === "cancelled") && (
            <button
              className="primary"
              disabled={busy}
              onClick={() => {
                closeBlankAuthWindow(popup.current);
                popup.current = openBlankAuthWindow();
                void start();
              }}
            >
              重新开始认证
            </button>
          )}
        </footer>
      </div>
    </Modal>
  );
}
