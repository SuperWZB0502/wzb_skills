import { useEffect, useRef, useState } from "react";
import type { ProviderProfile } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { Modal } from "./Modal";
import { AccountAuthDialog, closeBlankAuthWindow, openBlankAuthWindow } from "./AccountAuthDialog";
export function ServiceDialog({
  provider,
  onSaved,
  onClose,
}: {
  provider: ProviderProfile | null;
  onSaved(provider: ProviderProfile): void | Promise<void>;
  onClose(): void;
}) {
  const [name, setName] = useState(provider?.name || "");
  const [executor, setExecutor] = useState<ProviderProfile["executor"]>(provider?.executor || "codex");
  const [baseUrl, setBaseUrl] = useState(provider?.baseUrl || "");
  const [authMode, setAuthMode] = useState<ProviderProfile["authMode"]>(provider?.authMode || "api_key");
  const [apiKey, setApiKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [authProvider, setAuthProvider] = useState<ProviderProfile | null>(null);
  const authWindow = useRef<Window | null>(null);
  useEffect(
    () => () => {
      setApiKey("");
      closeBlankAuthWindow(authWindow.current);
    },
    [],
  );
  if (authProvider)
    return (
      <AccountAuthDialog
        provider={authProvider}
        authWindow={authWindow.current}
        onClose={onClose}
        onAuthenticated={async (result) => {
          await onSaved(result);
        }}
      />
    );
  return (
    <Modal title={provider ? "配置模型服务" : "新增模型服务"} subtitle="服务统一管理 · 身份选择使用" onClose={onClose}>
      <form
        className="dialog-form service-form"
        onSubmit={async (event) => {
          event.preventDefault();
          setBusy(true);
          setError("");
          if (authMode === "account" && provider?.credentialState !== "configured")
            authWindow.current = openBlankAuthWindow();
          try {
            let saved: ProviderProfile;
            if (provider) {
              saved = provider;
              if (authMode === "api_key" && apiKey) {
                saved = (await officeApi.providerCredential(provider.id, apiKey)).provider;
                setApiKey("");
              }
            } else {
              saved = (
                await officeApi.createProvider({
                  name: name.trim(),
                  baseUrl: authMode === "account" ? "" : baseUrl.trim(),
                  executor,
                  authMode,
                  ...(authMode === "api_key" && apiKey ? { apiKey } : {}),
                })
              ).provider;
              setApiKey("");
            }
            if (saved.authMode === "account" && saved.credentialState !== "configured") setAuthProvider(saved);
            else await onSaved(saved);
          } catch (e) {
            closeBlankAuthWindow(authWindow.current);
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <div className="form-grid">
          <label>
            服务名称
            <input
              value={name}
              required
              readOnly={Boolean(provider)}
              onChange={(event) => setName(event.target.value)}
              placeholder="自定义服务名称"
            />
          </label>
          <label>
            厂商
            <select
              aria-label="执行厂商"
              value={executor}
              disabled={Boolean(provider)}
              onChange={(event) => setExecutor(event.target.value as ProviderProfile["executor"])}
            >
              <option value="codex">Codex</option>
              <option value="claude-code">Claude Code</option>
            </select>
          </label>
        </div>
        <label>
          服务 URL
          {authMode === "account" ? (
            <input value="使用官方账户服务" readOnly />
          ) : (
            <input
              type="url"
              value={baseUrl}
              required
              readOnly={Boolean(provider)}
              onChange={(event) => setBaseUrl(event.target.value)}
              placeholder={executor === "codex" ? "https://your-service.example/v1" : "https://your-service.example"}
            />
          )}
        </label>
        <div className="form-grid">
          <label>
            认证方式
            <select
              aria-label="认证方式"
              value={authMode}
              disabled={Boolean(provider)}
              onChange={(event) => {
                setAuthMode(event.target.value as ProviderProfile["authMode"]);
                setApiKey("");
              }}
            >
              <option value="api_key">API Key</option>
              <option value="account">账户认证</option>
            </select>
          </label>
          {authMode === "api_key" ? (
            <label>
              API Key
              <input
                type="password"
                value={apiKey}
                autoComplete="off"
                spellCheck={false}
                onChange={(event) => setApiKey(event.target.value)}
                placeholder={
                  provider?.credentialState === "configured" ? "留空保留当前运行期凭据" : "仅保存在本次运行内存"
                }
              />
            </label>
          ) : (
            <div className="account-auth-summary">
              <span>账户认证</span>
              <p>
                {provider?.credentialState === "configured"
                  ? "账户已认证，可继续使用。"
                  : "保存后开始官方账户授权流程。"}
              </p>
            </div>
          )}
        </div>
        <p className="hint">
          服务配置会保留；Key/账户凭据只存在运行层内存。选择此服务的伙伴使用服务凭据，无需逐个填写。
        </p>
        {provider && <p className="hint">已有服务的名称、厂商、地址与认证方式保持只读。需要另一种配置时请新建服务。</p>}
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <footer className="dialog-footer">
          <button type="button" onClick={onClose}>
            取消
          </button>
          <button className="primary" disabled={busy}>
            {busy
              ? "正在保存…"
              : authMode === "account" && provider?.credentialState !== "configured"
                ? "保存并开始账户认证"
                : "保存服务"}
          </button>
        </footer>
      </form>
    </Modal>
  );
}
