import type { AgentProfile } from "../../shared/office-contracts";
import { Modal } from "./Modal";
import { credentialLabels, roleLabels, stateLabels, summary } from "./labels";
export function AgentInfoCard({
  agent,
  onClose,
  onChat,
  onEdit,
  onCredential,
}: {
  agent: AgentProfile;
  onClose(): void;
  onChat(): void;
  onEdit(): void;
  onCredential(): void;
}) {
  return (
    <Modal title={agent.name} onClose={onClose} subtitle="身份与实时工作状态">
      <div className="dialog-form">
        <div className="profile-hero">
          <span className="initial-avatar large">{agent.name.slice(0, 1)}</span>
          <div>
            <h3>{roleLabels[agent.jobFunction]}</h3>
            <span className={"status " + agent.workState}>
              <i />
              {stateLabels[agent.workState]}
            </span>
          </div>
        </div>
        <div className="work-summary">
          <span className="eyebrow">此刻在做什么</span>
          <p>{summary(agent)}</p>
          {agent.currentTaskId && <small>任务 · {agent.currentTaskId}</small>}
        </div>
        <dl className="profile-details">
          <div>
            <dt>模型</dt>
            <dd>{agent.model || "尚未配置"}</dd>
          </div>
          <div>
            <dt>思考强度</dt>
            <dd>{agent.reasoningEffort || "模型默认"}</dd>
          </div>
          <div>
            <dt>运行期凭据</dt>
            <dd>{credentialLabels[agent.credentialState]}</dd>
          </div>
          <div>
            <dt>性别标签</dt>
            <dd>{agent.gender || "未指定"}</dd>
          </div>
        </dl>
        <footer className="dialog-footer">
          <button onClick={onEdit}>编辑身份</button>
          <button onClick={onCredential}>配置服务</button>
          <button className="primary" onClick={onChat}>
            打开独立对话 ↗
          </button>
        </footer>
      </div>
    </Modal>
  );
}
