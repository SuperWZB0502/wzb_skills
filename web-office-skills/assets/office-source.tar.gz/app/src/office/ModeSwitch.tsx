import { navigateMode } from "./view-mode";
export function ModeSwitch({ mode }: { mode: "chat" | "office" }) {
  return (
    <div className="mode-switch" aria-label="切换界面">
      <button className={mode === "office" ? "active" : ""} onClick={() => mode !== "office" && navigateMode("office")}>
        任务动画
      </button>
      <button className={mode === "chat" ? "active" : ""} onClick={() => mode !== "chat" && navigateMode("chat")}>
        极简对话
      </button>
    </div>
  );
}
