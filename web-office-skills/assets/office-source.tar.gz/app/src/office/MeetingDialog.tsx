import { useEffect, useState } from "react";
import type { AgentProfile, MeetingSnapshot, OfficeMessage } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { MessageBody } from "./MessageBody";
import { Modal } from "./Modal";
export function MeetingDialog({
  meetingId,
  agents,
  onClose,
}: {
  meetingId: string;
  agents: AgentProfile[];
  onClose(): void;
}) {
  const [data, setData] = useState<{ meeting: MeetingSnapshot; messages: OfficeMessage[] } | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    const load = () =>
      officeApi
        .meeting(meetingId)
        .then((r) => {
          if (alive) setData(r);
        })
        .catch(() => {
          if (alive) setError("暂时无法读取会议记录。");
        });
    void load();
    const timer = setInterval(load, 2500);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [meetingId]);
  return (
    <Modal title="会议记录" onClose={onClose} subtitle="来自真实任务的讨论">
      <div className="meeting-content">
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        {!data ? (
          <div className="skeleton">正在读取会议…</div>
        ) : (
          <>
            <div className="work-summary">
              <span className="eyebrow">
                {data.meeting.phase === "ended"
                  ? "会议已结束"
                  : data.meeting.phase === "review"
                    ? "评审讨论中"
                    : "任务启动讨论"}
              </span>
              <p>关联任务 · {data.meeting.taskId}</p>
              <small>
                参会：
                {data.meeting.participantIds
                  .map((id) => agents.find((a) => a.id === id)?.name || "离职员工")
                  .join("、")}
              </small>
            </div>
            {data.messages.length === 0 ? (
              <p className="hint">会议记录正在等待第一条发言。</p>
            ) : (
              data.messages.map((m) => (
                <article className="message" key={m.id}>
                  <div className="message-byline">
                    <strong>{agents.find((a) => a.id === m.agentId)?.name || "历史身份"}</strong>
                    <time>{new Date(m.at).toLocaleTimeString()}</time>
                  </div>
                  <MessageBody content={m.content} role={m.role} agentId={m.agentId} />
                </article>
              ))
            )}
          </>
        )}
      </div>
    </Modal>
  );
}
