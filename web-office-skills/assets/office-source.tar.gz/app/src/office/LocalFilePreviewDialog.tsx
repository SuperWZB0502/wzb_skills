import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { LocalFileEntry, LocalTextPreview } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { Modal } from "./Modal";

export function LocalFilePreviewDialog({ entry, onClose }: { entry: LocalFileEntry; onClose(): void }) {
  const [preview, setPreview] = useState<LocalTextPreview>();
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    void officeApi.localTextPreview(entry.path, controller.signal).then(setPreview, (failure: Error) => {
      if (!controller.signal.aborted) setError(failure.message);
    });
    return () => controller.abort();
  }, [entry.path]);
  return (
    <Modal title={entry.name} subtitle={entry.path} className="markdown-preview" onClose={onClose}>
      <div className="markdown-preview__toolbar">
        <span>{preview?.truncated ? "只显示文件开头的 256 KiB。" : entry.preview === "markdown" ? "Markdown 预览" : "文本预览"}</span>
      </div>
      <div className="markdown-preview__body">
        {!preview && !error && <div className="skeleton">正在读取…</div>}
        {error && <p className="form-error" role="alert">{error}</p>}
        {preview?.kind === "text" && <pre className="local-file-preview-text">{preview.text}</pre>}
        {preview?.kind === "markdown" && (
          <div className="message-content markdown-body">
            <ReactMarkdown skipHtml remarkPlugins={[remarkGfm]} components={{
              img: ({ alt }) => <span>{alt ?? ""}</span>,
              a: ({ children }) => <span>{children}</span>,
            }}>{preview.text}</ReactMarkdown>
          </div>
        )}
      </div>
    </Modal>
  );
}

export function openLocalImage(entry: LocalFileEntry, onFailure: (message: string) => void) {
  const tab = window.open("about:blank", "_blank");
  if (!tab) {
    onFailure("浏览器阻止了新标签页。");
    return;
  }
  tab.opener = null;
  tab.document.title = entry.name;
  tab.document.body.textContent = "正在读取原图…";
  const controller = new AbortController();
  let objectUrl: string | undefined;
  const watch = window.setInterval(() => {
    if (!tab.closed) return;
    window.clearInterval(watch);
    controller.abort();
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  }, 500);
  void officeApi.localImagePreview(entry.path, controller.signal).then((data) => {
    if (tab.closed) return;
    objectUrl = URL.createObjectURL(data);
    tab.location.replace(objectUrl);
  }).catch((error: Error) => {
    if (!tab.closed) tab.document.body.textContent = error.message;
    if (!controller.signal.aborted) onFailure(error.message);
  });
}
