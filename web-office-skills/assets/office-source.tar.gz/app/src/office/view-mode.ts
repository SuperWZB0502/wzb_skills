import type { ViewMode } from "../../shared/office-contracts";
export function navigateMode(mode: ViewMode) {
  window.location.assign(mode === "chat" ? "/chat.html" : "/office.html");
}
