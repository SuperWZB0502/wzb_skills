/** The suffix is a user-selected Claude CLI option, not a provider capability claim. */
export function splitClaudeContext(model: string | null | undefined) {
  const value = model?.trim() || "";
  const longContext = /(?:\[1m\])+$/i.test(value);
  return { baseModel: value.replace(/(?:\[1m\])+$/i, "").trim(), longContext };
}

export function withClaudeContext(model: string | null | undefined, longContext: boolean) {
  const { baseModel } = splitClaudeContext(model);
  return baseModel ? baseModel + (longContext ? "[1m]" : "") : "";
}
