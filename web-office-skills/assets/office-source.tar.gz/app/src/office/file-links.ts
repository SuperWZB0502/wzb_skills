/**
 * Assistant replies link to deliverables with workspace-relative paths. The browser
 * turns those into authenticated office file URLs, so images render inline and other
 * files download without exposing the workspace layout to the page.
 */
const scheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/;
const imageExtensions = new Set(["png", "jpg", "jpeg", "webp", "gif", "svg"]);
const pageExtensions = new Set(["html", "htm"]);
export type FileLinkMode = "download" | "inline" | "view";

export function extensionOf(href: string): string {
  const clean = href.split(/[?#]/)[0];
  const match = /\.([a-zA-Z0-9]+)$/.exec(clean);
  return match ? match[1].toLowerCase() : "";
}

/** True only for plain relative paths; site routes, anchors and absolute URLs are left alone. */
export function isWorkspaceFileHref(href: string | null | undefined): boolean {
  if (!href) return false;
  const value = href.trim().replace(/^\.\/+/, "");
  if (!value || value.startsWith("#") || value.startsWith("/") || value.startsWith("//")) return false;
  if (scheme.test(value)) return false;
  if (value.includes("\\") || value.includes("\0")) return false;
  return value.split("/").every((segment) => segment && segment !== "." && segment !== "..");
}

export function fileModeOf(href: string): FileLinkMode {
  const extension = extensionOf(href);
  if (pageExtensions.has(extension)) return "view";
  if (imageExtensions.has(extension)) return "inline";
  return "download";
}

/** Markdown renderers hand back already percent-encoded hrefs; decode once before re-encoding. */
export function decodeHref(href: string): string {
  try {
    return decodeURIComponent(href);
  } catch {
    return href;
  }
}

/** Build the office endpoint URL for one deliverable link. */
export function workspaceFileUrl(agentId: string, href: string, mode: FileLinkMode = fileModeOf(href)): string {
  const path = decodeHref(href).trim().replace(/^\.\//, "");
  return `/api/office/agents/${encodeURIComponent(agentId)}/files?path=${encodeURIComponent(path)}&mode=${mode}`;
}
