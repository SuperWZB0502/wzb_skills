/**
 * Assistant replies link to deliverables with workspace-relative paths. The browser
 * turns those into authenticated office file URLs, so images render inline and other
 * files download without exposing the workspace layout to the page.
 */
const scheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/;
const imageExtensions = new Set(["png", "jpg", "jpeg", "webp", "gif", "svg"]);
const pageExtensions = new Set(["html", "htm"]);
const markdownExtensions = new Set(["md", "markdown", "mdown", "mkd"]);
export type FileLinkMode = "download" | "inline" | "view";

export function extensionOf(href: string): string {
  const clean = href.split(/[?#]/)[0];
  const match = /\.([a-zA-Z0-9]+)$/.exec(clean);
  return match ? match[1].toLowerCase() : "";
}

export interface WorkspaceHrefParts {
  /** Workspace-relative file path, decoded once, with a leading `./` removed. */
  path: string;
  /** Anchor text without its `#`; the browser needs it to route inside the previewed page. */
  fragment: string;
}

/**
 * A Markdown href carries up to three parts: the file path, a query and an anchor. Only the path
 * names a file, so only it may travel in the API's `path` parameter; the anchor has to stay on the
 * browser URL where the previewed page reads it back from `location.hash`.
 * Splitting happens before decoding so an encoded `%23` remains part of a real file name.
 */
export function splitWorkspaceHref(href: string): WorkspaceHrefParts {
  const value = href.trim();
  const hashAt = value.indexOf("#");
  const head = hashAt < 0 ? value : value.slice(0, hashAt);
  const fragment = hashAt < 0 ? "" : value.slice(hashAt + 1);
  const queryAt = head.indexOf("?");
  // A query never selects a file on disk; keeping it in `path` made the endpoint look for "a.png?v=2".
  const rawPath = queryAt < 0 ? head : head.slice(0, queryAt);
  return { path: decodeHref(rawPath).trim().replace(/^\.\//, ""), fragment };
}

/** True only for plain relative paths; site routes, anchors and absolute URLs are left alone. */
export function isWorkspaceFileHref(href: string | null | undefined): boolean {
  if (!href) return false;
  const value = href.trim().replace(/^\.\/+/, "");
  if (!value || value.startsWith("#") || value.startsWith("/") || value.startsWith("//")) return false;
  if (scheme.test(value)) return false;
  if (value.includes("\\") || value.includes("\0")) return false;
  const { path } = splitWorkspaceHref(value);
  if (!path || path.startsWith("/") || scheme.test(path)) return false;
  if (path.includes("\\") || path.includes("\0")) return false;
  return path.split("/").every((segment) => segment && segment !== "." && segment !== "..");
}

export function fileModeOf(href: string): FileLinkMode {
  const extension = extensionOf(href);
  if (pageExtensions.has(extension)) return "view";
  if (imageExtensions.has(extension)) return "inline";
  return "download";
}

/** Markdown renderers hand back already percent-encoded hrefs; decode once before re-encoding. */
export function decodeHref(href: string): string {
  try {
    return decodeURIComponent(href);
  } catch {
    return href;
  }
}

/** Delimiters a URL fragment cannot carry literally; everything else stays readable (`#8`, `#总结`). */
const fragmentReserved = new Set(['"', "#", "<", ">", "\\", "^", "`", "|", "{", "}"]);

/** Keep the anchor readable for `location.hash`, escaping only what a URL cannot hold. */
export function encodeFragment(fragment: string): string {
  let encoded = "";
  for (const character of decodeHref(fragment)) {
    const code = character.codePointAt(0)!;
    // Spaces and control characters would end the URL early or be rewritten by the browser.
    encoded +=
      code <= 0x20 || code === 0x7f || fragmentReserved.has(character)
        ? "%" + code.toString(16).toUpperCase().padStart(2, "0")
        : character;
  }
  return encoded;
}

/** Build the office endpoint URL for one deliverable link; the anchor stays on the browser side. */
export function workspaceFileUrl(agentId: string, href: string, mode: FileLinkMode = fileModeOf(href)): string {
  const { path, fragment } = splitWorkspaceHref(href);
  const url = `/api/office/agents/${encodeURIComponent(agentId)}/files?path=${encodeURIComponent(path)}&mode=${mode}`;
  return fragment ? `${url}#${encodeFragment(fragment)}` : url;
}

/** Markdown deliverables open in the rendered preview dialog instead of downloading. */
export function isMarkdownHref(href: string | null | undefined): boolean {
  return Boolean(href) && markdownExtensions.has(extensionOf(href!));
}

/** Relative hrefs may be rebased on a document path; anchors, routes and URLs never are. */
export function isRelativeHref(href: string | null | undefined): boolean {
  if (!href) return false;
  const value = href.trim();
  return Boolean(value) && !value.startsWith("#") && !value.startsWith("/") && !scheme.test(value);
}

export function fileNameOf(path: string): string {
  return path.split("/").pop() || path;
}

/**
 * Resolve `href` relative to the directory of the document being previewed, so images and
 * links inside a markdown file keep working. Returns null when the path escapes the workspace.
 * Any anchor is carried along unchanged, so the caller can keep it on the browser URL.
 */
export function resolveRelativePath(basePath: string | null | undefined, href: string): string | null {
  if (!isRelativeHref(href)) return null;
  // Rebase on the folder that holds the document, not on the document itself.
  const segments = (basePath ?? "").split("/").filter(Boolean);
  segments.pop();
  const { path, fragment } = splitWorkspaceHref(href);
  for (const segment of path.split("/")) {
    if (!segment || segment === ".") continue;
    if (segment === "..") {
      if (!segments.length) return null;
      segments.pop();
      continue;
    }
    if (segment.includes("\\") || segment.includes("\0")) return null;
    segments.push(segment);
  }
  if (!segments.length) return null;
  const resolved = segments.join("/");
  return fragment ? `${resolved}#${fragment}` : resolved;
}
