import { useEffect } from "react";
import type { AgentProfile } from "../../shared/office-contracts";
import { createPortal } from "react-dom";
export function AgentActionsMenu({
  agent,
  point,
  onEdit,
  onClone,
  onDelete,
  onClose,
}: {
  agent: AgentProfile;
  point: { x: number; y: number };
  onEdit(): void;
  onClone(): void;
  onDelete(): void;
  onClose(): void;
}) {
  useEffect(() => {
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [onClose]);
  return createPortal(
    <div className="menu-shade" onMouseDown={onClose}>
      <div
        className="context-menu"
        role="menu"
        aria-label={agent.name + " 的操作"}
        style={{
          left: Math.max(8, Math.min(point.x, window.innerWidth - 200)),
          top: Math.max(8, Math.min(point.y, window.innerHeight - 180)),
        }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <small>{agent.name}</small>
        <button role="menuitem" onClick={onEdit}>
          编辑身份
        </button>
        {!agent.isBoss && (
          <>
            <button role="menuitem" onClick={onClone}>
              复制为新伙伴
            </button>
            <button role="menuitem" className="danger-text" onClick={onDelete}>
              删除身份
            </button>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}
