import type { AgentProfile } from "../../shared/office-contracts";
export const roleLabels = {
  boss: "Boss · 你的身份",
  se: "SE · 系统工程",
  pl: "PL · 项目协调",
  developer: "开发",
  tester: "测试",
};
export const stateLabels = {
  idle: "空闲",
  working: "工作中",
  waiting_input: "等待你的回复",
  meeting: "会议中",
  error: "遇到问题",
  offline: "离线",
};
export const credentialLabels = { required: "服务待认证", configured: "服务认证已就绪", invalid: "服务认证需要更新" };
export function summary(agent: AgentProfile) {
  return agent.currentTaskId || ["working", "meeting", "waiting_input"].includes(agent.workState)
    ? agent.currentWorkSummary || "正在处理任务"
    : "当前暂无任务";
}
