import type { AttachmentDraft } from "./useChatAttachments";
export function AttachmentDrafts({
  items,
  disabled,
  onRemove,
  onRetry,
}: {
  items: AttachmentDraft[];
  disabled: boolean;
  onRemove(id: string): void;
  onRetry(id: string): void;
}) {
  if (!items.length) return null;
  return (
    <div className="attachment-drafts" aria-label="待发送图片">
      {items.map((item) => (
        <figure key={item.localId}>
          <img src={item.previewUrl} alt={item.file.name} />
          <button
            className="attachment-remove"
            type="button"
            disabled={disabled}
            aria-label={"移除图片 " + item.file.name}
            onClick={() => onRemove(item.localId)}
          >
            ×
          </button>
          <figcaption>
            <span title={item.file.name}>{item.file.name}</span>
            <small>
              {item.status === "uploaded" ? "已上传" : item.status === "uploading" ? "正在上传…" : item.error}
            </small>
            {item.status === "error" && (
              <button type="button" disabled={disabled} onClick={() => onRetry(item.localId)}>
                重试上传
              </button>
            )}
          </figcaption>
        </figure>
      ))}
    </div>
  );
}
