import { setOfficeTheme, useOfficeTheme } from "./theme";
export function ThemeSwitch() {
  const theme = useOfficeTheme();
  const next = theme === "dark" ? "light" : "dark";
  return (
    <button
      type="button"
      className="theme-switch"
      aria-label={next === "light" ? "切换浅色主题" : "切换深色主题"}
      title={next === "light" ? "切换浅色主题" : "切换深色主题"}
      onClick={() => setOfficeTheme(next)}
    >
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        aria-hidden="true"
      >
        {theme === "dark" ? (
          <>
            <circle cx="12" cy="12" r="4" />
            <path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5" />
          </>
        ) : (
          <path d="M20 15.5A9 9 0 0 1 8.5 4a9 9 0 1 0 11.5 11.5Z" />
        )}
      </svg>
    </button>
  );
}
