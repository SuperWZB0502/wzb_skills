import { useEffect, useRef, useState } from "react";
import { Application, Assets, Container, Graphics, Sprite, Text, type Texture } from "pixi.js";
import type { AgentProfile, OfficeSnapshot } from "../../shared/office-contracts";
import { getOfficeTheme, useOfficeTheme } from "./theme";
import {
  layoutMeeting,
  layoutOfficeZones,
  officeWalkPath,
  type RoomRect,
  type OfficeRoom,
  type WalkPoint,
} from "./meeting-layout";
import { drawPlant, drawWhiteboard } from "../components/office-view/drawing-furniture-a";
import { drawBookshelf, drawCoffeeMachine } from "../components/office-view/drawing-furniture-b";
interface Props {
  snapshot: OfficeSnapshot;
  archivedAgents?: AgentProfile[];
  onPrimary(id: string): void;
  onContext(id: string, p: { x: number; y: number }): void;
  onMeeting(id: string): void;
  onKnowledge?(): void;
  onArchives?(): void;
  onArchived?(agent: AgentProfile): void;
}
interface Actor {
  node: Container;
  body: Sprite;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  state: string;
  phase: number;
  frames: Texture[];
  route: WalkPoint[];
}
const ink = 0x42413d;
function label(
  parent: Container,
  text: string,
  x: number,
  y: number,
  size = 15,
  color = getOfficeTheme() === "dark" ? 0xd8d8d5 : ink,
) {
  const t = new Text({
    text,
    style: { fontFamily: 'Arial,"Microsoft YaHei",sans-serif', fontSize: size, fill: color, fontWeight: "500" },
  });
  t.position.set(x, y);
  parent.addChild(t);
  return t;
}
function rect(parent: Container, x: number, y: number, w: number, h: number, color: number, r = 0) {
  const g = new Graphics().roundRect(x, y, w, h, r).fill(color);
  parent.addChild(g);
  return g;
}
function room(parent: Container, r: RoomRect, title: string, note: string, floor: number, dark = false) {
  rect(parent, r.x + 5, r.y + 7, r.width, r.height, dark ? 0x121212 : 0xd5d4c7, 9);
  rect(parent, r.x, r.y, r.width, r.height, dark ? 0x3b3b3b : 0xe5e3d5, 6);
  rect(parent, r.x + 4, r.y + 4, r.width - 8, r.height - 8, floor, 4);
  const lines = new Graphics();
  for (let y = r.y + 62; y < r.y + r.height; y += 29) {
    lines
      .moveTo(r.x + 5, y)
      .lineTo(r.x + r.width - 5, y)
      .stroke({ color: 0xc6c8b4, width: 1, alpha: 0.25 });
    for (let x = r.x + 30; x < r.x + r.width; x += 65)
      lines
        .moveTo(x + (Math.round(y / 29) % 2) * 32, y - 29)
        .lineTo(x + (Math.round(y / 29) % 2) * 32, y)
        .stroke({ color: 0xc6c8b4, width: 1, alpha: 0.2 });
  }
  parent.addChild(lines);
  rect(parent, r.x + 3, r.y + 3, r.width - 6, 47, dark ? 0x262626 : 0xf8f7ed, 3);
  label(parent, title, r.x + 18, r.y + 15, 16, dark ? 0xd8d8d5 : ink);
  label(parent, note, r.x + r.width - 85, r.y + 18, 10, dark ? 0xaaa69d : 0x8a8f7e);
}
function desk(parent: Container, x: number, y: number, active: boolean) {
  rect(parent, x - 48, y + 30, 98, 12, 0xbfc2af, 5);
  rect(parent, x - 42, y + 28, 5, 25, 0x9f916f);
  rect(parent, x + 37, y + 28, 5, 25, 0x9f916f);
  rect(parent, x - 49, y - 11, 98, 46, 0xb7a77e, 4);
  rect(parent, x - 49, y - 15, 98, 44, 0xe0cda3, 4);
  rect(parent, x - 46, y - 13, 92, 3, 0xefe2c6);
  rect(parent, x - 18, y - 44, 40, 29, 0x54615b, 3);
  rect(parent, x - 15, y - 41, 34, 23, active ? 0xaac6ae : 0xc2cdc0, 1);
  rect(parent, x - 4, y - 15, 11, 7, 0x637168, 2);
  rect(parent, x - 17, y + 4, 37, 9, 0xa0a89a, 2);
  rect(parent, x + 30, y - 5, 9, 10, 0xf5f2e8, 1);
  rect(parent, x - 38, y - 6, 13, 17, 0xfaf7ec);
}
export function OfficeCanvas(props: Props) {
  const theme = useOfficeTheme();
  const dark = theme === "dark";
  const host = useRef<HTMLDivElement>(null);
  const latest = useRef(props);
  latest.current = props;
  const render = useRef<((s: OfficeSnapshot) => Promise<void>) | null>(null);
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);
  useEffect(() => {
    setReady(false);
    setError("");
    let stopped = false;
    let observer: ResizeObserver | undefined;
    let generation = 0;
    const app = new Application();
    let initialized = false;
    let actors = new Map<string, Actor>();
    const lastPositions = new Map<string, { x: number; y: number }>();
    let scene: Container;
    let contentHeight = 800;
    let rootWidth = layoutOfficeZones(0).worldWidth;
    const build = async (snapshot: OfficeSnapshot) => {
      const version = ++generation;
      const archivedAgents = latest.current.archivedAgents || [];
      const textures = await Promise.all(
        [...snapshot.agents, ...archivedAgents].map(async (a) => {
          const n = Math.min(14, Math.max(1, a.spriteNumber || 1));
          const frames = await Promise.all([1, 2, 3].map((f) => Assets.load<Texture>(`/sprites/${n}-D-${f}.png`)));
          return [a.id, frames] as const;
        }),
      );
      if (stopped || version !== generation) return;
      actors.forEach((a, id) => lastPositions.set(id, { x: a.x, y: a.y }));
      actors = new Map();
      if (scene) {
        app.stage.removeChild(scene);
        scene.destroy({ children: true, texture: false, textureSource: false });
      }
      scene = new Container();
      app.stage.addChild(scene);
      const regularCount = snapshot.agents.filter((a) => !a.isBoss).length;
      const z = layoutOfficeZones(regularCount, regularCount + 1, archivedAgents.length);
      rootWidth = z.worldWidth;
      contentHeight = Math.max(
        z.rest.y + z.rest.height + 35,
        z.meeting.y + z.meeting.height + 35,
        z.blackroom.y + z.blackroom.height + 35,
      );
      rect(scene, 0, 0, rootWidth, contentHeight, dark ? 0x1b1b1b : 0xeee8dd);
      for (const aisle of [z.verticalAisle, z.bossAisle, z.libraryAisle, z.horizontalAisle, z.blackroomAisle])
        rect(scene, aisle.x, aisle.y, aisle.width, aisle.height, dark ? 0x171717 : 0xd9d1c3);
      room(scene, z.boss, "BOSS 办公室", "你的空间", dark ? 0x2d2d2d : 0xebe5d8, dark);
      room(scene, z.meeting, "会议室", "真实讨论", dark ? 0x303030 : 0xe5e4d4, dark);
      room(scene, z.work, "一起，把事情做好", "工作区", dark ? 0x2a2a2a : 0xf0e9dc, dark);
      room(scene, z.library, "公司知识库", "分类检索", dark ? 0x2e2e2e : 0xede6d6, dark);
      room(scene, z.rest, "休息一下", "休息区", dark ? 0x303030 : 0xede5d5, dark);
      room(scene, z.blackroom, "小黑屋", "历史保留", 0x252525, true);
      const blackroomHit = new Graphics()
        .rect(z.blackroom.x, z.blackroom.y, z.blackroom.width, z.blackroom.height)
        .fill({ color: 0xffffff, alpha: 0.001 });
      blackroomHit.eventMode = "static";
      blackroomHit.cursor = "pointer";
      blackroomHit.on("pointertap", () => latest.current.onArchives?.());
      scene.addChild(blackroomHit);
      for (let x = z.work.x + 25; x < z.work.x + z.work.width - 50; x += 155) {
        rect(scene, x, 87, 104, 8, 0xb5c5af, 2);
        rect(scene, x + 5, 95, 94, 4, 0xdce5d5);
      }
      const doorway = (point: WalkPoint, vertical: boolean) => {
        const color = dark ? 0xaba18c : 0xb29a6b;
        rect(
          scene,
          point.x - (vertical ? 6 : 23),
          point.y - (vertical ? 23 : 6),
          vertical ? 12 : 46,
          vertical ? 46 : 12,
          color,
          2,
        );
        rect(
          scene,
          point.x - (vertical ? 3 : 20),
          point.y - (vertical ? 20 : 3),
          vertical ? 6 : 40,
          vertical ? 40 : 6,
          dark ? 0x222222 : 0xe4ded3,
          1,
        );
      };
      doorway(z.doors.boss, true);
      doorway(z.doors.meeting, true);
      doorway(z.doors.work, false);
      doorway(z.doors.rest, false);
      doorway(z.doors.library, true);
      doorway(z.doors.blackroom, true);
      for (let row = 0; row < Math.max(2, Math.floor((z.library.height - 70) / 75)); row++)
        for (let col = 0; col < 3; col++) {
          const bookcase = new Container();
          bookcase.position.set(z.library.x + 20 + col * 88, z.library.y + 75 + row * 75);
          bookcase.scale.set(2.45);
          drawBookshelf(bookcase, 0, 0);
          scene.addChild(bookcase);
          const folders = new Graphics();
          for (let index = 0; index < 4; index++)
            folders
              .roundRect(z.library.x + 24 + col * 88 + index * 15, z.library.y + 125 + row * 75, 12, 14, 1)
              .fill([0xb6a879, 0x9aadaf, 0xc1aaa0, 0xaaa78f][index]);
          scene.addChild(folders);
        }
      const libraryHit = new Graphics()
        .rect(z.library.x, z.library.y, z.library.width, z.library.height)
        .fill({ color: 0xffffff, alpha: 0.001 });
      libraryHit.eventMode = "static";
      libraryHit.cursor = "pointer";
      libraryHit.on("pointertap", () => latest.current.onKnowledge?.());
      scene.addChild(libraryHit);
      desk(scene, 185, 190, false);
      const shelf = new Container();
      shelf.position.set(55, 106);
      shelf.scale.set(2);
      drawBookshelf(shelf, 0, 0);
      scene.addChild(shelf);
      const plant = (x: number, y: number, scale = 1.4) => {
        const c = new Container();
        c.position.set(x, y);
        c.scale.set(scale);
        drawPlant(c, 0, 0);
        scene.addChild(c);
      };
      plant(302, 97);
      plant(z.work.x + z.work.width - 40, 110);
      const wb = new Container();
      wb.position.set(65, z.meeting.y + 65);
      wb.scale.set(2);
      drawWhiteboard(wb, 0, 0);
      scene.addChild(wb);
      const activeMeeting = snapshot.meetings.find((m) => m.phase !== "ended");
      const recentMeeting = activeMeeting || snapshot.meetings[snapshot.meetings.length - 1];
      const table = rect(scene, 105, z.meeting.y + 150, 150, 80, 0xc7b58c, 16);
      rect(scene, 110, z.meeting.y + 153, 140, 71, 0xe4d1a6, 13);
      label(scene, recentMeeting ? "点击查看会议记录" : "尚无进行中的会议", 116, z.meeting.y + 185, 12, 0x756f59);
      if (recentMeeting) {
        table.eventMode = "static";
        table.cursor = "pointer";
        table.on("pointertap", () => latest.current.onMeeting(recentMeeting.id));
      }
      const sofa = (x: number) => {
        rect(scene, x, z.rest.y + 90, 180, 60, dark ? 0x5a5a5a : 0xaaa99f, 10);
        rect(scene, x + 10, z.rest.y + 84, 160, 42, dark ? 0x777570 : 0xd0cbc0, 8);
        for (let index = 0; index < 3; index++)
          rect(scene, x + 15 + index * 50, z.rest.y + 86, 45, 34, dark ? 0x85817a : 0xdfd9ca, 5);
      };
      sofa(z.rest.x + 35);
      sofa(z.rest.x + 345);
      rect(scene, z.rest.x + 250, z.rest.y + 108, 62, 34, 0xcab68e, 8);
      const coffee = new Container();
      coffee.position.set(z.rest.x + z.rest.width - 62, z.rest.y + 78);
      coffee.scale.set(2.2);
      drawCoffeeMachine(coffee, 0, 0);
      scene.addChild(coffee);
      label(scene, "COFFEE", z.rest.x + z.rest.width - 70, z.rest.y + 157, 9, dark ? 0xb5b0a4 : 0x8f8878);
      const regular = snapshot.agents.filter((a) => !a.isBoss);
      if (!regular.length) {
        label(scene, "添加伙伴，给想法找个搭档。", z.work.x + 250, z.work.y + 185, 17, 0x9ca58e);
        label(scene, "右上角「添加伙伴」 · 独立模型与会话", z.work.x + 267, z.work.y + 218, 11, 0xa9b19d);
      }
      regular.forEach((a, i) => {
        const x = z.work.x + 88 + (i % 5) * 150;
        const y = z.work.y + 163 + Math.floor(i / 5) * 130;
        desk(scene, x, y, a.workState === "working");
        label(scene, String(i + 1).padStart(2, "0"), x - 47, y + 44, 10, 0xa3a08c);
      });
      const meetingSeats = new Map<string, { x: number; y: number }>();
      snapshot.meetings
        .filter((m) => m.phase !== "ended")
        .forEach((m) => layoutMeeting(z.meeting, m.participantIds).forEach((p) => meetingSeats.set(p.agentId, p)));
      const textureMap = new Map(textures);
      if (!archivedAgents.length)
        label(scene, "会话保留为公司资产", z.blackroom.x + 55, z.blackroom.y + 120, 12, 0xbdb8ae);
      archivedAgents.forEach((agent, index) => {
        const node = new Container();
        node.position.set(z.blackroom.x + 58 + (index % 3) * 92, z.blackroom.y + 140 + Math.floor(index / 3) * 108);
        const body = new Sprite(textureMap.get(agent.id)![0]);
        body.anchor.set(0.5, 1);
        body.height = 55;
        body.scale.x = body.scale.y;
        node.addChild(body);
        const title = label(node, agent.name, 0, -78, 11, 0xd0cbc2);
        const characters = Array.from(agent.name);
        while (title.width > 72 && characters.length > 1) {
          characters.pop();
          title.text = characters.join("") + "…";
        }
        title.x = -title.width / 2;
        node.addChildAt(new Graphics().roundRect(title.x - 5, -82, title.width + 10, 22, 4).fill(0x151515), 0);
        node.eventMode = "static";
        node.cursor = "pointer";
        node.on("pointertap", (event) => {
          event.stopPropagation();
          latest.current.onArchived?.(agent);
        });
        scene.addChild(node);
      });
      snapshot.agents.forEach((a, index) => {
        const workIndex = regular.findIndex((b) => b.id === a.id);
        let destination: OfficeRoom = a.isBoss ? "boss" : "work";
        let target = a.isBoss
          ? { x: 185, y: 166 }
          : { x: z.work.x + 88 + (workIndex % 5) * 150, y: z.work.y + 144 + Math.floor(workIndex / 5) * 130 };
        if (!a.isBoss && a.workState === "idle") {
          destination = "rest";
          target = { x: z.rest.x + 74 + (workIndex % 8) * 78, y: z.rest.y + 145 + Math.floor(workIndex / 8) * 75 };
        }
        if (a.workState === "meeting" && meetingSeats.has(a.id)) {
          destination = "meeting";
          target = meetingSeats.get(a.id)!;
        }
        const node = new Container();
        const shadow = new Graphics().ellipse(0, 1, 17, 5).fill({ color: 0x4e634d, alpha: 0.15 });
        node.addChild(shadow);
        const frames = textureMap.get(a.id)!;
        const body = new Sprite(frames[0]);
        body.anchor.set(0.5, 1);
        body.height = 55;
        body.scale.x = body.scale.y;
        node.addChild(body);
        const nameColor =
          a.workState === "working"
            ? 0xc64646
            : a.workState === "meeting"
              ? 0xb38a16
              : a.workState === "idle"
                ? 0x398254
                : a.workState === "error"
                  ? 0xc64646
                  : a.workState === "waiting_input"
                    ? 0xb38a16
                    : 0x858d85;
        const title = label(node, a.name, -40, -78, 12, nameColor);
        const maxWidth =
          destination === "meeting" ? 60 : destination === "rest" ? 60 : destination === "boss" ? 180 : 120;
        const nameCharacters = Array.from(a.name);
        while (title.width > maxWidth && nameCharacters.length > 1) {
          nameCharacters.pop();
          title.text = nameCharacters.join("") + "…";
        }
        title.x = -title.width / 2;
        const plate = new Graphics()
          .roundRect(title.x - 6, -82, title.width + 12, 22, 5)
          .fill({ color: dark ? 0x181818 : 0xfffbf1, alpha: 0.97 })
          .stroke({ color: nameColor, alpha: 0.4, width: 1 });
        node.addChildAt(plate, node.getChildIndex(title));
        if (a.workState === "waiting_input" || a.workState === "error") {
          const bubble = rect(node, -9, -108, 18, 18, a.workState === "error" ? 0xc47a64 : 0xa9bb80, 5);
          label(node, a.workState === "error" ? "!" : "…", -3, -107, 13, 0xffffff);
          bubble.alpha = 0.95;
        }
        node.eventMode = "static";
        node.cursor = "pointer";
        node.on("pointertap", (event) => {
          if (event.button === 0) latest.current.onPrimary(a.id);
        });
        node.on("rightclick", (event) => {
          (event.nativeEvent as MouseEvent).preventDefault();
          latest.current.onContext(a.id, {
            x: (event.nativeEvent as MouseEvent).clientX,
            y: (event.nativeEvent as MouseEvent).clientY,
          });
        });
        const old = lastPositions.get(a.id) || target;
        const actor = {
          node,
          body,
          x: old.x,
          y: old.y,
          targetX: target.x,
          targetY: target.y,
          state: a.workState,
          phase: index * 0.7,
          frames,
          route: officeWalkPath(z, old, target, destination),
        };
        node.position.set(old.x, old.y);
        actors.set(a.id, actor);
        scene.addChild(node);
      });
      resize();
      setReady(true);
    };
    const resize = () => {
      if (!host.current || !initialized || !scene) return;
      const width = host.current.clientWidth;
      const scale = width / rootWidth;
      scene.scale.set(scale);
      app.renderer.resize(width, Math.max(420, contentHeight * scale));
    };
    const init = async () => {
      try {
        await app.init({
          background: dark ? 0x1b1b1b : 0xeee8dd,
          antialias: false,
          resolution: Math.min(devicePixelRatio || 1, 2),
          autoDensity: true,
          preference: "webgl",
        });
        initialized = true;
        if (stopped) {
          app.destroy(true, { children: true, texture: false, textureSource: false });
          return;
        }
        host.current?.appendChild(app.canvas);
        app.canvas.setAttribute("aria-label", "智能体办公室。角色的等价操作可通过右侧伙伴列表使用。");
        app.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
        app.ticker.maxFPS = 30;
        app.ticker.add((t) => {
          for (const actor of actors.values()) {
            let remaining = Math.min(t.deltaMS, 80) * 0.12;
            const moving = actor.route.length > 0;
            while (remaining > 0 && actor.route.length) {
              const next = actor.route[0];
              const dx = next.x - actor.x,
                dy = next.y - actor.y;
              const distance = Math.hypot(dx, dy);
              if (distance <= remaining) {
                actor.x = next.x;
                actor.y = next.y;
                remaining -= distance;
                actor.route.shift();
              } else {
                actor.x += (dx / distance) * remaining;
                actor.y += (dy / distance) * remaining;
                remaining = 0;
              }
            }
            actor.phase += t.deltaMS * 0.004;
            actor.node.position.set(actor.x, actor.y);
            actor.body.y = moving
              ? Math.sin(actor.phase * 2) * 2
              : actor.state === "working"
                ? Math.sin(actor.phase) * 0.8
                : 0;
            actor.body.texture = actor.frames[moving ? Math.floor(actor.phase * 2) % 3 : 0];
          }
        });
        observer = new ResizeObserver(resize);
        if (host.current) observer.observe(host.current);
        render.current = build;
        await build(latest.current.snapshot);
      } catch {
        if (!stopped) setError("动画画布暂不可用。你仍可通过伙伴列表查看状态与对话。");
      }
    };
    void init();
    return () => {
      stopped = true;
      generation++;
      observer?.disconnect();
      render.current = null;
      if (initialized) {
        app.ticker.stop();
        app.destroy(true, { children: true, texture: false, textureSource: false });
      }
      actors.clear();
    };
  }, [dark]);
  useEffect(() => {
    void render.current?.(props.snapshot).catch(() => setError("角色素材加载失败，请刷新重试。"));
  }, [props.snapshot, props.archivedAgents]);
  return (
    <div className="office-canvas" ref={host} data-scene-ready={ready}>
      {!ready && !error && <div className="canvas-loading">正在布置工作室…</div>}
      {error && (
        <div role="alert" className="canvas-error">
          {error}
        </div>
      )}
    </div>
  );
}
