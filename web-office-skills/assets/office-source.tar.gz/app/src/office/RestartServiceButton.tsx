import { useEffect, useRef, useState } from "react";
import { OfficeNetworkError, officeApi } from "./api";
import { ConfirmDialog } from "./ConfirmDialog";

/** How often the page asks the runtime whether it came back with a new boot identity. */
const POLL_INTERVAL_MS = 1500;
/** Give up (and tell the operator) after this long without a new boot identity. */
const POLL_LIMIT_MS = 120_000;

/**
 * Header entry that restarts the runtime through `office.mjs restart`.
 *
 * The server refuses while any run is active, so this can never interrupt somebody's task. The
 * credentials live in runtime memory only, which is why the dialog says they have to be provided
 * again; conversation transcripts and finished runs are untouched.
 */
export function RestartServiceButton({ bootId }: { bootId?: string }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const timer = useRef<number | null>(null);
  useEffect(
    () => () => {
      if (timer.current !== null) window.clearTimeout(timer.current);
    },
    [],
  );
  const watchForNewBoot = () => {
    const deadline = Date.now() + POLL_LIMIT_MS;
    const poll = async () => {
      if (Date.now() > deadline) {
        setBusy(false);
        setNote("");
        setError("重启后两分钟内没有恢复。请在服务器执行 bash restart-office.sh，并查看 logs/runtime.log。");
        return;
      }
      try {
        const next = await officeApi.snapshot();
        if (!bootId || next.bootId !== bootId) {
          location.reload();
          return;
        }
      } catch {
        /* Runtime is down: keep waiting for it to answer again. */
      }
      timer.current = window.setTimeout(() => void poll(), POLL_INTERVAL_MS);
    };
    timer.current = window.setTimeout(() => void poll(), POLL_INTERVAL_MS);
  };
  const restart = async () => {
    setBusy(true);
    setError("");
    setNote("正在重启，服务恢复后此页面会自动刷新…");
    try {
      await officeApi.restartOffice();
    } catch (failure) {
      // A refusal (tasks running, switch off) is final and must be shown as-is. A dropped
      // connection may just mean the runtime exited before answering: let the poll decide.
      if (!(failure instanceof OfficeNetworkError)) {
        setBusy(false);
        setNote("");
        setError((failure as Error).message);
        return;
      }
    }
    watchForNewBoot();
  };
  return (
    <>
      <button
        className="outline"
        title="重启服务进程；有任务在运行时会拒绝"
        onClick={() => {
          setError("");
          setNote("");
          setBusy(false);
          setOpen(true);
        }}
      >
        重启服务
      </button>
      {open && (
        <ConfirmDialog
          title="重启服务？"
          subtitle="同席工作室 · 系统"
          confirmLabel="确认重启"
          busyLabel="正在重启…"
          tone="danger"
          busy={busy}
          error={error}
          onConfirm={() => void restart()}
          onClose={() => setOpen(false)}
        >
          <ul className="confirm-list">
            <li>重启期间网页会短暂不可用（约 10–20 秒），恢复后自动刷新。</li>
            <li>模型 API Key 与账户授权只保存在运行内存里，重启后需要重新填写或重新授权。</li>
            <li>会话记录、已完成的任务和文件都不会被删除。</li>
            <li>还有任务在运行时服务会拒绝重启，等任务结束后再点一次即可。</li>
          </ul>
          {note && <p className="hint">{note}</p>}
        </ConfirmDialog>
      )}
    </>
  );
}
