import { useSyncExternalStore } from "react";
export type OfficeTheme = "dark" | "light";
const themeEvent = "office-theme-change";
export function getOfficeTheme(): OfficeTheme {
  return document.documentElement.dataset.theme === "light" ? "light" : "dark";
}
export function setOfficeTheme(theme: OfficeTheme) {
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#181818" : "#f7f3eb");
  try {
    localStorage.setItem("office.theme", theme);
  } catch {
    /* Theme remains available for this page. */
  }
  window.dispatchEvent(new Event(themeEvent));
}
function subscribe(callback: () => void) {
  const onStorage = (event: StorageEvent) => {
    if (event.key === "office.theme") {
      const value = event.newValue === "light" ? "light" : "dark";
      document.documentElement.dataset.theme = value;
      document.documentElement.style.colorScheme = value;
      callback();
    }
  };
  window.addEventListener(themeEvent, callback);
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(themeEvent, callback);
    window.removeEventListener("storage", onStorage);
  };
}
export function useOfficeTheme() {
  return useSyncExternalStore(subscribe, getOfficeTheme, () => "dark" as const);
}
if (typeof document !== "undefined" && !document.documentElement.dataset.theme) {
  let theme: OfficeTheme = "dark";
  try {
    if (localStorage.getItem("office.theme") === "light") theme = "light";
  } catch {
    /* Private browsing fallback. */
  }
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
}

if (typeof document !== "undefined")
  document
    .querySelector('meta[name="theme-color"]')
    ?.setAttribute("content", getOfficeTheme() === "dark" ? "#181818" : "#f7f3eb");
