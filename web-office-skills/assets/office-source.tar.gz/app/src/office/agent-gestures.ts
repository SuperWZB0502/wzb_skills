export interface AgentGestureHandlers {
  single(id: string): void;
  double(id: string): void;
  context(id: string, point: { x: number; y: number }): void;
}
export function createAgentGestureController(handlers: AgentGestureHandlers, delayMs = 300) {
  const pending = new Map<string, ReturnType<typeof setTimeout>>();
  const cancel = () => {
    pending.forEach(clearTimeout);
    pending.clear();
  };
  return {
    primary(id: string) {
      const t = pending.get(id);
      if (t) {
        clearTimeout(t);
        pending.delete(id);
        handlers.double(id);
      } else
        pending.set(
          id,
          setTimeout(() => {
            pending.delete(id);
            handlers.single(id);
          }, delayMs),
        );
    },
    context(id: string, point: { x: number; y: number }) {
      cancel();
      handlers.context(id, point);
    },
    dispose: cancel,
  };
}
