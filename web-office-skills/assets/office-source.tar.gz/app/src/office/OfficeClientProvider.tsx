import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { OfficeSnapshot, RunProgressEvent } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { applyOfficeEvent, type OfficeEvent } from "./client-events";
interface OfficeClientState {
  snapshot: OfficeSnapshot | null;
  connected: boolean;
  error: string;
  release: boolean;
  subscribeProgress(callback: (event: RunProgressEvent) => void): () => void;
  refresh(): Promise<OfficeSnapshot | undefined>;
}
const Context = createContext<OfficeClientState | null>(null);
export function OfficeClientProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<OfficeSnapshot | null>(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState("");
  const [release, setRelease] = useState(false);
  const alive = useRef(true);
  const progressListeners = useRef(new Set<(event: RunProgressEvent) => void>());
  const subscribeProgress = useCallback((callback: (event: RunProgressEvent) => void) => {
    progressListeners.current.add(callback);
    return () => {
      progressListeners.current.delete(callback);
    };
  }, []);
  const refresh = useCallback(async () => {
    try {
      const next = await officeApi.snapshot();
      if (alive.current) {
        setSnapshot((current) =>
          current ? applyOfficeEvent(current, { type: "office.snapshot", payload: next }) : next,
        );
        setError("");
      }
      return next;
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    alive.current = true;
    let socket: WebSocket | undefined;
    let timer: ReturnType<typeof setTimeout>;
    let stopped = false;
    const connect = async () => {
      await refresh();
      if (stopped) return;
      socket = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
      socket.onopen = () => setConnected(true);
      socket.onmessage = (event) => {
        try {
          const value = JSON.parse(event.data) as OfficeEvent;
          if (value.type === "office.progress") {
            for (const callback of progressListeners.current) callback(value.payload as RunProgressEvent);
          } else if (value.type === "office.release") setRelease(true);
          else setSnapshot((s) => (s ? applyOfficeEvent(s, value) : s));
        } catch {
          /* Ignore unrelated upstream events. */
        }
      };
      socket.onclose = () => {
        if (stopped) return;
        setConnected(false);
        timer = setTimeout(connect, 1800);
      };
      socket.onerror = () => socket?.close();
    };
    void connect();
    const interval = setInterval(() => void refresh(), 15000);
    return () => {
      stopped = true;
      alive.current = false;
      clearTimeout(timer);
      clearInterval(interval);
      socket?.close();
    };
  }, [refresh]);
  return (
    <Context.Provider value={{ snapshot, connected, error, release, refresh, subscribeProgress }}>
      {children}
    </Context.Provider>
  );
}
export function useOptionalOfficeClient() {
  return useContext(Context);
}
export function useOfficeClient() {
  const value = useOptionalOfficeClient();
  if (!value) throw new Error("OfficeClientProvider required");
  return value;
}
