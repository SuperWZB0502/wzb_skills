import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { OfficeSnapshot, RunProgressEvent } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { applyOfficeEvent, type OfficeEvent } from "./client-events";
import { nextReconnectDelay } from "../hooks/useWebSocket";

/** 握手超过这个时间仍未 open，就主动关掉重连（半开连接不会自己触发 close）。 */
const RECONNECT_HANDSHAKE_TIMEOUT_MS = 10_000;
/** 连接稳定这么久才把退避计数清零，避免「连上就断」时退避永远回到 1 秒。 */
const RECONNECT_STABLE_RESET_MS = 5_000;
interface OfficeClientState {
  snapshot: OfficeSnapshot | null;
  connected: boolean;
  error: string;
  release: boolean;
  subscribeProgress(callback: (event: RunProgressEvent) => void): () => void;
  refresh(): Promise<OfficeSnapshot | undefined>;
}
const Context = createContext<OfficeClientState | null>(null);
export function OfficeClientProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<OfficeSnapshot | null>(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState("");
  const [release, setRelease] = useState(false);
  const alive = useRef(true);
  const progressListeners = useRef(new Set<(event: RunProgressEvent) => void>());
  const subscribeProgress = useCallback((callback: (event: RunProgressEvent) => void) => {
    progressListeners.current.add(callback);
    return () => {
      progressListeners.current.delete(callback);
    };
  }, []);
  const refresh = useCallback(async () => {
    try {
      const next = await officeApi.snapshot();
      if (alive.current) {
        setSnapshot((current) =>
          current ? applyOfficeEvent(current, { type: "office.snapshot", payload: next }) : next,
        );
        setError("");
      }
      return next;
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    }
  }, []);
  useEffect(() => {
    alive.current = true;
    let socket: WebSocket | undefined;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;
    let stableTimer: ReturnType<typeof setTimeout> | undefined;
    let handshakeTimer: ReturnType<typeof setTimeout> | undefined;
    let attempt = 0;
    let connecting = false;
    let stopped = false;
    const clearRetry = () => {
      if (retryTimer !== undefined) clearTimeout(retryTimer);
      retryTimer = undefined;
    };
    // 退避重连：1s 起、指数增长、封顶 30s，带抖动；离线时等 online 事件。
    const schedule = (immediate = false) => {
      if (stopped || connecting) return;
      clearRetry();
      if (immediate) {
        attempt = 0;
        retryTimer = setTimeout(() => void connect(), 0);
        return;
      }
      if (typeof navigator !== "undefined" && navigator.onLine === false) return;
      const delay = nextReconnectDelay(attempt);
      attempt += 1;
      retryTimer = setTimeout(() => void connect(), delay);
    };
    const connect = async () => {
      if (stopped || connecting) return;
      connecting = true;
      clearRetry();
      try {
        await refresh();
      } catch {
        /* refresh 自己记录错误；连不上 WS 时由重连驱动 */
      }
      if (stopped) {
        connecting = false;
        return;
      }
      socket = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
      const current = socket;
      // 半开连接不会自己触发 close，握手超时就主动放弃。
      handshakeTimer = setTimeout(() => {
        if (current.readyState !== WebSocket.OPEN) current.close();
      }, RECONNECT_HANDSHAKE_TIMEOUT_MS);
      socket.onopen = () => {
        connecting = false;
        if (handshakeTimer !== undefined) clearTimeout(handshakeTimer);
        if (stopped) return;
        setConnected(true);
        if (stableTimer !== undefined) clearTimeout(stableTimer);
        stableTimer = setTimeout(() => {
          attempt = 0;
        }, RECONNECT_STABLE_RESET_MS);
      };
      socket.onmessage = (event) => {
        try {
          const value = JSON.parse(event.data) as OfficeEvent;
          if (value.type === "office.progress") {
            for (const callback of progressListeners.current) callback(value.payload as RunProgressEvent);
          } else if (value.type === "office.release") setRelease(true);
          else setSnapshot((s) => (s ? applyOfficeEvent(s, value) : s));
        } catch {
          /* Ignore unrelated upstream events. */
        }
      };
      socket.onclose = () => {
        connecting = false;
        if (handshakeTimer !== undefined) clearTimeout(handshakeTimer);
        if (stopped) return;
        setConnected(false);
        schedule();
      };
      socket.onerror = () => socket?.close();
    };
    // 回到前台 / 网络恢复 / 窗口聚焦：已连上就补一次数据，没连上就立刻重连，不等退避。
    const wake = () => {
      if (stopped || connecting) return;
      if (socket?.readyState === WebSocket.OPEN) {
        void refresh();
        return;
      }
      schedule(true);
    };
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") wake();
    };
    void connect();
    const interval = setInterval(() => void refresh(), 15000);
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("online", wake);
    window.addEventListener("focus", wake);
    return () => {
      stopped = true;
      alive.current = false;
      clearRetry();
      if (stableTimer !== undefined) clearTimeout(stableTimer);
      if (handshakeTimer !== undefined) clearTimeout(handshakeTimer);
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("online", wake);
      window.removeEventListener("focus", wake);
      socket?.close();
    };
  }, [refresh]);
  return (
    <Context.Provider value={{ snapshot, connected, error, release, refresh, subscribeProgress }}>
      {children}
    </Context.Provider>
  );
}
export function useOptionalOfficeClient() {
  return useContext(Context);
}
export function useOfficeClient() {
  const value = useOptionalOfficeClient();
  if (!value) throw new Error("OfficeClientProvider required");
  return value;
}
