import { createContext, useCallback, useContext, useEffect, useId, useRef, useState, type CSSProperties, type MouseEvent } from "react";
import { ArrowUp, ChevronLeft, ChevronRight, File, Folder, FolderOpen, Home, Link2, MoreHorizontal, RefreshCw } from "lucide-react";
import type { LocalDirectory, LocalFileEntry, LocalFileOperation } from "../../shared/office-contracts";
import { LocalFileError, officeApi } from "./api";
import { copyCodeText } from "./copy-code-text";
import { ConfirmDialog } from "./ConfirmDialog";
import { LocalFilePreviewDialog, openLocalImage } from "./LocalFilePreviewDialog";
import {
  readDirectoryView, readWorkspaceDirectoryWidth, saveDirectoryView, saveWorkspaceDirectoryWidth,
  workspaceDirectoryMaxWidth, workspaceDirectoryMinWidth, type DirectoryViewState,
} from "./file-browser-state";
import "./file-browser.css";

const STORAGE_KEY = "web-office.file-browser.v1";
type Source = "local" | "remote";
type Preferences = { source: Source; localPath: string };
type CopyTarget = LocalFileEntry & { root?: boolean };
type OpenMenu = (event: MouseEvent<HTMLButtonElement>, entry: CopyTarget) => void;
type FileAction =
  | { action: "file" | "directory"; target: LocalFileEntry }
  | { action: "delete"; target: LocalFileEntry; permanent?: boolean }
  | { action: "paste"; target: LocalFileEntry; source: LocalFileEntry };
let localCopyBuffer: LocalFileEntry | undefined;
const TreeContext = createContext<{
  view: DirectoryViewState;
  select(path: string): void;
  toggle(path: string): void;
  expand(path: string, expanded: boolean): void;
  open(entry: LocalFileEntry): void;
} | null>(null);

function preferences(): Preferences {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null");
    return {
      source: value?.source === "remote" ? "remote" : "local",
      localPath: typeof value?.localPath === "string" && value.localPath.length <= 4096 ? value.localPath : "",
    };
  } catch {
    return { source: "local", localPath: "" };
  }
}

const errorMessage = (error: unknown) => error instanceof Error ? error.message : "无法读取目录。";

function DirectoryContents({ directory, openMenu }: { directory: LocalDirectory; openMenu: OpenMenu }) {
  return (
    <>
      <ul className="file-browser-tree">
        {directory.entries.map((entry) => <DirectoryEntry key={entry.path} entry={entry} openMenu={openMenu} />)}
      </ul>
      {!directory.entries.length && <p className="file-browser-note">此文件夹为空。</p>}
      {directory.truncated && <p className="file-browser-note">此目录条目较多，仅显示首批 {directory.entries.length} 项。</p>}
    </>
  );
}

function DirectoryEntry({ entry, openMenu }: { entry: LocalFileEntry; openMenu: OpenMenu }) {
  const tree = useContext(TreeContext)!;
  const expanded = tree.view.expanded.includes(entry.path);
  const [directory, setDirectory] = useState<LocalDirectory>();
  const [error, setError] = useState("");
  const beforeClick = useRef<boolean | undefined>(undefined);
  const folder = entry.kind === "directory";
  const Icon = folder ? (expanded ? FolderOpen : Folder) : entry.kind === "link" ? Link2 : File;
  useEffect(() => {
    if (!expanded || directory) return;
    let current = true;
    setError("");
    void officeApi.localDirectory(entry.path).then((result) => {
      if (current) setDirectory(result);
    }, (failure: unknown) => {
      if (current) setError(errorMessage(failure));
    });
    return () => { current = false; };
  }, [directory, entry.path, expanded]);

  return (
    <li>
      <div className="file-browser-row">
        {folder ? (
          <button type="button" className="file-browser-expand" aria-label={(expanded ? "折叠 " : "展开 ") + entry.name}
            aria-expanded={expanded} onClick={() => tree.toggle(entry.path)}>
            <ChevronRight className={expanded ? "file-browser-expanded" : ""} size={14} aria-hidden="true" />
          </button>
        ) : <span className="file-browser-indent" />}
        <button type="button" className={"file-browser-item" + (entry.path === tree.view.selected ? " is-selected" : "")} title={entry.name}
          onClick={(event) => {
            tree.select(entry.path);
            if (!folder) return;
            if (event.detail === 1) beforeClick.current = expanded;
            if (event.detail <= 1) tree.toggle(entry.path);
          }}
          onDoubleClick={() => {
            if (folder && beforeClick.current !== undefined) tree.expand(entry.path, beforeClick.current);
            beforeClick.current = undefined;
            tree.open(entry);
          }}
          onKeyDown={(event) => {
            if (event.key === "Enter") { event.preventDefault(); tree.open(entry); }
          }}
          onContextMenu={(event) => openMenu(event, entry)}>
          <Icon className={folder ? "file-browser-folder-icon" : ""} size={16} aria-hidden="true" />
          <span>{entry.name}</span>
        </button>
        <button type="button" className="file-browser-more" title="路径操作" aria-label={entry.name + " 的路径操作"}
          onClick={(event) => openMenu(event, entry)}><MoreHorizontal size={16} aria-hidden="true" /></button>
      </div>
      {expanded && (
        <div className="file-browser-children">
          {!directory && !error && <p className="file-browser-note" role="status">正在读取…</p>}
          {error && <p className="file-browser-note" role="alert">{error}</p>}
          {directory && <DirectoryContents directory={directory} openMenu={openMenu} />}
        </div>
      )}
    </li>
  );
}

function LocalBrowser({ initialPath, onNavigate, writeEnabled, agentId }: {
  initialPath: string;
  onNavigate(path: string): void;
  writeEnabled: boolean;
  agentId?: string;
}) {
  const [startPath] = useState(initialPath);
  const [path, setPath] = useState(initialPath);
  const [current, setCurrent] = useState<LocalDirectory>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [revision, setRevision] = useState(0);
  const [view, setView] = useState(() => readDirectoryView(initialPath));
  const viewRef = useRef(view);
  const directoryRef = useRef("");
  const pane = useRef<HTMLDivElement>(null);
  const treeContents = useRef<HTMLDivElement>(null);
  const restoreScroll = useRef<number | undefined>(undefined);
  const [preview, setPreview] = useState<LocalFileEntry>();
  const [copied, setCopied] = useState(localCopyBuffer);
  const [fileAction, setFileAction] = useState<FileAction>();
  const [actionName, setActionName] = useState("");
  const [actionError, setActionError] = useState("");
  const [actionBusy, setActionBusy] = useState(false);
  const [recycleFailed, setRecycleFailed] = useState(false);
  const [menu, setMenu] = useState<{ entry: CopyTarget; left: number; top: number; trigger: HTMLButtonElement }>();
  const menuRef = useRef<HTMLDivElement>(null);
  const request = useRef(0);

  function updateView(update: (state: DirectoryViewState) => DirectoryViewState) {
    viewRef.current = update(viewRef.current);
    setView(viewRef.current);
    if (directoryRef.current) saveDirectoryView(directoryRef.current, viewRef.current);
  }

  function showDirectory(result: LocalDirectory) {
    directoryRef.current = result.path;
    viewRef.current = readDirectoryView(result.path);
    restoreScroll.current = viewRef.current.scrollTop;
    setView(viewRef.current);
    setCurrent(result);
    setPath(result.path);
    onNavigate(result.path);
  }

  useEffect(() => {
    let active = true;
    const id = ++request.current;
    setLoading(true);
    (async () => {
      try {
        const result = await officeApi.localDirectory(startPath, agentId).catch((error: unknown) => {
          if (!active || !startPath) throw error;
          return officeApi.localDirectory("");
        });
        if (!active || id !== request.current) return;
        showDirectory(result);
      } catch (error) {
        if (active && id === request.current) setError(errorMessage(error));
      } finally {
        if (active && id === request.current) setLoading(false);
      }
    })();
    return () => { active = false; ++request.current; };
  }, [agentId, startPath, onNavigate]);

  useEffect(() => {
    const element = pane.current;
    const contents = treeContents.current;
    if (!element || !contents) return;
    const restore = () => {
      const wanted = restoreScroll.current;
      if (wanted === undefined) return;
      element.scrollTop = wanted;
      if (Math.abs(element.scrollTop - wanted) < 1) restoreScroll.current = undefined;
    };
    restore();
    const observer = new ResizeObserver(restore);
    observer.observe(contents);
    return () => observer.disconnect();
  }, [current]);

  async function navigate(target: string) {
    const id = ++request.current;
    setLoading(true);
    setError("");
    setNotice("");
    setMenu(undefined);
    try {
      const result = await officeApi.localDirectory(target, target === "" ? agentId : undefined);
      if (id !== request.current) return;
      showDirectory(result);
      setRevision((value) => value + 1);
    } catch (error) {
      if (id === request.current) setError(errorMessage(error));
    } finally {
      if (id === request.current) setLoading(false);
    }
  }

  const openMenu: OpenMenu = (event, entry) => {
    event.preventDefault();
    updateView((state) => ({ ...state, selected: entry.path }));
    const bounds = event.currentTarget.getBoundingClientRect();
    setMenu({
      entry,
      left: Math.max(8, Math.min(event.clientX || bounds.left, window.innerWidth - 184)),
      top: Math.max(8, Math.min(event.clientY || bounds.bottom, window.innerHeight - (writeEnabled ? 280 : 110))),
      trigger: event.currentTarget,
    });
  };

  useEffect(() => {
    if (!menu) return;
    menuRef.current?.querySelector("button")?.focus({ preventScroll: true });
    const dismiss = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setMenu(undefined);
    };
    const resize = () => setMenu(undefined);
    document.addEventListener("pointerdown", dismiss);
    window.addEventListener("resize", resize);
    return () => {
      document.removeEventListener("pointerdown", dismiss);
      window.removeEventListener("resize", resize);
    };
  }, [menu]);

  async function copy(value: string) {
    setMenu(undefined);
    menu?.trigger.focus();
    try {
      await copyCodeText(value, () => Boolean(menu?.trigger.isConnected));
      setNotice("已复制路径。");
    } catch {
      setNotice("未能写入剪贴板。");
    }
  }

  function openEntry(entry: LocalFileEntry) {
    setNotice("");
    if (entry.kind === "directory") void navigate(entry.path);
    else if (entry.preview === "image") openLocalImage(entry, setNotice);
    else if (entry.preview) setPreview(entry);
    else setNotice("不支持预览这种文件。");
  }

  function beginAction(action: FileAction) {
    setMenu(undefined);
    setActionName("");
    setActionError("");
    setRecycleFailed(false);
    setFileAction(action);
  }

  async function submitAction() {
    if (!fileAction || actionBusy) return;
    const { action, target } = fileAction;
    const operation: LocalFileOperation = action === "delete"
      ? { action, path: target.path, permanent: fileAction.permanent, confirmName: actionName }
      : action === "paste"
        ? { action, directory: target.path, source: fileAction.source.path }
        : { action, directory: target.path, name: actionName };
    setActionBusy(true);
    setActionError("");
    try {
      await officeApi.localFileOperation(operation);
      setFileAction(undefined);
      if (current) await navigate(current.path);
      setNotice("文件操作已完成。");
    } catch (failure) {
      setActionError(errorMessage(failure));
      setRecycleFailed(failure instanceof LocalFileError && failure.code === "local_file_recycle_unavailable");
    } finally {
      setActionBusy(false);
    }
  }

  const rootEntry: CopyTarget | undefined = current && {
    name: current.path.split(/[\\/]/).filter(Boolean).at(-1) ?? current.path,
    kind: "directory", path: current.path, relativePath: current.relativePath, root: true,
  };
  const directoryTarget = menu?.entry.kind === "directory" ? menu.entry : rootEntry;

  return (
    <TreeContext.Provider value={{
      view,
      select: (target) => updateView((state) => ({ ...state, selected: target })),
      toggle: (target) => updateView((state) => ({
        ...state, expanded: state.expanded.includes(target) ? state.expanded.filter((item) => item !== target)
          : [...state.expanded.slice(-127), target],
      })),
      expand: (target, expanded) => updateView((state) => ({
        ...state, expanded: expanded ? [...state.expanded.filter((item) => item !== target).slice(-127), target]
          : state.expanded.filter((item) => item !== target),
      })),
      open: openEntry,
    }}>
      <form className="file-browser-address" onSubmit={(event) => { event.preventDefault(); void navigate(path); }}>
        <button type="button" title={agentId ? "Agent 工作目录" : "工作区"} aria-label={agentId ? "Agent 工作目录" : "工作区"}
          onClick={() => void navigate("")}><Home size={16} /></button>
        <button type="button" title="上一级" aria-label="上一级" disabled={!current?.parent} onClick={() => void navigate(current?.parent ?? "")}><ArrowUp size={16} /></button>
        <input aria-label="目录路径" placeholder="输入目录路径" value={path} spellCheck={false} onChange={(event) => setPath(event.target.value)} />
        <button type="submit" disabled={loading}>跳转</button>
        <button type="button" title="刷新目录" aria-label="刷新目录" disabled={loading || !current} onClick={() => void navigate(current?.path ?? "")}><RefreshCw size={16} /></button>
      </form>
      {error && <p className="file-browser-error" role="alert">{error}</p>}
      <div ref={pane} className="file-browser-pane" aria-label="文件目录" aria-busy={loading}
        onWheel={() => { restoreScroll.current = undefined; setMenu(undefined); }}
        onPointerDown={() => { restoreScroll.current = undefined; }}
        onScroll={(event) => {
          if (restoreScroll.current !== undefined || !directoryRef.current) return;
          const scrollTop = event.currentTarget.scrollTop;
          viewRef.current = { ...viewRef.current, scrollTop };
          saveDirectoryView(directoryRef.current, viewRef.current);
        }}
        onContextMenu={(event) => {
          if (!rootEntry || event.target !== event.currentTarget) return;
          event.preventDefault();
          pane.current?.querySelector<HTMLButtonElement>(".file-browser-root button")?.dispatchEvent(new MouseEvent("contextmenu", {
            bubbles: true, clientX: event.clientX, clientY: event.clientY,
          }));
        }}>
        {loading && <p className="file-browser-note" role="status">正在读取…</p>}
        {current && rootEntry && (
          <div ref={treeContents}>
            <div className="file-browser-root">
              <button type="button" title={current.path} className="file-browser-item" onContextMenu={(event) => openMenu(event, rootEntry)}
                onClick={(event) => openMenu(event, rootEntry)}>
                <FolderOpen size={16} aria-hidden="true" /><span>{current.path}</span>
              </button>
            </div>
            <DirectoryContents key={revision} directory={current} openMenu={openMenu} />
          </div>
        )}
      </div>
      <div className="file-browser-status" role="status">{notice}</div>
      {menu && (
        <div className="file-browser-menu" ref={menuRef} style={{ left: menu.left, top: menu.top }}
          role="group" aria-label="路径操作" onKeyDown={(event) => {
            if (event.key !== "Escape") return;
            event.preventDefault();
            event.stopPropagation();
            setMenu(undefined);
            menu.trigger.focus();
          }}>
          {writeEnabled && directoryTarget && (
            <>
              <button type="button" onClick={() => beginAction({ action: "file", target: directoryTarget })}>新建文件</button>
              <button type="button" onClick={() => beginAction({ action: "directory", target: directoryTarget })}>新建文件夹</button>
              {!menu.entry.root && menu.entry.kind !== "link" && (
                <button type="button" onClick={() => {
                  localCopyBuffer = menu.entry;
                  setCopied(menu.entry);
                  setMenu(undefined);
                  setNotice("已复制：" + menu.entry.name);
                }}>复制</button>
              )}
              <button type="button" disabled={!copied} onClick={() => copied && beginAction({ action: "paste", target: directoryTarget, source: copied })}>粘贴</button>
              {!menu.entry.root && menu.entry.kind !== "link" && (
                <button type="button" onClick={() => beginAction({ action: "delete", target: menu.entry })}>删除</button>
              )}
            </>
          )}
          <button type="button" onClick={() => void copy(menu.entry.path)}>复制路径</button>
          <button type="button" disabled={menu.entry.relativePath === null}
            title={menu.entry.relativePath === null ? "与工作区不在同一驱动器" : undefined}
            onClick={() => menu.entry.relativePath !== null && void copy(menu.entry.relativePath)}>复制相对路径</button>
        </div>
      )}
      {preview && <LocalFilePreviewDialog entry={preview} onClose={() => setPreview(undefined)} />}
      {fileAction && (
        <ConfirmDialog title={fileAction.action === "delete"
          ? fileAction.permanent ? "永久删除" : "移入回收站"
          : fileAction.action === "paste" ? "粘贴" : fileAction.action === "directory" ? "新建文件夹" : "新建文件"}
          subtitle={fileAction.target.path} confirmLabel={fileAction.action === "delete" ? "确认删除" : "确认"}
          tone={fileAction.action === "delete" ? "danger" : "primary"} error={actionError}
          busy={actionBusy} onConfirm={() => void submitAction()} onClose={() => setFileAction(undefined)}>
          {(fileAction.action === "file" || fileAction.action === "directory" ||
            (fileAction.action === "delete" && fileAction.permanent)) && (
            <label className="file-browser-name-input">
              {fileAction.action === "delete" ? "输入名称确认：" + fileAction.target.name : "名称"}
              <input type="text" value={actionName} onChange={(event) => setActionName(event.target.value)} />
            </label>
          )}
          {fileAction.action === "paste" && <p>复制「{fileAction.source.name}」，不会覆盖同名项目。</p>}
          {fileAction.action === "delete" && !fileAction.permanent && <p>将「{fileAction.target.name}」移入 Windows 回收站。</p>}
          {recycleFailed && <button type="button" className="danger" onClick={() =>
            beginAction({ action: "delete", target: fileAction.target, permanent: true })}>改为永久删除</button>}
        </ConfirmDialog>
      )}
    </TreeContext.Provider>
  );
}

function FileBrowserContents({ localEnabled, writeEnabled, agentId }: { localEnabled: boolean; writeEnabled: boolean; agentId?: string }) {
  const [saved, setSaved] = useState(() => agentId ? { source: "local" as const, localPath: "" } : preferences());
  const saveLocation = useCallback((path: string) => {
    setSaved((value) => value.localPath === path ? value : { ...value, localPath: path });
  }, []);
  useEffect(() => {
    if (agentId) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    } catch {
      return;
    }
  }, [agentId, saved]);
  return (
    <div className="file-browser-body">
      <label className="file-browser-source">
        <span>目录来源</span>
        <select value={saved.source} onChange={(event) =>
          setSaved({ ...saved, source: event.target.value === "remote" ? "remote" : "local" })}>
          <option value="local">本地文件</option>
          <option value="remote">远程服务器（预留）</option>
        </select>
      </label>
      {saved.source === "remote" ? (
        <div className="file-browser-empty">远程目录尚未接入。</div>
      ) : localEnabled ? (
        <LocalBrowser initialPath={agentId ? "" : saved.localPath} onNavigate={saveLocation} writeEnabled={writeEnabled} agentId={agentId} />
      ) : (
        <div className="file-browser-empty">当前实例未启用本地文件浏览。</div>
      )}
    </div>
  );
}

export function FileBrowserDock({ open, onOpenChange, placement, localEnabled, writeEnabled = false, agentId }: {
  open: boolean;
  onOpenChange(open: boolean): void;
  placement: "workspace" | "chat";
  localEnabled: boolean;
  writeEnabled?: boolean;
  agentId?: string;
}) {
  const panelId = useId();
  const toggle = useRef<HTMLButtonElement>(null);
  const closeOnBackdrop = placement === "workspace";
  const [workspaceWidth, setWorkspaceWidth] = useState(readWorkspaceDirectoryWidth);
  const [viewportWidth, setViewportWidth] = useState(() => document.documentElement.clientWidth);
  const drag = useRef<{ pointerId: number; startX: number; startWidth: number; latest: number | null } | null>(null);
  const dock = useRef<HTMLDivElement>(null);
  const maxWidth = Math.min(workspaceDirectoryMaxWidth, Math.max(1, viewportWidth - 32));
  const minWidth = Math.min(workspaceDirectoryMinWidth, maxWidth);
  const constrainWidth = (width: number) => Math.round(Math.max(minWidth, Math.min(maxWidth, width)));
  const displayedWidth = constrainWidth(workspaceWidth);
  useEffect(() => {
    if (placement !== "workspace") return;
    const measure = () => setViewportWidth(document.documentElement.clientWidth);
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [placement]);
  const actionLabel = open ? "收起目录浏览器" : "展开目录浏览器";
  const Arrow = open || placement === "chat" ? ChevronLeft : ChevronRight;
  const close = () => {
    onOpenChange(false);
    toggle.current?.focus();
  };
  return (
    <>
      {open && closeOnBackdrop && <div className="file-browser-dismiss-surface" aria-hidden="true" onClick={close} />}
      <div ref={dock} className={`file-browser-dock is-${placement}` + (open ? " is-open" : "")}
        style={closeOnBackdrop ? { "--file-browser-panel-width": `${displayedWidth}px` } as CSSProperties : undefined}
        onKeyDown={(event) => {
        if (!open || event.key !== "Escape" || event.defaultPrevented || !event.currentTarget.contains(event.target as Node)) return;
        event.preventDefault();
        event.stopPropagation();
        if (closeOnBackdrop) close();
      }}>
        <button ref={toggle} type="button" className="icon-button file-browser-toggle" title={actionLabel}
          aria-label={actionLabel} aria-expanded={open} aria-controls={panelId} onClick={() => open ? close() : onOpenChange(true)}>
          <Arrow size={15} aria-hidden="true" />
        </button>
        <aside id={panelId} className="file-browser-side-panel" aria-label="目录浏览器" hidden={!open}>
          {open && (
            <>
              <h2 className="file-browser-side-title">目录浏览器</h2>
              <FileBrowserContents localEnabled={localEnabled} writeEnabled={writeEnabled} agentId={agentId} />
            </>
          )}
        </aside>
        {open && closeOnBackdrop && (
          <div className="file-browser-resize-handle" role="separator" aria-label="目录宽度" aria-orientation="vertical"
            aria-controls={panelId} aria-valuemin={minWidth} aria-valuemax={maxWidth} aria-valuenow={displayedWidth}
            title="拖拽调整目录宽度" tabIndex={0}
            onPointerDown={(event) => {
              if (event.button !== 0 || !event.isPrimary) return;
              event.preventDefault();
              event.currentTarget.focus({ preventScroll: true });
              event.currentTarget.setPointerCapture(event.pointerId);
              drag.current = { pointerId: event.pointerId, startX: event.clientX,
                startWidth: dock.current?.getBoundingClientRect().width ?? displayedWidth, latest: null };
            }}
            onPointerMove={(event) => {
              const active = drag.current;
              if (!active || active.pointerId !== event.pointerId) return;
              const width = constrainWidth(active.startWidth + event.clientX - active.startX);
              if (width === active.latest || (active.latest === null && width === displayedWidth)) return;
              active.latest = width;
              setWorkspaceWidth(width);
            }}
            onLostPointerCapture={(event) => {
              const active = drag.current;
              if (!active || active.pointerId !== event.pointerId) return;
              drag.current = null;
              if (active.latest !== null) saveWorkspaceDirectoryWidth(active.latest);
            }}
            onKeyDown={(event) => {
              const width = event.key === "ArrowLeft" ? displayedWidth - 24
                : event.key === "ArrowRight" ? displayedWidth + 24
                : event.key === "Home" ? minWidth
                : event.key === "End" ? maxWidth : undefined;
              if (width === undefined) return;
              event.preventDefault();
              const next = constrainWidth(width);
              if (next === displayedWidth) return;
              setWorkspaceWidth(next);
              saveWorkspaceDirectoryWidth(next);
            }} />
        )}
      </div>
    </>
  );
}
