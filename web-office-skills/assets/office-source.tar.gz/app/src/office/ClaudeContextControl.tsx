import { useId } from "react";

export function ClaudeContextControl({
  checked,
  hasModel,
  disabled = false,
  compact = false,
  onChange,
}: {
  checked: boolean;
  hasModel: boolean;
  disabled?: boolean;
  compact?: boolean;
  onChange(checked: boolean): void;
}) {
  const descriptionId = useId();
  const explanation = "请仅在已确认服务和所选模型支持 1M 时勾选；这是手动配置，不会自动检测能力，仅对后续任务生效。";
  return (
    <div className={"claude-context-control" + (compact ? " is-compact" : "")}>
      <label title={explanation}>
        <input
          type="checkbox"
          checked={hasModel && checked}
          disabled={disabled || !hasModel}
          aria-describedby={descriptionId}
          onChange={(event) => onChange(event.target.checked)}
        />
        <span>1M 长上下文</span>
        {compact && <small>需服务支持</small>}
      </label>
      <p id={descriptionId} className={compact ? "sr-only" : "hint"}>
        {explanation}
      </p>
    </div>
  );
}
