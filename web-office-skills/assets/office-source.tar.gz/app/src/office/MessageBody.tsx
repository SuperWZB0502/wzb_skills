import { isValidElement, memo, useCallback, useMemo, useState } from "react";
import ReactMarkdown, { defaultUrlTransform, type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import type { OfficeMessage } from "../../shared/office-contracts";
import { MarkdownCodeBlock } from "./MarkdownCodeBlock";
import { MarkdownPreviewDialog } from "./MarkdownPreviewDialog";
import {
  fileModeOf,
  isMarkdownHref,
  isRelativeHref,
  isWorkspaceFileHref,
  resolveRelativePath,
  splitWorkspaceHref,
  workspaceFileUrl,
} from "./file-links";
import "./message-markdown.css";

const plugins = [remarkGfm];
const officeFilePrefix = "/api/office/agents/";
/** Our own pre-encoded office file URLs must survive sanitisation untouched; everything else uses the default policy. */
const safeUrlTransform = (url: string) => (url.startsWith(officeFilePrefix) ? url : defaultUrlTransform(url));
const fileKindLabel = { download: "下载", inline: "查看", view: "在线打开", markdown: "预览" } as const;

/**
 * Relative links from an assistant reply point at files in its own workspace. When a
 * Markdown document is previewed, its own links resolve against that document's folder,
 * and nested Markdown links open another preview instead of downloading the source.
 */
function markdownComponents(agentId?: string, basePath?: string, onPreview?: (path: string) => void): Components {
  const resolve = (href: string) =>
    basePath && isRelativeHref(href) ? (resolveRelativePath(basePath, href) ?? href) : href;
  const fileUrl = (href: string, mode?: "download" | "inline" | "view") =>
    agentId ? workspaceFileUrl(agentId, href, mode) : href;
  return {
    pre({ children, node }) {
      const language = isValidElement<{ className?: string }>(children)
        ? /(?:^|\s)language-([\w+-]+)/.exec(children.props.className || "")?.[1]
        : undefined;
      const code = node?.children.find((child) => child.type === "element" && child.tagName === "code");
      const text =
        code?.type === "element" && code.children.every((child) => child.type === "text")
          ? code.children.map((child) => (child.type === "text" ? child.value : "")).join("")
          : null;
      return (
        <MarkdownCodeBlock language={language} text={text}>
          {children}
        </MarkdownCodeBlock>
      );
    },
    table({ children }) {
      return (
        <div className="markdown-table-scroll" tabIndex={0} role="region" aria-label="Markdown 表格">
          <table>{children}</table>
        </div>
      );
    },
    a({ href, children, title }) {
      if (!href) return <span>{children}</span>;
      const target = resolve(href);
      if (agentId && isWorkspaceFileHref(target)) {
        // The anchor belongs to the browser URL, never to the file the API reads.
        const { path } = splitWorkspaceHref(target);
        // A markdown document is previewed whole; its own anchor kept the API path broken before.
        if (isMarkdownHref(path) && onPreview) {
          return (
            <a
              className="workspace-file-link"
              href={fileUrl(target, "download")}
              title={title ?? path}
              onClick={(event) => {
                // Keep modifier clicks and middle clicks working as a real download link.
                if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
                event.preventDefault();
                onPreview(path);
              }}
            >
              {children}
              <span className="workspace-file-kind">{fileKindLabel.markdown}</span>
            </a>
          );
        }
        const mode = fileModeOf(path);
        return (
          <a
            className="workspace-file-link"
            href={fileUrl(target)}
            title={title ?? target}
            target="_blank"
            rel="noopener noreferrer"
            download={mode === "download" ? "" : undefined}
          >
            {children}
            <span className="workspace-file-kind">{fileKindLabel[mode]}</span>
          </a>
        );
      }
      return (
        <a href={href} title={title} target="_blank" rel="noopener noreferrer">
          {children}
        </a>
      );
    },
    // Workspace images render inline; other remote Markdown images still open on demand.
    img({ src, alt, title }) {
      if (!src) return <span>{alt}</span>;
      const target = resolve(src);
      if (agentId && isWorkspaceFileHref(target)) {
        const url = workspaceFileUrl(agentId, target, "inline");
        return (
          <a
            className="message-inline-image"
            href={url}
            title={title ?? alt ?? src}
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={url} alt={alt ?? ""} loading="lazy" />
          </a>
        );
      }
      return (
        <a href={src} title={title} target="_blank" rel="noopener noreferrer">
          查看图片{alt ? `：${alt}` : ""}
        </a>
      );
    },
  };
}

export const MessageBody = memo(function MessageBody({
  content,
  role,
  agentId,
  basePath,
}: {
  content: string;
  role: OfficeMessage["role"];
  agentId?: string;
  /** Workspace path of the document being previewed, so its relative links keep working. */
  basePath?: string;
}) {
  const [previewPath, setPreviewPath] = useState<string | null>(null);
  const openPreview = useCallback((path: string) => setPreviewPath(path), []);
  const closePreview = useCallback(() => setPreviewPath(null), []);
  const components = useMemo(
    () => markdownComponents(agentId, basePath, openPreview),
    [agentId, basePath, openPreview],
  );
  if (!content) return null;
  if (role !== "assistant") return <div className="message-content">{content}</div>;
  return (
    <>
      <div className="message-content markdown-body">
        <ReactMarkdown remarkPlugins={plugins} components={components} skipHtml urlTransform={safeUrlTransform}>
          {content}
        </ReactMarkdown>
      </div>
      {previewPath && agentId && <MarkdownPreviewDialog agentId={agentId} path={previewPath} onClose={closePreview} />}
    </>
  );
});
