import { isValidElement, memo, useMemo } from "react";
import ReactMarkdown, { defaultUrlTransform, type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import type { OfficeMessage } from "../../shared/office-contracts";
import { MarkdownCodeBlock } from "./MarkdownCodeBlock";
import { fileModeOf, isWorkspaceFileHref, workspaceFileUrl } from "./file-links";
import "./message-markdown.css";

const plugins = [remarkGfm];
const officeFilePrefix = "/api/office/agents/";
/** Our own pre-encoded office file URLs must survive sanitisation untouched; everything else uses the default policy. */
const safeUrlTransform = (url: string) => (url.startsWith(officeFilePrefix) ? url : defaultUrlTransform(url));
const fileKindLabel = { download: "下载", inline: "查看", view: "在线打开" } as const;

/** Relative links from an assistant reply point at files in its own workspace. */
function markdownComponents(agentId?: string): Components {
  const fileUrl = (href: string) => (agentId ? workspaceFileUrl(agentId, href) : href);
  return {
    pre({ children, node }) {
      const language = isValidElement<{ className?: string }>(children)
        ? /(?:^|\s)language-([\w+-]+)/.exec(children.props.className || "")?.[1]
        : undefined;
      const code = node?.children.find((child) => child.type === "element" && child.tagName === "code");
      const text =
        code?.type === "element" && code.children.every((child) => child.type === "text")
          ? code.children.map((child) => (child.type === "text" ? child.value : "")).join("")
          : null;
      return (
        <MarkdownCodeBlock language={language} text={text}>
          {children}
        </MarkdownCodeBlock>
      );
    },
    table({ children }) {
      return (
        <div className="markdown-table-scroll" tabIndex={0} role="region" aria-label="Markdown 表格">
          <table>{children}</table>
        </div>
      );
    },
    a({ href, children, title }) {
      if (!href) return <span>{children}</span>;
      if (agentId && isWorkspaceFileHref(href)) {
        const mode = fileModeOf(href);
        return (
          <a
            className="workspace-file-link"
            href={fileUrl(href)}
            title={title ?? href}
            target="_blank"
            rel="noopener noreferrer"
            download={mode === "download" ? "" : undefined}
          >
            {children}
            <span className="workspace-file-kind">{fileKindLabel[mode]}</span>
          </a>
        );
      }
      return (
        <a href={href} title={title} target="_blank" rel="noopener noreferrer">
          {children}
        </a>
      );
    },
    // Workspace images render inline; other remote Markdown images still open on demand.
    img({ src, alt, title }) {
      if (!src) return <span>{alt}</span>;
      if (agentId && isWorkspaceFileHref(src)) {
        const url = workspaceFileUrl(agentId, src, "inline");
        return (
          <a
            className="message-inline-image"
            href={url}
            title={title ?? alt ?? src}
            target="_blank"
            rel="noopener noreferrer"
          >
            <img src={url} alt={alt ?? ""} loading="lazy" />
          </a>
        );
      }
      return (
        <a href={src} title={title} target="_blank" rel="noopener noreferrer">
          查看图片{alt ? `：${alt}` : ""}
        </a>
      );
    },
  };
}

export const MessageBody = memo(function MessageBody({
  content,
  role,
  agentId,
}: {
  content: string;
  role: OfficeMessage["role"];
  agentId?: string;
}) {
  const components = useMemo(() => markdownComponents(agentId), [agentId]);
  if (!content) return null;
  if (role !== "assistant") return <div className="message-content">{content}</div>;
  return (
    <div className="message-content markdown-body">
      <ReactMarkdown remarkPlugins={plugins} components={components} skipHtml urlTransform={safeUrlTransform}>
        {content}
      </ReactMarkdown>
    </div>
  );
});
