import { useEffect, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
export function Modal({
  title,
  onClose,
  children,
  className = "",
  subtitle,
}: {
  title: string;
  onClose(): void;
  children: ReactNode;
  className?: string;
  subtitle?: string;
}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const handler = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      const dialogs = document.querySelectorAll('[role="dialog"]');
      if (dialogs[dialogs.length - 1] !== ref.current) return;
      if (event.key === "Escape") {
        if (document.fullscreenElement) return;
        event.preventDefault();
        event.stopPropagation();
        onClose();
      }
      if (event.key === "Tab") {
        const nativeReader = document.fullscreenElement;
        const scope =
          (nativeReader && ref.current?.contains(nativeReader) ? nativeReader : null) ??
          ref.current?.querySelector('[data-fullscreen-reader="true"]') ??
          ref.current;
        const items = scope?.querySelectorAll<HTMLElement>(
          'button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex="0"]',
        );
        if (!items?.length) return;
        const first = items[0],
          last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          last.focus();
          event.preventDefault();
        } else if (!event.shiftKey && document.activeElement === last) {
          first.focus();
          event.preventDefault();
        }
      }
    };
    document.addEventListener("keydown", handler);
    const focusTimer = setTimeout(() => ref.current?.querySelector<HTMLElement>("input,textarea,button")?.focus(), 0);
    return () => {
      clearTimeout(focusTimer);
      document.removeEventListener("keydown", handler);
      previous?.focus();
    };
  }, [onClose]);
  return createPortal(
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section ref={ref} role="dialog" aria-modal="true" aria-label={title} className={"modal " + className}>
        <header className="modal-header">
          <div>
            <span className="eyebrow">{subtitle || "同席工作室"}</span>
            <h2>{title}</h2>
          </div>
          <button className="icon-button" aria-label="关闭" onClick={onClose}>
            ×
          </button>
        </header>
        {children}
      </section>
    </div>,
    document.body,
  );
}
