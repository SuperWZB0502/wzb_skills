import { useEffect, useRef, useState } from "react";
import type { AgentProfile, OfficeMessage, ConversationContextReference } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { MessageBody } from "./MessageBody";
import { useReaderFullscreen } from "./useReaderFullscreen";
import { Modal } from "./Modal";
import { ConversationControls } from "./ConversationControls";
import { CompanyKnowledgeDialog } from "./CompanyKnowledgeDialog";
import { useAgentConversations } from "./useAgentConversations";
import { stateLabels, roleLabels } from "./labels";
import { ChatModelControls } from "./ChatModelControls";
import { FileBrowserDock } from "./FileBrowserDialog";
import { useChatAttachments } from "./useChatAttachments";
import { AttachmentDrafts } from "./AttachmentDrafts";
import { useRunProgress } from "./useRunProgress";
import { useAutoConversationTitle } from "./useAutoConversationTitle";
import { clearChatDraft, readChatDraft, writeChatDraft } from "./draft-storage";
import { TaskProgressPanel, type ChatSubmission } from "./TaskProgressPanel";
import { contextBadgeLabel, contextBadgeTitle } from "./context-usage";
export function AgentChatDialog({
  agent,
  onClose,
  onCredential,
  onSent,
  archived = false,
  localFileBrowserEnabled = false,
  localFileWriteEnabled = false,
}: {
  agent: AgentProfile;
  archived?: boolean;
  localFileBrowserEnabled?: boolean;
  localFileWriteEnabled?: boolean;
  onClose(): void;
  onCredential(): void;
  onSent(): void;
}) {
  const sessions = useAgentConversations(agent.id, archived);
  const conversationId = sessions.conversationId;
  const currentConversation = useRef({ agentId: agent.id, id: conversationId });
  if (currentConversation.current.agentId !== agent.id || currentConversation.current.id !== conversationId)
    currentConversation.current = { agentId: agent.id, id: conversationId };
  const conversationSelection = currentConversation.current;
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const updateConversation = sessions.update;
  const [loadedConversationId, setLoadedConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<OfficeMessage[]>([]);
  const visibleMessages = loadedConversationId === conversationId ? messages : [];
  const conversationContext = sessions.conversations.find((item) => item.id === conversationId)?.context;
  const [references, setReferences] = useState<ConversationContextReference[]>([]);
  const [knowledgeOpen, setKnowledgeOpen] = useState(false);
  const [fileBrowserOpen, setFileBrowserOpen] = useState(false);
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [runId, setRunId] = useState<string | null>(null);
  const [submission, setSubmission] = useState<ChatSubmission | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const attachments = useChatAttachments(agent.id);
  const progress = useRunProgress(agent.id, !archived && Boolean(conversationId), conversationId);
  const profileBelongsHere = Boolean(
    conversationId &&
    (agent.currentConversationId === conversationId ||
      progress.events.some((event) => event.runId === agent.currentRunId) ||
      (submission?.runId && submission.runId === agent.currentRunId)),
  );
  const progressAgent: AgentProfile = profileBelongsHere
    ? agent
    : { ...agent, currentRunId: null, currentWorkSummary: "", currentTaskId: null, workState: "idle" };
  useAutoConversationTitle({
    conversation: sessions.conversations.find((item) => item.id === conversationId) ?? null,
    messages: visibleMessages,
    enabled: !archived && !loading && !sessions.loading && loadedConversationId === conversationId,
    onUpdated: updateConversation,
  });
  const scroll = useRef<HTMLDivElement>(null);
  const reader = useRef<HTMLElement>(null);
  const fullscreen = useReaderFullscreen(reader);
  const fileInput = useRef<HTMLInputElement>(null);
  const requestKey = useRef<string | null>(null);
  const followBottom = useRef(true),
    jumpToBottom = useRef(true),
    composing = useRef(false),
    sendingLock = useRef(false);
  const activeRunId = agent.currentRunId !== undefined ? agent.currentRunId : runId;
  const canStop =
    !archived &&
    profileBelongsHere &&
    Boolean(activeRunId) &&
    ["working", "meeting", "waiting_input"].includes(agent.workState);
  const filesReady = attachments.items.every((item) => item.status === "uploaded" && item.attachment);
  const hasPayload = Boolean(content.trim()) || attachments.items.length > 0;
  const sendDisabled = sending || !hasPayload || !filesReady || !conversationId || sessions.loading;
  const stopControl = canStop && (
    <button
      type="button"
      onClick={async () => {
        try {
          await officeApi.stop(activeRunId!);
          setRunId(null);
          onSent();
        } catch (e) {
          setError((e as Error).message);
        }
      }}
    >
      停止任务
    </button>
  );
  useEffect(() => {
    let alive = true;
    setMessages([]);
    setContent(readChatDraft(conversationId));
    setError("");
    setLoading(true);
    setRunId(null);
    setSubmission(null);
    requestKey.current = null;
    followBottom.current = true;
    jumpToBottom.current = true;
    if (!conversationId) {
      setLoading(false);
      return;
    }
    const load = () =>
      officeApi
        .conversationMessages(conversationId)
        .then((result) => {
          if (alive) {
            setMessages(result.messages);
            setLoadedConversationId(conversationId);
            updateConversation(result.conversation);
            setLoading(false);
          }
        })
        .catch(() => {
          if (alive) {
            setError("暂时无法读取对话记录。");
            setLoading(false);
          }
        });
    void load();
    const interval = archived ? undefined : setInterval(load, 2000);
    return () => {
      alive = false;
      clearInterval(interval);
    };
  }, [agent.id, archived, conversationId, updateConversation]);
  useEffect(() => {
    setReferences([]);
    if (!conversationId) return;
    let alive = true;
    officeApi
      .conversationContext(conversationId)
      .then((result) => {
        if (alive) setReferences(result.references);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [conversationId]);
  const lastMessage = visibleMessages[visibleMessages.length - 1];
  const lastMessageContent = lastMessage?.content;
  const lastAttachmentCount = lastMessage?.attachments?.length;
  useEffect(() => {
    const element = scroll.current;
    if (!element) return;
    if (jumpToBottom.current) {
      // Opening a conversation lands on the newest message instead of animating from the top.
      element.scrollTop = element.scrollHeight;
      const frame = requestAnimationFrame(() => {
        if (!jumpToBottom.current) return;
        element.scrollTop = element.scrollHeight;
        // Stay pinned until the conversation's messages are actually painted.
        if (visibleMessages.length > 0) jumpToBottom.current = false;
      });
      return () => cancelAnimationFrame(frame);
    }
    if (followBottom.current) element.scrollTo?.({ top: element.scrollHeight, behavior: "smooth" });
  }, [visibleMessages.length, lastMessageContent, lastAttachmentCount, loading]);
  useEffect(() => {
    // Images finishing after the first paint would otherwise leave the view above the newest reply.
    const element = scroll.current;
    if (!element) return;
    const pin = () => {
      if (followBottom.current) element.scrollTop = element.scrollHeight;
    };
    element.addEventListener("load", pin, true);
    return () => element.removeEventListener("load", pin, true);
  }, [conversationId]);
  const addFiles = (files: File[]) => {
    if (archived || sendingLock.current) return;
    requestKey.current = null;
    attachments.add(files);
  };
  const switchConversation = (id: string) => {
    if (sendingLock.current) return;
    setReferences([]);
    setMessages([]);
    setLoadedConversationId(null);
    setLoading(true);
    setContent(readChatDraft(id));
    setSubmission(null);
    setRunId(null);
    requestKey.current = null;
    followBottom.current = true;
    jumpToBottom.current = true;
    attachments.clear();
    sessions.choose(id);
  };
  const fileBrowserAvailable = !archived && !fullscreen.active;
  return (
    <Modal
      title={archived ? agent.name + " 的历史对话" : "与 " + agent.name + " 聊天"}
      onClose={onClose}
      className={"office-agent-chat" + (fullscreen.viewport ? " is-reader-fullscreen" : "") +
        (fileBrowserAvailable ? " has-file-browser-toggle" : "") +
        (fileBrowserAvailable && fileBrowserOpen ? " has-file-browser-open" : "")}
      subtitle={
        archived ? "小黑屋 · 会话保留为公司资产" : roleLabels[agent.jobFunction] + " / " + stateLabels[agent.workState]
      }
    >
      {fileBrowserAvailable && (
        <FileBrowserDock placement="chat" open={fileBrowserOpen} onOpenChange={setFileBrowserOpen} agentId={agent.id}
          localEnabled={localFileBrowserEnabled} writeEnabled={localFileWriteEnabled} />
      )}
      <div className="chat-meta">
        {!archived && <span className={"state-dot " + agent.workState} />}
        <span>
          {archived
            ? roleLabels[agent.jobFunction] + " · 历史归属"
            : !profileBelongsHere && ["working", "meeting", "waiting_input"].includes(agent.workState)
              ? "伙伴正在其他会话工作"
              : stateLabels[agent.workState]}
        </span>
        {conversationContext && (
          <span
            className={
              "chat-context" + (conversationContext.percent >= conversationContext.threshold ? " is-near-limit" : "")
            }
            title={contextBadgeTitle(conversationContext)}
          >
            {contextBadgeLabel(conversationContext)}
          </span>
        )}
        <span className="chat-continuity">{archived ? "历史记录只读" : "关闭窗口后，任务继续运行"}</span>
      </div>
      <ConversationControls
        conversations={sessions.conversations}
        selectedId={conversationId}
        loading={sessions.loading || sending}
        creating={sessions.creating}
        archived={archived}
        references={references}
        onSelect={switchConversation}
        onCreate={() => {
          if (sendingLock.current) return;
          setReferences([]);
          attachments.clear();
          setContent("");
          setSubmission(null);
          setRunId(null);
          void sessions.create();
        }}
        onLibrary={() => setKnowledgeOpen(true)}
        onRenamed={updateConversation}
        onReferencesChanged={(updated) => {
          if (mounted.current && currentConversation.current === conversationSelection) setReferences(updated);
        }}
      />
      {sessions.error && (
        <p className="form-error chat-error" role="alert">
          {sessions.error}
        </p>
      )}
      {!archived && <ChatModelControls agent={agent} onApplied={onSent} />}
      {!archived && (
        <TaskProgressPanel
          agent={progressAgent}
          events={progress.events}
          connected={progress.connected}
          historyError={progress.historyError}
          submission={submission}
        />
      )}
      <section
        ref={reader}
        className={"office-chat-reader" + (fullscreen.viewport ? " is-viewport-fullscreen" : "")}
        aria-label="聊天内容"
        data-fullscreen-reader={fullscreen.active ? "true" : undefined}
      >
        <div className="chat-reader-toolbar">
          <span>{fullscreen.active ? "全屏阅读 · Esc 退出" : "聊天内容"}</span>
          <button
            type="button"
            aria-label={fullscreen.active ? "退出聊天内容全屏" : "全屏显示聊天内容"}
            aria-pressed={fullscreen.active}
            disabled={fullscreen.busy}
            onClick={() => void fullscreen.toggle()}
          >
            {fullscreen.active ? "退出全屏" : "全屏"}
          </button>
        </div>
        <div
          ref={scroll}
          className="office-agent-chat__messages"
          aria-live="polite"
          onScroll={(event) => {
            const element = event.currentTarget;
            const atBottom = element.scrollHeight - element.scrollTop - element.clientHeight < 100;
            followBottom.current = atBottom;
            if (!atBottom) jumpToBottom.current = false;
          }}
        >
          {loading || sessions.loading ? (
            <div className="skeleton">正在读取独立会话…</div>
          ) : visibleMessages.length === 0 ? (
            <div className="chat-empty">
              <span className="initial-avatar large">{agent.name.slice(0, 1)}</span>
              <h3>{archived ? "这个身份暂无历史消息" : "从一个具体的想法开始"}</h3>
              {!archived && <p>向 {agent.name} 交代目标、背景或希望得到的结果，也可以附上图片。</p>}
            </div>
          ) : (
            visibleMessages.map((message) => (
              <article key={message.id} className={"message message-" + message.role}>
                <div className="message-byline">
                  <strong>{message.role === "user" ? "你" : message.role === "system" ? "工作室" : agent.name}</strong>
                  <time>
                    {new Date(message.at).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}
                  </time>
                </div>
                <MessageBody content={message.content} role={message.role} agentId={message.agentId} />
                {Boolean(message.attachments?.length) && (
                  <div className="message-attachments">
                    {message.attachments!.map((attachment) => (
                      <a
                        key={attachment.id}
                        href={attachment.url}
                        target="_blank"
                        rel="noreferrer"
                        title={attachment.name}
                      >
                        <img src={attachment.url} alt={attachment.name} loading="lazy" />
                        <small>{attachment.name}</small>
                      </a>
                    ))}
                  </div>
                )}
              </article>
            ))
          )}
        </div>
      </section>
      {error && (
        <p className="form-error chat-error" role="alert">
          {error}
        </p>
      )}
      {archived ? (
        <div className="office-agent-chat__composer archived-notice">小黑屋 · 仅可查看历史消息</div>
      ) : (
        <form
          className={"office-agent-chat__composer " + (dragActive ? "is-dragging" : "")}
          onDragOver={(event) => {
            if (!sending && event.dataTransfer.types.includes("Files")) {
              event.preventDefault();
              setDragActive(true);
            }
          }}
          onDragLeave={(event) => {
            if (!event.currentTarget.contains(event.relatedTarget as Node)) setDragActive(false);
          }}
          onDrop={(event) => {
            event.preventDefault();
            setDragActive(false);
            addFiles(Array.from(event.dataTransfer.files));
          }}
          onSubmit={async (event) => {
            event.preventDefault();
            if (archived || sendDisabled || sendingLock.current || agent.credentialState !== "configured") return;
            sendingLock.current = true;
            setSending(true);
            setError("");
            setSubmission({ at: Date.now(), runId: null, state: "submitting" });
            requestKey.current ??= crypto.randomUUID();
            const attachmentIds = attachments.items.map((item) => item.attachment!.id);
            try {
              const result = await officeApi.send(agent.id, content.trim(), requestKey.current, attachmentIds, {
                conversationId: conversationId!,
              });
              setRunId(result.runId);
              setSubmission((current) => ({ ...current!, runId: result.runId, state: "accepted" }));
              followBottom.current = true;
              setContent("");
              clearChatDraft(conversationId);
              attachments.clear();
              requestKey.current = null;
              onSent();
              try {
                const history = await officeApi.conversationMessages(conversationId!);
                setMessages(history.messages);
                setLoadedConversationId(conversationId);
                updateConversation(history.conversation);
              } catch {
                setError("任务已接收，对话记录将在恢复连接后同步。");
              }
            } catch (e) {
              setError((e as Error).message);
              setSubmission((current) => (current ? { ...current, state: "failed" } : null));
            } finally {
              sendingLock.current = false;
              setSending(false);
            }
          }}
        >
          {agent.credentialState !== "configured" ? (
            <div className="credential-notice">
              <span>历史可查看。选择已认证的模型服务后即可开始新任务。</span>
              {stopControl}
              <button type="button" onClick={onCredential}>
                配置模型服务 ↗
              </button>
            </div>
          ) : (
            <>
              <AttachmentDrafts
                items={attachments.items}
                disabled={sending}
                onRemove={(id) => {
                  requestKey.current = null;
                  attachments.remove(id);
                }}
                onRetry={(id) => void attachments.retry(id)}
              />
              {attachments.error && (
                <p className="attachment-error" role="alert">
                  {attachments.error}
                </p>
              )}
              <label className="sr-only" htmlFor="chat-content">
                消息
              </label>
              <textarea
                id="chat-content"
                disabled={sending}
                value={content}
                onChange={(event) => {
                  setContent(event.target.value);
                  writeChatDraft(conversationId, event.target.value);
                  requestKey.current = null;
                }}
                onCompositionStart={() => {
                  composing.current = true;
                }}
                onCompositionEnd={() => {
                  composing.current = false;
                }}
                onKeyDown={(event) => {
                  if (
                    event.key !== "Enter" ||
                    composing.current ||
                    event.nativeEvent.isComposing ||
                    event.keyCode === 229
                  )
                    return;
                  event.preventDefault();
                  if (event.altKey) {
                    const input = event.currentTarget;
                    const start = input.selectionStart,
                      end = input.selectionEnd;
                    setContent((current) => current.slice(0, start) + "\n" + current.slice(end));
                    requestKey.current = null;
                    requestAnimationFrame(() => input.setSelectionRange(start + 1, start + 1));
                  } else if (!event.repeat && !sendDisabled) event.currentTarget.form?.requestSubmit();
                }}
                onPaste={(event) => {
                  const files = Array.from(event.clipboardData.files);
                  if (files.length) {
                    event.preventDefault();
                    addFiles(files);
                    const text = event.clipboardData.getData("text/plain");
                    if (text) setContent((current) => current + text);
                  }
                }}
                placeholder={dragActive ? "放开即可添加图片" : "交代给 " + agent.name + " 的下一件事…"}
                rows={2}
              />
              <input
                ref={fileInput}
                className="sr-only"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                multiple
                disabled={sending}
                aria-label="选择聊天图片"
                onChange={(event) => {
                  addFiles(Array.from(event.target.files || []));
                  event.target.value = "";
                }}
              />
              <div className="composer-bottom">
                <div className="composer-shortcuts">
                  <button
                    type="button"
                    disabled={sending || attachments.items.length >= 4}
                    onClick={() => fileInput.current?.click()}
                  >
                    添加图片
                  </button>
                  <small>
                    Enter 发送 · Alt + Enter 换行<span>PNG / JPEG / WebP · 每张 5 MiB · 最多 4 张</span>
                  </small>
                </div>
                <div>
                  {stopControl}
                  <button className="primary" disabled={sendDisabled}>
                    {sending ? "正在提交…" : "发送消息"} ↑
                  </button>
                </div>
              </div>
            </>
          )}
        </form>
      )}
      {knowledgeOpen && (
        <CompanyKnowledgeDialog
          targetConversationId={archived ? undefined : conversationId || undefined}
          onClose={() => setKnowledgeOpen(false)}
          onReferenced={(updated) => {
            if (mounted.current && currentConversation.current === conversationSelection) setReferences(updated);
          }}
        />
      )}
    </Modal>
  );
}
