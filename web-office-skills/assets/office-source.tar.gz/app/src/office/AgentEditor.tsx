import { useEffect, useRef, useState } from "react";
import type {
  AgentDraft,
  AgentProfile,
  ModelCapability,
  ProviderCapabilities,
  ProviderProfile,
  ReasoningEffort,
} from "../../shared/office-contracts";
import { officeApi } from "./api";
import { Modal } from "./Modal";
import { AppearancePicker } from "./AppearancePicker";
import { ClaudeContextControl } from "./ClaudeContextControl";
import { splitClaudeContext, withClaudeContext } from "./claude-context";

const effortLabels: Record<ReasoningEffort, string> = {
  none: "不启用 · none",
  minimal: "最低 · minimal",
  low: "低 · low",
  medium: "中 · medium",
  high: "高 · high",
  xhigh: "极高 · xhigh",
  max: "最高 · max",
  ultra: "超高 · ultra",
};
const catalogLabels = {
  ready: "模型目录已读取",
  key_required: "需要所选服务的运行期认证",
  unauthorized: "模型目录认证未通过",
  unsupported: "服务未提供模型目录",
  unavailable: "暂时无法读取模型目录",
};
const sourceLabels: Record<ModelCapability["reasoningSource"], string> = {
  provider: "服务目录元数据",
  codex: "Codex CLI 目录",
  unverified: "未核实的档位信息",
};
interface CatalogResult {
  providerId: string;
  model: string;
  capabilities: ProviderCapabilities;
}
export function AgentEditor({
  agent,
  onSaved,
  onClose,
}: {
  agent: AgentProfile | null;
  onSaved(agent: AgentProfile): void;
  onClose(): void;
}) {
  const [draft, setDraft] = useState<AgentDraft>({
    name: agent?.name || "",
    jobFunction: agent?.isBoss ? "se" : (agent?.jobFunction as AgentDraft["jobFunction"]) || "developer",
    gender: agent?.gender || "未指定",
    spriteNumber: agent?.spriteNumber || 1,
    providerId: agent?.providerId || null,
    model: agent?.model || "",
    reasoningEffort: agent?.reasoningEffort || null,
  });
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [catalog, setCatalog] = useState<CatalogResult | null>(null);
  const [catalogBusy, setCatalogBusy] = useState(false);
  const [catalogError, setCatalogError] = useState("");
  const [refreshVersion, setRefreshVersion] = useState(0);
  const requestSeq = useRef(0);
  const forceRefresh = useRef(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const providerId = draft.providerId;
  const agentId = agent?.id;
  const selectedService = providers.find((provider) => provider.id === providerId);
  const isClaude = selectedService?.executor === "claude-code";
  const context = isClaude
    ? splitClaudeContext(draft.model)
    : { baseModel: draft.model?.trim() || "", longContext: false };
  const modelId = context.baseModel;
  const persistedModel = isClaude ? withClaudeContext(modelId, context.longContext) : modelId;
  const modelBase = (value: string) => (isClaude ? splitClaudeContext(value).baseModel : value);
  const selectModel = (value: string) => {
    const selected = splitClaudeContext(value);
    setDraft({
      ...draft,
      model: isClaude ? withClaudeContext(selected.baseModel, context.longContext || selected.longContext) : value,
    });
    setError("");
  };
  const slotId =
    selectedService?.credentialSlotId ||
    (agent?.providerId === providerId ? agent?.credentialSlotId || undefined : undefined);
  useEffect(() => {
    let alive = true;
    officeApi
      .providers()
      .then((r) => {
        if (alive) setProviders(r.providers);
      })
      .catch(() => {
        if (alive) setError("暂时无法获取模型服务，请稍后重试。");
      });
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    const seq = ++requestSeq.current;
    let alive = true;
    const refresh = forceRefresh.current;
    forceRefresh.current = false;
    setCatalogError("");
    if (!providerId) {
      setCatalog(null);
      setCatalogBusy(false);
      return;
    }
    setCatalogBusy(true);
    const timer = setTimeout(
      () => {
        officeApi
          .capabilities(providerId, { agentId, slotId, model: modelId || undefined, refresh })
          .then((capabilities) => {
            if (alive && requestSeq.current === seq) setCatalog({ providerId, model: modelId, capabilities });
          })
          .catch(() => {
            if (alive && requestSeq.current === seq) {
              setCatalog(null);
              setCatalogError("暂时无法读取目录。仍可手填模型 ID，或稍后刷新。");
            }
          })
          .finally(() => {
            if (alive && requestSeq.current === seq) setCatalogBusy(false);
          });
      },
      refresh ? 0 : 350,
    );
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [providerId, modelId, agentId, slotId, refreshVersion]);
  const cap = catalog?.providerId === providerId ? catalog.capabilities : null;
  const currentCatalog = catalog?.providerId === providerId && catalog.model === modelId;
  const modelCapability = currentCatalog
    ? cap?.selectedModel && modelBase(cap.selectedModel.id) === modelId
      ? cap.selectedModel
      : cap?.modelCapabilities?.find((m) => modelBase(m.id) === modelId)
    : undefined;
  const efforts = modelCapability?.reasoningEfforts || [];
  const modelOptions = [...new Set((cap?.models || []).map(modelBase))].filter(Boolean);
  const effortNeedsChoice =
    Boolean(draft.reasoningEffort) && currentCatalog && !catalogBusy && !efforts.includes(draft.reasoningEffort!);
  const effortPending = Boolean(draft.reasoningEffort) && (!currentCatalog || catalogBusy);
  const canReadOwnCredentials = selectedService?.credentialState === "configured";
  return (
    <Modal title={agent ? "编辑 " + agent.name : "添加一位伙伴"} onClose={onClose} subtitle="独立身份 · 独立会话">
      <form
        className="dialog-form"
        onSubmit={async (e) => {
          e.preventDefault();
          if (providerId && draft.reasoningEffort && (effortPending || effortNeedsChoice || !modelCapability)) {
            setError("当前模型的思考档位尚未确认，请选择模型默认或目录中的档位后保存。");
            return;
          }
          setBusy(true);
          setError("");
          try {
            const body = {
              ...draft,
              name: draft.name.trim(),
              providerId: providerId || null,
              model: providerId ? persistedModel || null : null,
              reasoningEffort: providerId ? draft.reasoningEffort : null,
            };
            const { jobFunction, ...bossBody } = body;
            const result = await officeApi.saveAgent(agent?.isBoss ? bossBody : body, agent?.id);
            onSaved(result.agent);
          } catch (e) {
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <div className="form-grid">
          <label>
            名称
            <input
              value={draft.name}
              maxLength={80}
              required
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              placeholder="给伙伴取个名字"
            />
          </label>
          <label>
            职能
            {agent?.isBoss ? (
              <input value="Boss · 你的身份（固定）" readOnly />
            ) : (
              <select
                value={draft.jobFunction}
                onChange={(e) => setDraft({ ...draft, jobFunction: e.target.value as AgentDraft["jobFunction"] })}
              >
                <option value="se">SE · 系统工程 / 方案设计</option>
                <option value="pl">PL · 项目协调</option>
                <option value="developer">开发</option>
                <option value="tester">测试</option>
              </select>
            )}
          </label>
        </div>
        <label>
          模型服务
          <select
            aria-label="模型服务"
            value={providerId || ""}
            onChange={(e) => {
              const nextProviderId = e.target.value || null;
              ++requestSeq.current;
              setCatalog(null);
              setCatalogBusy(false);
              setDraft({ ...draft, providerId: nextProviderId, model: null, reasoningEffort: null });
              setError("");
            }}
          >
            <option value="">稍后配置</option>
            {providers.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
        {providerId && (
          <section className="model-settings" aria-label="模型与思考设置">
            <div className="model-catalog-heading">
              <div>
                <strong>选择模型</strong>
                <small>使用所选服务的凭据读取目录</small>
              </div>
              <button
                type="button"
                disabled={!providerId || catalogBusy}
                onClick={() => {
                  forceRefresh.current = true;
                  setRefreshVersion((v) => v + 1);
                }}
              >
                {catalogBusy ? "读取中…" : "刷新目录"}
              </button>
            </div>
            <label>
              模型目录
              <select
                aria-label="模型目录"
                disabled={catalogBusy || modelOptions.length === 0}
                value={modelOptions.includes(modelId) ? modelId : ""}
                onChange={(e) => {
                  selectModel(e.target.value);
                }}
              >
                <option value="">
                  {catalogBusy
                    ? "正在读取…"
                    : modelOptions.length
                      ? "从目录选择，或在下方手填"
                      : "暂无可选目录，请在下方手填"}
                </option>
                {modelOptions.map((id) => {
                  const item = cap?.modelCapabilities?.find((m) => modelBase(m.id) === id);
                  return (
                    <option key={id} value={id}>
                      {item?.name && item.name !== id ? `${item.name} · ${id}` : id}
                    </option>
                  );
                })}
              </select>
            </label>
            <label>
              模型 ID（可手填）
              <input
                aria-label="模型 ID"
                value={modelId}
                onChange={(e) => {
                  selectModel(e.target.value);
                }}
                placeholder="输入服务支持的完整模型 ID"
                autoComplete="off"
                spellCheck={false}
              />
            </label>
            {isClaude && (
              <ClaudeContextControl
                checked={context.longContext}
                hasModel={Boolean(modelId)}
                disabled={busy}
                onChange={(checked) => {
                  setDraft({ ...draft, model: withClaudeContext(modelId, checked) });
                  setError("");
                }}
              />
            )}
            <div className="catalog-status" role="status" aria-live="polite">
              <strong>
                {!providerId
                  ? "先选择模型服务；也可先手填模型 ID"
                  : catalogBusy
                    ? "正在读取模型目录与当前模型档位…"
                    : catalogError || (cap?.catalogState ? catalogLabels[cap.catalogState] : "目录信息尚未提供")}
              </strong>
              {cap?.catalogMessage && <p>{cap.catalogMessage}</p>}
              {!canReadOwnCredentials && providerId && (
                <p>此服务尚需认证。可在“我的模型服务”补充服务凭据，无需为每个伙伴单独填写。</p>
              )}
              {!catalogBusy && modelOptions.length === 0 && (
                <p>目录为空不影响手填模型 ID；读取失败、缺少 Key 或服务不支持目录时均可继续。</p>
              )}
              {cap?.codexCatalogState === "unavailable" && <p>本地 Codex CLI 目录暂不可用。</p>}
            </div>
            <label>
              思考强度
              <select
                aria-label="思考强度"
                value={draft.reasoningEffort || ""}
                onChange={(e) => {
                  setDraft({ ...draft, reasoningEffort: (e.target.value as ReasoningEffort) || null });
                  setError("");
                }}
              >
                <option value="">模型默认</option>
                {draft.reasoningEffort && !efforts.includes(draft.reasoningEffort) && (
                  <option value={draft.reasoningEffort} disabled>
                    {effortLabels[draft.reasoningEffort]}（待重新选择）
                  </option>
                )}
                {efforts.map((effort) => (
                  <option key={effort} value={effort}>
                    {effortLabels[effort]}
                  </option>
                ))}
              </select>
            </label>
            {effortNeedsChoice && (
              <div className="effort-notice" role="alert">
                <p>当前模型目录未列出已选档位“{draft.reasoningEffort}”。请选择可用档位，或明确改用模型默认后保存。</p>
                <button
                  type="button"
                  onClick={() => {
                    setDraft({ ...draft, reasoningEffort: null });
                    setError("");
                  }}
                >
                  改用模型默认
                </button>
              </div>
            )}
            {modelCapability ? (
              <p className="hint">
                档位来源：{sourceLabels[modelCapability.reasoningSource]}。
                {modelCapability.defaultReasoningEffort
                  ? `目录记录的默认值：${modelCapability.defaultReasoningEffort}。`
                  : ""}
                目录元数据不代表远程模型已成功调用；实际支持范围以所选模型服务为准。
              </p>
            ) : (
              <p className="hint">
                {modelId ? "尚无当前模型的档位目录，可保留模型默认。" : "填写或选择模型后读取对应档位。"}
                “模型默认”不传递额外思考强度参数。
              </p>
            )}
          </section>
        )}
        <AppearancePicker
          value={draft.spriteNumber}
          onChange={(value) => setDraft({ ...draft, spriteNumber: value })}
        />
        <p className="hint">服务选择可稍后配置。选择服务后，身份会自动使用该服务的运行期认证。</p>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <footer className="dialog-footer">
          <button type="button" onClick={onClose}>
            取消
          </button>
          <button className="primary" disabled={busy || Boolean(providerId && (effortNeedsChoice || effortPending))}>
            {busy ? "正在保存…" : "保存身份"}
          </button>
        </footer>
      </form>
    </Modal>
  );
}
