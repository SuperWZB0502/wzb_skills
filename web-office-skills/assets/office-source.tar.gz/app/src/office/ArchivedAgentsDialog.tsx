import { useEffect, useState } from "react";
import type { AgentProfile } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { Modal } from "./Modal";
import { roleLabels } from "./labels";

export function ArchivedAgentsDialog({
  onClose,
  onOpenHistory,
  onChanged,
}: {
  onClose(): void;
  onOpenHistory(agent: AgentProfile): void;
  onChanged?(dismissedId: string): void | Promise<unknown>;
}) {
  const [agents, setAgents] = useState<AgentProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [revision, setRevision] = useState(0);
  const [dismissing, setDismissing] = useState<AgentProfile | null>(null);
  const [dismissBusy, setDismissBusy] = useState(false);
  useEffect(() => {
    let alive = true;
    officeApi
      .archivedAgents()
      .then((result) => {
        if (alive) setAgents(result.agents);
      })
      .catch(() => {
        if (alive) setError("暂时无法读取小黑屋，请稍后重试。");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [revision]);
  return (
    <Modal title="小黑屋" subtitle="已移除身份 · 配置与历史会话保留" onClose={onClose}>
      <div className="dialog-form">
        <p className="hint">
          这里的身份已从正式员工移除，配置与历史会话保留，不再参与工作或会议。进一步开除员工会清除身份配置并从这里移除，会话仍留在公司知识库。
        </p>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        {notice && (
          <p className="hint" role="status">
            {notice}
          </p>
        )}
        {loading ? (
          <div className="skeleton">正在读取小黑屋…</div>
        ) : agents.length === 0 ? (
          <p className="hint">小黑屋目前没有员工。</p>
        ) : (
          <div className="archived-agent-list">
            {agents.map((agent) => (
              <div key={agent.id} className="archived-agent-entry">
                <button
                  className="archived-agent-row"
                  aria-label={"查看 " + agent.name + " 的历史对话"}
                  onClick={() => onOpenHistory(agent)}
                >
                  <span className="initial-avatar">{agent.name.slice(0, 1)}</span>
                  <span>
                    <strong>{agent.name}</strong>
                    <small>{roleLabels[agent.jobFunction]} · 小黑屋</small>
                  </span>
                  <span className="archived-history-link">查看历史 ↗</span>
                </button>
                {!agent.isBoss && (
                  <button
                    className="archived-clear-config"
                    disabled={dismissBusy}
                    onClick={() => {
                      setError("");
                      setNotice("");
                      setDismissing(agent);
                    }}
                  >
                    开除员工
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
        {dismissing && (
          <Modal
            title={"开除员工“" + dismissing.name + "”？"}
            subtitle="最终清除身份配置 · 会话留公司知识库"
            onClose={() => {
              if (!dismissBusy) setDismissing(null);
            }}
          >
            <div className="dialog-form">
              <p>
                开除后将清除模型、服务及凭据绑定等身份配置，并从小黑屋移除。历史会话和原生历史作为公司资产继续保留在公司知识库，项目成果保留。
              </p>
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <footer className="dialog-footer">
                <button disabled={dismissBusy} onClick={() => setDismissing(null)}>
                  取消
                </button>
                <button
                  className="danger"
                  disabled={dismissBusy}
                  onClick={async () => {
                    const dismissed = dismissing;
                    setDismissBusy(true);
                    setError("");
                    try {
                      await officeApi.dismissAgent(dismissed.id);
                      setAgents((current) => current.filter((agent) => agent.id !== dismissed.id));
                      setDismissing(null);
                      setNotice("已开除“" + dismissed.name + "”，会话继续保留在公司知识库。");
                      setRevision((value) => value + 1);
                      await onChanged?.(dismissed.id);
                    } catch (e) {
                      setError((e as Error).message);
                    } finally {
                      setDismissBusy(false);
                    }
                  }}
                >
                  {dismissBusy ? "正在开除…" : "确认开除员工"}
                </button>
              </footer>
            </div>
          </Modal>
        )}
      </div>
    </Modal>
  );
}
