import type { AgentProfile } from "../../shared/office-contracts";
export const testAgent: AgentProfile = {
  id: "a",
  name: "青禾",
  jobFunction: "developer",
  isBoss: false,
  gender: "未指定",
  spriteNumber: 1,
  providerId: "p",
  model: "model-one",
  reasoningEffort: null,
  credentialState: "required",
  credentialSlotId: null,
  workState: "idle",
  currentTaskId: null,
  currentWorkSummary: "",
};
