import { useEffect, useRef, useState, type FormEvent } from "react";
import { createPortal } from "react-dom";
import type { ConversationContextReference, OfficeConversation } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { ConfirmDialog } from "./ConfirmDialog";
import { useOptionalOfficeClient } from "./OfficeClientProvider";
import { useAnchoredMenu } from "./useAnchoredMenu";

function previewText(title: string, total: number, unit: "会话" | "引用"): string {
  return total > 1 ? `${title} 等 ${total} 个${unit}` : title;
}

export function ConversationControls({
  conversations,
  selectedId,
  loading,
  creating,
  archived,
  references,
  onSelect,
  onCreate,
  onLibrary,
  onRenamed,
  onReferencesChanged,
}: {
  conversations: OfficeConversation[];
  selectedId: string | null;
  loading: boolean;
  creating: boolean;
  archived: boolean;
  references: ConversationContextReference[];
  onSelect(id: string): void;
  onCreate(): void;
  onLibrary(): void;
  onRenamed(conversation: OfficeConversation): void;
  onReferencesChanged(references: ConversationContextReference[]): void;
}) {
  const [copied, setCopied] = useState(false),
    [error, setError] = useState("");
  const [renaming, setRenaming] = useState(false),
    [draft, setDraft] = useState(""),
    [saving, setSaving] = useState(false),
    [renameError, setRenameError] = useState("");
  const [removingReference, setRemovingReference] = useState<string | null>(null);
  const [compacting, setCompacting] = useState(false);
  const [compactNote, setCompactNote] = useState("");
  const [confirmingCompact, setConfirmingCompact] = useState(false);
  const [compactError, setCompactError] = useState("");
  const conversationMenu = useAnchoredMenu({ align: "start", minWidth: 300, maxWidth: 560 });
  const referenceMenu = useAnchoredMenu({ align: "end", minWidth: 320, maxWidth: 620 });
  const selection = useRef({ id: selectedId });
  const mounted = useRef(true);
  if (selection.current.id !== selectedId) selection.current = { id: selectedId };
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  useEffect(() => {
    setCopied(false);
    setError("");
    setRenaming(false);
    setDraft("");
    setRenameError("");
    setCompactNote("");
    setConfirmingCompact(false);
    setCompactError("");
  }, [selectedId]);
  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), 1800);
    return () => clearTimeout(timer);
  }, [copied]);
  // Absent snapshot (unit tests) or an older runtime means the switch is on.
  const styledConfirm = useOptionalOfficeClient()?.snapshot?.features?.compactConfirm ?? true;
  const runCompact = async () => {
    if (!selectedId) return;
    setCompacting(true);
    setCompactError("");
    const operationSelection = selection.current;
    try {
      const result = await officeApi.compactConversation(selectedId);
      if (!mounted.current || selection.current !== operationSelection) return;
      setConfirmingCompact(false);
      setCompactNote(
        `已压缩：${result.messages} 条 → ${result.keptMessages} 条原文 + ${
          result.summarisedMessages
        } 条要点（${Math.round(result.digestCharacters / 100) / 10}k 字符）`,
      );
    } catch (e) {
      if (mounted.current && selection.current === operationSelection)
        setCompactError((e as Error).message || "压缩失败，请重试。");
    } finally {
      if (mounted.current) setCompacting(false);
    }
  };
  const current = conversations.find((conversation) => conversation.id === selectedId);
  const conversationPreview = loading
    ? "正在读取会话…"
    : current
      ? previewText(current.title || "未命名会话", conversations.length, "会话")
      : "选择会话";
  const firstReference = references[0];
  const referencePreview =
    references.length === 0 ? "新增引用" : previewText(firstReference.title || "未命名会话", references.length, "引用");
  const closeMenus = () => {
    conversationMenu.close();
    referenceMenu.close();
  };
  const removeReference = async (reference: ConversationContextReference) => {
    if (!selectedId || removingReference) return;
    const operationSelection = selection.current;
    setRemovingReference(reference.id);
    setError("");
    try {
      await officeApi.removeConversationContext(selectedId, reference.id);
      if (!mounted.current || selection.current !== operationSelection) return;
      const result = await officeApi.conversationContext(selectedId);
      if (!mounted.current || selection.current !== operationSelection) return;
      onReferencesChanged(result.references);
      if (!result.references.length) referenceMenu.close();
    } catch (e) {
      if (mounted.current && selection.current === operationSelection)
        setError((e as Error).message || "删除引用失败，请重试。");
    } finally {
      if (mounted.current) setRemovingReference(null);
    }
  };
  const cancelRename = () => {
    setRenaming(false);
    setDraft("");
    setRenameError("");
  };
  const saveRename = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedId || saving) return;
    const title = draft.trim();
    if (!title) {
      setRenameError("会话标题不能为空。");
      return;
    }
    const operationSelection = selection.current;
    setSaving(true);
    setRenameError("");
    try {
      const result = await officeApi.patchConversation(selectedId, { title });
      if (!mounted.current || selection.current !== operationSelection) return;
      onRenamed(result.conversation);
      setRenaming(false);
      setDraft("");
    } catch (e) {
      if (mounted.current && selection.current === operationSelection)
        setRenameError((e as Error).message || "保存失败，请重试。");
    } finally {
      if (mounted.current) setSaving(false);
    }
  };
  const openKnowledgePicker = () => {
    closeMenus();
    onLibrary();
  };
  return (
    <section className="conversation-controls" aria-label="当前会话">
      <div className="conversation-toolbar">
        <div className="conversation-module">
          <span className="conversation-module-label">会话</span>
          <div className="conversation-picker" onKeyDown={conversationMenu.onKeyDown}>
            <button
              type="button"
              ref={conversationMenu.toggleRef}
              className="conversation-picker-toggle"
              aria-label="选择会话"
              aria-haspopup="true"
              aria-expanded={conversationMenu.open}
              aria-controls={conversationMenu.menuId}
              data-conversation-id={selectedId || ""}
              title={conversationPreview}
              disabled={loading || creating}
              onClick={conversationMenu.toggle}
            >
              <span className="picker-text">{conversationPreview}</span>
              <span className="picker-caret" aria-hidden="true">
                ▾
              </span>
            </button>
            {conversationMenu.open &&
              conversationMenu.position &&
              createPortal(
                <ul
                  className="conversation-picker-menu"
                  id={conversationMenu.menuId}
                  ref={conversationMenu.menuRef}
                  style={conversationMenu.position}
                  aria-label="会话列表"
                  onKeyDown={conversationMenu.onKeyDown}
                >
                  {conversations.map((conversation) => (
                    <li key={conversation.id}>
                      <button
                        type="button"
                        className={"conversation-option" + (conversation.id === selectedId ? " is-selected" : "")}
                        aria-current={conversation.id === selectedId ? "true" : undefined}
                        onClick={() => {
                          conversationMenu.close();
                          if (conversation.id !== selectedId) onSelect(conversation.id);
                        }}
                      >
                        <span className="picker-text">{conversation.title || "未命名会话"}</span>
                        <small>{conversation.messageCount} 条</small>
                      </button>
                    </li>
                  ))}
                </ul>,
                document.body,
              )}
          </div>
        </div>
        <div className="conversation-actions">
          {!archived && (
            <button type="button" disabled={loading || creating} onClick={onCreate}>
              {creating ? "正在新建…" : "新建会话"}
            </button>
          )}
          {!archived && (
            <button
              type="button"
              disabled={!selectedId || loading || creating || renaming}
              onClick={() => {
                if (!current) return;
                setDraft(current.title);
                setRenameError("");
                setRenaming(true);
              }}
            >
              重命名
            </button>
          )}
          <button
            type="button"
            disabled={!selectedId || loading || compacting}
            title="把本会话的历史压成摘要并换一个新上下文；原上下文文件仍保留在服务器上"
            onClick={() => {
              if (!selectedId) return;
              setCompactError("");
              if (
                !styledConfirm &&
                !window.confirm(
                  "压缩本会话上下文？\n\n会把历史压缩成摘要，下次提问在新上下文里继续；消息记录不会删除。",
                )
              )
                return;
              if (styledConfirm) {
                setConfirmingCompact(true);
                return;
              }
              void runCompact();
            }}
          >
            {compacting ? "压缩中…" : "压缩上下文"}
          </button>
          <button
            type="button"
            disabled={!selectedId}
            title={selectedId || "复制会话 ID"}
            onClick={async () => {
              const operationSelection = selection.current;
              try {
                await navigator.clipboard.writeText(selectedId!);
                if (!mounted.current || selection.current !== operationSelection) return;
                setCopied(true);
                setError("");
              } catch {
                if (mounted.current && selection.current === operationSelection)
                  setError("无法自动复制，请手动选择下方会话 ID。");
              }
            }}
          >
            {copied ? "已复制 ID" : "复制会话 ID"}
          </button>
        </div>
        {(!archived || references.length > 0) && (
          <div className="conversation-reference-group">
            <span className="conversation-reference-label">引用</span>
            <div className="conversation-reference-picker" onKeyDown={referenceMenu.onKeyDown}>
              {references.length === 0 ? (
                <button
                  type="button"
                  ref={referenceMenu.toggleRef}
                  className="conversation-reference-toggle"
                  disabled={!selectedId || loading}
                  onClick={openKnowledgePicker}
                >
                  <span className="picker-text">新增引用</span>
                  <span className="picker-caret" aria-hidden="true">
                    ＋
                  </span>
                </button>
              ) : (
                <button
                  type="button"
                  ref={referenceMenu.toggleRef}
                  className="conversation-reference-toggle"
                  aria-haspopup="true"
                  aria-expanded={referenceMenu.open}
                  aria-controls={referenceMenu.menuId}
                  title="查看每条引用的原始所有人和标题"
                  onClick={referenceMenu.toggle}
                >
                  <span className="picker-text">{referencePreview}</span>
                  <span className="picker-caret" aria-hidden="true">
                    ▾
                  </span>
                </button>
              )}
              {referenceMenu.open &&
                referenceMenu.position &&
                createPortal(
                  <ul
                    className="conversation-reference-menu"
                    id={referenceMenu.menuId}
                    ref={referenceMenu.menuRef}
                    style={referenceMenu.position}
                    aria-label="已引用会话列表"
                    onKeyDown={referenceMenu.onKeyDown}
                  >
                    {!archived && (
                      <li className="conversation-reference-add">
                        <button type="button" onClick={openKnowledgePicker}>
                          ＋ 新增引用
                        </button>
                      </li>
                    )}
                    {references.map((reference) => (
                      <li key={reference.id}>
                        <span className="reference-owner" title={"原始会话所有人：" + reference.sourceAgentName}>
                          {reference.sourceAgentName}
                        </span>
                        <span className="reference-title" title={reference.title || "未命名会话"}>
                          {reference.title || "未命名会话"}
                        </span>
                        <small>{reference.messageCount} 条</small>
                        {!archived && (
                          <button
                            type="button"
                            className="reference-delete"
                            aria-label={"删除引用：" + (reference.title || reference.sourceAgentName)}
                            disabled={removingReference === reference.id}
                            onClick={() => void removeReference(reference)}
                          >
                            {removingReference === reference.id ? "删除中…" : "删除"}
                          </button>
                        )}
                      </li>
                    ))}
                  </ul>,
                  document.body,
                )}
            </div>
          </div>
        )}
      </div>
      {!archived && renaming && selectedId && (
        <form className="conversation-rename" onSubmit={saveRename}>
          <label>
            会话标题
            <input
              aria-label="会话标题"
              value={draft}
              maxLength={160}
              autoFocus
              disabled={saving}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Escape") {
                  event.stopPropagation();
                  cancelRename();
                }
              }}
            />
          </label>
          <button type="submit" disabled={saving || !draft.trim()}>
            {saving ? "正在保存…" : "保存标题"}
          </button>
          <button type="button" disabled={saving} onClick={cancelRename}>
            取消
          </button>
          {renameError && (
            <p className="form-error" role="alert">
              {renameError}
            </p>
          )}
        </form>
      )}
      {error && selectedId && (
        <div className="conversation-id">
          <span>会话 ID</span>
          <code>{selectedId}</code>
        </div>
      )}
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {compactNote && !error && (
        <p className="form-hint" role="status">
          {compactNote}
        </p>
      )}
      {confirmingCompact && (
        <ConfirmDialog
          title="压缩本会话上下文？"
          subtitle="同席工作室 · 上下文"
          confirmLabel="确认压缩"
          busyLabel="压缩中…"
          busy={compacting}
          error={compactError}
          onConfirm={() => void runCompact()}
          onClose={() => {
            if (!compacting) setConfirmingCompact(false);
          }}
        >
          <p>会把历史压缩成摘要，下一次提问在新上下文里继续。</p>
          <ul className="confirm-list">
            <li>消息记录不会删除，会话还是当前这一个。</li>
            <li>原上下文文件仍保留在服务器上，需要时可以追溯。</li>
            <li>压缩后上下文用量从零重新计算。</li>
          </ul>
        </ConfirmDialog>
      )}
    </section>
  );
}
