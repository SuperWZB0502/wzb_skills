/** Conversation titles created by the office itself; a real user/auto title replaces them. */
const placeholderTitles = new Set(["", "新会话", "默认会话", "未命名会话"]);
export const maxConversationTitle = 160;
const summaryLimit = 26;

/** True while a conversation still carries a generated placeholder title. */
export function isDefaultConversationTitle(title: string | null | undefined): boolean {
  return placeholderTitles.has(String(title ?? "").trim());
}

/** Trim markdown noise so a chat request turns into a readable one-line label. */
function clean(value: string | null | undefined): string {
  return String(value ?? "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]*)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/<?https?:\/\/\S+>?/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/^\s*(?:[-*+>]\s+|\d+\s*[.、:：)]\s*)/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function clip(value: string): string {
  if (!value) return "";
  let text = value;
  const stop = /[。！？!?；;，,\n]/.exec(value);
  if (stop && stop.index >= 4) text = value.slice(0, stop.index).trim();
  if (text.length <= summaryLimit) return text;
  let cut = text.slice(0, summaryLimit);
  const boundary = Math.max(cut.lastIndexOf(" "), cut.lastIndexOf("，"), cut.lastIndexOf(","), cut.lastIndexOf("、"));
  if (boundary >= 12) cut = cut.slice(0, boundary);
  return cut.trim() + "…";
}

/**
 * Derive a one-line conversation title from the first exchange, similar to CLI
 * session summaries. The first user request wins; the assistant reply is only a
 * fallback when the user text is too short to describe the task.
 */
export function deriveConversationTitle(input: { user?: string | null; assistant?: string | null }): string {
  const user = clean(input.user);
  const assistant = clean(input.assistant);
  const source = user.length >= 4 ? user : assistant.length >= 4 ? assistant : "";
  const title = source ? clip(source).slice(0, maxConversationTitle) : "";
  return title.length >= 2 ? title : "";
}
