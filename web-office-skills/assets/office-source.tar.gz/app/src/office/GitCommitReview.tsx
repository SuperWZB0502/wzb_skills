import { useEffect, useState } from "react";
import { officeApi, type GitCommitRequest } from "./api";
import { Modal } from "./Modal";

export function GitCommitReview() {
  const [requests, setRequests] = useState<GitCommitRequest[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const request = requests[0];

  useEffect(() => {
    let disposed = false;
    const refresh = async () => {
      try {
        const result = await officeApi.pendingGitCommits();
        if (!disposed) setRequests(result.requests);
      } catch {
        // A transient network failure leaves the last pending request visible.
      }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 2000);
    return () => {
      disposed = true;
      window.clearInterval(timer);
    };
  }, []);
  if (!request) return null;

  async function decide(approve: boolean) {
    setError("");
    setBusy(true);
    try {
      await officeApi.reviewGitCommit(request.id, approve);
      setRequests((items) => items.filter((item) => item.id !== request.id));
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : "提交审批失败。");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="本地 Git 提交审批" onClose={() => { if (!busy) void decide(false); }}>
      <p>{request.agentName} 请求提交以下文件。</p>
      <p><strong>工作树</strong> <code>{request.worktree}</code></p>
      <p><strong>本地分支</strong> <code>{request.branch}</code></p>
      <p><strong>提交说明</strong> {request.message}</p>
      <ul>{request.files.map((file) => <li key={file}><code>{file}</code></li>)}</ul>
      {error && <p role="alert">{error}</p>}
      <div className="modal-actions">
        <button type="button" disabled={busy} onClick={() => void decide(false)}>拒绝</button>
        <button type="button" className="primary" disabled={busy} onClick={() => void decide(true)}>允许本地提交</button>
      </div>
    </Modal>
  );
}
