import { useEffect, useState } from "react";
import type { AgentProfile, ProviderProfile } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { Modal } from "./Modal";
import { ServiceDialog } from "./ServiceDialog";
import { credentialLabels } from "./labels";
// Compatibility entry: credentials now belong to the selected service, never an individual agent form.
export function CredentialDialog({
  agent,
  onConfigured,
  onClose,
}: {
  agent: AgentProfile;
  agents: AgentProfile[];
  onConfigured(slotId: string): void | Promise<void>;
  onClose(): void;
}) {
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [selected, setSelected] = useState(agent.providerId || "");
  const [service, setService] = useState<ProviderProfile | null | undefined>();
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    officeApi
      .providers()
      .then((result) => {
        if (alive) setProviders(result.providers);
      })
      .catch(() => {
        if (alive) setError("暂时无法读取模型服务。");
      });
    return () => {
      alive = false;
    };
  }, []);
  const bind = async (provider: ProviderProfile) => {
    await officeApi.saveAgent({ providerId: provider.id }, agent.id);
    await onConfigured(provider.credentialSlotId || "");
  };
  if (service !== undefined)
    return (
      <ServiceDialog
        provider={service}
        onClose={() => {
          setService(undefined);
          void officeApi
            .providers()
            .then((result) => setProviders(result.providers))
            .catch(() => {});
        }}
        onSaved={bind}
      />
    );
  const chosen = providers.find((provider) => provider.id === selected);
  return (
    <Modal title={"为 " + agent.name + " 选择模型服务"} subtitle="服务凭据由所有使用者共享" onClose={onClose}>
      <form
        className="dialog-form"
        onSubmit={async (event) => {
          event.preventDefault();
          if (selected && !chosen) return;
          setBusy(true);
          setError("");
          try {
            if (!selected) {
              await officeApi.saveAgent({ providerId: null, model: null, reasoningEffort: null }, agent.id);
              await onConfigured("");
            } else if (chosen!.credentialState !== "configured") {
              await officeApi.saveAgent({ providerId: chosen!.id }, agent.id);
              setService(chosen);
            } else await bind(chosen!);
          } catch (e) {
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label>
          模型服务
          <select aria-label="模型服务" value={selected} onChange={(event) => setSelected(event.target.value)}>
            <option value="">稍后配置</option>
            {providers.map((provider) => (
              <option key={provider.id} value={provider.id}>
                {provider.name} · {credentialLabels[provider.credentialState || "required"]}
              </option>
            ))}
          </select>
        </label>
        <p className="hint">选择服务后自动使用该服务的运行期凭据。补充 API Key 或账户认证会更新服务本身。</p>
        <button type="button" className="service-add-inline" onClick={() => setService(null)}>
          ＋ 新增模型服务
        </button>
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <footer className="dialog-footer">
          <button type="button" onClick={onClose}>
            取消
          </button>
          <button className="primary" disabled={busy || Boolean(selected && !chosen)}>
            {busy
              ? "正在应用…"
              : !selected
                ? "应用配置"
                : chosen?.credentialState === "configured"
                  ? "使用此服务"
                  : "配置此服务"}
          </button>
        </footer>
      </form>
    </Modal>
  );
}
