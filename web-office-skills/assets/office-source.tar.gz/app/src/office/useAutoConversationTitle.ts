import { useEffect, useRef } from "react";
import type { OfficeConversation, OfficeMessage } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { deriveConversationTitle, isDefaultConversationTitle } from "./conversation-title";
const attemptLimit = 2;
/**
 * Give a fresh conversation a one-line summary title after its first exchange.
 * Runs only while the conversation still shows a placeholder title, so a manual
 * rename is never overwritten; a failed request is retried once on a later poll.
 */
export function useAutoConversationTitle({
  conversation,
  messages,
  enabled,
  onUpdated,
}: {
  conversation: OfficeConversation | null;
  messages: OfficeMessage[];
  enabled: boolean;
  onUpdated(conversation: OfficeConversation): void;
}) {
  const attempts = useRef(new Map<string, number>());
  const inFlight = useRef(new Set<string>());
  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  useEffect(() => {
    if (!enabled || !conversation || inFlight.current.has(conversation.id)) return;
    if (!isDefaultConversationTitle(conversation.title)) return;
    if ((attempts.current.get(conversation.id) ?? 0) >= attemptLimit) return;
    const firstUser = messages.find((message) => message.role === "user" && message.content.trim());
    if (!firstUser) return;
    const title = deriveConversationTitle({
      user: firstUser.content,
      assistant: messages.find((message) => message.role === "assistant")?.content,
    });
    if (!title) return;
    attempts.current.set(conversation.id, (attempts.current.get(conversation.id) ?? 0) + 1);
    inFlight.current.add(conversation.id);
    void officeApi
      .patchConversation(conversation.id, { title })
      .then((result) => {
        if (alive.current) onUpdated(result.conversation);
      })
      .catch(() => {
        /* Best effort: the next poll retries once, the manual rename stays available. */
      })
      .finally(() => {
        inFlight.current.delete(conversation.id);
      });
  }, [conversation, messages, enabled, onUpdated]);
}
