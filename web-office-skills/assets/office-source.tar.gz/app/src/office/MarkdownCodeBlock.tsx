import { useEffect, useRef, useState, type ReactNode } from "react";
import { copyCodeText } from "./copy-code-text";

type CopyStatus = "idle" | "copying" | "copied" | "failed";
export function MarkdownCodeBlock({
  language,
  text,
  children,
}: {
  language?: string;
  text: string | null;
  children: ReactNode;
}) {
  const contentRef = useRef({ text });
  if (contentRef.current.text !== text) contentRef.current = { text };
  const content = contentRef.current;
  const [feedback, setFeedback] = useState<{ content: typeof content; status: CopyStatus }>({
    content,
    status: "idle",
  });
  const status = feedback.content === content ? feedback.status : "idle";
  const mounted = useRef(true);
  const attemptRef = useRef<{ content: typeof content } | null>(null);
  const resetTimer = useRef<{ content: typeof content; id: ReturnType<typeof setTimeout> } | null>(null);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      attemptRef.current = null;
      if (resetTimer.current) clearTimeout(resetTimer.current.id);
      resetTimer.current = null;
    };
  }, []);
  useEffect(
    () => () => {
      if (resetTimer.current?.content === content) {
        clearTimeout(resetTimer.current.id);
        resetTimer.current = null;
      }
    },
    [content],
  );
  return (
    <div className="markdown-code-block">
      <div className="markdown-code-toolbar">
        {language && <div className="markdown-code-language">{language}</div>}
        <button
          type="button"
          className="markdown-code-copy"
          aria-disabled={status === "copying"}
          aria-busy={status === "copying"}
          aria-label={status === "copied" ? "代码已复制" : status === "failed" ? "复制失败，点击重试" : "复制代码"}
          title={status === "failed" ? "复制失败，请手动选择代码，或点击重试。" : "复制代码正文"}
          onClick={async () => {
            if (attemptRef.current?.content === content) return;
            const attempt = { content };
            attemptRef.current = attempt;
            if (resetTimer.current) clearTimeout(resetTimer.current.id);
            resetTimer.current = null;
            const ownsContent = () => mounted.current && contentRef.current === content;
            const isCurrent = () => ownsContent() && attemptRef.current === attempt;
            setFeedback({ content, status: "copying" });
            try {
              if (text === null) throw new Error("code_text_unavailable");
              await copyCodeText(text, isCurrent);
              if (!isCurrent()) return;
              setFeedback({ content, status: "copied" });
              resetTimer.current = {
                content,
                id: setTimeout(() => {
                  if (ownsContent()) setFeedback({ content, status: "idle" });
                  if (resetTimer.current?.content === content) resetTimer.current = null;
                }, 2500),
              };
            } catch {
              if (isCurrent()) setFeedback({ content, status: "failed" });
            } finally {
              if (attemptRef.current === attempt) attemptRef.current = null;
            }
          }}
        >
          {status === "copying"
            ? "复制中…"
            : status === "copied"
              ? "已复制"
              : status === "failed"
                ? "复制失败，重试"
                : "复制"}
        </button>
        <span className="sr-only" role="status" aria-live="polite" aria-atomic="true">
          {status === "copied"
            ? "代码已复制。"
            : status === "failed"
              ? "复制失败，请手动选择代码或重试。"
              : status === "copying"
                ? "正在复制代码。"
                : ""}
        </span>
      </div>
      <pre>{children}</pre>
    </div>
  );
}
