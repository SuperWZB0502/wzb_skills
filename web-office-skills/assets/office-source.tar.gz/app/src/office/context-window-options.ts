/**
 * Context-window presets shown next to the reasoning-effort picker.
 *
 * The office stores a concrete token count (not a percentage) so the value stays meaningful if a
 * model's maximum ever changes. Labels match what the user sees elsewhere: `654k（75%）`.
 */

export const CONTEXT_WINDOW_SHARES = [25, 50, 75, 100] as const;

export interface ContextWindowOption {
  /** Concrete token count handed to the executor, or null for "model default". */
  value: number | null;
  label: string;
}

/** 872000 → "872k"; 654000 → "654k"; 436000 → "436k". */
export function formatWindowTokens(tokens: number): string {
  if (!Number.isFinite(tokens) || tokens <= 0) return "0";
  const thousands = tokens / 1000;
  return (Number.isInteger(thousands) ? String(thousands) : thousands.toFixed(1).replace(/\.0$/, "")) + "k";
}

/** Presets for a model: 默认 + 25/50/75/100% of its maximum window. */
export function contextWindowOptions(maximum: number | null | undefined): ContextWindowOption[] {
  if (!maximum || !Number.isFinite(maximum) || maximum <= 0) return [];
  const options: ContextWindowOption[] = [{ value: null, label: "模型默认" }];
  for (const share of CONTEXT_WINDOW_SHARES) {
    const tokens = Math.round((maximum * share) / 100 / 1000) * 1000;
    options.push({ value: tokens, label: `${formatWindowTokens(tokens)}（${share}%）` });
  }
  return options;
}

/** Option text for a value that is not one of the presets (for example an older saved share). */
export function customWindowLabel(tokens: number): string {
  return `${formatWindowTokens(tokens)}（自定义）`;
}
