import { useCallback, useEffect, useRef, useState } from "react";
import type { OfficeAttachment } from "../../shared/office-contracts";
import { officeApi } from "./api";
export interface AttachmentDraft {
  localId: string;
  file: File;
  previewUrl: string;
  status: "uploading" | "uploaded" | "error";
  attachment?: OfficeAttachment;
  error?: string;
}
const supportedTypes = new Set(["image/png", "image/jpeg", "image/webp"]);
export function useChatAttachments(agentId: string) {
  const [items, setItems] = useState<AttachmentDraft[]>([]);
  const [error, setError] = useState("");
  const current = useRef<AttachmentDraft[]>([]);
  const alive = useRef(true);
  const inFlight = useRef(new Set<string>());
  const update = useCallback((next: AttachmentDraft[]) => {
    current.current = next;
    if (alive.current) setItems(next);
  }, []);
  const clear = useCallback(() => {
    current.current.forEach((item) => URL.revokeObjectURL(item.previewUrl));
    update([]);
    setError("");
  }, [update]);
  useEffect(() => {
    alive.current = true;
    current.current = [];
    setItems([]);
    setError("");
    return () => {
      alive.current = false;
      current.current.forEach((item) => URL.revokeObjectURL(item.previewUrl));
      current.current = [];
    };
  }, [agentId]);
  const upload = useCallback(
    async (localId: string) => {
      const item = current.current.find((value) => value.localId === localId);
      if (!item || item.status === "uploaded" || inFlight.current.has(localId)) return;
      inFlight.current.add(localId);
      update(
        current.current.map((value) =>
          value.localId === localId ? { ...value, status: "uploading", error: undefined } : value,
        ),
      );
      try {
        const { attachment } = await officeApi.uploadAttachment(agentId, item.file);
        if (alive.current)
          update(
            current.current.map((value) =>
              value.localId === localId ? { ...value, status: "uploaded", attachment } : value,
            ),
          );
      } catch {
        if (alive.current)
          update(
            current.current.map((value) =>
              value.localId === localId ? { ...value, status: "error", error: "上传失败，可重试或移除" } : value,
            ),
          );
      } finally {
        inFlight.current.delete(localId);
      }
    },
    [agentId, update],
  );
  const add = useCallback(
    (files: File[]) => {
      setError("");
      const added: AttachmentDraft[] = [];
      const problems: string[] = [];
      for (const file of files) {
        if (!supportedTypes.has(file.type)) {
          problems.push("仅支持 PNG、JPEG 和 WebP 图片。");
          continue;
        }
        if (!file.size || file.size > 5 * 1024 * 1024) {
          problems.push("每张图片需大于 0 且不超过 5 MiB。");
          continue;
        }
        if (current.current.length + added.length >= 4) {
          problems.push("每条消息最多附 4 张图片。");
          continue;
        }
        added.push({ localId: crypto.randomUUID(), file, previewUrl: URL.createObjectURL(file), status: "uploading" });
      }
      update([...current.current, ...added]);
      if (problems.length) setError([...new Set(problems)].join(" "));
      added.forEach((item) => void upload(item.localId));
    },
    [update, upload],
  );
  const remove = useCallback(
    (localId: string) => {
      const item = current.current.find((value) => value.localId === localId);
      if (item) URL.revokeObjectURL(item.previewUrl);
      update(current.current.filter((value) => value.localId !== localId));
      setError("");
    },
    [update],
  );
  return { items, error, add, remove, retry: upload, clear };
}
