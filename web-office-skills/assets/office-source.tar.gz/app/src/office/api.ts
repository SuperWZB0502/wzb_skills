import type {
  AgentDraft,
  OfficeAttachment,
  RunProgressEvent,
  AgentPatch,
  AgentProfile,
  OfficeMessage,
  OfficeSnapshot,
  ProviderCapabilities,
  ProviderProfile,
  MeetingSnapshot,
  OfficeConversation,
  ConversationContextReference,
  ProviderAuthFlow,
  ExecutorKind,
  AuthMode,
  HistoricalAgentIdentity,
  LocalDirectory,
  LocalFileOperation,
  LocalTextPreview,
} from "../../shared/office-contracts";
export interface GitCommitRequest {
  id: string;
  agentName: string;
  worktree: string;
  branch: string;
  head: string;
  message: string;
  files: string[];
}
export interface CapabilityOptions {
  agentId?: string;
  slotId?: string;
  model?: string;
  refresh?: boolean;
}
export interface ConversationCleanup {
  id: string;
  conversationId?: string;
  message: string;
}
/** The request never reached the runtime (offline, or the runtime is shutting down). */
export class OfficeNetworkError extends Error {
  constructor() {
    super("无法连接工作室，请检查连接后重试。");
    this.name = "OfficeNetworkError";
  }
}
export class OfficeApiError extends Error {
  constructor(
    message: string,
    readonly code: "conversation_cleanup_pending",
  ) {
    super(message);
    this.name = "OfficeApiError";
  }
}
let csrfToken = "";
const localDirectoryErrors: Record<string, string> = {
  local_file_browser_disabled: "此连接未启用本地文件浏览。",
  local_directory_invalid: "请输入有效的本机目录路径。",
  local_directory_missing: "目录不存在。",
  local_directory_not_folder: "该路径不是文件夹。",
  local_directory_denied: "当前系统账号无权访问此目录。",
  local_directory_unavailable: "暂时无法读取目录。",
  local_agent_directory_missing: "当前 Agent 尚未创建工作目录。",
  agent_not_found: "找不到当前 Agent。",
  local_file_write_disabled: "当前实例未启用本地文件操作。",
  local_file_exists: "目标已存在，未覆盖。",
  local_file_protected: "该位置由 Web Office 管理，不允许在目录浏览器中修改。",
  local_file_special: "不支持符号链接或特殊文件。",
  local_file_name_invalid: "文件名无效。",
  local_file_copy_inside: "不能复制到自身或自己的子目录。",
  local_file_confirm_required: "输入完整名称后才能永久删除。",
  local_file_recycle_unavailable: "无法移入回收站，文件未永久删除。",
  local_file_operation_failed: "文件操作失败。",
  local_file_busy: "已有操作正在进行，请稍后再试。",
  local_preview_unsupported: "不支持预览这种文件。",
  local_preview_too_large: "图片过大或包含多帧，无法预览原图。",
};
async function request<T>(path: string, method = "GET", body?: unknown, options?: { signal?: AbortSignal; blob?: boolean }): Promise<T> {
  let response: Response;
  try {
    response = await fetch("/api/office" + path, {
      method,
      credentials: "same-origin",
      signal: options?.signal,
      headers: { "content-type": "application/json", ...(csrfToken ? { "x-csrf-token": csrfToken } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch {
    throw new OfficeNetworkError();
  }
  if (!response.ok) {
    // Interpret known application codes only; never echo an upstream response or a submitted Key.
    let code: unknown;
    try {
      code = ((await response.json()) as { error?: unknown }).error;
    } catch {
      /* No safe application code. */
    }
    if ((path === "/local-directory" || path.startsWith("/local-file-")) &&
        typeof code === "string" && Object.hasOwn(localDirectoryErrors, code))
      throw new LocalFileError(code, localDirectoryErrors[code]);
    if (code === "conversation_cleanup_pending")
      throw new OfficeApiError("会话删除或存储清理尚未完成，请在知识库重试清理。", "conversation_cleanup_pending");
    if (response.status === 409 && method === "DELETE" && /^\/conversations\/[^/]+$/.test(path))
      throw new Error("该会话仍有运行中的任务，请先停止任务再删除。");
    if (code === "provider_in_use") throw new Error("服务删除未完成，请刷新服务列表后重试。");
    if (code === "agent_not_archived") throw new Error("请先将身份移入小黑屋，再开除员工。");
    if (code === "boss_protected") throw new Error("Boss 身份不能删除或开除。");
    if (code === "restart_blocked_active_runs") throw new Error("还有任务正在运行，已取消重启；等这些任务结束后再试。");
    if (code === "restart_disabled") throw new Error("当前未启用网页重启入口，请在服务器执行 bash restart-office.sh。");
    if (code === "unsupported_reasoning_effort") {
      throw new Error("所选模型不支持该思考档位，请刷新目录后重新选择，或改用模型默认。");
    }
    throw new Error(
      response.status === 401
        ? "会话已失效，请重新配对。"
        : response.status === 409
          ? "当前状态已变化，请刷新后重试。"
          : "请求未完成，请检查配置后重试。",
    );
  }
  if (response.status === 204) return undefined as T;
  if (options?.blob) return response.blob() as Promise<T>;
  return response.json() as Promise<T>;
}
export class LocalFileError extends Error {
  constructor(readonly code: string, message: string) { super(message); }
}
export const officeApi = {
  setCsrf(value: string) {
    csrfToken = value;
  },
  session: () => request<{ authenticated: true; csrfToken: string }>("/session"),
  pair: (pairingCode: string) => request<{ csrfToken: string }>("/session", "POST", { pairingCode }),
  snapshot: () => request<OfficeSnapshot>("/snapshot"),
  localDirectory: (path: string, agentId?: string) => request<LocalDirectory>("/local-directory", "POST", { path, agentId }),
  localFileOperation: (operation: LocalFileOperation) =>
    request<{ ok: true }>("/local-file-operation", "POST", operation),
  localTextPreview: (path: string, signal: AbortSignal) =>
    request<LocalTextPreview>("/local-file-preview", "POST", { path, kind: "text" }, { signal }),
  localImagePreview: (path: string, signal: AbortSignal) =>
    request<Blob>("/local-file-preview", "POST", { path, kind: "image" }, { signal, blob: true }),
  pendingGitCommits: () => request<{ requests: GitCommitRequest[] }>("/git-commits"),
  reviewGitCommit: (id: string, approve: boolean) =>
    request<{ ok: true }>("/git-commits/" + encodeURIComponent(id), "POST", { approve }),
  restartOffice: () => request<{ restarting: true; bootId: string; activeRuns: number }>("/admin/restart", "POST", {}),
  logout: () => request<void>("/session/logout", "POST"),
  providers: () => request<{ providers: ProviderProfile[] }>("/providers"),
  archivedAgents: () => request<{ agents: AgentProfile[] }>("/agents/archived"),
  historicalAgents: () => request<{ agents: HistoricalAgentIdentity[] }>("/agents/archived?includeDismissed=true"),
  capabilities: (id: string, options: CapabilityOptions = {}) => {
    const query = new URLSearchParams();
    if (options.agentId) query.set("agentId", options.agentId);
    if (options.slotId) query.set("slotId", options.slotId);
    if (options.model) query.set("model", options.model);
    if (options.refresh) query.set("refresh", "1");
    return request<ProviderCapabilities>(
      "/providers/" + encodeURIComponent(id) + "/capabilities" + (query.size ? "?" + query : ""),
    );
  },
  provider: (name: string, baseUrl: string) =>
    request<{ provider: ProviderProfile }>("/providers", "POST", {
      name,
      baseUrl,
      executor: "codex",
      authMode: "api_key",
    }),
  createProvider: (body: {
    name: string;
    baseUrl: string;
    executor: ExecutorKind;
    authMode: AuthMode;
    apiKey?: string;
  }) => request<{ provider: ProviderProfile }>("/providers", "POST", body),
  providerCredential: (id: string, apiKey: string) =>
    request<{ provider: ProviderProfile }>("/providers/" + encodeURIComponent(id) + "/credential", "PUT", { apiKey }),
  deleteProvider: (id: string) => request<{ ok: true }>("/providers/" + encodeURIComponent(id), "DELETE"),
  startProviderAuth: (id: string) =>
    request<{ flow: ProviderAuthFlow }>("/providers/" + encodeURIComponent(id) + "/auth/start", "POST", {}),
  providerAuthStatus: (id: string, loginId: string) =>
    request<{ flow: ProviderAuthFlow }>(
      "/providers/" + encodeURIComponent(id) + "/auth/status?loginId=" + encodeURIComponent(loginId),
    ),
  completeProviderAuth: (id: string, loginId: string, code: string) =>
    request<{ flow: ProviderAuthFlow }>("/providers/" + encodeURIComponent(id) + "/auth/complete", "POST", {
      loginId,
      code,
    }),
  cancelProviderAuth: (id: string, loginId: string) =>
    request<{ ok: true }>("/providers/" + encodeURIComponent(id) + "/auth", "DELETE", { loginId }),
  credentials: (body: { providerId: string; apiKey: string; restoreSlotId?: string }) =>
    request<{ slotId: string; state: string }>("/credentials", "POST", body),
  bindCredential: (id: string, slotId: string) =>
    request<{ agent: AgentProfile }>("/agents/" + encodeURIComponent(id) + "/credential", "PUT", { slotId }),
  saveAgent: (draft: AgentDraft | AgentPatch, id?: string) =>
    request<{ agent: AgentProfile }>(
      id ? "/agents/" + encodeURIComponent(id) : "/agents",
      id ? "PATCH" : "POST",
      draft,
    ),
  cloneAgent: (id: string) =>
    request<{ agent: AgentProfile }>("/agents/" + encodeURIComponent(id) + "/clone", "POST", {}),
  deleteAgent: (id: string, stop: boolean) =>
    request<{ ok: true }>("/agents/" + encodeURIComponent(id) + (stop ? "?stop=true" : ""), "DELETE"),
  dismissAgent: (id: string) => request<{ ok: true }>("/agents/" + encodeURIComponent(id) + "/dismiss", "DELETE"),
  messages: (id: string) => request<{ messages: OfficeMessage[] }>("/agents/" + encodeURIComponent(id) + "/messages"),
  progress: (id: string, afterSeq = 0, conversationId?: string) =>
    request<{ events: RunProgressEvent[] }>(
      "/agents/" +
        encodeURIComponent(id) +
        "/progress?afterSeq=" +
        afterSeq +
        (conversationId ? "&conversationId=" + encodeURIComponent(conversationId) : ""),
    ),
  conversations: (id: string) =>
    request<{ conversations: OfficeConversation[] }>("/agents/" + encodeURIComponent(id) + "/conversations"),
  createConversation: (id: string, title?: string) =>
    request<{ conversation: OfficeConversation }>(
      "/agents/" + encodeURIComponent(id) + "/conversations",
      "POST",
      title ? { title } : {},
    ),
  allConversations: (search = "") =>
    request<{ conversations: OfficeConversation[] }>(
      "/conversations" + (search ? "?search=" + encodeURIComponent(search) : ""),
    ),
  conversationMessages: (id: string) =>
    request<{ conversation: OfficeConversation; messages: OfficeMessage[] }>(
      "/conversations/" + encodeURIComponent(id) + "/messages",
    ),
  patchConversation: (id: string, body: { title?: string; category?: string }) =>
    request<{ conversation: OfficeConversation }>("/conversations/" + encodeURIComponent(id), "PATCH", body),
  deleteConversation: (id: string) => request<{ ok: true }>("/conversations/" + encodeURIComponent(id), "DELETE"),
  compactConversation: (id: string, recent?: number) =>
    request<{
      conversationId: string;
      messages: number;
      keptMessages: number;
      summarisedMessages: number;
      digestCharacters: number;
      droppedThreads: number;
      previousPercent: number | null;
    }>("/conversations/" + encodeURIComponent(id) + "/compact", "POST", { recent }),
  conversationCleanups: () => request<{ cleanups: ConversationCleanup[] }>("/conversation-cleanups"),
  retryConversationCleanup: (id: string) =>
    request<{ ok: true }>("/conversation-cleanups/" + encodeURIComponent(id) + "/retry", "POST", {}),
  conversationContext: (id: string) =>
    request<{ references: ConversationContextReference[] }>("/conversations/" + encodeURIComponent(id) + "/context"),
  addConversationContext: (id: string, sourceConversationIds: string[]) =>
    request<{ references: ConversationContextReference[] }>(
      "/conversations/" + encodeURIComponent(id) + "/context",
      "POST",
      { sourceConversationIds },
    ),
  removeConversationContext: (id: string, referenceId: string) =>
    request<{ ok: true }>(
      "/conversations/" + encodeURIComponent(id) + "/context/" + encodeURIComponent(referenceId),
      "DELETE",
    ),
  uploadAttachment: async (agentId: string, file: File) => {
    const dataBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("无法读取图片，请重新选择。"));
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.readAsDataURL(file);
    });
    return request<{ attachment: OfficeAttachment }>(
      "/agents/" + encodeURIComponent(agentId) + "/attachments",
      "POST",
      { name: file.name, mimeType: file.type, dataBase64 },
    );
  },
  send: (
    id: string,
    content: string,
    idempotencyKey: string,
    attachmentIds: string[] = [],
    options: { conversationId?: string; contextConversationIds?: string[] } = {},
  ) =>
    request<{ messageId: string; runId: string; conversationId: string }>(
      "/agents/" + encodeURIComponent(id) + "/messages",
      "POST",
      {
        content,
        idempotencyKey,
        attachmentIds,
        ...options,
      },
    ),
  stop: (runId: string) => request<{ ok: true }>("/runs/" + encodeURIComponent(runId) + "/stop", "POST"),
  meeting: (id: string) =>
    request<{ meeting: MeetingSnapshot; messages: OfficeMessage[] }>("/meetings/" + encodeURIComponent(id)),
  createMeeting: (title: string, participantIds: string[]) =>
    request<{ meeting: MeetingSnapshot }>("/meetings", "POST", { title, participantIds }),
};
