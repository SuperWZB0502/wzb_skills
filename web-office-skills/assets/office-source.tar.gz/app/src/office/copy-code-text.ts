function focusWithoutScroll(element: HTMLElement) {
  try {
    element.focus({ preventScroll: true });
  } catch {
    element.focus();
  }
}

function copyUsingSelection(text: string) {
  const focused = document.activeElement;
  const selection = document.getSelection();
  const ranges: Range[] = [];
  if (selection)
    for (let index = 0; index < selection.rangeCount; index++) ranges.push(selection.getRangeAt(index).cloneRange());
  const field = focused instanceof HTMLInputElement || focused instanceof HTMLTextAreaElement ? focused : null;
  const start = field?.selectionStart;
  const end = field?.selectionEnd;
  const direction = field?.selectionDirection;
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.readOnly = true;
  textarea.tabIndex = -1;
  textarea.setAttribute("aria-hidden", "true");
  Object.assign(textarea.style, {
    position: "fixed",
    top: "0",
    left: "0",
    width: "1px",
    height: "1px",
    opacity: "0",
    padding: "0",
    border: "0",
    fontSize: "16px",
    pointerEvents: "none",
  });
  // A body-level textarea cannot receive focus while a descendant is fullscreen.
  (document.fullscreenElement || document.body).appendChild(textarea);
  try {
    focusWithoutScroll(textarea);
    textarea.select();
    textarea.setSelectionRange(0, text.length);
    if (
      document.activeElement !== textarea ||
      textarea.selectionStart !== 0 ||
      textarea.selectionEnd !== text.length ||
      !document.execCommand("copy")
    )
      throw new Error("copy_failed");
  } finally {
    textarea.remove();
    try {
      if (focused instanceof HTMLElement && focused.isConnected) focusWithoutScroll(focused);
      if (field?.isConnected && start != null && end != null)
        field.setSelectionRange(start, end, direction || undefined);
    } catch {
      /* A removed or no longer selectable field cannot be restored. */
    }
    try {
      if (selection) {
        selection.removeAllRanges();
        for (const range of ranges) if (range.commonAncestorContainer.isConnected) selection.addRange(range);
      }
    } catch {
      /* The original message may have changed while the browser handled copy. */
    }
  }
}

export async function copyCodeText(text: string, isCurrent: () => boolean) {
  if (!isCurrent()) throw new Error("copy_cancelled");
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
  } catch {
    /* Permission denial and insecure contexts may still permit selection copy. */
  }
  if (!isCurrent()) throw new Error("copy_cancelled");
  copyUsingSelection(text);
}
