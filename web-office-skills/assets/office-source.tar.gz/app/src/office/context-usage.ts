import type { OfficeConversationContext } from "../../shared/office-contracts";

/** Compact token counts for badges: 1234 → "1.2k", 200000 → "200k". */
export function formatTokens(tokens: number): string {
  if (!Number.isFinite(tokens) || tokens <= 0) return "0";
  if (tokens >= 1_000_000) return (tokens / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (tokens >= 10_000) return Math.round(tokens / 1000) + "k";
  if (tokens >= 1000) return (tokens / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return String(Math.round(tokens));
}

/** Badge text for the chat header; empty when the executor has not reported usage yet. */
export function contextBadgeLabel(context: OfficeConversationContext | null | undefined): string {
  if (!context || !Number.isFinite(context.percent)) return "";
  // Legacy rows recorded thread totals; a request can never exceed its own window.
  if (!(context.window > 0) || context.used > context.window * 2) return "";
  return "上下文 " + Math.min(100, Math.max(0, Math.round(context.percent))) + "%";
}

/** Tooltip explaining the number and when compaction kicks in. */
export function contextBadgeTitle(context: OfficeConversationContext | null | undefined): string {
  if (!context || !(context.window > 0) || context.used > context.window * 2) return "";
  return `已用 ${formatTokens(context.used)} / ${formatTokens(context.window)} tokens，达到 ${context.threshold}% 时自动压缩上下文`;
}
