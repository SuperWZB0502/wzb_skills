import { useCallback, useEffect, useRef, useState } from "react";
import type { OfficeConversation } from "../../shared/office-contracts";
import { officeApi } from "./api";
const rememberedConversation = new Map<string, string>();
export function useAgentConversations(agentId: string, archived: boolean) {
  const [conversations, setConversations] = useState<OfficeConversation[]>([]),
    [conversationId, setConversationId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true),
    [creating, setCreating] = useState(false),
    [error, setError] = useState("");
  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    let current = true;
    setConversations([]);
    setConversationId(null);
    setLoading(true);
    setError("");
    void officeApi
      .conversations(agentId)
      .then(async (result) => {
        if (!current) return;
        let list = result.conversations;
        if (!list.length && !archived) {
          const created = await officeApi.createConversation(agentId);
          list = [created.conversation];
        }
        if (!current) return;
        setConversations(list);
        const remembered = rememberedConversation.get(agentId);
        const selected =
          list.find((item) => item.id === remembered) || [...list].sort((a, b) => b.updatedAt - a.updatedAt)[0];
        if (selected) {
          setConversationId(selected.id);
          rememberedConversation.set(agentId, selected.id);
        }
      })
      .catch((e) => {
        if (current) setError((e as Error).message);
      })
      .finally(() => {
        if (current) setLoading(false);
      });
    return () => {
      current = false;
      alive.current = false;
    };
  }, [agentId, archived]);
  const choose = useCallback(
    (id: string) => {
      setConversationId(id);
      rememberedConversation.set(agentId, id);
      setError("");
    },
    [agentId],
  );
  const create = useCallback(async () => {
    if (archived || creating) return;
    setCreating(true);
    setError("");
    try {
      const result = await officeApi.createConversation(agentId);
      if (alive.current) {
        setConversations((current) => [result.conversation, ...current]);
        choose(result.conversation.id);
      }
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    } finally {
      if (alive.current) setCreating(false);
    }
  }, [agentId, archived, creating, choose]);
  const update = useCallback(
    (conversation: OfficeConversation) =>
      setConversations((current) => current.map((item) => (item.id === conversation.id ? conversation : item))),
    [],
  );
  return { conversations, conversationId, loading, creating, error, choose, create, update };
}
