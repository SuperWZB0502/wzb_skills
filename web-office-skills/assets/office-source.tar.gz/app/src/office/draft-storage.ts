/**
 * Chat drafts are kept per conversation in this browser only, so leaving the
 * dialog (or the page) never discards half-written text. No server copy and no
 * storage of attachments: only the plain text the user typed.
 */
const prefix = "office.chat.draft.";
export const maxDraftLength = 20000;
function key(conversationId: string | null | undefined): string | null {
  return conversationId ? prefix + conversationId : null;
}
export function readChatDraft(conversationId: string | null | undefined): string {
  const name = key(conversationId);
  if (!name) return "";
  try {
    return (globalThis.localStorage?.getItem(name) ?? "").slice(0, maxDraftLength);
  } catch {
    return "";
  }
}
export function writeChatDraft(conversationId: string | null | undefined, text: string): void {
  const name = key(conversationId);
  if (!name) return;
  try {
    if (!text) globalThis.localStorage?.removeItem(name);
    else globalThis.localStorage?.setItem(name, text.slice(0, maxDraftLength));
  } catch {
    /* Storage may be full or blocked; the draft then only lives in this mount. */
  }
}
export function clearChatDraft(conversationId: string | null | undefined): void {
  const name = key(conversationId);
  if (!name) return;
  try {
    globalThis.localStorage?.removeItem(name);
  } catch {
    /* ignore */
  }
}
