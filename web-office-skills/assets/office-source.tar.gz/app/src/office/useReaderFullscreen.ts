import { useCallback, useEffect, useRef, useState, type RefObject } from "react";

/** Keep the same reader DOM; fall back to filling the viewport if native fullscreen is unavailable. */
export function useReaderFullscreen(target: RefObject<HTMLElement | null>) {
  const [mode, setMode] = useState<"native" | "viewport" | null>(null);
  const [busy, setBusy] = useState(false);
  const modeRef = useRef(mode);
  const mounted = useRef(false);
  const pending = useRef(false);
  const exitedAt = useRef(-Infinity);
  const updateMode = useCallback((next: typeof mode) => {
    modeRef.current = next;
    if (mounted.current) setMode(next);
  }, []);

  useEffect(() => {
    mounted.current = true;
    const element = target.current;
    const onChange = () => {
      if (document.fullscreenElement === element) updateMode("native");
      else if (modeRef.current === "native") {
        exitedAt.current = performance.now();
        updateMode(null);
      }
    };
    const onEscape = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || event.isComposing) return;
      const native = document.fullscreenElement === element;
      // Some browsers dispatch fullscreenchange before the Escape key event.
      // That same Escape must not also close the underlying chat dialog.
      if (!native && modeRef.current !== "viewport" && performance.now() - exitedAt.current > 300) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (native) void document.exitFullscreen().catch(() => {});
      else if (modeRef.current === "viewport") {
        exitedAt.current = performance.now();
        updateMode(null);
      }
    };
    document.addEventListener("fullscreenchange", onChange);
    document.addEventListener("keydown", onEscape, true);
    return () => {
      mounted.current = false;
      document.removeEventListener("fullscreenchange", onChange);
      document.removeEventListener("keydown", onEscape, true);
      if (document.fullscreenElement === element) void document.exitFullscreen().catch(() => {});
    };
  }, [target, updateMode]);

  const toggle = useCallback(async () => {
    const element = target.current;
    if (!element || pending.current) return;
    if (modeRef.current === "viewport") {
      exitedAt.current = performance.now();
      updateMode(null);
      return;
    }
    pending.current = true;
    setBusy(true);
    try {
      if (document.fullscreenElement === element) await document.exitFullscreen().catch(() => {});
      else {
        try {
          if (!element.requestFullscreen) throw new Error("fullscreen_unavailable");
          await element.requestFullscreen();
        } catch {
          if (mounted.current && element.isConnected) updateMode("viewport");
        }
      }
    } finally {
      pending.current = false;
      if (mounted.current) setBusy(false);
    }
  }, [target, updateMode]);

  return { active: mode !== null, viewport: mode === "viewport", busy, toggle };
}
