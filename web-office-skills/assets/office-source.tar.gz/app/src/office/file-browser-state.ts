export interface DirectoryViewState {
  expanded: string[];
  selected: string | null;
  scrollTop: number;
}

const storageKey = "web-office.file-browser.tree.v1";
const workspaceWidthKey = "web-office.file-browser.workspace-width.v1";
export const workspaceDirectoryDefaultWidth = 336;
export const workspaceDirectoryMinWidth = 260;
export const workspaceDirectoryMaxWidth = 840;
const emptyView = (): DirectoryViewState => ({ expanded: [], selected: null, scrollTop: 0 });
const validPath = (value: unknown): value is string => typeof value === "string" && value.length <= 4096;

function savedViews(): [string, DirectoryViewState][] {
  try {
    const value = JSON.parse(localStorage.getItem(storageKey) ?? "[]");
    return Array.isArray(value) ? value.filter((entry) => Array.isArray(entry) && validPath(entry[0])).slice(0, 16) : [];
  } catch {
    return [];
  }
}

export function readDirectoryView(path: string): DirectoryViewState {
  const view = savedViews().find(([name]) => name === path)?.[1];
  if (!view) return emptyView();
  return {
    expanded: Array.isArray(view.expanded) ? view.expanded.filter(validPath).slice(0, 128) : [],
    selected: validPath(view.selected) ? view.selected : null,
    scrollTop: Number.isFinite(view.scrollTop) ? Math.max(0, view.scrollTop) : 0,
  };
}

export function saveDirectoryView(path: string, view: DirectoryViewState) {
  try {
    const next = [[path, view], ...savedViews().filter(([name]) => name !== path)].slice(0, 16);
    localStorage.setItem(storageKey, JSON.stringify(next));
  } catch {
    return;
  }
}

export function readWorkspaceDirectoryWidth() {
  try {
    const value = Number(localStorage.getItem(workspaceWidthKey));
    if (Number.isInteger(value) && value >= workspaceDirectoryMinWidth && value <= workspaceDirectoryMaxWidth)
      return value;
  } catch {
    return workspaceDirectoryDefaultWidth;
  }
  return workspaceDirectoryDefaultWidth;
}

export function saveWorkspaceDirectoryWidth(value: number) {
  try {
    localStorage.setItem(workspaceWidthKey, String(value));
  } catch {
    return;
  }
}
