import { useEffect, useId, useRef, useState, type KeyboardEvent } from "react";

export interface MenuPosition {
  top: number;
  left: number;
  width: number;
}

/**
 * Shared dropdown plumbing for the conversation and reference pickers: the menu is
 * rendered in a portal with fixed coordinates so it is never clipped by the chat
 * toolbar, and closes on outside click, scroll, resize or Escape.
 */
export function useAnchoredMenu({
  align = "start",
  minWidth = 260,
  maxWidth = 560,
}: { align?: "start" | "end"; minWidth?: number; maxWidth?: number } = {}) {
  const toggleRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLUListElement>(null);
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState<MenuPosition | null>(null);
  const menuId = useId();

  const close = (restoreFocus = false) => {
    setOpen(false);
    if (restoreFocus) toggleRef.current?.focus();
  };

  const openMenu = () => {
    const rect = toggleRef.current?.getBoundingClientRect();
    if (!rect) return;
    const viewport = window.innerWidth - 16;
    const width = Math.max(Math.min(minWidth, viewport), Math.min(rect.width, Math.min(maxWidth, viewport)));
    const preferred = align === "end" ? rect.right - width : rect.left;
    const left = Math.max(8, Math.min(preferred, window.innerWidth - width - 8));
    setPosition({ top: rect.bottom + 6, left, width });
    setOpen(true);
  };

  const toggle = () => (open ? close() : openMenu());

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (toggleRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onViewportChange = () => setOpen(false);
    document.addEventListener("mousedown", onPointerDown);
    window.addEventListener("resize", onViewportChange);
    window.addEventListener("scroll", onViewportChange, true);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      window.removeEventListener("resize", onViewportChange);
      window.removeEventListener("scroll", onViewportChange, true);
    };
  }, [open]);

  const onKeyDown = (event: KeyboardEvent) => {
    if (event.key !== "Escape" || !open) return;
    // Keep the chat dialog open; only the dropdown closes.
    event.stopPropagation();
    close(true);
  };

  return { open, position, menuId, toggleRef, menuRef, close, toggle, openMenu, onKeyDown };
}
