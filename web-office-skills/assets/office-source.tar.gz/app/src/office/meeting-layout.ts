export interface RoomRect {
  x: number;
  y: number;
  width: number;
  height: number;
}
export interface SeatPoint {
  agentId: string;
  x: number;
  y: number;
}
export interface WalkPoint {
  x: number;
  y: number;
}
export type OfficeRoom = "boss" | "meeting" | "work" | "rest";
export function layoutOfficeZones(agentCount: number, meetingCapacity = agentCount + 1, archivedCount = 0) {
  const aisleWidth = 76;
  const workBase = Math.max(375, Math.ceil(agentCount / 5) * 132 + 150);
  const restHeight = Math.max(230, Math.ceil(agentCount / 8) * 76 + 125);
  const meetingMin = Math.max(300, Math.ceil(meetingCapacity / 3) * 86 + 170);
  const total = Math.max(workBase + aisleWidth + restHeight, 260 + aisleWidth + meetingMin);
  const workHeight = total - aisleWidth - restHeight;
  const boss = { x: 30, y: 30, width: 310, height: 260 };
  const meeting = { x: 30, y: boss.y + boss.height + aisleWidth, width: 310, height: total - 260 - aisleWidth };
  const work = { x: 340 + aisleWidth, y: 30, width: 770, height: workHeight };
  const rest = { x: work.x, y: 30 + workHeight + aisleWidth, width: 770, height: restHeight };
  const library = { x: work.x + work.width + aisleWidth, y: 30, width: 300, height: Math.min(workHeight, 440) };
  const blackroomHeight = Math.max(230, Math.ceil(archivedCount / 3) * 108 + 95);
  const blackroom = {
    x: library.x,
    y: Math.max(library.y + library.height + aisleWidth, 30 + total - blackroomHeight),
    width: 300,
    height: blackroomHeight,
  };
  return {
    boss,
    meeting,
    work,
    rest,
    library,
    blackroom,
    libraryAisle: {
      x: work.x + work.width,
      y: 30,
      width: aisleWidth,
      height: Math.max(total, blackroom.y + blackroom.height - 30),
    },
    worldWidth: library.x + library.width + 30,
    verticalAisle: { x: 340, y: 30, width: aisleWidth, height: total },
    bossAisle: { x: 30, y: boss.y + boss.height, width: work.x - 30, height: aisleWidth },
    blackroomAisle: {
      x: work.x + work.width,
      y: library.y + library.height,
      width: aisleWidth + library.width,
      height: aisleWidth,
    },
    horizontalAisle: { x: 340, y: 30 + workHeight, width: library.x - 340, height: aisleWidth },
    doors: {
      boss: { x: 340, y: boss.y + boss.height - 50 },
      meeting: { x: 340, y: meeting.y + 65 },
      work: { x: work.x + work.width / 2, y: work.y + work.height },
      rest: { x: rest.x + rest.width / 2, y: rest.y },
      library: { x: library.x, y: library.y + library.height - 50 },
      blackroom: { x: blackroom.x, y: blackroom.y + 65 },
    },
  };
}
export type OfficeZones = ReturnType<typeof layoutOfficeZones>;
export function layoutMeeting(room: RoomRect, participantIds: string[]): SeatPoint[] {
  const columns = 3;
  const rows = Math.ceil(participantIds.length / columns);
  return participantIds.map((agentId, index) => ({
    agentId,
    x: room.x + (((index % columns) + 1) * room.width) / (columns + 1),
    y: room.y + 135 + ((Math.floor(index / columns) + 1) * (room.height - 165)) / (rows + 1),
  }));
}
function locate(zones: OfficeZones, point: WalkPoint): OfficeRoom | null {
  return (
    (["boss", "meeting", "work", "rest"] as const).find((name) => {
      const room = zones[name];
      return (
        point.x >= room.x && point.x <= room.x + room.width && point.y >= room.y && point.y <= room.y + room.height
      );
    }) || null
  );
}
function insidePath(zones: OfficeZones, room: OfficeRoom, point: WalkPoint, outward: boolean): WalkPoint[] {
  const door = zones.doors[room];
  let path: WalkPoint[];
  if (room === "work") {
    const laneX = Math.min(zones.work.x + zones.work.width - 25, point.x + 60);
    path = [point, { x: laneX, y: point.y }, { x: laneX, y: door.y - 35 }, { x: door.x, y: door.y - 35 }, door];
  } else if (room === "rest")
    path = [point, { x: point.x, y: zones.rest.y + 60 }, { x: door.x, y: zones.rest.y + 60 }, door];
  else {
    const laneX = zones[room].x + zones[room].width - 35;
    path = [point, { x: laneX, y: point.y }, { x: laneX, y: door.y }, door];
  }
  return outward ? path.slice(1) : path.slice(0, -1).reverse();
}
export function officeWalkPath(
  zones: OfficeZones,
  from: WalkPoint,
  to: WalkPoint,
  destination: OfficeRoom,
): WalkPoint[] {
  const origin = locate(zones, from);
  if (origin === destination) return [to];
  const verticalX = zones.verticalAisle.x + zones.verticalAisle.width / 2;
  const crossY = zones.horizontalAisle.y + zones.horizontalAisle.height / 2;
  const path: WalkPoint[] = origin ? insidePath(zones, origin, from, true) : [];
  const fromDoor = origin ? zones.doors[origin] : from;
  if ((origin === "work" || origin === "rest") && (destination === "work" || destination === "rest")) {
    path.push({ x: fromDoor.x, y: crossY }, zones.doors[destination], ...insidePath(zones, destination, to, false));
    return path;
  }
  if (
    origin === "work" ||
    origin === "rest" ||
    (!origin && from.y >= zones.horizontalAisle.y && from.y <= zones.rest.y)
  )
    path.push({ x: fromDoor.x, y: crossY }, { x: verticalX, y: crossY });
  else path.push({ x: verticalX, y: fromDoor.y });
  const entry = zones.doors[destination];
  if (destination === "work" || destination === "rest")
    path.push({ x: verticalX, y: crossY }, { x: entry.x, y: crossY }, entry);
  else path.push({ x: verticalX, y: entry.y }, entry);
  path.push(...insidePath(zones, destination, to, false));
  return path.filter(
    (point, index) =>
      index === 0 || Math.abs(point.x - path[index - 1].x) + Math.abs(point.y - path[index - 1].y) > 0.1,
  );
}
