export function AppearancePicker({ value, onChange }: { value: number | null; onChange(value: number): void }) {
  return (
    <fieldset className="appearance">
      <legend>角色外观</legend>
      <div>
        {Array.from({ length: 14 }, (_, i) => (
          <button
            key={i}
            type="button"
            aria-label={"外观 " + (i + 1)}
            aria-pressed={value === i + 1}
            className={value === i + 1 ? "selected" : ""}
            onClick={() => onChange(i + 1)}
          >
            <img alt="" src={"/sprites/" + (i + 1) + "-D-1.png"} />
          </button>
        ))}
      </div>
      <small>外观与性别标签独立选择。</small>
    </fieldset>
  );
}
