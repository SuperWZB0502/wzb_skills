import { useCallback, useEffect, useRef, useState } from "react";
import type { ProviderProfile } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { ServiceDialog } from "./ServiceDialog";
import { Modal } from "./Modal";
import { credentialLabels } from "./labels";
import { useOptionalOfficeClient } from "./OfficeClientProvider";
export function ProviderList({ onChanged }: { onChanged(): void | Promise<unknown> }) {
  const client = useOptionalOfficeClient();
  const bootId = client?.snapshot?.bootId;
  const credentialSignature = client?.snapshot?.agents
    .map((agent) => [agent.id, agent.providerId, agent.credentialState, agent.credentialSlotId].join(":"))
    .join("|");
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<ProviderProfile | null | undefined>();
  const [deleting, setDeleting] = useState<ProviderProfile | null>(null);
  const loadSeq = useRef(0);
  const load = useCallback(async () => {
    const seq = ++loadSeq.current;
    try {
      const result = await officeApi.providers();
      if (seq !== loadSeq.current) return;
      setProviders(result.providers);
      setError("");
    } catch (e) {
      if (seq === loadSeq.current) setError((e as Error).message);
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load, bootId, credentialSignature]);
  return (
    <section className="provider-list" aria-label="我的模型服务">
      <div className="section-heading">
        <h2>
          我的模型服务 <span>{providers.length}</span>
        </h2>
        <button className="icon-button" aria-label="新增模型服务" onClick={() => setEditing(null)}>
          ＋
        </button>
      </div>
      {loading ? (
        <p className="hint">正在读取服务…</p>
      ) : providers.length === 0 ? (
        <div className="provider-empty">
          <p>先添加一个自己的模型服务。</p>
          <button type="button" onClick={() => setEditing(null)}>
            新增模型服务 ↗
          </button>
        </div>
      ) : (
        providers.map((provider) => (
          <article className="provider-row" key={provider.id}>
            <button
              className="provider-main"
              onClick={() => setEditing(provider)}
              aria-label={"配置服务 " + provider.name}
            >
              <span className="provider-vendor">{provider.executor === "claude-code" ? "CC" : "CX"}</span>
              <span>
                <strong>{provider.name}</strong>
                <small>
                  {provider.executor === "claude-code" ? "Claude Code" : "Codex"} ·{" "}
                  {provider.authMode === "account" ? "账户认证" : "API Key"}
                </small>
                <em className={"provider-state " + (provider.credentialState || "required")}>
                  {credentialLabels[provider.credentialState || "required"]}
                </em>
              </span>
            </button>
            <button
              className="icon-button provider-delete"
              aria-label={"删除服务 " + provider.name}
              onClick={() => {
                setError("");
                setDeleting(provider);
              }}
            >
              ×
            </button>
          </article>
        ))
      )}
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {editing !== undefined && (
        <ServiceDialog
          provider={editing}
          onClose={() => {
            setEditing(undefined);
            void load();
            void onChanged();
          }}
          onSaved={async () => {
            setEditing(undefined);
            await load();
            await onChanged();
          }}
        />
      )}
      {deleting && (
        <Modal
          title={"删除模型服务“" + deleting.name + "”？"}
          subtitle="关联伙伴将自动改为稍后配置"
          onClose={() => setDeleting(null)}
        >
          <div className="dialog-form">
            <p className="hint">
              删除后，使用此服务的伙伴会自动改为“稍后配置”。已开始的任务继续使用原配置直到结束，会话记录保留。
            </p>
            {error && (
              <p className="form-error" role="alert">
                {error}
              </p>
            )}
            <footer className="dialog-footer">
              <button onClick={() => setDeleting(null)}>取消</button>
              <button
                className="danger"
                disabled={busy}
                onClick={async () => {
                  setBusy(true);
                  setError("");
                  try {
                    await officeApi.deleteProvider(deleting.id);
                    setDeleting(null);
                    await load();
                    await onChanged();
                  } catch (e) {
                    setError((e as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                {busy ? "正在删除…" : "确认删除服务"}
              </button>
            </footer>
          </div>
        </Modal>
      )}
    </section>
  );
}
