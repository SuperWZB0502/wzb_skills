import type { AgentProfile, MeetingSnapshot, OfficeSnapshot, TaskRuntimeEvent } from "../../shared/office-contracts";
export interface OfficeEvent {
  type: string;
  payload: unknown;
}
export function applyOfficeEvent(snapshot: OfficeSnapshot, event: OfficeEvent): OfficeSnapshot {
  if (event.type === "office.snapshot") {
    const incoming = event.payload as OfficeSnapshot;
    return incoming.bootId === snapshot.bootId && incoming.lastSeq < snapshot.lastSeq ? snapshot : incoming;
  }
  if (event.type === "office.task") {
    const p = event.payload as TaskRuntimeEvent;
    if (p.seq <= snapshot.lastSeq) return snapshot;
    return {
      ...snapshot,
      lastSeq: p.seq,
      agents: snapshot.agents.map((a) =>
        a.id === p.agentId
          ? {
              ...a,
              workState: p.state,
              currentTaskId: p.taskId,
              currentConversationId: a.currentRunId === p.runId ? a.currentConversationId : null,
              currentWorkSummary: p.summary,
              currentRunId: ["working", "meeting", "waiting_input"].includes(p.state) ? p.runId : null,
            }
          : a,
      ),
    };
  }
  if (event.type === "office.agent") {
    const p = event.payload as AgentProfile | { agent?: AgentProfile; deletedId?: string };
    if ("deletedId" in p && p.deletedId)
      return { ...snapshot, agents: snapshot.agents.filter((a) => a.id !== p.deletedId) };
    const agent = ("agent" in p ? p.agent : p) as AgentProfile;
    if (!agent?.id) return snapshot;
    return {
      ...snapshot,
      agents: snapshot.agents.some((a) => a.id === agent.id)
        ? snapshot.agents.map((a) => (a.id === agent.id ? agent : a))
        : [...snapshot.agents, agent],
    };
  }
  if (event.type === "office.meeting") {
    const p = event.payload as MeetingSnapshot | { meeting: MeetingSnapshot };
    const meeting = "meeting" in p ? p.meeting : p;
    return { ...snapshot, meetings: [...snapshot.meetings.filter((m) => m.id !== meeting.id), meeting] };
  }
  return snapshot;
}
