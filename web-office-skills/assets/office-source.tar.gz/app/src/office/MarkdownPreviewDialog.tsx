import { startTransition, useEffect, useRef, useState } from "react";
import { Modal } from "./Modal";
import { MessageBody } from "./MessageBody";
import { fileNameOf, workspaceFileUrl } from "./file-links";

/** Hard cap: the renderer runs on the main thread, multi-MB documents freeze the page. */
export const maxPreviewBytes = 5 * 1024 * 1024;
/** Above this size we still render, but warn that it may take a moment. */
export const largePreviewBytes = 1024 * 1024;

type PreviewState =
  | { status: "loading" }
  | { status: "ready"; text: string; bytes: number }
  | { status: "tooLarge"; bytes: number }
  | { status: "error"; message: string };

function formatBytes(bytes: number): string {
  if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + " MB";
  if (bytes >= 1024) return Math.round(bytes / 1024) + " KB";
  return bytes + " B";
}

/** Rendered Markdown preview for a workspace document (never the raw source). */
export function MarkdownPreviewDialog({ agentId, path, onClose }: { agentId: string; path: string; onClose(): void }) {
  const [state, setState] = useState<PreviewState>({ status: "loading" });
  const mounted = useRef(true);
  const downloadUrl = workspaceFileUrl(agentId, path, "download");
  useEffect(() => {
    mounted.current = true;
    const controller = new AbortController();
    setState({ status: "loading" });
    void (async () => {
      try {
        const response = await fetch(downloadUrl, {
          signal: controller.signal,
          headers: { "cache-control": "no-cache" },
        });
        if (!response.ok) throw new Error("http_" + response.status);
        const declared = Number(response.headers.get("content-length") ?? "0");
        if (declared > maxPreviewBytes) {
          if (mounted.current) setState({ status: "tooLarge", bytes: declared });
          return;
        }
        const text = await response.text();
        const bytes = new TextEncoder().encode(text).length;
        if (!mounted.current) return;
        if (bytes > maxPreviewBytes) {
          setState({ status: "tooLarge", bytes });
          return;
        }
        startTransition(() => setState({ status: "ready", text, bytes }));
      } catch (error) {
        if (controller.signal.aborted || !mounted.current) return;
        setState({ status: "error", message: "暂时无法读取这个文档。" });
      }
    })();
    return () => {
      controller.abort();
      mounted.current = false;
    };
  }, [downloadUrl]);
  return (
    <Modal title={fileNameOf(path)} subtitle={path} onClose={onClose} className="markdown-preview">
      <div className="markdown-preview__toolbar">
        <span>
          {state.status === "ready"
            ? `${formatBytes(state.bytes)}${state.bytes > largePreviewBytes ? " · 文档较大，渲染需要几秒" : ""}`
            : state.status === "tooLarge"
              ? `文档过大（${formatBytes(state.bytes)}），超过 ${formatBytes(maxPreviewBytes)} 预览上限`
              : "Markdown 预览"}
        </span>
        <a className="workspace-file-link" href={downloadUrl} download="">
          下载原文
        </a>
      </div>
      <div className="markdown-preview__body">
        {state.status === "loading" && <div className="skeleton">正在读取并渲染文档…</div>}
        {state.status === "error" && (
          <p className="form-error" role="alert">
            {state.message}可以点上方「下载原文」查看。
          </p>
        )}
        {state.status === "tooLarge" && (
          <p className="form-error" role="alert">
            这个文件太大，浏览器端渲染会卡住页面；请使用「下载原文」查看。
          </p>
        )}
        {state.status === "ready" && (
          <MessageBody content={state.text} role="assistant" agentId={agentId} basePath={path} />
        )}
      </div>
    </Modal>
  );
}
