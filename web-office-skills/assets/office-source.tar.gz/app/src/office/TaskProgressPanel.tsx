import { memo, useEffect, useState } from "react";
import type { AgentProfile, RunProgressEvent } from "../../shared/office-contracts";
export interface ChatSubmission {
  at: number;
  runId: string | null;
  state: "submitting" | "accepted" | "failed";
}
const kindLabels = {
  queued: "排队",
  starting: "准备",
  thinking: "等待模型",
  commentary: "执行进展",
  tool: "工具活动",
  completed: "已完成",
  error: "执行出错",
  stopped: "已停止",
};
function publicTitle(event: RunProgressEvent) {
  return event.kind === "thinking" ? "等待模型响应" : event.title || kindLabels[event.kind];
}
export const TaskProgressPanel = memo(function TaskProgressPanel({
  agent,
  events,
  connected,
  historyError,
  submission,
}: {
  agent: AgentProfile;
  events: RunProgressEvent[];
  connected: boolean;
  historyError: string;
  submission: ChatSubmission | null;
}) {
  const [now, setNow] = useState(Date.now());
  const submittedEvents = submission?.runId ? events.filter((event) => event.runId === submission.runId) : [];
  const submittedFinished = submittedEvents.some((event) => ["completed", "error", "stopped"].includes(event.kind));
  const targetRun =
    (!submittedFinished && submission?.runId) ||
    agent.currentRunId ||
    submission?.runId ||
    events[events.length - 1]?.runId;
  const [fallbackStarted, setFallbackStarted] = useState(Date.now());
  useEffect(() => setFallbackStarted(Date.now()), [targetRun, submission?.at]);
  const unboundSubmission = Boolean(
    submission && !submission.runId && ["submitting", "failed"].includes(submission.state),
  );
  const visibleEvents = unboundSubmission ? [] : events.filter((event) => event.runId === targetRun);
  const firstEventAt = visibleEvents[0]?.at;
  useEffect(() => {
    if (firstEventAt) setFallbackStarted((previous) => Math.min(previous, firstEventAt));
  }, [targetRun, firstEventAt]);
  const latest = visibleEvents[visibleEvents.length - 1];
  const terminalEvent = [...visibleEvents]
    .reverse()
    .find((event) => ["completed", "error", "stopped"].includes(event.kind));
  const terminal = Boolean(terminalEvent);
  const currentEvent = terminalEvent || latest;
  const targetsProfileRun = targetRun === agent.currentRunId && !unboundSubmission;
  const profileRunning = targetsProfileRun && ["working", "meeting", "waiting_input"].includes(agent.workState);
  const progressRunning = visibleEvents.some((event) => ["pending", "running"].includes(event.status));
  const active =
    !terminal &&
    submission?.state !== "failed" &&
    (submission?.state === "submitting" || submission?.state === "accepted" || profileRunning || progressRunning);
  useEffect(() => {
    setNow(Date.now());
    if (!active) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [active, targetRun, submission?.at]);
  const started =
    submission?.state === "submitting"
      ? submission.at
      : submission && submission.runId === targetRun
        ? Math.min(submission.at, fallbackStarted)
        : fallbackStarted;
  const elapsed = started ? Math.max(0, Math.floor(((terminalEvent ? terminalEvent.at : now) - started) / 1000)) : 0;
  const sinceUpdate = latest ? Math.max(0, Math.floor((now - latest.at) / 1000)) : elapsed;
  const succeeded = terminalEvent?.kind === "completed" && terminalEvent.status === "completed";
  const received =
    visibleEvents.length > 0 ||
    profileRunning ||
    Boolean(submission?.runId === targetRun && submission?.state === "accepted");
  const executionSeen = visibleEvents.some((event) => ["thinking", "commentary", "tool"].includes(event.kind));
  const preparationSeen = visibleEvents.some((event) => event.kind === "starting");
  const prepared =
    succeeded ||
    executionSeen ||
    visibleEvents.some((event) => event.kind === "starting" && event.status === "completed");
  const completedStages = [received || succeeded, prepared, succeeded, succeeded];
  const attemptedStage = executionSeen || prepared ? 2 : preparationSeen || received ? 1 : 0;
  const failedStage = (terminalEvent && !succeeded) || submission?.state === "failed" ? attemptedStage : -1;
  const currentStage = active ? (executionSeen || prepared ? 2 : preparationSeen ? 1 : received ? -1 : 0) : -1;
  const title =
    submission?.state === "submitting"
      ? "已接收输入，正在提交任务"
      : submission?.state === "failed"
        ? "提交未完成，可重试"
        : currentEvent
          ? publicTitle(currentEvent)
          : profileRunning
            ? agent.currentWorkSummary || "任务正在运行，等待进度事件"
            : submission?.state === "accepted"
              ? "任务已接收，等待运行层调度"
              : "尚未开始新任务";
  const toolItems = new Map<string, RunProgressEvent>();
  visibleEvents.filter((event) => event.kind === "tool").forEach((event) => toolItems.set(event.itemId, event));
  return (
    <section className={"task-progress " + (active ? "is-active" : "")} aria-label="任务进度">
      <div className="progress-heading">
        <strong title={title}>{title}</strong>
        <span>{active ? `已等待 ${elapsed} 秒` : terminal ? `用时 ${elapsed} 秒` : ""}</span>
      </div>
      {(active || latest || submission) && (
        <div className="progress-stages" aria-label="任务阶段">
          {["接收任务", "准备环境", "执行任务", "完成任务"].map((name, index) => (
            <span
              key={name}
              className={
                completedStages[index]
                  ? "is-complete"
                  : index === failedStage
                    ? "is-interrupted"
                    : index === currentStage
                      ? "is-current"
                      : ""
              }
              aria-label={
                name +
                (completedStages[index]
                  ? "，已完成"
                  : index === failedStage
                    ? "，未完成"
                    : index === currentStage
                      ? "，进行中"
                      : "，等待中")
              }
              aria-current={index === currentStage ? "step" : undefined}
            >
              <span>{name}</span>
            </span>
          ))}
        </div>
      )}
      {!connected && (
        <p className="progress-disconnected" role="status">
          实时连接已断开，正在重连；已提交的任务继续运行，恢复后补齐进度。
        </p>
      )}
      {(toolItems.size > 0 || active || historyError) && (
        <details className="progress-tools">
          <summary>
            执行详情{toolItems.size > 0 ? ` · 工具 ${toolItems.size} 项` : ""}
            {active && sinceUpdate > 0 ? ` · ${sinceUpdate} 秒前更新` : ""}
          </summary>
          {active && targetsProfileRun && agent.currentWorkSummary && (
            <p className="progress-summary">{agent.currentWorkSummary}</p>
          )}
          {historyError && <p>{historyError}</p>}
          <div className="progress-tool-items">
            {[...toolItems.values()].map((event) => (
              <details key={event.itemId}>
                <summary>
                  {publicTitle(event)}{" "}
                  <span>
                    {terminal && ["running", "pending"].includes(event.status)
                      ? "已结束"
                      : event.status === "running"
                        ? "执行中"
                        : event.status === "failed"
                          ? "失败"
                          : event.status === "stopped"
                            ? "已停止"
                            : event.status === "completed"
                              ? "已完成"
                              : "等待中"}
                  </span>
                </summary>
                {event.detail && <pre>{event.detail}</pre>}
              </details>
            ))}
          </div>
        </details>
      )}
    </section>
  );
});
