import { useEffect, useRef, useState } from "react";
import type {
  AgentProfile,
  ConversationContextReference,
  OfficeConversation,
  OfficeMessage,
  HistoricalAgentIdentity,
} from "../../shared/office-contracts";
import { officeApi, OfficeApiError, type ConversationCleanup } from "./api";
import { Modal } from "./Modal";
import { MessageBody } from "./MessageBody";
import { useOptionalOfficeClient } from "./OfficeClientProvider";
export function CompanyKnowledgeDialog({
  agents = [],
  targetConversationId,
  onReferenced,
  onClose,
}: {
  agents?: AgentProfile[];
  targetConversationId?: string;
  onReferenced?(references: ConversationContextReference[]): void;
  onClose(): void;
}) {
  const client = useOptionalOfficeClient();
  const [revision, setRevision] = useState(0);
  const [search, setSearch] = useState(""),
    [filterAgent, setFilterAgent] = useState(""),
    [filterCategory, setFilterCategory] = useState("");
  const [conversations, setConversations] = useState<OfficeConversation[]>([]),
    [knownAgents, setKnownAgents] = useState<HistoricalAgentIdentity[]>(
      agents.length ? agents : client?.snapshot?.agents || [],
    );
  const [selected, setSelected] = useState<string[]>([]),
    [loading, setLoading] = useState(true),
    [saving, setSaving] = useState(false),
    [error, setError] = useState("");
  const [preview, setPreview] = useState<OfficeConversation | null>(null),
    [messages, setMessages] = useState<OfficeMessage[]>([]),
    [previewLoading, setPreviewLoading] = useState(false),
    [detailRequested, setDetailRequested] = useState(false);
  const [title, setTitle] = useState(""),
    [category, setCategory] = useState(""),
    [customCategory, setCustomCategory] = useState(false);
  const [deleting, setDeleting] = useState<OfficeConversation | null>(null),
    [deletingBusy, setDeletingBusy] = useState(false);
  const [cleanups, setCleanups] = useState<ConversationCleanup[]>([]),
    [cleanupError, setCleanupError] = useState(""),
    [cleanupNotice, setCleanupNotice] = useState(""),
    [retryingCleanup, setRetryingCleanup] = useState<string | null>(null);
  const previewId = preview?.id;
  const pendingDeletionId = useRef<string | null>(null);
  const currentTarget = useRef({ id: targetConversationId });
  const mounted = useRef(true);
  if (currentTarget.current.id !== targetConversationId) currentTarget.current = { id: targetConversationId };
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  useEffect(() => {
    let alive = true;
    officeApi
      .conversationCleanups()
      .then((result) => {
        if (alive) {
          setCleanups(result.cleanups);
          setCleanupError("");
          if (result.cleanups.length === 0) setCleanupNotice("");
        }
      })
      .catch((e) => {
        if (alive) setCleanupError((e as Error).message);
      });
    return () => {
      alive = false;
    };
  }, [revision]);
  useEffect(() => {
    let alive = true;
    officeApi
      .historicalAgents()
      .then((result) => {
        if (alive)
          setKnownAgents((current) => [
            ...current,
            ...result.agents.filter((agent) => !current.some((item) => item.id === agent.id)),
          ]);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    const timer = setTimeout(() => {
      officeApi
        .allConversations(search.trim())
        .then((result) => {
          if (alive) {
            setConversations(result.conversations);
            const deletedId = pendingDeletionId.current;
            if (deletedId) {
              if (!result.conversations.some((conversation) => conversation.id === deletedId)) {
                setSelected((current) => current.filter((id) => id !== deletedId));
                setPreview((current) => (current?.id === deletedId ? null : current));
              }
              pendingDeletionId.current = null;
            }
            setError("");
          }
        })
        .catch((e) => {
          if (alive) setError((e as Error).message);
        })
        .finally(() => {
          if (alive) setLoading(false);
        });
    }, 250);
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [search, revision]);
  useEffect(() => {
    setMessages([]);
    if (!previewId || !detailRequested) return;
    let alive = true;
    setPreviewLoading(true);
    officeApi
      .conversationMessages(previewId)
      .then((result) => {
        if (alive) setMessages(result.messages);
      })
      .catch((e) => {
        if (alive) setError((e as Error).message);
      })
      .finally(() => {
        if (alive) setPreviewLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [previewId, detailRequested]);
  const nameFor = (id: string) => knownAgents.find((agent) => agent.id === id)?.name || "历史成员 · " + id.slice(0, 8);
  const categories = [
    ...new Set(conversations.map((conversation) => conversation.category || "").filter(Boolean)),
  ].sort((a, b) => a.localeCompare(b, "zh-CN"));
  const visible = conversations.filter(
    (conversation) =>
      (!filterAgent || conversation.agentId === filterAgent) &&
      (!filterCategory ||
        (filterCategory === "__uncategorized" ? !conversation.category : conversation.category === filterCategory)),
  );
  const groups = [...new Set(visible.map((conversation) => conversation.agentId))];
  const toggle = (id: string) =>
    setSelected((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  const choose = (conversation: OfficeConversation) => {
    setPreview(conversation);
    setTitle(conversation.title);
    setCategory(conversation.category || "");
    setCustomCategory(Boolean(conversation.category && !categories.includes(conversation.category)));
    setDetailRequested(false);
    setMessages([]);
    setError("");
  };
  const removeConversationRecord = (id: string) => {
    setConversations((current) => current.filter((item) => item.id !== id));
    setSelected((current) => current.filter((item) => item !== id));
    if (preview?.id === id) {
      setPreview(null);
      setMessages([]);
      setDetailRequested(false);
    }
  };
  return (
    <Modal
      title="公司知识库"
      subtitle={targetConversationId ? "分类检索 · 明确选择上下文" : "会话概要与分类目录"}
      className="knowledge-dialog"
      onClose={onClose}
    >
      <div className="knowledge-content">
        <p className="hint">
          目录只显示概要和读取记录，点击“查看详细内容”才加载正文。选中的会话以只读快照加入当前上下文，不会自动全局共享。
        </p>
        <button
          type="button"
          className="knowledge-refresh"
          onClick={() => setRevision((value) => value + 1)}
          disabled={loading}
        >
          刷新知识库目录
        </button>
        <div className="knowledge-search">
          <label>
            <span className="sr-only">搜索公司会话</span>
            <input
              aria-label="搜索公司会话"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="搜索会话标题、概要或分类…"
            />
          </label>
          <select
            aria-label="按成员筛选会话"
            value={filterAgent}
            onChange={(event) => setFilterAgent(event.target.value)}
          >
            <option value="">所有成员</option>
            {[...new Set(conversations.map((conversation) => conversation.agentId))].map((id) => (
              <option key={id} value={id}>
                {nameFor(id)}
              </option>
            ))}
          </select>
          <select
            aria-label="按分类筛选会话"
            value={filterCategory}
            onChange={(event) => setFilterCategory(event.target.value)}
          >
            <option value="">所有分类</option>
            <option value="__uncategorized">未分类</option>
            {categories.map((value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ))}
          </select>
        </div>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        {(cleanups.length > 0 || cleanupNotice || cleanupError) && (
          <section className="knowledge-cleanups" aria-label="存储清理未完成">
            <h3>存储清理未完成</h3>
            {cleanupNotice && <p role="status">{cleanupNotice}</p>}
            {cleanupError && (
              <p className="form-error" role="alert">
                {cleanupError}
              </p>
            )}
            {cleanups.map((cleanup) => (
              <div key={cleanup.id}>
                <p>{cleanup.message}</p>
                <button
                  disabled={retryingCleanup !== null}
                  onClick={async () => {
                    setRetryingCleanup(cleanup.id);
                    setCleanupError("");
                    try {
                      await officeApi.retryConversationCleanup(cleanup.id);
                      setCleanupNotice("");
                      setRevision((value) => value + 1);
                    } catch (e) {
                      setCleanupError((e as Error).message);
                    } finally {
                      setRetryingCleanup(null);
                    }
                  }}
                >
                  {retryingCleanup === cleanup.id ? "正在重试…" : "重试清理"}
                </button>
              </div>
            ))}
          </section>
        )}
        <div className="knowledge-layout">
          <div className="knowledge-directory">
            {loading ? (
              <div className="skeleton">正在读取会话概要…</div>
            ) : groups.length === 0 ? (
              <p className="hint">没有匹配的会话。</p>
            ) : (
              groups.map((id) => (
                <details key={id} open>
                  <summary>
                    {nameFor(id)} <span>{visible.filter((conversation) => conversation.agentId === id).length}</span>
                  </summary>
                  {visible
                    .filter((conversation) => conversation.agentId === id)
                    .map((conversation) => (
                      <div
                        className={"knowledge-row " + (preview?.id === conversation.id ? "selected" : "")}
                        key={conversation.id}
                      >
                        {targetConversationId && conversation.id !== targetConversationId && (
                          <input
                            aria-label={"引用会话 " + conversation.title}
                            type="checkbox"
                            checked={selected.includes(conversation.id)}
                            onChange={() => toggle(conversation.id)}
                          />
                        )}
                        <button className="knowledge-row-open" onClick={() => choose(conversation)}>
                          <strong>{conversation.title || "未命名会话"}</strong>
                          <small>
                            {conversation.category || "未分类"} · {conversation.messageCount} 条消息
                          </small>
                          <p>{conversation.summary || "暂无概要"}</p>
                          <small>
                            最近使用：
                            {conversation.lastUsedAt
                              ? new Date(conversation.lastUsedAt).toLocaleString("zh-CN")
                              : "暂无记录"}
                          </small>
                          <small>
                            读取成员：
                            {conversation.readers?.length
                              ? conversation.readers.map((reader) => reader.agentName).join("、")
                              : "暂无"}
                          </small>
                        </button>
                        <button
                          type="button"
                          className="danger-text knowledge-row-delete"
                          aria-label={"永久删除会话：" + (conversation.title || "未命名会话")}
                          title={
                            conversation.id === targetConversationId
                              ? "请先切换到其他会话，再删除当前会话"
                              : "永久删除会话及其磁盘上的原生历史"
                          }
                          disabled={conversation.id === targetConversationId}
                          onClick={() => setDeleting(conversation)}
                        >
                          删除
                        </button>
                      </div>
                    ))}
                </details>
              ))
            )}
          </div>
          <section className="knowledge-preview" aria-label="会话概要与详细内容">
            {preview ? (
              <>
                <h3>{preview.title}</h3>
                <small>
                  {nameFor(preview.agentId)} · {preview.category || "未分类"}
                </small>
                <p className="knowledge-summary">{preview.summary || "这段会话尚无概要。"}</p>
                <div className="knowledge-readers">
                  <span>实际读取记录</span>
                  {preview.readers?.length ? (
                    preview.readers.map((reader) => (
                      <small key={reader.agentId}>
                        {reader.agentName} · {reader.count} 次 · {new Date(reader.lastReadAt).toLocaleString("zh-CN")}
                      </small>
                    ))
                  ) : (
                    <small>暂无成员读取记录。浏览此目录或详细内容不会冒充成员读取。</small>
                  )}
                </div>
                <form
                  className="knowledge-category-form"
                  onSubmit={async (event) => {
                    event.preventDefault();
                    setSaving(true);
                    setError("");
                    try {
                      const result = await officeApi.patchConversation(preview.id, {
                        title: title.trim(),
                        category: category.trim(),
                      });
                      setPreview(result.conversation);
                      setConversations((current) =>
                        current.map((item) => (item.id === result.conversation.id ? result.conversation : item)),
                      );
                    } catch (e) {
                      setError((e as Error).message);
                    } finally {
                      setSaving(false);
                    }
                  }}
                >
                  <label>
                    会话标题
                    <input value={title} required onChange={(event) => setTitle(event.target.value)} />
                  </label>
                  <label>
                    归类
                    <select
                      aria-label="会话归类"
                      value={customCategory ? "__custom" : category}
                      onChange={(event) => {
                        if (event.target.value === "__custom") {
                          setCustomCategory(true);
                        } else {
                          setCustomCategory(false);
                          setCategory(event.target.value);
                        }
                      }}
                    >
                      <option value="">未分类</option>
                      {categories.map((value) => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                      <option value="__custom">自定义分类…</option>
                    </select>
                  </label>
                  {customCategory && (
                    <label>
                      自定义分类
                      <input
                        value={category}
                        onChange={(event) => setCategory(event.target.value)}
                        placeholder="输入分类名称"
                      />
                    </label>
                  )}
                  <button disabled={saving} type="submit">
                    {saving ? "正在保存…" : "保存标题与分类"}
                  </button>
                </form>
                <div className="knowledge-detail-actions">
                  <button className="primary" disabled={previewLoading} onClick={() => setDetailRequested(true)}>
                    {previewLoading ? "正在加载正文…" : detailRequested ? "已加载详细内容" : "查看详细内容"}
                  </button>
                  <button
                    className="danger-text"
                    disabled={preview.id === targetConversationId}
                    title={preview.id === targetConversationId ? "请先切换到其他会话，再删除当前会话" : undefined}
                    onClick={() => setDeleting(preview)}
                  >
                    永久删除会话
                  </button>
                </div>
                {detailRequested &&
                  (previewLoading ? (
                    <div className="skeleton">正在读取消息…</div>
                  ) : messages.length === 0 ? (
                    <p className="hint">此会话暂无消息。</p>
                  ) : (
                    messages.map((message) => (
                      <article className="message" key={message.id}>
                        <div className="message-byline">
                          <strong>
                            {message.role === "user"
                              ? "用户"
                              : message.role === "system"
                                ? "系统"
                                : nameFor(preview.agentId)}
                          </strong>
                        </div>
                        <MessageBody content={message.content} role={message.role} agentId={message.agentId} />
                        {Boolean(message.attachments?.length) && (
                          <div className="message-attachments">
                            {message.attachments!.map((attachment) => (
                              <a key={attachment.id} href={attachment.url} target="_blank" rel="noreferrer">
                                <img loading="lazy" src={attachment.url} alt={attachment.name} />
                              </a>
                            ))}
                          </div>
                        )}
                      </article>
                    ))
                  ))}
              </>
            ) : (
              <p className="hint">选择一段会话查看概要、分类与读取记录。</p>
            )}
          </section>
        </div>
        <footer className="dialog-footer">
          <button onClick={onClose}>关闭</button>
          {targetConversationId && (
            <button
              className="primary"
              disabled={saving || selected.length === 0}
              onClick={async () => {
                setSaving(true);
                setError("");
                const operationTarget = currentTarget.current;
                try {
                  const result = await officeApi.addConversationContext(targetConversationId, selected);
                  if (!mounted.current || currentTarget.current !== operationTarget) return;
                  onReferenced?.(result.references);
                  onClose();
                } catch (e) {
                  if (mounted.current && currentTarget.current === operationTarget) setError((e as Error).message);
                } finally {
                  setSaving(false);
                }
              }}
            >
              {saving ? "正在添加…" : `添加 ${selected.length} 段会话快照`}
            </button>
          )}
        </footer>
        {deleting && (
          <Modal
            title="永久删除这段会话？"
            subtitle="此操作不可恢复"
            onClose={() => {
              if (!deletingBusy) setDeleting(null);
            }}
          >
            <div className="dialog-form">
              <p className="hint">
                将永久删除“{deleting.title}”、原生会话历史、关联附件等受管数据，无法恢复。运行中的会话需要先停止任务。
              </p>
              <footer className="dialog-footer">
                <button disabled={deletingBusy} onClick={() => setDeleting(null)}>
                  取消
                </button>
                <button
                  className="danger"
                  disabled={deletingBusy}
                  onClick={async () => {
                    setDeletingBusy(true);
                    setError("");
                    try {
                      await officeApi.deleteConversation(deleting.id);
                      removeConversationRecord(deleting.id);
                      setRevision((value) => value + 1);
                      setDeleting(null);
                    } catch (e) {
                      if (e instanceof OfficeApiError && e.code === "conversation_cleanup_pending") {
                        pendingDeletionId.current = deleting.id;
                        setCleanupNotice(e.message);
                        setRevision((value) => value + 1);
                      } else {
                        setError((e as Error).message);
                      }
                      setDeleting(null);
                    } finally {
                      setDeletingBusy(false);
                    }
                  }}
                >
                  {deletingBusy ? "正在删除…" : "确认永久删除"}
                </button>
              </footer>
            </div>
          </Modal>
        )}
      </div>
    </Modal>
  );
}
