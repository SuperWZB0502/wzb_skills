import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import type { AgentProfile, OfficeSnapshot } from "../../shared/office-contracts";
import { useOfficeClient } from "./OfficeClientProvider";
import { ModeSwitch } from "./ModeSwitch";
import { ThemeSwitch } from "./ThemeSwitch";
import { ProviderList } from "./ProviderList";
import { CompanyKnowledgeDialog } from "./CompanyKnowledgeDialog";
import { createAgentGestureController } from "./agent-gestures";
import { AgentInfoCard } from "./AgentInfoCard";
import { AgentChatDialog } from "./AgentChatDialog";
import { ArchivedAgentsDialog } from "./ArchivedAgentsDialog";
import { AgentEditor } from "./AgentEditor";
import { AgentActionsMenu } from "./AgentActionsMenu";
import { CredentialDialog } from "./CredentialDialog";
import { MeetingDialog } from "./MeetingDialog";
import { Modal } from "./Modal";
import { officeApi } from "./api";
import { roleLabels, stateLabels, summary } from "./labels";
export interface SceneProps {
  snapshot: OfficeSnapshot;
  archivedAgents: AgentProfile[];
  onPrimary(id: string): void;
  onContext(id: string, point: { x: number; y: number }): void;
  onMeeting(id: string): void;
  onKnowledge(): void;
  onArchives(): void;
  onArchived(agent: AgentProfile): void;
}
export function ChatWorkspace({
  mode = "chat",
  scene,
}: {
  mode?: "chat" | "office";
  scene?: (props: SceneProps) => ReactNode;
}) {
  const { snapshot, connected, error, release, refresh } = useOfficeClient();
  const [infoId, setInfo] = useState<string | null>(null);
  const [chatId, setChat] = useState<string | null>(null);
  const [archivesOpen, setArchivesOpen] = useState(false);
  const [archivedAgents, setArchivedAgents] = useState<AgentProfile[]>([]);
  const [archiveRevision, setArchiveRevision] = useState(0);
  const [archivedChat, setArchivedChat] = useState<AgentProfile | null>(null);
  const [editor, setEditor] = useState<string | null | undefined>();
  const [editorProfile, setEditorProfile] = useState<AgentProfile | null>(null);
  const [credentialProfile, setCredentialProfile] = useState<AgentProfile | null>(null);
  const [credentialId, setCredential] = useState<string | null>(null);
  const [context, setContext] = useState<{ id: string; x: number; y: number } | null>(null);
  const [deleteId, setDelete] = useState<string | null>(null);
  const [meetingId, setMeeting] = useState<string | null>(null);
  const [meetingOpen, setMeetingOpen] = useState(false);
  const [meetingTitle, setMeetingTitle] = useState("");
  const [participants, setParticipants] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState("");
  const [search, setSearch] = useState("");
  const [loggingOut, setLoggingOut] = useState(false);
  const [serviceRevision, setServiceRevision] = useState(0);
  const [knowledgeOpen, setKnowledgeOpen] = useState(false);
  const closeInfo = useCallback(() => setInfo(null), []),
    closeChat = useCallback(() => setChat(null), []),
    closeArchives = useCallback(() => setArchivesOpen(false), []),
    closeArchivedChat = useCallback(() => setArchivedChat(null), []),
    closeEditor = useCallback(() => {
      setEditor(undefined);
      setEditorProfile(null);
    }, []),
    closeCredential = useCallback(() => {
      setCredential(null);
      setCredentialProfile(null);
    }, []),
    closeContext = useCallback(() => setContext(null), []),
    closeMeeting = useCallback(() => setMeeting(null), []),
    closeDelete = useCallback(() => setDelete(null), []),
    closeMeetingForm = useCallback(() => setMeetingOpen(false), []);
  const gestures = useMemo(
    () =>
      createAgentGestureController({
        single: (id) => {
          setChat(null);
          setInfo(id);
        },
        double: (id) => {
          setInfo(null);
          setChat(id);
        },
        context: (id, p) => setContext({ id, ...p }),
      }),
    [],
  );
  useEffect(() => () => gestures.dispose(), [gestures]);
  const agents = snapshot?.agents || [];
  const activeAgentIds = agents
    .map((agent) => agent.id)
    .sort()
    .join("|");
  useEffect(() => {
    let alive = true;
    officeApi
      .archivedAgents()
      .then((result) => {
        if (alive) setArchivedAgents(result.agents);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [activeAgentIds, snapshot?.bootId, archiveRevision]);
  const find = (id: string | null | undefined) => agents.find((a) => a.id === id);
  const info = find(infoId),
    chat = find(chatId),
    credential = credentialProfile?.id === credentialId ? credentialProfile : find(credentialId),
    menuAgent = find(context?.id),
    deleteAgent = find(deleteId);
  const online = agents.filter((a) => a.workState === "working" || a.workState === "meeting").length;
  const meetings = snapshot?.meetings.slice(-3).reverse() || [];
  const doAction = async (action: () => Promise<unknown>) => {
    setBusy(true);
    setActionError("");
    try {
      await action();
      await refresh();
    } catch (e) {
      setActionError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const list = (compact = false) => (
    <div className={compact ? "agent-list compact" : "agent-list"}>
      {agents
        .filter((a) => a.name.toLowerCase().includes(search.toLowerCase()))
        .map((a) => (
          <div
            className="agent-row"
            key={a.id}
            onContextMenu={(e) => {
              e.preventDefault();
              gestures.context(a.id, { x: e.clientX, y: e.clientY });
            }}
          >
            <button className="agent-row-main" aria-label={"查看 " + a.name} onClick={() => gestures.primary(a.id)}>
              <span className={"initial-avatar " + (a.isBoss ? "boss-avatar" : "")}>{a.name.slice(0, 1)}</span>
              <span className="agent-row-text">
                <strong className={"agent-name " + a.workState}>
                  {a.name}
                  {a.isBoss && <em>你</em>}
                </strong>
                <small>{roleLabels[a.jobFunction]}</small>
                {!compact && <p>{summary(a)}</p>}
              </span>
              <span className={"status " + a.workState}>
                <i />
                {stateLabels[a.workState]}
              </span>
            </button>
            <button
              className="icon-button more-button"
              aria-label={a.name + " 的更多操作"}
              onClick={(e) => {
                const r = e.currentTarget.getBoundingClientRect();
                setContext({ id: a.id, x: r.left, y: r.bottom + 4 });
              }}
            >
              ···
            </button>
          </div>
        ))}
    </div>
  );
  return (
    <div className="workspace">
      <header className="app-header">
        <a className="wordmark" href={mode === "office" ? "/office.html" : "/chat.html"}>
          <span className="brand-mark">同</span>
          <span>
            同席<small>AGENT OFFICE</small>
          </span>
        </a>
        <ModeSwitch mode={mode} />
        <div className="header-right">
          <ThemeSwitch />
          <span className={"connection " + (connected ? "connected" : "")}>
            <i />
            {connected ? "实时已连接" : "正在同步"}
          </span>
          <button className="outline" onClick={() => setEditor(null)}>
            ＋ 添加伙伴
          </button>
        </div>
      </header>
      <main className="workspace-main">
        <div className="page-title">
          <div>
            <span className="eyebrow">YOUR OWN LITTLE OFFICE</span>
            <h1>{mode === "office" ? "今天，一起推进什么？" : "专注于眼前的对话。"}</h1>
            <p>
              {mode === "office"
                ? "每个人有自己的位置，每件事都有真实的进展。"
                : "选择一位伙伴，延续独立会话，把想法一步步变成结果。"}
            </p>
          </div>
          <div className="office-numbers">
            <span>
              <strong>{agents.length.toString().padStart(2, "0")}</strong>位伙伴
            </span>
            <span>
              <strong>{online.toString().padStart(2, "0")}</strong>正在协作
            </span>
            <button
              onClick={() => {
                setMeetingTitle("");
                setParticipants([]);
                setMeetingOpen(true);
              }}
            >
              发起会议 <span>↗</span>
            </button>
          </div>
        </div>
        {release && (
          <div className="update-banner">
            工作室有新版本。刷新页面即可使用，后台任务继续执行。
            <button onClick={() => location.reload()}>更新界面 ↗</button>
          </div>
        )}
        {(error || actionError) && (
          <div className="error-banner" role="alert">
            {error || actionError}
            <button onClick={() => void refresh()}>重新同步</button>
          </div>
        )}
        {!snapshot ? (
          <div className="loading-layout">
            <div className="skeleton">正在打开你的工作室…</div>
            <div className="skeleton" />
          </div>
        ) : mode === "office" ? (
          <div className="office-grid">
            <section className="office-stage">
              <div className="stage-toolbar">
                <div>
                  <span className="state-dot idle" />
                  <strong>办公室实况</strong>
                  <span className="muted">LIVE OFFICE</span>
                </div>
                <span>单击查看 · 双击对话 · 右键管理</span>
              </div>
              {scene?.({
                snapshot,
                archivedAgents,
                onPrimary: gestures.primary,
                onContext: gestures.context,
                onMeeting: setMeeting,
                onKnowledge: () => setKnowledgeOpen(true),
                onArchives: () => setArchivesOpen(true),
                onArchived: (agent) => {
                  setInfo(null);
                  setChat(null);
                  setArchivedChat(agent);
                },
              })}
              <div className="stage-bottom">
                <span>
                  <i className="state-dot working" /> 工作中
                </span>
                <span>
                  <i className="state-dot meeting" /> 会议中
                </span>
                <span>
                  <i className="state-dot idle" /> 休息中
                </span>
                <span className="stage-note">动画只呈现实际状态</span>
              </div>
            </section>
            <aside className="team-sidebar">
              <div className="section-heading">
                <h2>
                  我的伙伴 <span>{agents.length}</span>
                </h2>
                <button className="icon-button" aria-label="添加伙伴" onClick={() => setEditor(null)}>
                  ＋
                </button>
              </div>
              <label className="search-label">
                <span className="sr-only">搜索伙伴</span>
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜索伙伴名称…" />
              </label>
              {list(true)}
              <ProviderList key={serviceRevision} onChanged={refresh} />
            </aside>
          </div>
        ) : (
          <div className="chat-workspace">
            <section>
              <div className="section-heading">
                <h2>伙伴与独立会话</h2>
                <span className="muted">单击查看 · 双击对话</span>
              </div>
              {list()}
              <ProviderList key={serviceRevision} onChanged={refresh} />
              {agents.length === 0 && (
                <div className="empty-state">
                  <h3>为第一件事，找一位伙伴。</h3>
                  <p>添加 SE、PL、开发或测试，开始独立协作。</p>
                  <button className="primary" onClick={() => setEditor(null)}>
                    添加伙伴
                  </button>
                </div>
              )}
            </section>
            <aside className="quiet-panel">
              <span className="eyebrow">A LITTLE ROOM FOR THOUGHT</span>
              <h2>
                你的节奏，
                <br />
                你的工作室。
              </h2>
              <p>不同伙伴使用自己的模型和独立会话。任务在后台推进，你可以随时回来看看。</p>
              <span className="quiet-line" />
              <small>从目标和背景开始，给伙伴一个清晰的方向。</small>
            </aside>
          </div>
        )}
        {meetings.length > 0 && (
          <section className="meetings-strip">
            <span className="eyebrow">会议记录</span>
            {meetings.map((m) => (
              <button key={m.id} onClick={() => setMeeting(m.id)}>
                <i className="state-dot meeting" />
                {m.phase === "ended" ? "已结束会议" : m.phase === "review" ? "任务评审" : "启动会议"} ·{" "}
                {m.participantIds.length} 位参与者 <span>查看记录 ↗</span>
              </button>
            ))}
          </section>
        )}
        <footer className="workspace-footer">
          <span>
            同席 · 一个属于你的协作空间
            {snapshot?.executionMode && (
              <span
                title={snapshot.executionMode === "account" ? "任务使用当前系统账号权限执行" : "任务在受限沙箱内执行"}
              >
                {" "}
                · {snapshot.executionMode === "account" ? "账号权限运行" : "沙箱运行"}
              </span>
            )}
          </span>
          <div className="workspace-footer-actions">
            <button className="archive-entry" onClick={() => setKnowledgeOpen(true)}>
              公司知识库
            </button>
            <button className="archive-entry" onClick={() => setArchivesOpen(true)}>
              小黑屋 ↗
            </button>
            <button
              className="archive-entry"
              disabled={loggingOut}
              onClick={async () => {
                setLoggingOut(true);
                setActionError("");
                try {
                  await officeApi.logout();
                  window.location.reload();
                } catch (e) {
                  setActionError((e as Error).message);
                  setLoggingOut(false);
                }
              }}
            >
              {loggingOut ? "退出中…" : "退出登录"}
            </button>
          </div>
          <span title={snapshot?.workspaceRoot}>工作根目录：{snapshot?.workspaceRoot || "正在读取"}</span>
        </footer>
      </main>
      {info && (
        <AgentInfoCard
          agent={info}
          onClose={closeInfo}
          onChat={() => {
            setInfo(null);
            setChat(info.id);
          }}
          onEdit={() => {
            setInfo(null);
            setEditor(info.id);
          }}
          onCredential={() => {
            setInfo(null);
            setCredential(info.id);
          }}
        />
      )}
      {chat && (
        <AgentChatDialog
          key={chat.id}
          agent={chat}
          onClose={closeChat}
          onCredential={() => setCredential(chat.id)}
          onSent={() => void refresh()}
        />
      )}
      {knowledgeOpen && <CompanyKnowledgeDialog agents={agents} onClose={() => setKnowledgeOpen(false)} />}
      {archivesOpen && (
        <ArchivedAgentsDialog
          onClose={closeArchives}
          onChanged={(dismissedId) => {
            setArchivedAgents((current) => current.filter((agent) => agent.id !== dismissedId));
            setArchiveRevision((value) => value + 1);
            return refresh();
          }}
          onOpenHistory={(agent) => {
            setArchivesOpen(false);
            setInfo(null);
            setChat(null);
            setArchivedChat(agent);
          }}
        />
      )}
      {archivedChat && (
        <AgentChatDialog
          key={"archived-" + archivedChat.id}
          agent={archivedChat}
          archived
          onClose={closeArchivedChat}
          onCredential={() => {}}
          onSent={() => {}}
        />
      )}
      {editor !== undefined && (
        <AgentEditor
          agent={editorProfile?.id === editor ? editorProfile : find(editor) || null}
          onClose={closeEditor}
          onSaved={async (saved) => {
            setEditor(undefined);
            setEditorProfile(null);
            setInfo(null);
            setChat(null);
            const latest = await refresh();
            const current = latest?.agents.find((agent) => agent.id === saved.id) || saved;
            if (current.credentialState !== "configured" || !current.providerId) {
              // Missing service authentication is managed in the shared service list.
              setServiceRevision((value) => value + 1);
            }
          }}
        />
      )}
      {credential && (
        <CredentialDialog
          agent={credential}
          agents={agents}
          onClose={closeCredential}
          onConfigured={async () => {
            const id = credential.id;
            setCredential(null);
            setCredentialProfile(null);
            setServiceRevision((value) => value + 1);
            setChat(null);
            setInfo(null);
            const latest = await refresh();
            const current = latest?.agents.find((agent) => agent.id === id);
            if (!current) {
              setActionError("配置已保存，但暂时无法刷新身份。请稍后重新打开编辑。");
              return;
            }
            if (!current.providerId) return;
            setEditorProfile(current);
            setEditor(current.id);
          }}
        />
      )}
      {menuAgent && context && (
        <AgentActionsMenu
          agent={menuAgent}
          point={context}
          onClose={closeContext}
          onEdit={() => {
            setEditor(menuAgent.id);
            setContext(null);
          }}
          onClone={() => {
            setContext(null);
            void doAction(() => officeApi.cloneAgent(menuAgent.id));
          }}
          onDelete={() => {
            setContext(null);
            setDelete(menuAgent.id);
          }}
        />
      )}
      {deleteAgent && (
        <Modal
          title={"删除身份“" + deleteAgent.name + "”？"}
          subtitle="移入小黑屋 · 保留身份配置与会话"
          onClose={closeDelete}
        >
          <div className="dialog-form">
            <p>
              {deleteAgent.workState === "working" || deleteAgent.workState === "meeting"
                ? "这位员工仍在执行任务。删除身份会先停止任务，再从正式员工移入小黑屋；身份配置、会话、原生历史与项目成果保留。"
                : "此身份将从正式员工移入小黑屋，身份配置、会话、原生历史与项目成果保留。可在小黑屋查看历史或进一步开除员工。"}
            </p>
            <footer className="dialog-footer">
              <button onClick={closeDelete}>取消</button>
              <button
                className="danger"
                disabled={busy}
                onClick={() =>
                  void doAction(async () => {
                    await officeApi.deleteAgent(deleteAgent.id, true);
                    setDelete(null);
                  })
                }
              >
                {busy
                  ? "正在移入…"
                  : deleteAgent.workState === "working" || deleteAgent.workState === "meeting"
                    ? "停止并移入小黑屋"
                    : "移入小黑屋"}
              </button>
            </footer>
          </div>
        </Modal>
      )}
      {meetingId && <MeetingDialog meetingId={meetingId} agents={agents} onClose={closeMeeting} />}
      {meetingOpen && (
        <Modal title="召集一场真实讨论" onClose={closeMeetingForm}>
          <form
            className="dialog-form"
            onSubmit={(e) => {
              e.preventDefault();
              void doAction(async () => {
                const result = await officeApi.createMeeting(meetingTitle, participants);
                setMeetingOpen(false);
                setMeeting(result.meeting.id);
              });
            }}
          >
            <label>
              会议主题
              <input
                required
                value={meetingTitle}
                onChange={(e) => setMeetingTitle(e.target.value)}
                placeholder="希望伙伴们一起讨论什么？"
              />
            </label>
            <fieldset className="participant-picker">
              <legend>选择参会伙伴</legend>
              {agents.map((a) => (
                <label key={a.id}>
                  <input
                    type="checkbox"
                    checked={participants.includes(a.id)}
                    onChange={(e) =>
                      setParticipants(
                        e.target.checked ? [...participants, a.id] : participants.filter((id) => id !== a.id),
                      )
                    }
                  />
                  <span>
                    {a.name}
                    <small>{roleLabels[a.jobFunction]}</small>
                  </span>
                </label>
              ))}
            </fieldset>
            <footer className="dialog-footer">
              <button type="button" onClick={closeMeetingForm}>
                取消
              </button>
              <button className="primary" disabled={busy || participants.length === 0}>
                {busy ? "正在召集…" : "发起会议"}
              </button>
            </footer>
          </form>
        </Modal>
      )}
    </div>
  );
}
