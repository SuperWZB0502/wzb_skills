import type { ReactNode } from "react";
import { Modal } from "./Modal";

/**
 * Confirmation that belongs to the site instead of the browser's native dialog.
 *
 * The office renders its own chrome everywhere else, so a `window.confirm` breaks the visual
 * language and cannot show progress or a server error. `onConfirm` may be async: while it runs
 * the dialog stays open, the confirm button is disabled and the caller can show `error` inside.
 */
export function ConfirmDialog({
  title,
  subtitle,
  children,
  confirmLabel,
  busyLabel = "处理中…",
  cancelLabel = "取消",
  tone = "primary",
  busy = false,
  error = "",
  onConfirm,
  onClose,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  confirmLabel: string;
  busyLabel?: string;
  cancelLabel?: string;
  tone?: "primary" | "danger";
  busy?: boolean;
  error?: string;
  onConfirm(): void;
  onClose(): void;
}) {
  return (
    <Modal title={title} subtitle={subtitle} className="confirm-dialog" onClose={busy ? () => {} : onClose}>
      <div className="dialog-form">
        <div className="confirm-copy">{children}</div>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <footer className="dialog-footer">
          <button type="button" disabled={busy} onClick={onClose}>
            {cancelLabel}
          </button>
          <button
            type="button"
            className={tone === "danger" ? "danger" : "primary"}
            disabled={busy}
            onClick={onConfirm}
          >
            {busy ? busyLabel : confirmLabel}
          </button>
        </footer>
      </div>
    </Modal>
  );
}
