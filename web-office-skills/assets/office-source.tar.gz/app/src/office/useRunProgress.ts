import { useCallback, useEffect, useRef, useState } from "react";
import type { RunProgressEvent } from "../../shared/office-contracts";
import { officeApi } from "./api";
import { useOptionalOfficeClient } from "./OfficeClientProvider";
export function useRunProgress(agentId: string, enabled = true, conversationId?: string | null) {
  const client = useOptionalOfficeClient();
  const connected = client?.connected ?? false;
  const bootId = client?.snapshot?.bootId;
  const subscribe = client?.subscribeProgress;
  const [events, setEvents] = useState<RunProgressEvent[]>([]);
  const [historyError, setHistoryError] = useState("");
  const afterSeq = useRef(0);
  const generation = useRef(0);
  const invalidate = useCallback((expected: number) => {
    if (generation.current === expected) generation.current = expected + 1;
  }, []);
  const merge = useCallback(
    (incoming: RunProgressEvent[]) => {
      const relevant = incoming.filter(
        (event) =>
          event.agentId === agentId &&
          (!conversationId || event.conversationId === conversationId) &&
          Number.isFinite(event.seq),
      );
      if (!relevant.length) return;
      for (const event of relevant) afterSeq.current = Math.max(afterSeq.current, event.seq);
      setEvents((previous) => {
        const byItem = new Map(previous.map((event) => [event.runId + ":" + event.itemId, event]));
        relevant.forEach((event) => {
          const key = event.runId + ":" + event.itemId;
          const old = byItem.get(key);
          if (!old || event.seq > old.seq) byItem.set(key, event);
        });
        return [...byItem.values()].sort((a, b) => a.seq - b.seq).slice(-400);
      });
    },
    [agentId, conversationId],
  );
  const loadHistory = useCallback(async () => {
    if (!enabled) return;
    const currentGeneration = generation.current;
    try {
      // Backfill the full bounded window: a newly arrived WS seq must not hide older gap events.
      const result = await officeApi.progress(agentId, 0, conversationId || undefined);
      if (generation.current !== currentGeneration) return;
      merge(
        result.events.map((event) =>
          conversationId && event.conversationId == null ? { ...event, conversationId } : event,
        ),
      );
      setHistoryError("");
    } catch {
      if (generation.current === currentGeneration) setHistoryError("暂时无法补齐进度，仍会显示当前任务摘要。");
    }
  }, [agentId, enabled, merge, conversationId]);
  useEffect(() => {
    const myGeneration = ++generation.current;
    afterSeq.current = 0;
    setEvents([]);
    setHistoryError("");
    if (!enabled) return;
    const unsubscribe = subscribe?.((event) => {
      if (event.agentId === agentId) merge([event]);
    });
    void loadHistory();
    return () => {
      invalidate(myGeneration);
      unsubscribe?.();
    };
  }, [agentId, bootId, enabled, subscribe, merge, loadHistory, invalidate]);
  const previouslyConnected = useRef(connected);
  useEffect(() => {
    if (connected && !previouslyConnected.current) void loadHistory();
    previouslyConnected.current = connected;
  }, [connected, loadHistory]);
  const scopedEvents = events.filter(
    (event) => event.agentId === agentId && (!conversationId || event.conversationId === conversationId),
  );
  return { events: scopedEvents, connected, historyError };
}
