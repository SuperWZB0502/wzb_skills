import { useEffect, useState, type ReactNode } from "react";
import { officeApi } from "./api";
import { ThemeSwitch } from "./ThemeSwitch";
import { GitCommitReview } from "./GitCommitReview";
export function SessionGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [checking, setChecking] = useState(true);
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let current = true;
    officeApi
      .session()
      .then((s) => {
        if (current) {
          officeApi.setCsrf(s.csrfToken);
          setReady(true);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (current) setChecking(false);
      });
    return () => {
      current = false;
    };
  }, []);
  if (ready) return <>{children}<GitCommitReview /></>;
  return (
    <main className="pair-page">
      <div className="pair-theme-switch">
        <ThemeSwitch />
      </div>
      <div className="pair-brand">
        <span className="brand-mark">同</span>
        <span>
          同席 <small>PERSONAL AGENT OFFICE</small>
        </span>
      </div>
      <section className="pair-panel">
        <span className="eyebrow">你的个人智能体工作室</span>
        <h1>让想法，坐到一起。</h1>
        <p>连接自己的工作室，与你的智能体一起推进工作。角色、任务和对话都在这里继续。</p>
        {checking ? (
          <div className="skeleton">正在恢复安全会话…</div>
        ) : (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              setError("");
              try {
                const result = await officeApi.pair(code.trim());
                officeApi.setCsrf(result.csrfToken);
                setCode("");
                setReady(true);
              } catch {
                setError("配对未完成，请确认启动终端中的配对码。");
              } finally {
                setBusy(false);
              }
            }}
          >
            <label>
              工作室配对码
              <input
                autoFocus
                autoComplete="off"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="输入启动终端中的配对码"
                required
              />
            </label>
            <button className="primary" disabled={busy}>
              {busy ? "正在连接…" : "进入工作室"} <span>↗</span>
            </button>
            {error && (
              <p role="alert" className="form-error">
                {error}
              </p>
            )}
            <small>
              浏览器会记住登录 30 天；退出登录后需重新配对。API Key
              仅在网页提供并保存在运行层内存，服务重启后需要重新填写。
            </small>
          </form>
        )}
      </section>
      <footer>属于你的空间 · 真实任务 · 独立会话</footer>
    </main>
  );
}
