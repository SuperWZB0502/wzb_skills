import { useEffect, useRef, useState } from "react";
import type {
  AgentProfile,
  ProviderCapabilities,
  ProviderProfile,
  ReasoningEffort,
} from "../../shared/office-contracts";
import { officeApi } from "./api";
import { ClaudeContextControl } from "./ClaudeContextControl";
import { splitClaudeContext, withClaudeContext } from "./claude-context";
const effortNames: Record<ReasoningEffort, string> = {
  none: "不启用 · none",
  minimal: "最低 · minimal",
  low: "低 · low",
  medium: "中 · medium",
  high: "高 · high",
  xhigh: "极高 · xhigh",
  max: "最高 · max",
  ultra: "超高 · ultra",
};
export function ChatModelControls({ agent, onApplied }: { agent: AgentProfile; onApplied(): void }) {
  const [providerId, setProviderId] = useState(agent.providerId);
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [model, setModel] = useState(agent.model || "");
  const [effort, setEffort] = useState<ReasoningEffort | null>(agent.reasoningEffort);
  const [catalog, setCatalog] = useState<{
    providerId: string;
    slotId: string | null;
    model: string;
    cap: ProviderCapabilities;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [refreshVersion, setRefreshVersion] = useState(0);
  const force = useRef(false),
    edited = useRef(false);
  const requestSeq = useRef(0);
  const sourceProvider = useRef(agent.providerId);
  const selectedService = providers.find((provider) => provider.id === providerId);
  const isClaude = selectedService?.executor === "claude-code";
  const context = isClaude ? splitClaudeContext(model) : { baseModel: model.trim(), longContext: false };
  const modelId = context.baseModel;
  const persistedModel = isClaude ? withClaudeContext(modelId, context.longContext) : modelId;
  const originalModel = isClaude
    ? withClaudeContext(agent.model, splitClaudeContext(agent.model).longContext)
    : agent.model || "";
  const modelBase = (value: string) => (isClaude ? splitClaudeContext(value).baseModel : value);
  const agentId = agent.id;
  const serviceSlotId = providers.find((provider) => provider.id === providerId)?.credentialSlotId || null;
  const credentialSlotId = providerId === agent.providerId ? agent.credentialSlotId || serviceSlotId : serviceSlotId;
  const binding = useRef({ providerId, slotId: credentialSlotId, model: modelId });
  if (
    binding.current.providerId !== providerId ||
    binding.current.slotId !== credentialSlotId ||
    binding.current.model !== modelId
  )
    binding.current = { providerId, slotId: credentialSlotId, model: modelId };
  useEffect(() => {
    let alive = true;
    officeApi
      .providers()
      .then((result) => {
        if (alive) setProviders(result.providers);
      })
      .catch(() => {
        if (alive) setError("服务列表读取失败，请到“我的模型服务”检查配置。");
      });
    return () => {
      alive = false;
    };
  }, [agent.providerId, agent.credentialSlotId, agent.credentialState, refreshVersion]);
  useEffect(() => {
    if (sourceProvider.current !== agent.providerId) {
      sourceProvider.current = agent.providerId;
      ++requestSeq.current;
      edited.current = false;
      setProviderId(agent.providerId);
      setCatalog(null);
      setLoading(false);
    }
    if (!edited.current) {
      setModel(agent.model || "");
      setEffort(agent.reasoningEffort);
    }
  }, [agent.providerId, agent.model, agent.reasoningEffort]);
  useEffect(() => {
    const seq = ++requestSeq.current;
    const requestedBinding = binding.current;
    let alive = true;
    const refresh = force.current;
    force.current = false;
    setError("");
    if (!providerId) {
      setCatalog(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    const timer = setTimeout(
      () => {
        officeApi
          .capabilities(providerId, {
            agentId,
            slotId: credentialSlotId || undefined,
            model: modelId || undefined,
            refresh,
          })
          .then((cap) => {
            if (alive && seq === requestSeq.current && binding.current === requestedBinding)
              setCatalog({ providerId, slotId: credentialSlotId, model: modelId, cap });
          })
          .catch(() => {
            if (alive && seq === requestSeq.current && binding.current === requestedBinding) {
              setCatalog(null);
              setError("模型列表读取失败，请刷新或到“我的模型服务”检查配置。");
            }
          })
          .finally(() => {
            if (alive && seq === requestSeq.current && binding.current === requestedBinding) setLoading(false);
          });
      },
      refresh ? 0 : 350,
    );
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [agentId, providerId, credentialSlotId, modelId, refreshVersion]);
  const cap = catalog?.providerId === providerId && catalog.slotId === credentialSlotId ? catalog.cap : undefined;
  const info =
    catalog?.model === modelId
      ? cap?.selectedModel && modelBase(cap.selectedModel.id) === modelId
        ? cap.selectedModel
        : cap?.modelCapabilities?.find((item) => modelBase(item.id) === modelId)
      : undefined;
  const efforts = info?.reasoningEfforts || [];
  const models = [...new Set((cap?.models || []).map(modelBase))].filter(Boolean);
  const unsupported = Boolean(providerId && effort) && !loading && Boolean(info) && !efforts.includes(effort!);
  const pending = Boolean(providerId && effort) && (loading || !info);
  const dirty = providerId !== agent.providerId || persistedModel !== originalModel || effort !== agent.reasoningEffort;
  return (
    <section className="chat-model-controls" aria-label="聊天模型设置">
      <div className={"chat-model-row" + (!providerId ? " is-unconfigured" : isClaude ? " has-claude-context" : "")}>
        <label>
          服务
          <select
            aria-label="聊天模型服务"
            value={providerId || ""}
            disabled={saving}
            onChange={(event) => {
              edited.current = true;
              ++requestSeq.current;
              setProviderId(event.target.value || null);
              setModel("");
              setEffort(null);
              setCatalog(null);
              setLoading(false);
              setError("");
            }}
          >
            <option value="">稍后配置</option>
            {providerId && !providers.some((provider) => provider.id === providerId) && (
              <option value={providerId}>当前服务</option>
            )}
            {providers.map((provider) => (
              <option key={provider.id} value={provider.id}>
                {provider.name}
              </option>
            ))}
          </select>
        </label>
        {providerId && (
          <>
            <label>
              模型
              <select
                aria-label="聊天模型"
                value={modelId}
                disabled={saving || (loading && !models.length && !modelId)}
                onChange={(event) => {
                  edited.current = true;
                  ++requestSeq.current;
                  setModel(isClaude ? withClaudeContext(event.target.value, context.longContext) : event.target.value);
                  setError("");
                }}
              >
                <option value="" disabled>
                  {loading ? "正在读取…" : models.length ? "选择模型" : "暂无模型列表"}
                </option>
                {modelId && !models.includes(modelId) && <option value={modelId}>当前：{modelId}</option>}
                {models.map((id) => (
                  <option key={id} value={id}>
                    {cap?.modelCapabilities?.find((item) => modelBase(item.id) === id)?.name || id}
                  </option>
                ))}
              </select>
            </label>

            <label>
              档位
              <select
                aria-label="聊天思考强度"
                value={effort || ""}
                disabled={saving}
                onChange={(event) => {
                  edited.current = true;
                  setEffort((event.target.value as ReasoningEffort) || null);
                  setError("");
                }}
              >
                <option value="">模型默认</option>
                {effort && !efforts.includes(effort) && (
                  <option value={effort} disabled>
                    {effortNames[effort]}（需重选）
                  </option>
                )}
                {efforts.map((value) => (
                  <option key={value} value={value}>
                    {effortNames[value]}
                  </option>
                ))}
              </select>
            </label>
            {isClaude && (
              <ClaudeContextControl
                compact
                checked={context.longContext}
                hasModel={Boolean(modelId)}
                disabled={saving}
                onChange={(checked) => {
                  edited.current = true;
                  setModel(withClaudeContext(modelId, checked));
                  setError("");
                }}
              />
            )}
          </>
        )}
        <button
          className="primary"
          type="button"
          disabled={saving || !dirty || Boolean(providerId && (!modelId || unsupported || pending))}
          onClick={async () => {
            setSaving(true);
            setError("");
            try {
              const result = await officeApi.saveAgent(
                {
                  providerId: providerId || null,
                  model: providerId ? persistedModel : null,
                  reasoningEffort: providerId ? effort : null,
                },
                agentId,
              );
              edited.current = false;
              setModel(result.agent.model || "");
              setEffort(result.agent.reasoningEffort);
              onApplied();
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setSaving(false);
            }
          }}
        >
          {saving ? "应用中…" : "应用配置"}
        </button>
        <button
          type="button"
          className="model-refresh"
          aria-label="刷新聊天模型目录"
          disabled={!providerId || loading || saving}
          onClick={() => {
            force.current = true;
            ++requestSeq.current;
            setRefreshVersion((value) => value + 1);
          }}
        >
          {loading ? "读取中…" : "刷新"}
        </button>
      </div>
      {providerId && !loading && !error && !models.length && (
        <p className="chat-model-catalog-message" role="status">
          此服务暂无可用模型列表，请到“我的模型服务”检查配置。
        </p>
      )}
      {unsupported && (
        <p className="chat-model-error" role="alert">
          当前档位不可用，请重选或使用模型默认。
        </p>
      )}
      {error && (
        <p className="chat-model-error" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}
