export type ViewMode = "chat" | "office";
export type JobFunction = "se" | "pl" | "developer" | "tester" | "boss";
export type WorkState = "idle" | "working" | "waiting_input" | "meeting" | "error" | "offline";
export type CredentialState = "required" | "configured" | "invalid";
export type ExecutorKind = "codex" | "claude-code";
export type AuthMode = "api_key" | "account";
export type AgentLifecycle = "active" | "archived" | "dismissed";
export interface HistoricalAgentIdentity {
  id: string;
  name: string;
  jobFunction: JobFunction;
  isBoss: boolean;
}
export const REASONING_EFFORTS = ["none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"] as const;
export type ReasoningEffort = (typeof REASONING_EFFORTS)[number];
export interface AgentProfile {
  id: string;
  name: string;
  jobFunction: JobFunction;
  isBoss: boolean;
  gender: string;
  spriteNumber: number | null;
  providerId: string | null;
  model: string | null;
  reasoningEffort: ReasoningEffort | null;
  credentialState: CredentialState;
  credentialSlotId: string | null;
  workState: WorkState;
  currentTaskId: string | null;
  currentRunId?: string | null;
  currentConversationId?: string | null;
  currentWorkSummary: string;
}
export interface AgentDraft {
  name: string;
  jobFunction: Exclude<JobFunction, "boss">;
  gender?: string;
  spriteNumber: number | null;
  providerId: string | null;
  model: string | null;
  reasoningEffort: ReasoningEffort | null;
}
export type AgentPatch = Partial<AgentDraft>;
export interface ProviderProfile {
  id: string;
  name: string;
  baseUrl: string;
  wireApi: "responses" | "messages";
  executor: ExecutorKind;
  authMode: AuthMode;
  credentialSlotId: string | null;
  credentialState?: CredentialState;
}
export interface OfficeConversation {
  id: string;
  agentId: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messageCount: number;
  category?: string;
  summary?: string;
  lastUsedAt?: number | null;
  readers?: Array<{ agentId: string; agentName: string; lastReadAt: number; count: number }>;
}
export interface ConversationContextReference {
  id: string;
  sourceConversationId: string;
  sourceAgentId: string;
  sourceAgentName: string;
  title: string;
  importedAt: number;
  messageCount: number;
  excerpt: string;
}
export interface ProviderAuthFlow {
  loginId: string;
  state: "pending" | "completed" | "failed" | "cancelled";
  authUrl?: string;
  userCode?: string;
  requiresCode?: boolean;
  expiresAt?: number;
  message?: string;
}
export interface ProviderCapabilities {
  models: string[];
  reasoningEfforts: ReasoningEffort[];
  supportsResponses: boolean;
  modelCapabilities?: ModelCapability[];
  selectedModel?: ModelCapability;
  catalogState?: "ready" | "key_required" | "unauthorized" | "unsupported" | "unavailable";
  catalogMessage?: string;
  codexCatalogState?: "ready" | "unavailable";
}
export interface ModelCapability {
  id: string;
  name?: string;
  reasoningEfforts: ReasoningEffort[];
  defaultReasoningEffort: ReasoningEffort | null;
  reasoningSource: "provider" | "codex" | "unverified";
}
export interface TaskRuntimeEvent {
  seq: number;
  eventId: string;
  agentId: string;
  taskId: string | null;
  runId: string | null;
  state: WorkState;
  summary: string;
  at: number;
}
export interface MeetingSnapshot {
  id: string;
  taskId: string;
  participantIds: string[];
  phase: "kickoff" | "review" | "ended";
  messageIds: string[];
}
export interface OfficeSnapshot {
  bootId: string;
  workspaceRoot: string;
  executionMode?: "sandboxed" | "account";
  lastSeq: number;
  defaultView: ViewMode;
  agents: AgentProfile[];
  meetings: MeetingSnapshot[];
}
export interface OfficeMessage {
  id: string;
  agentId: string;
  role: "user" | "assistant" | "system";
  content: string;
  at: number;
  runId?: string | null;
  attachments?: OfficeAttachment[];
  conversationId?: string | null;
}
export interface OfficeAttachment {
  id: string;
  name: string;
  mimeType: "image/png" | "image/jpeg" | "image/webp";
  size: number;
  url: string;
}
export interface RunProgressEvent {
  seq: number;
  agentId: string;
  runId: string;
  itemId: string;
  kind: "queued" | "starting" | "thinking" | "commentary" | "tool" | "completed" | "error" | "stopped";
  status: "pending" | "running" | "completed" | "failed" | "stopped";
  title: string;
  detail?: string;
  at: number;
  conversationId?: string | null;
}
export interface ReleaseManifest {
  id: string;
  runtimeAbi: 1;
  schemaVersion: number;
  kind: "frontend" | "hot-modules" | "combined" | "restart-required";
  files: Record<string, string>;
  hotModules: Array<"agent-summary" | "role-prompts">;
}
