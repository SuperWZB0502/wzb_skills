# 开发岗项目目录规范

## 目录结构

```
work/<两位编号>-<项目名>/                 # 编号在同一父目录内独立；中文可，禁空格与"/"，名称<15字
  README.md                              # 结构 + 内容 + 当前状态
  code/                                  # 代码；本项目唯一 git 仓库
    README.md  docs/                     # docs 放拼接后的《特性文档.md》
  test/                                  # 实验中间产物，不进 git
    README.md
    <两位编号>-<主特性>/README.md、实验进展.md
      <两位编号>-<实验名>/README.md        # 本次实验全部输出只放这里
  feature/
    README.md                            # 主特性清单；主特性完成后更新
    <两位编号>-<主特性>/README.md、设计文档.md、实现文档.md、测试文档.md、开发进展.md
      <两位编号>-<子特性>/README.md、设计文档.md、实现文档.md、测试文档.md
```

## 硬规则

- 特性最多两级：主特性 + 子特性；子特性是叶子，不再下分；**每一级目录都要有 README.md**。
- 子特性 README：①≤200 字简介 ②特性开关 ③文件汇总表（序号 | 文件名 | 功能介绍）。
- 主特性 README：①≤500 字简介 ②特性开关 ③各子特性简介（直接复制子特性的 200 字）。
- 主特性有子特性时，其三份文档只写整体方案、实现机制、各子特性最新测试结果，并链接到子特性文档。
- `开发进展.md`：总表 `序号|特性名称|简要描述|收益|状态`，状态只能是待开发/待验证/已采纳/已否决；每完成一个子特性更新一次，主特性完成后更新 `feature/README.md`。
- `test/` 只放实验中间产物；交付物（PPT/HTML/图片/报告）放对应特性目录；每个特性、每次实验都要有记录，禁止散落。

## 开关与提交

- 特性开关统一用环境变量（如 `OFFICE_FEATURE_<主特性>_<子特性>`），默认关闭；README 写清名称、默认值、生效方式。
- 以主特性为最小粒度提交：定稿代码 + 设计/实现/测试拼接的《特性文档.md》（复制到 `code/docs/`）；提交前更新状态、跑结构检查、询问用户是否更改开关形式。
- commit message：`feat(<项目编号-项目名>): <主特性编号-名称>`。

## 阶段产出（skill 包）

可分发的 web-office skill 由项目 `code/` 仓库维护（`code/` 根即 skill 内容）。阶段产出按：`node code/scripts/pack-source.mjs --root <工作根> --skill <code>` → 在 code 仓库提交 `chore(skill): sync source @<工作根短哈希>` → `node code/scripts/package.mjs --target <工作根> --skill <code>` 出 ZIP，再跑 `verify.mjs` 与隐私扫描。详见 skill 的 `references/workflows.md`。

## 工具

```bash
node app/scripts/work-layout.mjs new-project --name "01-项目名"
node app/scripts/work-layout.mjs new-feature --project 01-项目名 --name "01-主特性"
node app/scripts/work-layout.mjs new-subfeature --project 01-项目名 --feature 01-主特性 --name "01-子特性"
node app/scripts/work-layout.mjs new-experiment --project 01-项目名 --feature 01-主特性 --name "01-实验"
node app/scripts/work-layout.mjs finalize-feature --project 01-项目名 --feature 01-主特性
node app/scripts/work-layout.mjs check
```
