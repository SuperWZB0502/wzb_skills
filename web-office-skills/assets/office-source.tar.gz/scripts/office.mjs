#!/usr/bin/env node
import path from "node:path";
import net from "node:net";
import { spawn } from "node:child_process";
import { open, mkdir, readFile, realpath, rm, lstat } from "node:fs/promises";
import { pathToFileURL } from "node:url";
const fail = (message) => {
  throw Error(message);
};
export function parseArgs(argv) {
  const [action, ...rest] = argv,
    options = {};
  for (let i = 0; i < rest.length; i += 2) {
    if (
      !/^--[a-z-]+$/.test(rest[i]) ||
      rest[i + 1] === undefined ||
      rest[i + 1].startsWith("--")
    )
      fail("Expected named options with values");
    const key = rest[i].slice(2);
    if (
      ![
        "root",
        "port",
        "mode",
        "bundle",
        "release",
        "older-than-days",
        "keep",
        "reason",
        "mode",
      ].includes(key) ||
      key in options
    )
      fail("Unknown or duplicate option");
    options[key] = rest[i + 1];
  }
  if (
    ![
      "start",
      "status",
      "pair",
      "stop",
      "update",
      "rollback",
      "logs-prune",
      "backup",
      "migrate-layout",
    ].includes(action)
  )
    fail("Use start|status|pair|stop|update|rollback|logs-prune");
  if (!options.root)
    fail("--root must identify the previously selected workspace");
  return { action, options };
}
async function configRoot(input) {
  const root = await realpath(path.resolve(input)),
    config = JSON.parse(
      await readFile(path.join(root, "workspace.json"), "utf8"),
    );
  if (config.workspaceRoot !== root) fail("workspace_root_mismatch");
  for (const name of ["state", "logs", "app", "scripts"]) {
    const target = path.join(root, name);
    if ((await realpath(target)) !== target)
      fail("workspace_symlink_not_allowed");
  }
  return { root, config };
}
export function control(action, args = {}, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ path: "state/run/control.sock" });
    let received = "",
      settled = false;
    const done = (error, result) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      error ? reject(error) : resolve(result);
    };
    socket.setTimeout(timeoutMs, () => done(Error("control_timeout")));
    socket.on("error", () => done(Error("runtime_unreachable")));
    socket.on("end", () => {
      if (!settled) done(Error("invalid_control_response"));
    });
    socket.on("connect", () =>
      socket.write(JSON.stringify({ action, args }) + "\n"),
    );
    socket.on("data", (data) => {
      received += data.toString();
      if (received.length > 1024 * 1024)
        return done(Error("invalid_control_response"));
      const end = received.indexOf("\n");
      if (end < 0) return;
      try {
        const message = JSON.parse(received.slice(0, end));
        if (message.ok !== true)
          return done(Error(message.error || "control_failed"));
        done(null, message.result);
      } catch {
        done(Error("invalid_control_response"));
      }
    });
  });
}
async function metadata(root) {
  try {
    return JSON.parse(
      await readFile(path.join(root, "state/runtime.json"), "utf8"),
    );
  } catch {
    fail("runtime_metadata_missing");
  }
}
async function identified(root) {
  const expected = await metadata(root),
    status = await control("status");
  if (
    !expected.bootId ||
    status.bootId !== expected.bootId ||
    status.pid !== expected.pid ||
    status.workspaceRoot !== root
  )
    fail("runtime_identity_mismatch");
  return status;
}
function alive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
export async function run(argv) {
  const { action, options } = parseArgs(argv),
    suppliedBundle = options.bundle ? path.resolve(options.bundle) : undefined,
    { root, config } = await configRoot(options.root);
  process.chdir(root);
  if (action === "migrate-layout") {
    const { execFileSync } = await import("node:child_process");
    const mode = options.mode ?? "apply";
    if (!["plan", "apply", "rollback"].includes(mode)) fail("invalid_migration_mode");
    return JSON.parse(
      execFileSync(process.execPath, [path.join(root, "app/scripts/office-migrate-layout.mjs"), "--root", root, "--mode", mode], {
        encoding: "utf8",
        timeout: 300000,
      }),
    );
  }
  if (action === "backup") {
    const { createOfficeBackup } = await import(
      pathToFileURL(path.join(root, "app/scripts/office-backup.mjs")).href
    );
    const keep = Number(options.keep ?? 7);
    if (!Number.isInteger(keep) || keep < 1 || keep > 365)
      fail("invalid_backup_retention");
    return createOfficeBackup({
      root,
      keep,
      reason: options.reason ?? "manual",
    });
  }
  if (action === "start") {
    try {
      return await identified(root);
    } catch (error) {
      let stale;
      try {
        stale = await metadata(root);
      } catch {}
      if (stale && alive(stale.pid))
        fail(
          "runtime_identity_unverified; inspect the existing process before starting",
        );
    }
    const lockPath = path.join(root, "state/start.lock");
    let lock;
    try {
      lock = await open(lockPath, "wx", 0o600);
    } catch {
      fail(
        "start_already_in_progress; inspect state/start.lock if an earlier installer was interrupted",
      );
    }
    try {
      await mkdir(path.join(root, "state/run"), {
        recursive: true,
        mode: 0o700,
      });
      if ((await lstat(path.join(root, "state/run"))).isSymbolicLink())
        fail("workspace_symlink_not_allowed");
      const port = Number(options.port ?? config.port ?? 18080),
        mode = options.mode ?? config.defaultView ?? config.mode;
      if (
        !Number.isInteger(port) ||
        port < 1 ||
        port > 65535 ||
        !["chat", "office"].includes(mode)
      )
        fail("invalid_start_options");
      const logPath = path.join(root, "logs/runtime.log");
      try {
        if ((await lstat(logPath)).isSymbolicLink())
          fail("workspace_symlink_not_allowed");
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      const log = await open(logPath, "a", 0o600);
      const env = {
        ...process.env,
        TMPDIR: path.join(root, "tmp"),
        TMP: path.join(root, "tmp"),
        TEMP: path.join(root, "tmp"),
        XDG_CACHE_HOME: path.join(root, "cache"),
        NODE_COMPILE_CACHE: path.join(root, "cache/node"),
      };
      for (const key of Object.keys(env))
        if (/(?:API[_-]?KEY|TOKEN|SECRET|PASSWORD|AUTHORIZATION)/i.test(key))
          delete env[key];
      const child = spawn(
        process.execPath,
        [
          "--import",
          pathToFileURL(path.join(root, "app/node_modules/tsx/dist/loader.mjs")).href,
          path.join(root, "app/server/office/main.ts"),
          "--root",
          root,
          "--port",
          String(port),
          "--mode",
          mode,
        ],
        { cwd: root, env, detached: true, stdio: ["ignore", log.fd, log.fd] },
      );
      let spawnError;
      child.once("error", () => {
        spawnError = true;
      });
      child.unref();
      await log.close();
      const deadline = Date.now() + 20000;
      while (Date.now() < deadline) {
        if (spawnError) fail("runtime_start_failed");
        try {
          const status = await identified(root);
          return status;
        } catch {}
        await new Promise((resolve) => setTimeout(resolve, 150));
      }
      fail("runtime_readiness_timeout; inspect logs/runtime.log");
    } finally {
      await lock.close();
      await rm(lockPath, { force: true });
    }
  }
  const status = await identified(root);
  if (action === "status") return status;
  const args = { bootId: status.bootId };
  if (action === "update") {
    if (!options.bundle) fail("--bundle is required");
    args.bundle = suppliedBundle;
  }
  if (action === "rollback") {
    if (!options.release) fail("--release is required");
    args.release = options.release;
  }
  if (action === "logs-prune") {
    const days = Number(options["older-than-days"] ?? 14);
    if (!Number.isFinite(days) || days < 0) fail("invalid_retention_days");
    args.olderThanDays = days;
  }
  // A release update copies and re-hashes the whole frontend on NFS; 30s was
  // shorter than a real activation, so the CLI reported failure after success.
  try {
    return await control(action, args, action === "update" ? 180000 : 10000);
  } catch (error) {
    if (action !== "update" || error.message !== "invalid_control_response")
      throw error;
    // The runtime may drop the control socket before answering while the release is
    // already active. Only report success if the active version really changed.
    const deadline = Date.now() + 60000;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      let current;
      try {
        current = await identified(root);
      } catch {
        continue;
      }
      if (current.version !== status.version)
        return { ...current, responseLost: true };
    }
    throw error;
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  run(process.argv.slice(2)).then(
    (result) => {
      process.stdout.write(JSON.stringify(result, null, 2) + "\n");
    },
    (error) => {
      process.stderr.write(`${error.message}\n`);
      process.exitCode = 1;
    },
  );
}
